package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class FightingFishRewardsActivity extends AppCompatActivity {
    private static final String GAME_BASE = "https://fishio.mascom.vn";
    private static final String ORIGIN = "https://fishio.mascom.vn";
    private static final String TAG = "FFRewards";
    private static final String USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148";
    private LinearLayout llContent;
    private View pbLoading;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tabAchievement;
    private TextView tabDaily;
    private TextView tabWeekly;
    private TextView tvEmpty;
    private String gameToken = "";
    private int currentTab = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newFixedThreadPool(2);
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        setContentView(R.layout.activity_fighting_fish_rewards);
        String stringExtra = getIntent().getStringExtra("gameToken");
        this.gameToken = stringExtra;
        if (stringExtra == null) {
            this.gameToken = "";
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m407lambda$onCreate$0$comzenoappFightingFishRewardsActivity(view);
            }
        });
        this.tabAchievement = (TextView) findViewById(R.id.tabAchievement);
        this.tabDaily = (TextView) findViewById(R.id.tabDaily);
        this.tabWeekly = (TextView) findViewById(R.id.tabWeekly);
        this.llContent = (LinearLayout) findViewById(R.id.llContent);
        this.pbLoading = findViewById(R.id.pbLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda16
            public final void onRefresh() {
                this.f$0.reloadCurrentTab();
            }
        });
        this.tabAchievement.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m408lambda$onCreate$1$comzenoappFightingFishRewardsActivity(view);
            }
        });
        this.tabDaily.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m409lambda$onCreate$2$comzenoappFightingFishRewardsActivity(view);
            }
        });
        this.tabWeekly.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m410lambda$onCreate$3$comzenoappFightingFishRewardsActivity(view);
            }
        });
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m407lambda$onCreate$0$comzenoappFightingFishRewardsActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m408lambda$onCreate$1$comzenoappFightingFishRewardsActivity(View view) {
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m409lambda$onCreate$2$comzenoappFightingFishRewardsActivity(View view) {
        selectTab(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m410lambda$onCreate$3$comzenoappFightingFishRewardsActivity(View view) {
        selectTab(2);
    }

    private void selectTab(int i) {
        this.currentTab = i;
        styleTab(this.tabAchievement, i == 0);
        styleTab(this.tabDaily, i == 1);
        styleTab(this.tabWeekly, i == 2);
        reloadCurrentTab();
    }

    private void styleTab(TextView textView, boolean z) {
        if (textView == null) {
            return;
        }
        if (z) {
            textView.setBackgroundResource(R.drawable.bg_game_count_selected);
            textView.setTextColor(-3632086);
            textView.setTypeface(null, 1);
        } else {
            textView.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView.setTextColor(-6381922);
            textView.setTypeface(null, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reloadCurrentTab() {
        this.llContent.removeAllViews();
        this.tvEmpty.setVisibility(8);
        setLoading(true);
        int i = this.currentTab;
        if (i == 0) {
            loadAchievements();
        } else if (i == 1) {
            loadTasks("DAILY");
        } else {
            if (i != 2) {
                return;
            }
            loadTasks("WEEKLY");
        }
    }

    private void setLoading(boolean z) {
        if (z) {
            View view = this.pbLoading;
            if (view != null) {
                view.setVisibility(0);
            }
            LinearLayout linearLayout = this.llContent;
            if (linearLayout != null) {
                linearLayout.setVisibility(8);
            }
            ValueAnimator valueAnimator = this.skeletonAnim;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            View view2 = this.pbLoading;
            if (view2 != null) {
                this.skeletonAnim = SkeletonPulse.start(view2);
                return;
            }
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.pbLoading);
        this.skeletonAnim = null;
        View view3 = this.pbLoading;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.llContent;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(0);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    private Request.Builder authGet(String str) {
        return new Request.Builder().url("https://fishio.mascom.vn" + str).header("Authorization", "Bearer " + this.gameToken).header("Accept", "*/*").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://fishio.mascom.vn").header("Referer", "https://fishio.mascom.vn/").header("Accept-Language", "en").get();
    }

    private void loadAchievements() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m403lambda$loadAchievements$6$comzenoappFightingFishRewardsActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadAchievements$6$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m403lambda$loadAchievements$6$comzenoappFightingFishRewardsActivity() {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/achievement/list").build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                final JSONArray jSONArraySortAchievements = sortAchievements(jSONArrayOptJSONArray);
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda5
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m401lambda$loadAchievements$4$comzenoappFightingFishRewardsActivity(jSONArraySortAchievements);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadAchievements", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m402lambda$loadAchievements$5$comzenoappFightingFishRewardsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAchievements$4$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m401lambda$loadAchievements$4$comzenoappFightingFishRewardsActivity(JSONArray jSONArray) {
        setLoading(false);
        if (jSONArray.length() == 0) {
            this.tvEmpty.setVisibility(0);
        } else {
            renderAchievements(jSONArray);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadAchievements$5$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m402lambda$loadAchievements$5$comzenoappFightingFishRewardsActivity(Exception exc) {
        setLoading(false);
        Toast.makeText((Context) this, (CharSequence) ("Load failed: " + exc.getMessage()), 0).show();
    }

    private JSONArray sortAchievements(JSONArray jSONArray) throws Exception {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getJSONObject(i));
        }
        arrayList.sort(new Comparator() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda2
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return this.f$0.m412lambda$sortAchievements$7$comzenoappFightingFishRewardsActivity((JSONObject) obj, (JSONObject) obj2);
            }
        });
        JSONArray jSONArray2 = new JSONArray();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            jSONArray2.put((JSONObject) it.next());
        }
        return jSONArray2;
    }

    /* JADX INFO: renamed from: lambda$sortAchievements$7$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ int m412lambda$sortAchievements$7$comzenoappFightingFishRewardsActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        return Integer.compare(scoreAch(jSONObject), scoreAch(jSONObject2));
    }

    private int scoreAch(JSONObject jSONObject) {
        boolean zOptBoolean = jSONObject.optBoolean("isClaimed", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("isCompleted", false);
        if (!zOptBoolean2 || zOptBoolean) {
            return !zOptBoolean2 ? 1 : 2;
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderAchievements(JSONArray jSONArray) {
        LayoutInflater layoutInflater;
        int i;
        int i2;
        JSONObject jSONObject;
        View viewInflate;
        ImageView imageView;
        TextView textView;
        TextView textView2;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        final TextView textView3;
        final int iOptInt;
        String strOptString;
        int iOptInt2;
        int iOptInt3;
        boolean zOptBoolean;
        boolean zOptBoolean2;
        final String strOptString2;
        final int iOptInt4;
        int i3;
        this.llContent.removeAllViews();
        LayoutInflater layoutInflater2 = getLayoutInflater();
        boolean z = false;
        int i4 = 0;
        while (i4 < jSONArray.length()) {
            try {
                jSONObject = jSONArray.getJSONObject(i4);
                viewInflate = layoutInflater2.inflate(R.layout.item_reward_task, this.llContent, z);
                imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
                textView = (TextView) viewInflate.findViewById(R.id.tvTaskName);
                textView2 = (TextView) viewInflate.findViewById(R.id.tvTaskProgress);
                progressBar = (ProgressBar) viewInflate.findViewById(R.id.progressBar);
                linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llTaskRewards);
                textView3 = (TextView) viewInflate.findViewById(R.id.btnClaim);
                iOptInt = jSONObject.optInt("id");
                strOptString = jSONObject.optString("name", "—");
                iOptInt2 = jSONObject.optInt("target", 1);
                layoutInflater = layoutInflater2;
            } catch (Exception e) {
                e = e;
                layoutInflater = layoutInflater2;
            }
            try {
                iOptInt3 = jSONObject.optInt("progress", 0);
                zOptBoolean = jSONObject.optBoolean("isClaimed", false);
                i = i4;
            } catch (Exception e2) {
                e = e2;
                i = i4;
                StringBuilder sb = new StringBuilder("render ach ");
                i2 = i;
                sb.append(i2);
                Log.e(TAG, sb.toString(), e);
                i4 = i2 + 1;
                layoutInflater2 = layoutInflater;
                z = false;
            }
            try {
                zOptBoolean2 = jSONObject.optBoolean("isCompleted", false);
                strOptString2 = jSONObject.optString("currentReward", "GEM");
                iOptInt4 = jSONObject.optInt("value", 0);
                textView.setText(strOptString);
                textView2.setText(iOptInt3 + " / " + iOptInt2);
                i3 = 100;
                int iMin = iOptInt2 > 0 ? Math.min(100, (int) ((iOptInt3 * 100.0f) / iOptInt2)) : 0;
                if (!zOptBoolean2) {
                    i3 = iMin;
                }
                progressBar.setProgress(i3);
                imageView.setImageResource(iconForType(strOptString2));
                linearLayout.removeAllViews();
                TextView textView4 = new TextView(this);
                textView4.setText(String.format(Locale.US, "+%d %s", Integer.valueOf(iOptInt4), strOptString2));
                textView4.setTextColor(-3632086);
                textView4.setTextSize(12.0f);
                textView4.setPadding(8, 2, 8, 2);
                linearLayout.addView(textView4);
            } catch (Exception e3) {
                e = e3;
                StringBuilder sb2 = new StringBuilder("render ach ");
                i2 = i;
                sb2.append(i2);
                Log.e(TAG, sb2.toString(), e);
                i4 = i2 + 1;
                layoutInflater2 = layoutInflater;
                z = false;
            }
            if (zOptBoolean) {
                textView3.setText("Claimed");
                textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView3.setTextColor(-7829368);
                textView3.setEnabled(false);
            } else if (zOptBoolean2) {
                textView3.setText("Claim");
                textView3.setBackgroundResource(R.drawable.bg_btn_gold);
                textView3.setTextColor(-16777216);
                textView3.setEnabled(true);
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda7
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m411lambda$renderAchievements$8$comzenoappFightingFishRewardsActivity(iOptInt, textView3, strOptString2, iOptInt4, view);
                    }
                });
            } else {
                textView3.setText(i3 + "%");
                textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView3.setTextColor(-5592406);
                try {
                    textView3.setEnabled(false);
                    this.llContent.addView(viewInflate);
                    i2 = i;
                } catch (Exception e4) {
                    e = e4;
                    StringBuilder sb22 = new StringBuilder("render ach ");
                    i2 = i;
                    sb22.append(i2);
                    Log.e(TAG, sb22.toString(), e);
                }
                i4 = i2 + 1;
                layoutInflater2 = layoutInflater;
                z = false;
            }
            this.llContent.addView(viewInflate);
            i2 = i;
            i4 = i2 + 1;
            layoutInflater2 = layoutInflater;
            z = false;
        }
    }

    /* JADX INFO: renamed from: lambda$renderAchievements$8$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m411lambda$renderAchievements$8$comzenoappFightingFishRewardsActivity(int i, TextView textView, String str, int i2, View view) {
        claimAchievement(i, textView, str, i2);
    }

    private void claimAchievement(final int i, final TextView textView, final String str, final int i2) {
        textView.setEnabled(false);
        textView.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m396lambda$claimAchievement$11$comzenoappFightingFishRewardsActivity(i, i2, str, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimAchievement$11$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m396lambda$claimAchievement$11$comzenoappFightingFishRewardsActivity(int i, final int i2, final String str, final TextView textView) {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/achievement/claim/" + i).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final JSONObject jSONObject = new JSONObject(strString);
                final boolean z = jSONObject.optBoolean("success", false) || "00000".equals(jSONObject.optString("error"));
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m397lambda$claimAchievement$9$comzenoappFightingFishRewardsActivity(z, i2, str, textView, jSONObject);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m395lambda$claimAchievement$10$comzenoappFightingFishRewardsActivity(textView, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimAchievement$9$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m397lambda$claimAchievement$9$comzenoappFightingFishRewardsActivity(boolean z, int i, String str, TextView textView, JSONObject jSONObject) {
        if (!z) {
            textView.setEnabled(true);
            textView.setText("Claim");
            Toast.makeText((Context) this, (CharSequence) ("Claim failed: " + jSONObject.optString("message", jSONObject.optString("error"))), 0).show();
            return;
        }
        Toast.makeText((Context) this, (CharSequence) ("Claimed +" + i + " " + str), 0).show();
        reloadCurrentTab();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimAchievement$10$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m395lambda$claimAchievement$10$comzenoappFightingFishRewardsActivity(TextView textView, Exception exc) {
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void loadTasks(final String str) {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m406lambda$loadTasks$14$comzenoappFightingFishRewardsActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadTasks$14$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m406lambda$loadTasks$14$comzenoappFightingFishRewardsActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/task/list?type=" + str).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObjectOptJSONObject = new JSONObject(strString).optJSONObject("data");
                if (jSONObjectOptJSONObject == null) {
                    jSONObjectOptJSONObject = new JSONObject();
                }
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("tasks");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                final JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("milestone");
                final JSONArray jSONArraySortTasks = sortTasks(jSONArrayOptJSONArray);
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda13
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m404lambda$loadTasks$12$comzenoappFightingFishRewardsActivity(jSONArraySortTasks, jSONObjectOptJSONObject2);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadTasks " + str, e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m405lambda$loadTasks$13$comzenoappFightingFishRewardsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadTasks$12$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m404lambda$loadTasks$12$comzenoappFightingFishRewardsActivity(JSONArray jSONArray, JSONObject jSONObject) {
        setLoading(false);
        if (jSONArray.length() == 0 && (jSONObject == null || jSONObject.optJSONArray("tasks") == null || jSONObject.optJSONArray("tasks").length() == 0)) {
            this.tvEmpty.setVisibility(0);
        } else {
            renderTasks(jSONArray, jSONObject);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadTasks$13$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m405lambda$loadTasks$13$comzenoappFightingFishRewardsActivity(Exception exc) {
        setLoading(false);
        Toast.makeText((Context) this, (CharSequence) ("Load failed: " + exc.getMessage()), 0).show();
    }

    private JSONArray sortTasks(JSONArray jSONArray) throws Exception {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getJSONObject(i));
        }
        arrayList.sort(new Comparator() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda20
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return this.f$0.m413lambda$sortTasks$15$comzenoappFightingFishRewardsActivity((JSONObject) obj, (JSONObject) obj2);
            }
        });
        JSONArray jSONArray2 = new JSONArray();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            jSONArray2.put((JSONObject) it.next());
        }
        return jSONArray2;
    }

    /* JADX INFO: renamed from: lambda$sortTasks$15$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ int m413lambda$sortTasks$15$comzenoappFightingFishRewardsActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        return Integer.compare(scoreTask(jSONObject), scoreTask(jSONObject2));
    }

    private int scoreTask(JSONObject jSONObject) {
        boolean zOptBoolean = jSONObject.optBoolean("userClaimed", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("userCompleted", false);
        if (!zOptBoolean2 || zOptBoolean) {
            return !zOptBoolean2 ? 1 : 2;
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderTasks(JSONArray jSONArray, JSONObject jSONObject) {
        this.llContent.removeAllViews();
        LayoutInflater layoutInflater = getLayoutInflater();
        if (jSONObject != null) {
            int iOptInt = jSONObject.optInt("target", 0);
            int iOptInt2 = jSONObject.optInt("progress", 0);
            TextView textView = new TextView(this);
            textView.setText(String.format(Locale.US, "Milestone  %d / %d pts", Integer.valueOf(iOptInt2), Integer.valueOf(iOptInt)));
            textView.setTextColor(-3632086);
            textView.setTextSize(14.0f);
            textView.setTypeface(null, 1);
            textView.setPadding(4, 4, 4, 10);
            this.llContent.addView(textView);
            ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, (int) (getResources().getDisplayMetrics().density * 8.0f));
            layoutParams.bottomMargin = (int) (getResources().getDisplayMetrics().density * 12.0f);
            progressBar.setLayoutParams(layoutParams);
            progressBar.setMax(100);
            progressBar.setProgress(iOptInt > 0 ? Math.min(100, (int) ((iOptInt2 * 100.0f) / iOptInt)) : 0);
            try {
                progressBar.setProgressDrawable(getResources().getDrawable(R.drawable.bg_progress_reward, getTheme()));
            } catch (Exception unused) {
            }
            this.llContent.addView(progressBar);
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("tasks");
            if (jSONArrayOptJSONArray != null) {
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    try {
                        addTaskRow(layoutInflater, jSONArrayOptJSONArray.getJSONObject(i), true);
                    } catch (Exception e) {
                        Log.e(TAG, "render ms task " + i, e);
                    }
                }
            }
            TextView textView2 = new TextView(this);
            textView2.setText("Tasks");
            textView2.setTextColor(-1);
            textView2.setTextSize(14.0f);
            textView2.setTypeface(null, 1);
            textView2.setPadding(4, 16, 4, 10);
            this.llContent.addView(textView2);
        }
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            try {
                addTaskRow(layoutInflater, jSONArray.getJSONObject(i2), false);
            } catch (Exception e2) {
                Log.e(TAG, "render task " + i2, e2);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addTaskRow(LayoutInflater layoutInflater, JSONObject jSONObject, boolean z) {
        String str;
        JSONArray jSONArray;
        String str2;
        View viewInflate = layoutInflater.inflate(R.layout.item_reward_task, (ViewGroup) this.llContent, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvTaskName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvTaskProgress);
        ProgressBar progressBar = (ProgressBar) viewInflate.findViewById(R.id.progressBar);
        LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llTaskRewards);
        final TextView textView3 = (TextView) viewInflate.findViewById(R.id.btnClaim);
        final int iOptInt = jSONObject.optInt("id");
        String strOptString = jSONObject.optString("name", "—");
        int iOptInt2 = jSONObject.optInt("progressTarget", 1);
        int iOptInt3 = jSONObject.optInt("userProgress", 0);
        boolean zOptBoolean = jSONObject.optBoolean("userClaimed", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("userCompleted", false);
        int iOptInt4 = jSONObject.optInt("point", 0);
        if (z && iOptInt2 <= 0) {
            iOptInt2 = iOptInt4;
        }
        textView.setText(strOptString);
        if (z) {
            textView2.setText(iOptInt4 + " pts required");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(iOptInt3);
            sb.append(" / ");
            sb.append(Math.max(iOptInt2, 1));
            if (iOptInt4 > 0) {
                str = "  ·  +" + iOptInt4 + " pts";
            } else {
                str = "";
            }
            sb.append(str);
            textView2.setText(sb.toString());
        }
        int i = 100;
        if (!z) {
            int iMin = iOptInt2 > 0 ? Math.min(100, (int) ((iOptInt3 * 100.0f) / iOptInt2)) : 0;
            if (!zOptBoolean2) {
                i = iMin;
            }
        } else if (!zOptBoolean2) {
            i = 0;
        }
        progressBar.setProgress(i);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("items");
        String str3 = "typeItem";
        imageView.setImageResource(iconForType((jSONArrayOptJSONArray == null || jSONArrayOptJSONArray.length() <= 0) ? "COIN" : jSONArrayOptJSONArray.optJSONObject(0).optString("typeItem", "COIN")));
        linearLayout.removeAllViews();
        if (jSONArrayOptJSONArray != null) {
            int i2 = 0;
            while (i2 < jSONArrayOptJSONArray.length()) {
                JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i2);
                if (jSONObjectOptJSONObject == null) {
                    jSONArray = jSONArrayOptJSONArray;
                    str2 = str3;
                } else {
                    String strOptString2 = jSONObjectOptJSONObject.optString(str3, "COIN");
                    int iOptInt5 = jSONObjectOptJSONObject.optInt("value", 0);
                    TextView textView4 = new TextView(this);
                    jSONArray = jSONArrayOptJSONArray;
                    str2 = str3;
                    textView4.setText(String.format(Locale.US, "+%d %s", Integer.valueOf(iOptInt5), strOptString2));
                    textView4.setTextColor(-3632086);
                    textView4.setTextSize(12.0f);
                    textView4.setPadding(8, 2, 8, 2);
                    linearLayout.addView(textView4);
                }
                i2++;
                jSONArrayOptJSONArray = jSONArray;
                str3 = str2;
            }
        }
        if (zOptBoolean) {
            textView3.setText("Claimed");
            textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView3.setTextColor(-7829368);
            textView3.setEnabled(false);
        } else if (zOptBoolean2) {
            textView3.setText("Claim");
            textView3.setBackgroundResource(R.drawable.bg_btn_gold);
            textView3.setTextColor(-16777216);
            textView3.setEnabled(true);
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m394lambda$addTaskRow$16$comzenoappFightingFishRewardsActivity(iOptInt, textView3, view);
                }
            });
        } else {
            textView3.setText(i + "%");
            textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView3.setTextColor(-5592406);
            textView3.setEnabled(false);
        }
        this.llContent.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addTaskRow$16$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m394lambda$addTaskRow$16$comzenoappFightingFishRewardsActivity(int i, TextView textView, View view) {
        claimTask(i, textView);
    }

    private void claimTask(final int i, final TextView textView) {
        textView.setEnabled(false);
        textView.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m400lambda$claimTask$19$comzenoappFightingFishRewardsActivity(i, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimTask$19$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m400lambda$claimTask$19$comzenoappFightingFishRewardsActivity(int i, final TextView textView) {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/task/award/" + i).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final JSONObject jSONObject = new JSONObject(strString);
                final boolean z = jSONObject.optBoolean("success", false) || "00000".equals(jSONObject.optString("error"));
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
                StringBuilder sb = new StringBuilder("Claimed");
                if (jSONArrayOptJSONArray != null) {
                    for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                        JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i2);
                        if (jSONObjectOptJSONObject != null) {
                            sb.append(" +");
                            sb.append(jSONObjectOptJSONObject.optInt("value", 0));
                            sb.append(" ");
                            sb.append(jSONObjectOptJSONObject.optString("typeItem", ""));
                        }
                    }
                }
                final String string = sb.toString();
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m398lambda$claimTask$17$comzenoappFightingFishRewardsActivity(z, string, textView, jSONObject);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishRewardsActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m399lambda$claimTask$18$comzenoappFightingFishRewardsActivity(textView, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimTask$17$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m398lambda$claimTask$17$comzenoappFightingFishRewardsActivity(boolean z, String str, TextView textView, JSONObject jSONObject) {
        if (z) {
            Toast.makeText((Context) this, (CharSequence) str, 0).show();
            reloadCurrentTab();
            return;
        }
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Claim failed: " + jSONObject.optString("message", jSONObject.optString("error"))), 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimTask$18$com-zeno-app-FightingFishRewardsActivity, reason: not valid java name */
    /* synthetic */ void m399lambda$claimTask$18$comzenoappFightingFishRewardsActivity(TextView textView, Exception exc) {
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x003e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private int iconForType(java.lang.String r4) {
        /*
            r3 = this;
            if (r4 != 0) goto L5
            int r4 = com.zeno.app.R.drawable.ic_coin_ff
            return r4
        L5:
            java.util.Locale r0 = java.util.Locale.US
            java.lang.String r4 = r4.toUpperCase(r0)
            int r0 = r4.hashCode()
            r1 = -1820631284(0xffffffff937b5f0c, float:-3.1727516E-27)
            r2 = 1
            if (r0 == r1) goto L34
            r1 = 70447(0x1132f, float:9.8717E-41)
            if (r0 == r1) goto L2a
            r1 = 2074257(0x1fa691, float:2.906653E-39)
            if (r0 == r1) goto L20
            goto L3e
        L20:
            java.lang.String r0 = "COIN"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L3e
            r4 = 2
            goto L3f
        L2a:
            java.lang.String r0 = "GEM"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L3e
            r4 = 0
            goto L3f
        L34:
            java.lang.String r0 = "TICKET"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L3e
            r4 = 1
            goto L3f
        L3e:
            r4 = -1
        L3f:
            if (r4 == 0) goto L49
            if (r4 == r2) goto L46
            int r4 = com.zeno.app.R.drawable.ic_coin_ff
            return r4
        L46:
            int r4 = com.zeno.app.R.drawable.ic_ticket_ff
            return r4
        L49:
            int r4 = com.zeno.app.R.drawable.ic_gem_ff
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.FightingFishRewardsActivity.iconForType(java.lang.String):int");
    }

    protected void onDestroy() {
        this.exec.shutdownNow();
        super.onDestroy();
    }
}
