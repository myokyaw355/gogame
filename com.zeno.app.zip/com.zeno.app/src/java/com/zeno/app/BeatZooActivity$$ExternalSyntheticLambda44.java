package com.zeno.app;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public final /* synthetic */ class BeatZooActivity$$ExternalSyntheticLambda44 implements Runnable {
    public final /* synthetic */ BeatZooActivity f$0;

    public /* synthetic */ BeatZooActivity$$ExternalSyntheticLambda44(BeatZooActivity beatZooActivity) {
        this.f$0 = beatZooActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.renderSongs();
    }
}
