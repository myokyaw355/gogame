package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.widget.NestedScrollView;
import com.bumptech.glide.Glide;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CarRacingGemShopActivity extends AppCompatActivity {
    private static final String GAME_BASE = "https://car-racing.mascom.vn";
    private static final String ORIGIN = "https://car-racing.mascom.vn";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12; Redmi K30 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36";
    private static final String X_REQ = "com.myentertainment.oneid";
    private String gameToken;
    private LinearLayout llItems;
    private LinearLayout llLoading;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svItems;
    private TextView tvEmpty;
    private TextView tvGemBalance;
    private long gems = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newFixedThreadPool(2);
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        setContentView(R.layout.activity_car_racing_gem_shop);
        this.gameToken = getIntent().getStringExtra("gameToken");
        this.gems = getIntent().getLongExtra("gems", 0L);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m190lambda$onCreate$0$comzenoappCarRacingGemShopActivity(view);
            }
        });
        this.tvGemBalance = (TextView) findViewById(R.id.tvGemBalance);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svItems = findViewById(R.id.svItems);
        this.llItems = (LinearLayout) findViewById(R.id.llItems);
        TextView textView = this.tvGemBalance;
        if (textView != null) {
            textView.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(this.gems)));
        }
        String str = this.gameToken;
        if (str == null || str.isEmpty()) {
            showEmpty("Login မပြီးသေးပါ");
        } else {
            loadItems();
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m190lambda$onCreate$0$comzenoappCarRacingGemShopActivity(View view) {
        finish();
    }

    private void loadItems() {
        showLoading();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m189lambda$loadItems$2$comzenoappCarRacingGemShopActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadItems$2$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m189lambda$loadItems$2$comzenoappCarRacingGemShopActivity() {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/shop/GEM").header("Authorization", "Bearer " + this.gameToken).header("Accept", "*/*").header("Content-Type", "application/json").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ).get().build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda9
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m188lambda$loadItems$1$comzenoappCarRacingGemShopActivity(strString);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code());
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseItems, reason: merged with bridge method [inline-methods] */
    public void m188lambda$loadItems$1$comzenoappCarRacingGemShopActivity(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Item list ယူ၍ မရပါ။"));
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
                this.skeletonAnim = null;
                LinearLayout linearLayout = this.llLoading;
                if (linearLayout != null) {
                    linearLayout.setVisibility(8);
                }
                this.tvEmpty.setVisibility(8);
                this.llItems.removeAllViews();
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject != null && "ACTIVE".equalsIgnoreCase(jSONObjectOptJSONObject.optString("status", "ACTIVE"))) {
                        addItemRow(jSONObjectOptJSONObject);
                    }
                }
                this.svItems.setVisibility(0);
                return;
            }
            showEmpty("Item မရှိသေးပါ။");
        } catch (Exception e) {
            showEmpty("Parse error: " + e.getMessage());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addItemRow(JSONObject jSONObject) {
        int i;
        String str;
        String strOptString;
        View view;
        Button button;
        TextView textView;
        final String str2;
        String str3;
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_car_racing_gem_shop, (ViewGroup) this.llItems, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivItemIcon);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvItemName);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvItemDesc);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvItemPrice);
        final TextView textView5 = (TextView) viewInflate.findViewById(R.id.tvQty);
        final TextView textView6 = (TextView) viewInflate.findViewById(R.id.tvTotalCost);
        TextView textView7 = (TextView) viewInflate.findViewById(R.id.btnMinus);
        TextView textView8 = (TextView) viewInflate.findViewById(R.id.btnPlus);
        Button button2 = (Button) viewInflate.findViewById(R.id.btnExchange);
        final int iOptInt = jSONObject.optInt("id", -1);
        String strOptString2 = jSONObject.optString("name", "Item");
        final long jOptLong = jSONObject.optLong("price", 0L);
        int iOptInt2 = jSONObject.optInt("value", 0);
        String strOptString3 = jSONObject.optString("icon", "");
        int iOptInt3 = jSONObject.optInt("limitUser", 0);
        textView2.setText(strOptString2);
        if (iOptInt2 > 0) {
            StringBuilder sb = new StringBuilder("Value: ");
            Locale locale = Locale.getDefault();
            str = strOptString2;
            Object[] objArr = {Integer.valueOf(iOptInt2)};
            i = iOptInt3;
            sb.append(String.format(locale, "%,d", objArr));
            strOptString = sb.toString();
        } else {
            i = iOptInt3;
            str = strOptString2;
            strOptString = "";
        }
        if (i > 0) {
            StringBuilder sb2 = new StringBuilder();
            if (strOptString.isEmpty()) {
                str3 = "";
            } else {
                str3 = strOptString + " · ";
            }
            sb2.append(str3);
            sb2.append("Limit: ");
            sb2.append(i);
            strOptString = sb2.toString();
        }
        if (strOptString.isEmpty()) {
            strOptString = jSONObject.optString("type", "GEM");
        }
        textView3.setText(strOptString);
        textView4.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(jOptLong)));
        if (imageView != null) {
            imageView.setImageTintList(null);
            imageView.clearColorFilter();
            if (strOptString3 != null && !strOptString3.isEmpty()) {
                Glide.with(this).load(strOptString3).placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift).into(imageView);
            } else {
                imageView.setImageResource(R.drawable.ic_gift);
            }
        }
        final int[] iArr = {1};
        if (textView5 != null) {
            textView5.setText("1");
        }
        if (textView6 != null) {
            textView6.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(jOptLong)));
        }
        if (textView7 != null) {
            str2 = str;
            button = button2;
            view = viewInflate;
            textView = textView8;
            textView7.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    CarRacingGemShopActivity.lambda$addItemRow$3(iArr, textView5, textView6, jOptLong, view2);
                }
            });
        } else {
            view = viewInflate;
            button = button2;
            textView = textView8;
            str2 = str;
        }
        if (textView != null) {
            final int i2 = i;
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    CarRacingGemShopActivity.lambda$addItemRow$4(i2, iArr, textView5, textView6, jOptLong, view2);
                }
            });
        }
        if (button != null) {
            button.setBackgroundTintList(null);
            final Button button3 = button;
            button3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m183lambda$addItemRow$5$comzenoappCarRacingGemShopActivity(iOptInt, str2, iArr, jOptLong, button3, view2);
                }
            });
        }
        this.llItems.addView(view);
    }

    static /* synthetic */ void lambda$addItemRow$3(int[] iArr, TextView textView, TextView textView2, long j, View view) {
        int i = iArr[0];
        if (i > 1) {
            int i2 = i - 1;
            iArr[0] = i2;
            if (textView != null) {
                textView.setText(String.valueOf(i2));
            }
            if (textView2 != null) {
                textView2.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j * ((long) iArr[0]))));
            }
        }
    }

    static /* synthetic */ void lambda$addItemRow$4(int i, int[] iArr, TextView textView, TextView textView2, long j, View view) {
        int iMin = i > 0 ? Math.min(99, i) : 99;
        int i2 = iArr[0];
        if (i2 < iMin) {
            int i3 = i2 + 1;
            iArr[0] = i3;
            if (textView != null) {
                textView.setText(String.valueOf(i3));
            }
            if (textView2 != null) {
                textView2.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j * ((long) iArr[0]))));
            }
        }
    }

    /* JADX INFO: renamed from: lambda$addItemRow$5$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m183lambda$addItemRow$5$comzenoappCarRacingGemShopActivity(int i, String str, int[] iArr, long j, Button button, View view) {
        doBuy(i, str, iArr[0], j, button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void doBuy(final int i, final String str, final int i2, final long j, final Button button) {
        if (i < 0) {
            return;
        }
        String str2 = this.gameToken;
        if (str2 == null || str2.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ", 0).show();
            return;
        }
        if (this.gems < ((long) i2) * j) {
            Toast.makeText((Context) this, (CharSequence) "Gem မလောက်ပါ", 0).show();
            return;
        }
        button.setEnabled(false);
        button.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f$0.m187lambda$doBuy$9$comzenoappCarRacingGemShopActivity(i2, i, button, j, str);
            }
        });
    }

    /* JADX WARN: Can't wrap try/catch for region: R(3:(8:58|4|54|5|(1:7)(1:8)|9|(1:11)|12)|(8:64|20|(5:22|23|56|24|(2:26|27)(1:67))(5:30|(1:32)|47|51|52)|36|(3:60|38|69)(1:68)|50|51|52)(3:16|(2:18|65)(1:66)|19)|53) */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x013e, code lost:
    
        r0 = e;
     */
    /* JADX INFO: renamed from: lambda$doBuy$9$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ void m187lambda$doBuy$9$comzenoappCarRacingGemShopActivity(int r14, int r15, final android.widget.Button r16, long r17, java.lang.String r19) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 356
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CarRacingGemShopActivity.m187lambda$doBuy$9$comzenoappCarRacingGemShopActivity(int, int, android.widget.Button, long, java.lang.String):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$doBuy$6$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m184lambda$doBuy$6$comzenoappCarRacingGemShopActivity(String str, Button button) {
        if (isFinishing()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        button.setEnabled(true);
        button.setText("လဲမည်");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$doBuy$8$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m186lambda$doBuy$8$comzenoappCarRacingGemShopActivity(String str, long j, boolean z, final Button button) {
        if (isFinishing()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        TextView textView = this.tvGemBalance;
        if (textView != null) {
            textView.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
        }
        if (z) {
            button.setText("ရပြီ ✓");
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m185lambda$doBuy$7$comzenoappCarRacingGemShopActivity(button);
                }
            }, 1200L);
        } else {
            button.setEnabled(true);
            button.setText("လဲမည်");
        }
    }

    /* JADX INFO: renamed from: lambda$doBuy$7$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m185lambda$doBuy$7$comzenoappCarRacingGemShopActivity(Button button) {
        if (isFinishing()) {
            return;
        }
        button.setEnabled(true);
        button.setText("လဲမည်");
    }

    private void showLoading() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m192lambda$showLoading$10$comzenoappCarRacingGemShopActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showLoading$10$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m192lambda$showLoading$10$comzenoappCarRacingGemShopActivity() {
        if (isFinishing()) {
            return;
        }
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
        this.tvEmpty.setVisibility(8);
        this.svItems.setVisibility(8);
        this.llItems.removeAllViews();
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingGemShopActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m191lambda$showEmpty$11$comzenoappCarRacingGemShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$11$com-zeno-app-CarRacingGemShopActivity, reason: not valid java name */
    /* synthetic */ void m191lambda$showEmpty$11$comzenoappCarRacingGemShopActivity(String str) {
        if (isFinishing()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svItems.setVisibility(8);
        this.tvEmpty.setText(str);
        this.tvEmpty.setVisibility(0);
    }

    protected void onDestroy() {
        this.exec.shutdownNow();
        super.onDestroy();
    }
}
