package com.zeno.app;

import android.animation.ValueAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class GameHistoryActivity extends BaseActivity {
    private static final String GAME_BASE = "https://pubapi-mygov2.mtgmm.co/v1/engine";
    private ExecutorService exec;
    private LinearLayout llHistoryError;
    private LinearLayout llHistoryLoading;
    private LinearLayout llPrizes;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private ScrollView svPrizes;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvHistoryError;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_game_history);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Prizes History");
        }
        if (toolbarFindViewById != null) {
            toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m426lambda$onCreate$0$comzenoappGameHistoryActivity(view);
                }
            });
        }
        this.llHistoryLoading = (LinearLayout) findViewById(R.id.llHistoryLoading);
        this.llHistoryError = (LinearLayout) findViewById(R.id.llHistoryError);
        this.tvHistoryError = (TextView) findViewById(R.id.tvHistoryError);
        this.llPrizes = (LinearLayout) findViewById(R.id.llPrizes);
        this.svPrizes = (ScrollView) findViewById(R.id.svPrizes);
        Button button = (Button) findViewById(R.id.btnHistoryRetry);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m427lambda$onCreate$1$comzenoappGameHistoryActivity(view);
                }
            });
        }
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        if (swipeRefreshLayoutFindViewById != null) {
            swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda2
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return this.f$0.m428lambda$onCreate$2$comzenoappGameHistoryActivity(swipeRefreshLayout, view);
                }
            });
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda3
                public final void onRefresh() {
                    this.f$0.fetchPrizes();
                }
            });
        }
        fetchPrizes();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ void m426lambda$onCreate$0$comzenoappGameHistoryActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ void m427lambda$onCreate$1$comzenoappGameHistoryActivity(View view) {
        fetchPrizes();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ boolean m428lambda$onCreate$2$comzenoappGameHistoryActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        ScrollView scrollView = this.svPrizes;
        return scrollView != null && scrollView.getVisibility() == 0 && this.svPrizes.canScrollVertically(-1);
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchPrizes() {
        startHistorySkeleton();
        this.llHistoryError.setVisibility(8);
        this.svPrizes.setVisibility(8);
        final String gameToken = this.session.getGameToken();
        if (gameToken == null || gameToken.isEmpty()) {
            showError("Not logged in to game.\nPlease open Auto Play first.");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m425lambda$fetchPrizes$4$comzenoappGameHistoryActivity(gameToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPrizes$4$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ void m425lambda$fetchPrizes$4$comzenoappGameHistoryActivity(String str) {
        final JSONArray jSONArray;
        String strString;
        try {
            int i = 0;
            String[] strArr = {"https://pubapi-mygov2.mtgmm.co/v1/engine/game/reward/history", "https://pubapi-mygov2.mtgmm.co/v1/engine/game/history", "https://pubapi-mygov2.mtgmm.co/v1/engine/user/reward/history"};
            while (true) {
                jSONArray = null;
                if (i >= 3) {
                    strString = null;
                    break;
                }
                Response responseExecute = this.http.newCall(new Request.Builder().url(strArr[i]).addHeader("Authorization", "Bearer " + str).addHeader("Accept", "application/json").build()).execute();
                strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
                int iCode = responseExecute.code();
                responseExecute.close();
                if (iCode == 200 && strString != null && !strString.isEmpty()) {
                    break;
                } else {
                    i++;
                }
            }
            if (strString != null && !strString.isEmpty()) {
                JSONObject jSONObject = new JSONObject(strString);
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                if (jSONObjectOptJSONObject != null) {
                    jSONArray = jSONObjectOptJSONObject.optJSONArray("data");
                    if (jSONArray == null) {
                        jSONArray = jSONObjectOptJSONObject.optJSONArray("items");
                    }
                    if (jSONArray == null) {
                        jSONArray = jSONObjectOptJSONObject.optJSONArray("rewards");
                    }
                }
                if (jSONArray == null) {
                    jSONArray = jSONObject.optJSONArray("data");
                }
                if (jSONArray == null) {
                    jSONArray = jSONObject.optJSONArray("items");
                }
                if (jSONArray == null) {
                    jSONArray = new JSONArray();
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m424lambda$fetchPrizes$3$comzenoappGameHistoryActivity(jSONArray);
                    }
                });
                return;
            }
            showError("Game history not available.");
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPrizes$3$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ void m424lambda$fetchPrizes$3$comzenoappGameHistoryActivity(JSONArray jSONArray) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        stopHistorySkeleton();
        this.llPrizes.removeAllViews();
        if (jSONArray.length() == 0) {
            addEmptyView("No prize history yet.\nStart playing to win rewards! 🎮");
        } else {
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    addPrizeRow(jSONArray.getJSONObject(i));
                } catch (Exception unused) {
                }
            }
        }
        this.svPrizes.setVisibility(0);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:8:0x008b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void addPrizeRow(org.json.JSONObject r12) {
        /*
            Method dump skipped, instruction units count: 428
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.GameHistoryActivity.addPrizeRow(org.json.JSONObject):void");
    }

    private void showError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.GameHistoryActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m429lambda$showError$5$comzenoappGameHistoryActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$5$com-zeno-app-GameHistoryActivity, reason: not valid java name */
    /* synthetic */ void m429lambda$showError$5$comzenoappGameHistoryActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        stopHistorySkeleton();
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        this.svPrizes.setVisibility(8);
        this.tvHistoryError.setText(str);
        this.llHistoryError.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addEmptyView(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setTextSize(17.0f);
        textView.setGravity(17);
        textView.setPadding(24, 120, 24, 120);
        this.llPrizes.addView(textView);
    }

    private void startHistorySkeleton() {
        LinearLayout linearLayout = this.llHistoryLoading;
        if (linearLayout == null) {
            return;
        }
        linearLayout.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llHistoryLoading);
    }

    private void stopHistorySkeleton() {
        SkeletonPulse.stop(this.skeletonAnim, this.llHistoryLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llHistoryLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }
}
