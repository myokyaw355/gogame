package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class KongIslandShopActivity extends BaseActivity {
    private static final String BASE = "https://kong.mascom.vn";
    private ExecutorService exec;
    private LinearLayout llLoading;
    private LinearLayout llPackages;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svPackages;
    private LinearLayout tabRetail;
    private View tabRetailUnderline;
    private LinearLayout tabSubscription;
    private View tabSubscriptionUnderline;
    private TextView tvEmpty;
    private TextView tvTabHint;
    private TextView tvTabRetail;
    private TextView tvTabSubscription;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
    private boolean isSubscriptionTab = true;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_kong_island_shop);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Shop");
        }
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m587lambda$onCreate$0$comzenoappKongIslandShopActivity(view);
            }
        });
        this.tabSubscription = (LinearLayout) findViewById(R.id.tabSubscription);
        this.tabRetail = (LinearLayout) findViewById(R.id.tabRetail);
        this.tvTabSubscription = (TextView) findViewById(R.id.tvTabSubscription);
        this.tvTabRetail = (TextView) findViewById(R.id.tvTabRetail);
        this.tabSubscriptionUnderline = findViewById(R.id.tabSubscriptionUnderline);
        this.tabRetailUnderline = findViewById(R.id.tabRetailUnderline);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svPackages = findViewById(R.id.svPackages);
        this.llPackages = (LinearLayout) findViewById(R.id.llPackages);
        this.tvTabHint = (TextView) findViewById(R.id.tvTabHint);
        this.tabSubscription.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m588lambda$onCreate$1$comzenoappKongIslandShopActivity(view);
            }
        });
        this.tabRetail.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m589lambda$onCreate$2$comzenoappKongIslandShopActivity(view);
            }
        });
        fetchPackages("RENEW");
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m587lambda$onCreate$0$comzenoappKongIslandShopActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m588lambda$onCreate$1$comzenoappKongIslandShopActivity(View view) {
        switchTab(true);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m589lambda$onCreate$2$comzenoappKongIslandShopActivity(View view) {
        switchTab(false);
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void switchTab(boolean z) {
        if (this.isSubscriptionTab == z) {
            return;
        }
        this.isSubscriptionTab = z;
        updateTabBar();
        fetchPackages(z ? "RENEW" : "RETAIL");
    }

    private void updateTabBar() {
        if (this.isSubscriptionTab) {
            this.tvTabSubscription.setTextColor(-3632086);
            this.tvTabSubscription.setTypeface(null, 1);
            this.tabSubscriptionUnderline.setBackgroundColor(-3632086);
            this.tvTabRetail.setTextColor(-7829368);
            this.tvTabRetail.setTypeface(null, 0);
            this.tabRetailUnderline.setBackgroundColor(0);
            return;
        }
        this.tvTabRetail.setTextColor(-3632086);
        this.tvTabRetail.setTypeface(null, 1);
        this.tabRetailUnderline.setBackgroundColor(-3632086);
        this.tvTabSubscription.setTextColor(-7829368);
        this.tvTabSubscription.setTypeface(null, 0);
        this.tabSubscriptionUnderline.setBackgroundColor(0);
    }

    private void fetchPackages(final String str) {
        showLoading();
        final String kongToken = this.session.getKongToken();
        if (!ok(kongToken)) {
            showEmpty("Kong Runner ကို အရင်ဖွင့်ပြီး login ဝင်ပါ။");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m586lambda$fetchPackages$4$comzenoappKongIslandShopActivity(str, kongToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPackages$4$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m586lambda$fetchPackages$4$comzenoappKongIslandShopActivity(final String str, String str2) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/package/list?type=" + str).get().addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str2).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda6
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m585lambda$fetchPackages$3$comzenoappKongIslandShopActivity(strString, str);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code() + " — Package list ယူ၍ မရပါ။");
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseAndShow, reason: merged with bridge method [inline-methods] */
    public void m585lambda$fetchPackages$3$comzenoappKongIslandShopActivity(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Package list ယူ၍ မရပါ။"));
                return;
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject == null) {
                showEmpty("No data.");
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("listPackage");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                renderPackages(jSONArrayOptJSONArray, str2);
                return;
            }
            showEmpty("Package မရှိသေးပါ။");
        } catch (Exception e) {
            showEmpty("Parse error: " + e.getMessage());
        }
    }

    private void renderPackages(JSONArray jSONArray, String str) {
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.tvEmpty.setVisibility(8);
        this.llPackages.removeAllViews();
        if ("RENEW".equals(str)) {
            this.tvTabHint.setText("📅  ကြိုက်သော package ကို subscribe လုပ်ပါ — ဆက်တိုက် auto-renew ဖြစ်သည်");
        } else {
            this.tvTabHint.setText("🛒  တစ်ကြိမ်ဝယ်ပြီး ချက်ချင်းသုံးနိုင်သည် — VIP account လိုသည်");
        }
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                addPackageRow(jSONObjectOptJSONObject);
            }
        }
        this.svPackages.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v6 */
    /* JADX WARN: Type inference failed for: r4v7, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v8 */
    private void addPackageRow(JSONObject jSONObject) {
        ?? r4;
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_kong_package, (ViewGroup) this.llPackages, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivPackIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPackName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvPackBadge);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvPackPrice);
        final Button button = (Button) viewInflate.findViewById(R.id.btnPackBuy);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvStatTicket);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.tvStatBanana);
        TextView textView6 = (TextView) viewInflate.findViewById(R.id.tvStatMagnet);
        TextView textView7 = (TextView) viewInflate.findViewById(R.id.tvStatProtect);
        TextView textView8 = (TextView) viewInflate.findViewById(R.id.tvStatReborn);
        TextView textView9 = (TextView) viewInflate.findViewById(R.id.tvStatX2);
        View viewFindViewById = viewInflate.findViewById(R.id.colReborn);
        View viewFindViewById2 = viewInflate.findViewById(R.id.colX2);
        final String strOptString = jSONObject.optString("code", "");
        final String strOptString2 = jSONObject.optString("name", "Package");
        String strOptString3 = jSONObject.optString("icon", "");
        double dOptDouble = jSONObject.optDouble("price", 0.0d);
        String strOptString4 = jSONObject.optString("typePrice", "MMK");
        int iOptInt = jSONObject.optInt("ticket", 0);
        int iOptInt2 = jSONObject.optInt("banana", 0);
        int iOptInt3 = jSONObject.optInt("magnet", 0);
        int iOptInt4 = jSONObject.optInt("protect", 0);
        int iOptInt5 = jSONObject.optInt("reborn", 0);
        int iOptInt6 = jSONObject.optInt("x2banana", 0);
        boolean zOptBoolean = jSONObject.optBoolean("autoRenew", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("vipRequire", false);
        boolean zOptBoolean3 = jSONObject.optBoolean("cancelButton", false);
        if (ok(strOptString3)) {
            Glide.with(this).load(strOptString3).apply(new RequestOptions().placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift)).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_gift);
        }
        textView.setText(strOptString2);
        textView3.setText(String.format("%,.0f %s", Double.valueOf(dOptDouble), strOptString4));
        if (zOptBoolean) {
            textView2.setText("AUTO");
            textView2.setVisibility(0);
        } else if (zOptBoolean2) {
            textView2.setText("VIP");
            textView2.setVisibility(0);
        } else {
            textView2.setVisibility(8);
        }
        textView4.setText(String.valueOf(iOptInt));
        textView5.setText(String.valueOf(iOptInt2));
        textView6.setText(String.valueOf(iOptInt3));
        textView7.setText(String.valueOf(iOptInt4));
        if (iOptInt5 > 0) {
            textView8.setText(String.valueOf(iOptInt5));
            r4 = 0;
            viewFindViewById.setVisibility(0);
        } else {
            r4 = 0;
        }
        if (iOptInt6 > 0) {
            textView9.setText(String.valueOf(iOptInt6));
            viewFindViewById2.setVisibility(r4);
        }
        if (zOptBoolean3) {
            button.setText("ဝယ်ယူပြီး");
            button.setEnabled(r4);
            button.setBackgroundTintList(ColorStateList.valueOf(-13730510));
            button.setTextColor(-1);
        } else {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda8
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m581lambda$addPackageRow$5$comzenoappKongIslandShopActivity(strOptString, strOptString2, button, view);
                }
            });
        }
        this.llPackages.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addPackageRow$5$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m581lambda$addPackageRow$5$comzenoappKongIslandShopActivity(String str, String str2, Button button, View view) {
        buyPackage(str, str2, button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buyPackage(final String str, final String str2, final Button button) {
        if (ok(str)) {
            button.setEnabled(false);
            button.setText("...");
            final String kongToken = this.session.getKongToken();
            if (!ok(kongToken)) {
                Toast.makeText((Context) this, (CharSequence) "Kong Runner ကို အရင်ဖွင့်ပြီး login ဝင်ပါ။", 0).show();
                button.setEnabled(true);
                button.setText("ဝယ်မည်");
                return;
            }
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f$0.m584lambda$buyPackage$8$comzenoappKongIslandShopActivity(str, kongToken, str2, button);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$buyPackage$8$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m584lambda$buyPackage$8$comzenoappKongIslandShopActivity(String str, String str2, String str3, final Button button) throws Throwable {
        final String strOptString;
        Response responseExecute;
        final boolean z = false;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("code", str);
            responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/package/buy-package").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str2).addHeader("Origin", BASE).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
        } catch (Exception e) {
            strOptString = "Network error: " + e.getMessage();
        }
        try {
            JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
            if (jSONObject2.optBoolean("success", false)) {
                try {
                    strOptString = str3 + " ဝယ်ယူပြီးပါပြီ! 🎉";
                    z = true;
                } catch (Throwable th) {
                    th = th;
                    z = true;
                    if (responseExecute != null) {
                        try {
                            responseExecute.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } else {
                strOptString = jSONObject2.optString("message", "ဝယ်ယူ၍ မရပါ။");
            }
            if (responseExecute != null) {
                responseExecute.close();
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m583lambda$buyPackage$7$comzenoappKongIslandShopActivity(strOptString, z, button);
                }
            });
        } catch (Throwable th3) {
            th = th3;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyPackage$7$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m583lambda$buyPackage$7$comzenoappKongIslandShopActivity(String str, boolean z, final Button button) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        if (z) {
            button.setText("ဝယ်ပြီး");
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m582lambda$buyPackage$6$comzenoappKongIslandShopActivity(button);
                }
            }, 1200L);
        } else {
            button.setEnabled(true);
            button.setText("ဝယ်မည်");
        }
    }

    /* JADX INFO: renamed from: lambda$buyPackage$6$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m582lambda$buyPackage$6$comzenoappKongIslandShopActivity(Button button) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        button.setEnabled(true);
        button.setText("ဝယ်မည်");
    }

    private void showLoading() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m591lambda$showLoading$9$comzenoappKongIslandShopActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showLoading$9$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m591lambda$showLoading$9$comzenoappKongIslandShopActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.llLoading.setVisibility(0);
        this.tvEmpty.setVisibility(8);
        this.svPackages.setVisibility(8);
        this.llPackages.removeAllViews();
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandShopActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m590lambda$showEmpty$10$comzenoappKongIslandShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$10$com-zeno-app-KongIslandShopActivity, reason: not valid java name */
    /* synthetic */ void m590lambda$showEmpty$10$comzenoappKongIslandShopActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svPackages.setVisibility(8);
        this.tvEmpty.setText(str);
        this.tvEmpty.setVisibility(0);
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
