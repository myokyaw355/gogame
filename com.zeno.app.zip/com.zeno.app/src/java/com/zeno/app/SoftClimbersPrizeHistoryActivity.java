package com.zeno.app;

import android.animation.ValueAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SoftClimbersPrizeHistoryActivity extends BaseActivity {
    private static final String SC_BASE = "https://api.softclimbers.com";
    private ExecutorService exec;
    private LinearLayout llError;
    private LinearLayout llItems;
    private LinearLayout llLoading;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private ScrollView svItems;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvError;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();
    private int currentPage = 0;
    private boolean hasMore = true;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_sc_prize_history);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Prize History");
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        toolbarFindViewById.setNavigationIcon(R.drawable.ic_back);
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m706lambda$onCreate$0$comzenoappSoftClimbersPrizeHistoryActivity(view);
            }
        });
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.llError = (LinearLayout) findViewById(R.id.llError);
        this.llItems = (LinearLayout) findViewById(R.id.llItems);
        this.svItems = (ScrollView) findViewById(R.id.svItems);
        this.tvError = (TextView) findViewById(R.id.tvError);
        Button button = (Button) findViewById(R.id.btnRetry);
        Button button2 = (Button) findViewById(R.id.btnLoadMore);
        if (button != null) {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m707lambda$onCreate$1$comzenoappSoftClimbersPrizeHistoryActivity(view);
                }
            });
        }
        if (button2 != null) {
            button2.setBackgroundTintList(null);
            button2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m708lambda$onCreate$2$comzenoappSoftClimbersPrizeHistoryActivity(view);
                }
            });
        }
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        if (swipeRefreshLayoutFindViewById != null) {
            swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda6
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return this.f$0.m709lambda$onCreate$3$comzenoappSoftClimbersPrizeHistoryActivity(swipeRefreshLayout, view);
                }
            });
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda7
                public final void onRefresh() {
                    this.f$0.m710lambda$onCreate$4$comzenoappSoftClimbersPrizeHistoryActivity();
                }
            });
        }
        fetchHistory();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m706lambda$onCreate$0$comzenoappSoftClimbersPrizeHistoryActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m707lambda$onCreate$1$comzenoappSoftClimbersPrizeHistoryActivity(View view) {
        this.currentPage = 0;
        this.hasMore = true;
        this.llItems.removeAllViews();
        fetchHistory();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m708lambda$onCreate$2$comzenoappSoftClimbersPrizeHistoryActivity(View view) {
        fetchHistory();
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ boolean m709lambda$onCreate$3$comzenoappSoftClimbersPrizeHistoryActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        ScrollView scrollView = this.svItems;
        return scrollView != null && scrollView.getVisibility() == 0 && this.svItems.canScrollVertically(-1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m710lambda$onCreate$4$comzenoappSoftClimbersPrizeHistoryActivity() {
        this.currentPage = 0;
        this.hasMore = true;
        this.llItems.removeAllViews();
        fetchHistory();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void fetchHistory() {
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
        this.llError.setVisibility(8);
        if (this.currentPage == 0) {
            this.svItems.setVisibility(8);
        }
        final String scGameToken = this.session.getScGameToken();
        if (!ok(scGameToken)) {
            showError("Not logged in to SoftClimbers.\nOpen the game card first.");
        } else {
            final int i = this.currentPage;
            this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m705lambda$fetchHistory$6$comzenoappSoftClimbersPrizeHistoryActivity(scGameToken, i);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchHistory$6$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m705lambda$fetchHistory$6$comzenoappSoftClimbersPrizeHistoryActivity(String str, int i) {
        try {
            String[] strArrFetchPrizeHistoryPage = fetchPrizeHistoryPage(str, i);
            String str2 = strArrFetchPrizeHistoryPage[1];
            if (str2 != null) {
                showError(str2);
            } else {
                final String str3 = strArrFetchPrizeHistoryPage[0];
                this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m704lambda$fetchHistory$5$comzenoappSoftClimbersPrizeHistoryActivity(str3);
                    }
                });
            }
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    private String[] fetchPrizeHistoryPage(String str, int i) {
        try {
            String[] strArrDoGet = doGet("https://api.softclimbers.com/api/v1/prize-history?page=" + i + "&size=20", str);
            if ("401".equals(strArrDoGet[1])) {
                String strReLoginSoftClimbers = reLoginSoftClimbers();
                if (!ok(strReLoginSoftClimbers)) {
                    return new String[]{"", "Session expired. Open game card to refresh login."};
                }
                strArrDoGet = doGet("https://api.softclimbers.com/api/v1/prize-history?page=" + i + "&size=20", strReLoginSoftClimbers);
            }
            String str2 = strArrDoGet[0];
            return str2 == null ? new String[]{"", "Network error. Please retry."} : new String[]{str2, null};
        } catch (Exception e) {
            return new String[]{"", "Error: " + e.getMessage()};
        }
    }

    private String[] doGet(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("Authorization", "Bearer " + str2).addHeader("access-token", str2).addHeader("user-agent", "ZenoMyID/2.0");
            String phone = this.session.getPhone();
            if (ok(phone)) {
                builderAddHeader.addHeader("phone-number", phone);
                builderAddHeader.addHeader("msisdn", phone);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                String[] strArr = {responseExecute.body() != null ? responseExecute.body().string() : "", String.valueOf(responseExecute.code())};
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return strArr;
            } finally {
            }
        } catch (Exception unused) {
            return new String[]{null, "0"};
        }
    }

    private String reLoginSoftClimbers() {
        JSONObject jSONObjectOptJSONObject;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        String avatarUrl = this.session.getAvatarUrl();
        String fullName = this.session.getFullName();
        if (ok(phone) && ok(accessToken)) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("msisdn", phone);
                jSONObject.put("accessToken", accessToken);
                if (!ok(avatarUrl)) {
                    avatarUrl = "";
                }
                jSONObject.put("avatar", avatarUrl);
                if (ok(fullName)) {
                    phone = fullName;
                }
                jSONObject.put("username", phone);
                jSONObject.put("lang", "mu");
                Response responseExecute = this.http.newCall(new Request.Builder().url("https://api.softclimbers.com/api/v1/auth/login").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("content-type", "application/json").build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                    if (jSONObject2.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject2.optJSONObject("data")) != null) {
                        String strOptString = jSONObjectOptJSONObject.optString("token", "");
                        if (ok(strOptString)) {
                            this.session.saveScGameToken(strOptString);
                            if (responseExecute != null) {
                                responseExecute.close();
                            }
                            return strOptString;
                        }
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                } finally {
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseAndShow, reason: merged with bridge method [inline-methods] */
    public void m704lambda$fetchHistory$5$comzenoappSoftClimbersPrizeHistoryActivity(String str) {
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        JSONArray jSONArrayOptJSONArray = null;
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        int i = 8;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.optInt("code", -1) != 0) {
                showError("Error: " + jSONObject.optString("message", "unknown"));
                return;
            }
            Object objOpt = jSONObject.opt("data");
            if (objOpt instanceof JSONArray) {
                jSONArrayOptJSONArray = (JSONArray) objOpt;
            } else if (objOpt instanceof JSONObject) {
                JSONObject jSONObject2 = (JSONObject) objOpt;
                JSONArray jSONArrayOptJSONArray2 = jSONObject2.optJSONArray("content");
                if (jSONArrayOptJSONArray2 == null) {
                    jSONArrayOptJSONArray2 = jSONObject2.optJSONArray("items");
                }
                if (jSONArrayOptJSONArray2 == null) {
                    jSONArrayOptJSONArray2 = jSONObject2.optJSONArray("list");
                }
                jSONArrayOptJSONArray = jSONArrayOptJSONArray2;
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
                }
            }
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                this.svItems.setVisibility(0);
                for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                    try {
                        addItemRow(jSONArrayOptJSONArray.getJSONObject(i2));
                    } catch (Exception unused) {
                    }
                }
                this.currentPage++;
                Button button = (Button) findViewById(R.id.btnLoadMore);
                if (button != null) {
                    if (jSONArrayOptJSONArray.length() >= 20) {
                        i = 0;
                    }
                    button.setVisibility(i);
                    return;
                }
                return;
            }
            if (this.currentPage == 0) {
                this.svItems.setVisibility(0);
                addEmptyView("No prize history yet.\nPlay the game to collect puzzle pieces!");
                return;
            }
            this.hasMore = false;
            Button button2 = (Button) findViewById(R.id.btnLoadMore);
            if (button2 != null) {
                button2.setVisibility(8);
            }
        } catch (Exception e) {
            showError("Parse error: " + e.getMessage());
        }
    }

    private void addItemRow(JSONObject jSONObject) {
        View viewInflate = getLayoutInflater().inflate(R.layout.item_sc_prize_row, (ViewGroup) this.llItems, false);
        String strOptString = jSONObject.optString("name", jSONObject.optString("reward_name", jSONObject.optString("itemName", "Puzzle Piece")));
        jSONObject.optString("type", jSONObject.optString("itemType", jSONObject.optString("reward_type", "PUZZLE_PIECE")));
        String date = formatDate(jSONObject.optString("obtainedAt", jSONObject.optString("createdAt", jSONObject.optString("created_at", ""))));
        jSONObject.optInt("pieceIndex", jSONObject.optInt("piece_index", -1));
        jSONObject.optBoolean("redeemable", false);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvItemName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvItemDate);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvItemType);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvItemBadge);
        textView.setText(strOptString);
        textView2.setText(date);
        textView3.setText("");
        textView4.setText("");
        textView4.setBackgroundResource(R.drawable.ic_gift_prize_badge);
        textView4.setTextColor(-3632086);
        this.llItems.addView(viewInflate);
    }

    private String formatDate(String str) {
        if (!ok(str)) {
            return "--";
        }
        try {
            try {
                return new SimpleDateFormat("dd MMM yyyy  HH:mm", Locale.US).format(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).parse(str));
            } catch (Exception unused) {
                return str;
            }
        } catch (Exception unused2) {
            return new SimpleDateFormat("dd MMM yyyy  HH:mm", Locale.US).format(new Date(Long.parseLong(str)));
        }
    }

    private void showError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersPrizeHistoryActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m711lambda$showError$7$comzenoappSoftClimbersPrizeHistoryActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$7$com-zeno-app-SoftClimbersPrizeHistoryActivity, reason: not valid java name */
    /* synthetic */ void m711lambda$showError$7$comzenoappSoftClimbersPrizeHistoryActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        this.svItems.setVisibility(8);
        this.tvError.setText(str);
        this.llError.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addEmptyView(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        textView.setPadding(32, 100, 32, 100);
        this.llItems.addView(textView);
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
