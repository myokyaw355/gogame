package com.zeno.app;

import android.animation.ValueAnimator;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SoftClimbersLeaderboardActivity extends BaseActivity {
    private static final String SC_BASE = "https://api.softclimbers.com";
    private ExecutorService exec;
    private LinearLayout llError;
    private LinearLayout llLoading;
    private LinearLayout llRows;
    private LinearLayout rankUserFooter;
    private LinearLayout rankUserRow;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svRows;
    private TextView tvError;
    private TextView tvMonthlyTab;
    private TextView tvWeeklyTab;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();
    private String currentType = "WEEKLY";

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_sc_leaderboard);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Leaderboard");
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        toolbarFindViewById.setNavigationIcon(R.drawable.ic_back);
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m699lambda$onCreate$0$comzenoappSoftClimbersLeaderboardActivity(view);
            }
        });
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.llError = (LinearLayout) findViewById(R.id.llError);
        this.llRows = (LinearLayout) findViewById(R.id.llRows);
        this.svRows = findViewById(R.id.svRows);
        this.tvError = (TextView) findViewById(R.id.tvError);
        this.tvWeeklyTab = (TextView) findViewById(R.id.tvWeeklyTab);
        this.tvMonthlyTab = (TextView) findViewById(R.id.tvMonthlyTab);
        this.rankUserFooter = (LinearLayout) findViewById(R.id.rankUserFooter);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        Button button = (Button) findViewById(R.id.btnRetry);
        if (button != null) {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m700lambda$onCreate$1$comzenoappSoftClimbersLeaderboardActivity(view);
                }
            });
        }
        this.tvWeeklyTab.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m701lambda$onCreate$2$comzenoappSoftClimbersLeaderboardActivity(view);
            }
        });
        this.tvMonthlyTab.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m702lambda$onCreate$3$comzenoappSoftClimbersLeaderboardActivity(view);
            }
        });
        highlightTab("WEEKLY");
        fetchLeaderboard("WEEKLY");
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m699lambda$onCreate$0$comzenoappSoftClimbersLeaderboardActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m700lambda$onCreate$1$comzenoappSoftClimbersLeaderboardActivity(View view) {
        fetchLeaderboard(this.currentType);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m701lambda$onCreate$2$comzenoappSoftClimbersLeaderboardActivity(View view) {
        this.currentType = "WEEKLY";
        switchTab();
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m702lambda$onCreate$3$comzenoappSoftClimbersLeaderboardActivity(View view) {
        this.currentType = "MONTHLY";
        switchTab();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void switchTab() {
        highlightTab(this.currentType);
        fetchLeaderboard(this.currentType);
    }

    private void highlightTab(String str) {
        boolean zEquals = "WEEKLY".equals(str);
        this.tvWeeklyTab.setBackgroundResource(zEquals ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
        this.tvWeeklyTab.setTextColor(zEquals ? -3632086 : -7829368);
        this.tvWeeklyTab.setTypeface(null, zEquals ? 1 : 0);
        this.tvMonthlyTab.setBackgroundResource(!zEquals ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
        this.tvMonthlyTab.setTextColor(zEquals ? -7829368 : -3632086);
        this.tvMonthlyTab.setTypeface(null, !zEquals ? 1 : 0);
    }

    private void fetchLeaderboard(final String str) {
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
        this.llError.setVisibility(8);
        this.svRows.setVisibility(8);
        this.llRows.removeAllViews();
        LinearLayout linearLayout = this.rankUserFooter;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        final String scGameToken = this.session.getScGameToken();
        if (!ok(scGameToken)) {
            showError("Not logged in to SoftClimbers.\nOpen the game card first.");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m698lambda$fetchLeaderboard$5$comzenoappSoftClimbersLeaderboardActivity(str, scGameToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$5$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m698lambda$fetchLeaderboard$5$comzenoappSoftClimbersLeaderboardActivity(String str, String str2) {
        try {
            String[] strArrDoGet = doGet("https://api.softclimbers.com/api/v1/leaderboard?type=" + str + "&page=0&size=50", str2);
            if ("401".equals(strArrDoGet[1])) {
                String strReLoginSoftClimbers = reLoginSoftClimbers();
                if (!ok(strReLoginSoftClimbers)) {
                    showError("Session expired. Open game card to refresh login.");
                    return;
                }
                strArrDoGet = doGet("https://api.softclimbers.com/api/v1/leaderboard?type=" + str + "&page=0&size=50", strReLoginSoftClimbers);
            }
            final String str3 = strArrDoGet[0];
            if (str3 == null) {
                showError("Network error. Please retry.");
            } else {
                this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m697lambda$fetchLeaderboard$4$comzenoappSoftClimbersLeaderboardActivity(str3);
                    }
                });
            }
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    private String[] doGet(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("Authorization", "Bearer " + str2).addHeader("access-token", str2).addHeader("user-agent", "ZenoMyID/2.0");
            String phone = this.session.getPhone();
            if (ok(phone)) {
                builderAddHeader.addHeader("phone-number", phone);
                builderAddHeader.addHeader("msisdn", phone);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                String[] strArr = {responseExecute.body() != null ? responseExecute.body().string() : "", String.valueOf(responseExecute.code())};
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return strArr;
            } finally {
            }
        } catch (Exception unused) {
            return new String[]{null, "0"};
        }
    }

    private String reLoginSoftClimbers() {
        JSONObject jSONObjectOptJSONObject;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        String avatarUrl = this.session.getAvatarUrl();
        String fullName = this.session.getFullName();
        if (ok(phone) && ok(accessToken)) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("msisdn", phone);
                jSONObject.put("accessToken", accessToken);
                if (!ok(avatarUrl)) {
                    avatarUrl = "";
                }
                jSONObject.put("avatar", avatarUrl);
                if (ok(fullName)) {
                    phone = fullName;
                }
                jSONObject.put("username", phone);
                jSONObject.put("lang", "mu");
                Response responseExecute = this.http.newCall(new Request.Builder().url("https://api.softclimbers.com/api/v1/auth/login").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("content-type", "application/json").build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                    if (jSONObject2.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject2.optJSONObject("data")) != null) {
                        String strOptString = jSONObjectOptJSONObject.optString("token", "");
                        if (ok(strOptString)) {
                            this.session.saveScGameToken(strOptString);
                            if (responseExecute != null) {
                                responseExecute.close();
                            }
                            return strOptString;
                        }
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                } finally {
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00b1 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX INFO: renamed from: parseAndShow, reason: merged with bridge method [inline-methods] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void m697lambda$fetchLeaderboard$4$comzenoappSoftClimbersLeaderboardActivity(java.lang.String r13) {
        /*
            Method dump skipped, instruction units count: 297
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.SoftClimbersLeaderboardActivity.m697lambda$fetchLeaderboard$4$comzenoappSoftClimbersLeaderboardActivity(java.lang.String):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addRow(int i, JSONObject jSONObject, String str) {
        int i2;
        int i3;
        int iOptInt = jSONObject.optInt("rank", jSONObject.optInt("rankNo", i));
        String strOptString = jSONObject.optString("username", jSONObject.optString("nickname", jSONObject.optString("msisdn", jSONObject.optString("phone", "User " + iOptInt))));
        if (strOptString.startsWith("09") && strOptString.length() >= 8) {
            strOptString = strOptString.substring(0, 4) + "****" + strOptString.substring(strOptString.length() - 2);
        }
        long jOptLong = jSONObject.optLong("score", jSONObject.optLong("totalScore", jSONObject.optLong("point", 0L)));
        int iOptInt2 = jSONObject.optInt("level", jSONObject.optInt("lvl", 0));
        String strOptString2 = jSONObject.optString("msisdn", jSONObject.optString("phone", ""));
        boolean z = ok(str) && str.length() > 2 && ok(strOptString2) && strOptString2.contains(str.substring(2));
        String strOptString3 = jSONObject.optString("avatar", null);
        if ("null".equals(strOptString3) || (strOptString3 != null && strOptString3.isEmpty())) {
            strOptString3 = null;
        }
        int iDp = dp(6);
        int iDp2 = dp(8);
        int iDp3 = dp(10);
        int iDp4 = dp(12);
        int iDp5 = dp(36);
        int iDp6 = dp(40);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 0, 0, iDp);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setPadding(iDp2, iDp3, iDp2, iDp3);
        int i4 = iOptInt == 1 ? 587192064 : iOptInt == 2 ? 417193437 : iOptInt == 3 ? 587165763 : z ? 583570474 : 285212671;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(iDp4);
        gradientDrawable.setColor(i4);
        linearLayout.setBackground(gradientDrawable);
        if (iOptInt <= 3) {
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(iDp6, iDp6);
            layoutParams2.setMarginEnd(iDp2);
            imageView.setLayoutParams(layoutParams2);
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if (iOptInt == 1) {
                i3 = R.drawable.ic_medal_gold;
            } else if (iOptInt == 2) {
                i3 = R.drawable.ic_medal_silver;
            } else {
                i3 = R.drawable.ic_medal_bronze;
            }
            imageView.setImageResource(i3);
            linearLayout.addView(imageView);
        } else {
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(iDp6, -2);
            layoutParams3.setMarginEnd(iDp2);
            textView.setLayoutParams(layoutParams3);
            textView.setText(String.valueOf(iOptInt));
            textView.setTextColor(-7829368);
            textView.setTextSize(2, 13.0f);
            textView.setGravity(17);
            linearLayout.addView(textView);
        }
        ImageView imageView2 = new ImageView(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(iDp5, iDp5);
        layoutParams4.setMarginEnd(iDp3);
        imageView2.setLayoutParams(layoutParams4);
        imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView2.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView2.setClipToOutline(true);
        loadCircleAvatar(imageView2, strOptString3);
        linearLayout.addView(imageView2);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(this);
        if (z) {
            strOptString = strOptString + " (You)";
        }
        textView2.setText(strOptString);
        textView2.setTextColor((iOptInt > 3 && !z) ? -3355444 : -1);
        textView2.setTextSize(2, iOptInt <= 3 ? 14.0f : 13.0f);
        if (iOptInt <= 3 || z) {
            i2 = 1;
            textView2.setTypeface(null, 1);
        } else {
            i2 = 1;
        }
        textView2.setMaxLines(i2);
        textView2.setEllipsize(TextUtils.TruncateAt.END);
        linearLayout2.addView(textView2);
        if (iOptInt2 > 0) {
            TextView textView3 = new TextView(this);
            textView3.setText("Lv." + iOptInt2);
            textView3.setTextColor(-3632086);
            textView3.setTextSize(2, 11.0f);
            linearLayout2.addView(textView3);
        }
        linearLayout.addView(linearLayout2);
        TextView textView4 = new TextView(this);
        textView4.setText(String.format(Locale.getDefault(), "%,d pts", Long.valueOf(jOptLong)));
        int i5 = -10752;
        if (iOptInt > 3 && !z) {
            i5 = -5592406;
        }
        textView4.setTextColor(i5);
        textView4.setTextSize(2, 12.0f);
        if (iOptInt <= 3 || z) {
            textView4.setTypeface(null, 1);
        }
        textView4.setGravity(8388613);
        linearLayout.addView(textView4);
        this.llRows.addView(linearLayout);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showMyRankFooter(JSONObject jSONObject, String str, int i, long j) {
        String fullName;
        String str2;
        LinearLayout linearLayout = this.rankUserFooter;
        if (linearLayout == null) {
            return;
        }
        if (jSONObject == null && i <= 0) {
            linearLayout.setVisibility(8);
            return;
        }
        int iOptInt = jSONObject != null ? jSONObject.optInt("rank", jSONObject.optInt("rankNo", 0)) : i;
        if (jSONObject != null) {
            fullName = jSONObject.optString("username", jSONObject.optString("nickname", jSONObject.optString("msisdn", str)));
        } else {
            fullName = ok(this.session.getFullName()) ? this.session.getFullName() : str;
        }
        if (fullName.startsWith("09") && fullName.length() >= 8) {
            fullName = fullName.substring(0, 4) + "****" + fullName.substring(fullName.length() - 2);
        }
        long jOptLong = jSONObject != null ? jSONObject.optLong("score", jSONObject.optLong("totalScore", jSONObject.optLong("point", 0L))) : j;
        int iOptInt2 = jSONObject != null ? jSONObject.optInt("level", jSONObject.optInt("lvl", 0)) : 0;
        String strOptString = jSONObject != null ? jSONObject.optString("avatar", null) : null;
        if ("null".equals(strOptString) || (strOptString != null && strOptString.isEmpty())) {
            strOptString = null;
        }
        if (!ok(strOptString)) {
            strOptString = this.session.getAvatarUrl();
        }
        int iDp = dp(6);
        int iDp2 = dp(8);
        int iDp3 = dp(10);
        int iDp4 = dp(36);
        int iDp5 = dp(40);
        this.rankUserRow.removeAllViews();
        TextView textView = new TextView(this);
        textView.setText("ကိုယ်တိုင်");
        textView.setTextColor(-7829368);
        textView.setTextSize(2, 11.0f);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.rankUserRow.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, iDp, 0, 0);
        linearLayout2.setLayoutParams(layoutParams);
        TextView textView2 = new TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(iDp5, -2);
        layoutParams2.setMarginEnd(iDp2);
        textView2.setLayoutParams(layoutParams2);
        if (iOptInt > 0) {
            str2 = "#" + iOptInt;
        } else {
            str2 = "--";
        }
        textView2.setText(str2);
        textView2.setTextColor(-3632086);
        textView2.setTextSize(2, 13.0f);
        textView2.setTypeface(null, 1);
        textView2.setGravity(17);
        linearLayout2.addView(textView2);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(iDp4, iDp4);
        layoutParams3.setMarginEnd(iDp3);
        imageView.setLayoutParams(layoutParams3);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView.setClipToOutline(true);
        loadCircleAvatar(imageView, strOptString);
        linearLayout2.addView(imageView);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView3 = new TextView(this);
        textView3.setText(fullName);
        textView3.setTextColor(-1);
        textView3.setTextSize(2, 13.0f);
        textView3.setTypeface(null, 1);
        textView3.setMaxLines(1);
        textView3.setEllipsize(TextUtils.TruncateAt.END);
        linearLayout3.addView(textView3);
        if (iOptInt2 > 0) {
            TextView textView4 = new TextView(this);
            textView4.setText("Lv." + iOptInt2);
            textView4.setTextColor(-3632086);
            textView4.setTextSize(2, 11.0f);
            linearLayout3.addView(textView4);
        }
        linearLayout2.addView(linearLayout3);
        TextView textView5 = new TextView(this);
        textView5.setText(String.format(Locale.getDefault(), "%,d pts", Long.valueOf(jOptLong)));
        textView5.setTextColor(-10752);
        textView5.setTextSize(2, 12.0f);
        textView5.setTypeface(null, 1);
        textView5.setGravity(8388613);
        linearLayout2.addView(textView5);
        this.rankUserRow.addView(linearLayout2);
        this.rankUserFooter.setVisibility(0);
    }

    private void loadCircleAvatar(ImageView imageView, String str) {
        if (ok(str)) {
            Glide.with(this).load(str).apply(new RequestOptions().transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    private void showError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersLeaderboardActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m703lambda$showError$6$comzenoappSoftClimbersLeaderboardActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$6$com-zeno-app-SoftClimbersLeaderboardActivity, reason: not valid java name */
    /* synthetic */ void m703lambda$showError$6$comzenoappSoftClimbersLeaderboardActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svRows.setVisibility(8);
        this.tvError.setText(str);
        this.llError.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addEmptyView(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        textView.setPadding(dp(32), dp(100), dp(32), dp(100));
        this.llRows.addView(textView);
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
