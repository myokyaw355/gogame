package com.zeno.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SpinWheelView extends View {
    private Bitmap centerBitmap;
    private final RectF oval;
    private final Paint paintBorder;
    private final Paint paintFill;
    private final Paint paintPtr;
    private final Paint paintSub;
    private final Paint paintText;
    private final List<Segment> segments;
    private boolean spinning;
    private float wheelAngle;

    public static class Segment {
        public final int bgColor;
        public final Bitmap icon;
        public final String label;
        public final String sub;
        public final int textColor;

        public Segment(String str, String str2, int i, int i2, Bitmap bitmap) {
            this.label = str;
            this.sub = str2;
            this.bgColor = i;
            this.textColor = i2;
            this.icon = bitmap;
        }
    }

    public SpinWheelView(Context context) {
        super(context);
        this.segments = new ArrayList();
        this.paintFill = new Paint(1);
        this.paintBorder = new Paint(1);
        this.paintText = new Paint(1);
        this.paintSub = new Paint(1);
        this.paintPtr = new Paint(1);
        this.oval = new RectF();
        this.centerBitmap = null;
        this.wheelAngle = 0.0f;
        this.spinning = false;
        init();
    }

    public SpinWheelView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.segments = new ArrayList();
        this.paintFill = new Paint(1);
        this.paintBorder = new Paint(1);
        this.paintText = new Paint(1);
        this.paintSub = new Paint(1);
        this.paintPtr = new Paint(1);
        this.oval = new RectF();
        this.centerBitmap = null;
        this.wheelAngle = 0.0f;
        this.spinning = false;
        init();
    }

    public SpinWheelView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.segments = new ArrayList();
        this.paintFill = new Paint(1);
        this.paintBorder = new Paint(1);
        this.paintText = new Paint(1);
        this.paintSub = new Paint(1);
        this.paintPtr = new Paint(1);
        this.oval = new RectF();
        this.centerBitmap = null;
        this.wheelAngle = 0.0f;
        this.spinning = false;
        init();
    }

    private void init() {
        this.paintBorder.setStyle(Paint.Style.STROKE);
        this.paintBorder.setColor(-3632086);
        this.paintText.setTypeface(Typeface.create(Typeface.DEFAULT, 1));
        this.paintText.setTextAlign(Paint.Align.CENTER);
        this.paintSub.setTextAlign(Paint.Align.CENTER);
        this.paintSub.setColor(-3632086);
        this.paintPtr.setAntiAlias(true);
        try {
            this.centerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_spin_center);
        } catch (Exception unused) {
        }
    }

    public void setSegments(List<Segment> list) {
        this.segments.clear();
        this.segments.addAll(list);
        invalidate();
    }

    public boolean isSpinning() {
        return this.spinning;
    }

    public void spinToIndex(int i, long j, final Runnable runnable) {
        if (this.spinning || this.segments.isEmpty()) {
            return;
        }
        this.spinning = true;
        float size = 360.0f / this.segments.size();
        float f = (((270.0f - ((i * size) + (size / 2.0f))) % 360.0f) + 360.0f) % 360.0f;
        float f2 = this.wheelAngle;
        float f3 = (((f - (((f2 % 360.0f) + 360.0f) % 360.0f)) % 360.0f) + 360.0f) % 360.0f;
        if (f3 < 30.0f) {
            f3 += 360.0f;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, "wheelAngle", f2, 1800.0f + f2 + f3);
        objectAnimatorOfFloat.setDuration(j);
        objectAnimatorOfFloat.setInterpolator(new DecelerateInterpolator(3.0f));
        objectAnimatorOfFloat.addListener(new AnimatorListenerAdapter() { // from class: com.zeno.app.SpinWheelView.1
            @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
            public void onAnimationEnd(Animator animator) {
                SpinWheelView.this.spinning = false;
                Runnable runnable2 = runnable;
                if (runnable2 != null) {
                    runnable2.run();
                }
            }
        });
        objectAnimatorOfFloat.start();
    }

    public void setWheelAngle(float f) {
        this.wheelAngle = f;
        invalidate();
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        int i;
        float f;
        super.onDraw(canvas);
        if (this.segments.isEmpty()) {
            return;
        }
        float f2 = 2.0f;
        float width = getWidth() / 2.0f;
        float height = getHeight() / 2.0f;
        float fMin = Math.min(width, height) - dp(18.0f);
        float f3 = height - fMin;
        this.oval.set(width - fMin, f3, width + fMin, height + fMin);
        int size = this.segments.size();
        float f4 = 360.0f / size;
        canvas.save();
        canvas.rotate(this.wheelAngle % 360.0f, width, height);
        int i2 = 0;
        while (i2 < size) {
            Segment segment = this.segments.get(i2);
            float f5 = i2 * f4;
            this.paintFill.setColor(segment.bgColor);
            float f6 = f4;
            int i3 = i2;
            canvas.drawArc(this.oval, f5, f6, true, this.paintFill);
            this.paintBorder.setStrokeWidth(dp(1.5f));
            canvas.drawArc(this.oval, f5, f6, true, this.paintBorder);
            float f7 = 0.58f * fMin;
            double radians = Math.toRadians(f5 + (f4 / f2));
            float fCos = (((float) Math.cos(radians)) * f7) + width;
            float fSin = (f7 * ((float) Math.sin(radians))) + height;
            if (segment.icon != null) {
                float fDp = dp(28.0f);
                Rect rect = new Rect(0, 0, segment.icon.getWidth(), segment.icon.getHeight());
                float f8 = fDp / 2.0f;
                i = size;
                f = f4;
                canvas.drawBitmap(segment.icon, rect, new RectF(fCos - f8, (fSin - f8) - dp(6.0f), fCos + f8, (f8 + fSin) - dp(6.0f)), (Paint) null);
            } else {
                i = size;
                f = f4;
                if (segment.label != null && !segment.label.isEmpty()) {
                    this.paintText.setTextSize(dp(14.0f));
                    this.paintText.setColor(-1);
                    canvas.drawText(segment.label, fCos, fSin - dp(2.0f), this.paintText);
                }
            }
            if (segment.sub != null && !segment.sub.isEmpty()) {
                this.paintSub.setTextSize(dp(12.0f));
                this.paintSub.setColor(-1);
                this.paintSub.setTypeface(Typeface.create(Typeface.DEFAULT, 1));
                canvas.drawText(segment.sub, fCos, fSin + dp(18.0f), this.paintSub);
            }
            i2 = i3 + 1;
            size = i;
            f4 = f;
            f2 = 2.0f;
        }
        this.paintBorder.setStrokeWidth(dp(3.0f));
        canvas.drawCircle(width, height, fMin, this.paintBorder);
        this.paintFill.setColor(-15066598);
        canvas.drawCircle(width, height, dp(20.0f), this.paintFill);
        this.paintBorder.setStrokeWidth(dp(2.0f));
        canvas.drawCircle(width, height, dp(20.0f), this.paintBorder);
        if (this.centerBitmap != null) {
            float fDp2 = dp(34.0f) / 2.0f;
            canvas.drawBitmap(this.centerBitmap, new Rect(0, 0, this.centerBitmap.getWidth(), this.centerBitmap.getHeight()), new RectF(width - fDp2, height - fDp2, width + fDp2, height + fDp2), (Paint) null);
        }
        canvas.restore();
        float fDp3 = dp(8.0f) + f3;
        float fDp4 = f3 - dp(14.0f);
        float fDp5 = dp(10.0f);
        Path path = new Path();
        path.moveTo(width, fDp3);
        path.lineTo(width - fDp5, fDp4);
        path.lineTo(width + fDp5, fDp4);
        path.close();
        this.paintPtr.setStyle(Paint.Style.FILL);
        this.paintPtr.setColor(-1527744);
        canvas.drawPath(path, this.paintPtr);
        this.paintPtr.setStyle(Paint.Style.STROKE);
        this.paintPtr.setColor(-6260704);
        this.paintPtr.setStrokeWidth(dp(2.0f));
        canvas.drawPath(path, this.paintPtr);
    }

    private float dp(float f) {
        return f * getContext().getResources().getDisplayMetrics().density;
    }
}
