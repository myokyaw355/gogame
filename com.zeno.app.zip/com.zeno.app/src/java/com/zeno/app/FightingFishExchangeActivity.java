package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class FightingFishExchangeActivity extends BaseActivity {
    private static final String BASE = "https://fishio.mascom.vn";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private ExecutorService exec;
    private String gameToken;
    private LinearLayout llItems;
    private LinearLayout llLoading;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svItems;
    private TextView tvBananaBalance;
    private TextView tvEmpty;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).build();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_fighting_fish_exchange);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        String stringExtra = getIntent().getStringExtra("gameToken");
        this.gameToken = stringExtra;
        if (stringExtra == null) {
            this.gameToken = "";
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m390lambda$onCreate$0$comzenoappFightingFishExchangeActivity(view);
            }
        });
        TextView textView = (TextView) findViewById(R.id.tvTitle);
        if (textView != null) {
            textView.setText("Gem ဖြင့်လဲလှယ်မည်");
        }
        this.tvBananaBalance = (TextView) findViewById(R.id.tvBananaBalance);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svItems = findViewById(R.id.svItems);
        this.llItems = (LinearLayout) findViewById(R.id.llItems);
        TextView textView2 = this.tvBananaBalance;
        if (textView2 != null) {
            textView2.setText("---");
        }
        loadAll();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m390lambda$onCreate$0$comzenoappFightingFishExchangeActivity(View view) {
        finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void loadAll() {
        showLoading();
        final String str = this.gameToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m387lambda$loadAll$3$comzenoappFightingFishExchangeActivity(str);
            }
        });
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m389lambda$loadAll$5$comzenoappFightingFishExchangeActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadAll$3$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m387lambda$loadAll$3$comzenoappFightingFishExchangeActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://fishio.mascom.vn/api/user/info").get().addHeader("Accept", "*/*").addHeader("Authorization", "Bearer " + str).addHeader("Origin", BASE).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                final long jOptLong = 0;
                try {
                    JSONObject jSONObjectOptJSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "").optJSONObject("data");
                    if (jSONObjectOptJSONObject != null) {
                        JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("gameData");
                        long jOptLong2 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optLong("gem", jSONObjectOptJSONObject2.optLong("totalGem", 0L)) : 0L;
                        if (jOptLong2 == 0) {
                            try {
                                jOptLong = jSONObjectOptJSONObject.optLong("gem", 0L);
                            } catch (Exception unused) {
                                jOptLong = jOptLong2;
                            }
                        } else {
                            jOptLong = jOptLong2;
                        }
                    }
                } catch (Exception unused2) {
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m385lambda$loadAll$1$comzenoappFightingFishExchangeActivity(jOptLong);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception unused3) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m386lambda$loadAll$2$comzenoappFightingFishExchangeActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$1$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m385lambda$loadAll$1$comzenoappFightingFishExchangeActivity(long j) {
        TextView textView = this.tvBananaBalance;
        if (textView != null) {
            textView.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$2$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m386lambda$loadAll$2$comzenoappFightingFishExchangeActivity() {
        TextView textView = this.tvBananaBalance;
        if (textView != null) {
            textView.setText("---");
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$5$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m389lambda$loadAll$5$comzenoappFightingFishExchangeActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://fishio.mascom.vn/api/shop/item?typeCurrency=GEM").get().addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str).addHeader("Origin", BASE).addHeader("Referer", "https://fishio.mascom.vn/").addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda2
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m388lambda$loadAll$4$comzenoappFightingFishExchangeActivity(strString);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code());
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseItems, reason: merged with bridge method [inline-methods] */
    public void m388lambda$loadAll$4$comzenoappFightingFishExchangeActivity(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Item list မရပါ"));
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                this.llItems.removeAllViews();
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject != null) {
                        addItemRow(jSONObjectOptJSONObject);
                    }
                }
                SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
                this.skeletonAnim = null;
                LinearLayout linearLayout = this.llLoading;
                if (linearLayout != null) {
                    linearLayout.setVisibility(8);
                }
                this.tvEmpty.setVisibility(8);
                this.svItems.setVisibility(0);
                return;
            }
            showEmpty("Item မရှိပါ");
        } catch (Exception unused) {
            showEmpty("Parse error");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addItemRow(JSONObject jSONObject) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_fighting_fish_exchange, (ViewGroup) this.llItems, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivItemIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvItemName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvItemDesc);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvTotalCost);
        Button button = (Button) viewInflate.findViewById(R.id.btnExchange);
        final String strOptString = jSONObject.optString("code", "");
        final String strOptString2 = jSONObject.optString("name", strOptString);
        String strOptString3 = jSONObject.optString("description", "");
        int iOptInt = jSONObject.optInt("price", 0);
        final int iOptInt2 = jSONObject.optInt("value", 1);
        String strOptString4 = jSONObject.optString("icon", "");
        if (textView != null) {
            textView.setText(strOptString2);
        }
        if (textView2 != null) {
            textView2.setText(strOptString3);
        }
        if (textView3 != null) {
            textView3.setText(String.format(Locale.getDefault(), "%,d", Integer.valueOf(iOptInt)));
        }
        if (button != null) {
            button.setText("လဲမည်");
        }
        int iIconForCode = iconForCode(strOptString);
        if (imageView != null) {
            float f = getResources().getDisplayMetrics().density;
            int i = (int) (((iIconForCode == R.drawable.ic_ff_revive ? 52 : 46) * f) + 0.5f);
            ViewGroup.LayoutParams layoutParams = imageView.getLayoutParams();
            if (layoutParams != null) {
                layoutParams.width = i;
                layoutParams.height = i;
                imageView.setLayoutParams(layoutParams);
            }
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setAdjustViewBounds(true);
            imageView.setPadding(0, 0, 0, 0);
            if (iIconForCode != 0) {
                imageView.setImageResource(iIconForCode);
            } else if (ok(strOptString4)) {
                int i2 = (int) ((f * 46.0f) + 0.5f);
                if (layoutParams != null) {
                    layoutParams.width = i2;
                    layoutParams.height = i2;
                    imageView.setLayoutParams(layoutParams);
                }
                Glide.with(this).load(strOptString4).apply(new RequestOptions().placeholder(R.drawable.ic_gem_ff).error(R.drawable.ic_gem_ff).fitCenter().override(i2, i2)).into(imageView);
            } else {
                imageView.setImageResource(R.drawable.ic_gem_ff);
            }
        }
        if (textView3 != null) {
            textView3.setText(String.format(Locale.getDefault(), "%,d", Integer.valueOf(iOptInt)));
        }
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m381lambda$addItemRow$6$comzenoappFightingFishExchangeActivity(strOptString, iOptInt2, strOptString2, view);
                }
            });
        }
        this.llItems.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addItemRow$6$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m381lambda$addItemRow$6$comzenoappFightingFishExchangeActivity(String str, int i, String str2, View view) {
        buyItem(str, i, str2, 1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buyItem(final String str, int i, final String str2, int i2) {
        if (!ok(this.gameToken)) {
            Toast.makeText((Context) this, (CharSequence) "Login token မရှိပါ", 0).show();
            return;
        }
        final int i3 = i2 < 1 ? 1 : i2;
        Toast.makeText((Context) this, (CharSequence) "လဲလှယ်နေသည်...", 0).show();
        final String str3 = this.gameToken;
        final int i4 = i > 0 ? i : 1;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m384lambda$buyItem$9$comzenoappFightingFishExchangeActivity(str, i3, i4, str3, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyItem$9$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m384lambda$buyItem$9$comzenoappFightingFishExchangeActivity(String str, int i, int i2, String str2, String str3) {
        String str4;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("code", str);
            jSONObject.put("value", i);
            jSONObject.put("quantity", i);
            jSONObject.put("amount", i2 * i);
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://fishio.mascom.vn/api/shop/item").post(RequestBody.create(jSONObject.toString(), JSON)).addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str2).addHeader("Origin", BASE).addHeader("Referer", "https://fishio.mascom.vn/").addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                final boolean zOptBoolean = jSONObject2.optBoolean("success", false);
                final String strOptString = jSONObject2.optString("message", null);
                if (strOptString == null || strOptString.equals("null") || strOptString.isEmpty()) {
                    if (zOptBoolean) {
                        str4 = str3 + " × " + i + " ရရှိပါသည်";
                    } else {
                        str4 = "Error " + jSONObject2.optString("error", "");
                    }
                    strOptString = str4;
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda9
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m382lambda$buyItem$7$comzenoappFightingFishExchangeActivity(strOptString, zOptBoolean);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m383lambda$buyItem$8$comzenoappFightingFishExchangeActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyItem$7$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m382lambda$buyItem$7$comzenoappFightingFishExchangeActivity(String str, boolean z) {
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        if (z) {
            loadAll();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyItem$8$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m383lambda$buyItem$8$comzenoappFightingFishExchangeActivity(Exception exc) {
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void showLoading() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m392lambda$showLoading$10$comzenoappFightingFishExchangeActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showLoading$10$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m392lambda$showLoading$10$comzenoappFightingFishExchangeActivity() {
        this.llLoading.setVisibility(0);
        this.svItems.setVisibility(8);
        this.tvEmpty.setVisibility(8);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishExchangeActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m391lambda$showEmpty$11$comzenoappFightingFishExchangeActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$11$com-zeno-app-FightingFishExchangeActivity, reason: not valid java name */
    /* synthetic */ void m391lambda$showEmpty$11$comzenoappFightingFishExchangeActivity(String str) {
        this.llLoading.setVisibility(8);
        this.svItems.setVisibility(8);
        this.tvEmpty.setVisibility(0);
        this.tvEmpty.setText(str);
    }

    private int iconForCode(String str) {
        if (str == null) {
            return R.drawable.ic_gem_ff;
        }
        String upperCase = str.toUpperCase(Locale.ROOT);
        upperCase.hashCode();
        switch (upperCase) {
        }
        return R.drawable.ic_gem_ff;
    }

    private static boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
