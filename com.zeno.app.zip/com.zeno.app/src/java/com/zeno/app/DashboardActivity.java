package com.zeno.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.android.material.snackbar.Snackbar;
import com.zeno.app.LiveConfig;
import java.io.File;
import java.io.IOException;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class DashboardActivity extends BaseActivity {
    private static final String CONFIG_URL = "https://zenoofficial.x10.mx/myid/message.json";
    private static final int REQ_CROP_IMAGE = 4102;
    private static final int REQ_PICK_IMAGE = 4101;
    private ImageButton btnSettings;
    private View cardBeatZoo;
    private View cardCarRacing;
    private View cardData;
    private View cardFightingFish;
    private View cardKittyFall;
    private View cardKongIsland;
    private View cardMyIDGo;
    private View cardPoints;
    private View cardSoftClimbers;
    private ConnectivityManager connectivityManager;
    private ImageView ivAvatar;
    private ImageView ivCamera;
    private ImageView ivEditName;
    private ImageView ivKongIslandIcon;
    private ImageView ivRankStar;
    private View layoutBalances;
    private View layoutLoading;
    private GridLayout miniGamesGrid;
    private View miniGamesSkeleton;
    private ValueAnimator miniGamesSkeletonAnim;
    private ValueAnimator monthlySkeletonAnim;
    private View monthlyUsageContent;
    private View monthlyUsageSkeleton;
    private ConnectivityManager.NetworkCallback networkCallback;
    private Snackbar noInternetSnackbar;
    private View profileContent;
    private View profileSkeleton;
    private ValueAnimator profileSkeletonAnim;
    private ProgressBar progressPoints;
    private SessionManager sessionManager;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvData;
    private TextView tvFullName;
    private TextView tvMainBalance;
    private TextView tvMonthlyTotal;
    private TextView tvPhone;
    private TextView tvPointUsage;
    private TextView tvPoints;
    private TextView tvRankName;
    private TextView tvVoice;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient();
    private String currentBirthDate = "";
    private String currentGender = "male";
    private int currentPoints = 0;
    private String currentRank = "";
    private final AtomicInteger pendingRequests = new AtomicInteger(0);
    private boolean wasOffline = false;
    private final LiveConfig.Listener liveConfigListener = new LiveConfig.Listener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda13
        @Override // com.zeno.app.LiveConfig.Listener
        public final void onConfig(RemoteConfig remoteConfig) {
            this.f$0.m294lambda$new$1$comzenoappDashboardActivity(remoteConfig);
        }
    };

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(R.color.yellow_primary, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_dashboard);
        SessionManager sessionManager = new SessionManager(this);
        this.sessionManager = sessionManager;
        if (!sessionManager.isLoggedIn()) {
            startActivity(new Intent((Context) this, (Class<?>) LoginActivity.class));
            finish();
            return;
        }
        requestNotificationPermissionIfNeeded();
        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("ZenoMyID");
        }
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{getResources().getColor(R.color.yellow_primary, getTheme())});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.bg_card, getTheme()));
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda15
            public final void onRefresh() {
                this.f$0.m295lambda$onCreate$0$comzenoappDashboardActivity();
            }
        });
        bindViews();
        loadSavedUserInfo();
        setupNetworkMonitor();
        handleRemoteConfigDialogs();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m295lambda$onCreate$0$comzenoappDashboardActivity() {
        LiveConfig.refreshNow();
        loadAllData();
    }

    private void setupNetworkMonitor() {
        this.connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        this.wasOffline = true;
        this.networkCallback = new AnonymousClass1();
        this.connectivityManager.registerNetworkCallback(new NetworkRequest.Builder().addCapability(12).addCapability(16).build(), this.networkCallback);
        if (isConnected()) {
            return;
        }
        showNoInternetSnackbar();
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
    class AnonymousClass1 extends ConnectivityManager.NetworkCallback {
        AnonymousClass1() {
        }

        @Override // android.net.ConnectivityManager.NetworkCallback
        public void onAvailable(Network network) {
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m298lambda$onAvailable$0$comzenoappDashboardActivity$1();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onAvailable$0$com-zeno-app-DashboardActivity$1, reason: not valid java name */
        /* synthetic */ void m298lambda$onAvailable$0$comzenoappDashboardActivity$1() {
            DashboardActivity.this.dismissNoInternetSnackbar();
            if (DashboardActivity.this.wasOffline) {
                DashboardActivity.this.wasOffline = false;
                DashboardActivity.this.loadAllData();
            }
        }

        @Override // android.net.ConnectivityManager.NetworkCallback
        public void onLost(Network network) {
            DashboardActivity.this.uiHandler.postDelayed(new Runnable() { // from class: com.zeno.app.DashboardActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m299lambda$onLost$1$comzenoappDashboardActivity$1();
                }
            }, 300L);
        }

        /* JADX INFO: renamed from: lambda$onLost$1$com-zeno-app-DashboardActivity$1, reason: not valid java name */
        /* synthetic */ void m299lambda$onLost$1$comzenoappDashboardActivity$1() {
            if (DashboardActivity.this.isConnected()) {
                return;
            }
            DashboardActivity.this.wasOffline = true;
            DashboardActivity.this.showNoInternetSnackbar();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isConnected() {
        Network activeNetwork;
        NetworkCapabilities networkCapabilities;
        ConnectivityManager connectivityManager = this.connectivityManager;
        return (connectivityManager == null || (activeNetwork = connectivityManager.getActiveNetwork()) == null || (networkCapabilities = this.connectivityManager.getNetworkCapabilities(activeNetwork)) == null || !networkCapabilities.hasCapability(12)) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showNoInternetSnackbar() {
        View viewFindViewById;
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Snackbar snackbar = this.noInternetSnackbar;
        if ((snackbar == null || !snackbar.isShown()) && (viewFindViewById = findViewById(android.R.id.content)) != null) {
            Snackbar snackbarMake = Snackbar.make(viewFindViewById, "အင်တာနက်ချိပ်ဆက်ထားခြင်းမရှိပါ", -2);
            this.noInternetSnackbar = snackbarMake;
            View view = snackbarMake.getView();
            ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
            view.setLayoutParams(view.getLayoutParams());
            this.noInternetSnackbar.show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissNoInternetSnackbar() {
        Snackbar snackbar = this.noInternetSnackbar;
        if (snackbar == null || !snackbar.isShown()) {
            return;
        }
        this.noInternetSnackbar.dismiss();
        this.noInternetSnackbar = null;
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        String phone;
        super.onResume();
        RemoteConfig remoteConfigCurrent = LiveConfig.current();
        if (remoteConfigCurrent != null) {
            m294lambda$new$1$comzenoappDashboardActivity(remoteConfigCurrent);
        } else {
            hideAllGameCards();
        }
        LiveConfig.addListener(this.liveConfigListener);
        LiveConfig.refreshNow();
        SessionManager sessionManager = this.sessionManager;
        if (sessionManager == null || !sessionManager.isLoggedIn()) {
            return;
        }
        loadSavedUserInfo();
        if (this.tvPhone != null && (phone = this.sessionManager.getPhone()) != null) {
            this.tvPhone.setText(phone);
        }
        String accessToken = this.sessionManager.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            return;
        }
        fetchCustomer(accessToken);
        String phone2 = this.sessionManager.getPhone();
        String deviceId = this.sessionManager.getDeviceId();
        if (phone2 != null && !phone2.isEmpty()) {
            fetchLoyaltyInquiry(phone2, accessToken, deviceId);
            fetchAccountDetail(phone2, accessToken, deviceId);
        }
        fetchLoyaltyCsm(accessToken, deviceId);
    }

    protected void onPause() {
        super.onPause();
        LiveConfig.removeListener(this.liveConfigListener);
    }

    protected void onDestroy() {
        ConnectivityManager.NetworkCallback networkCallback;
        super.onDestroy();
        LiveConfig.removeListener(this.liveConfigListener);
        ConnectivityManager connectivityManager = this.connectivityManager;
        if (connectivityManager == null || (networkCallback = this.networkCallback) == null) {
            return;
        }
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        } catch (Exception unused) {
        }
    }

    private void hideAllGameCards() {
        View view = this.cardKongIsland;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.cardKittyFall;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.cardSoftClimbers;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        View view4 = this.cardMyIDGo;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        View view5 = this.cardBeatZoo;
        if (view5 != null) {
            view5.setVisibility(8);
        }
        View view6 = this.cardCarRacing;
        if (view6 != null) {
            view6.setVisibility(8);
        }
        View view7 = this.cardFightingFish;
        if (view7 != null) {
            view7.setVisibility(8);
        }
        reflowMiniGameCards();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: applyGameCardVisibility, reason: merged with bridge method [inline-methods] */
    public void m294lambda$new$1$comzenoappDashboardActivity(RemoteConfig remoteConfig) {
        if (remoteConfig == null) {
            return;
        }
        setCardState(this.cardKongIsland, remoteConfig.showKongIsland);
        setCardState(this.cardKittyFall, remoteConfig.showKittyFall);
        setCardState(this.cardSoftClimbers, remoteConfig.showSoftClimber);
        setCardState(this.cardMyIDGo, remoteConfig.showMyIDGo);
        setCardState(this.cardBeatZoo, remoteConfig.showBeatZoo);
        setCardState(this.cardCarRacing, remoteConfig.showCarRacing);
        setCardState(this.cardFightingFish, remoteConfig.showFightingFish);
        reflowMiniGameCards();
    }

    private void setCardState(View view, boolean z) {
        if (view == null) {
            return;
        }
        view.setVisibility(0);
        LockedCardOverlay.apply(view, !z);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean blockIfLocked(View view, String str) {
        if (!LockedCardOverlay.isLocked(view)) {
            return false;
        }
        RemoteConfig remoteConfigCurrent = LiveConfig.current();
        ZDialog.showGameLocked(this, remoteConfigCurrent != null ? remoteConfigCurrent.lockedText(str, "title", "Game Locked") : "Game Locked", remoteConfigCurrent != null ? remoteConfigCurrent.lockedText(str, "message", "ဤ Game ကို Owner မှ ယာယီပိတ်ထားပါသည်။") : "ဤ Game ကို Owner မှ ယာယီပိတ်ထားပါသည်။", remoteConfigCurrent != null ? remoteConfigCurrent.lockedText(str, "btn", "OK") : "OK");
        return true;
    }

    private void reflowMiniGameCards() {
        if (this.miniGamesGrid == null) {
            return;
        }
        View[] viewArr = {this.cardKongIsland, this.cardKittyFall, this.cardSoftClimbers, this.cardCarRacing, this.cardBeatZoo, this.cardFightingFish, this.cardMyIDGo};
        for (int i = 0; i < 7; i++) {
            View view = viewArr[i];
            if (view != null) {
                ViewParent parent = view.getParent();
                GridLayout gridLayout = this.miniGamesGrid;
                if (parent == gridLayout) {
                    gridLayout.removeView(view);
                }
            }
        }
        for (int i2 = 0; i2 < 7; i2++) {
            View view2 = viewArr[i2];
            if (view2 != null && view2.getVisibility() == 0) {
                if (!(view2.getLayoutParams() instanceof GridLayout.LayoutParams)) {
                    GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                    layoutParams.width = 0;
                    layoutParams.height = -2;
                    layoutParams.columnSpec = GridLayout.spec(Integer.MIN_VALUE, 1.0f);
                    layoutParams.setGravity(119);
                    int i3 = (int) getResources().getDisplayMetrics().density;
                    int i4 = i3 * 6;
                    layoutParams.setMargins(i4, 0, i4, i3 * 12);
                    view2.setLayoutParams(layoutParams);
                }
                this.miniGamesGrid.addView(view2);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void handleRemoteConfigDialogs() {
        Intent intent = getIntent();
        if (intent == null || intent.getStringExtra("cfg_version") == null) {
            return;
        }
        String stringExtra = intent.getStringExtra("cfg_notif_title");
        String stringExtra2 = intent.getStringExtra("cfg_notif_text");
        String stringExtra3 = intent.getStringExtra("cfg_notif_link");
        String stringExtra4 = intent.getStringExtra("cfg_notif_btn");
        String stringExtra5 = intent.getStringExtra("cfg_notif_image");
        if (LiveConfig.needsUpdate(this, LiveConfig.current()) || stringExtra == null || stringExtra.isEmpty()) {
            return;
        }
        if (stringExtra2 == null) {
            stringExtra2 = "";
        }
        String str = stringExtra3 != null ? stringExtra3 : "";
        String str2 = (stringExtra4 == null || stringExtra4.isEmpty()) ? "Open" : stringExtra4;
        if (stringExtra5 == null) {
            stringExtra5 = "";
        }
        ZDialog.showNotification(this, stringExtra, stringExtra2, str, str2, stringExtra5, null);
    }

    private void bindViews() {
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        this.profileSkeleton = findViewById(R.id.profile_skeleton);
        this.profileContent = findViewById(R.id.profile_content);
        this.layoutLoading = findViewById(R.id.layout_loading);
        this.monthlyUsageSkeleton = findViewById(R.id.monthlyUsageSkeleton);
        this.monthlyUsageContent = findViewById(R.id.monthlyUsageContent);
        this.miniGamesSkeleton = findViewById(R.id.miniGamesSkeleton);
        this.layoutBalances = findViewById(R.id.layout_balances);
        this.ivCamera = (ImageView) findViewById(R.id.ivCamera);
        this.ivEditName = (ImageView) findViewById(R.id.ivEditName);
        this.tvFullName = (TextView) findViewById(R.id.tvFullName);
        this.tvPhone = (TextView) findViewById(R.id.tvPhone);
        ImageView imageView = this.ivEditName;
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda19
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m285lambda$bindViews$2$comzenoappDashboardActivity(view);
                }
            });
        }
        TextView textView = this.tvFullName;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m286lambda$bindViews$3$comzenoappDashboardActivity(view);
                }
            });
        }
        ImageView imageView2 = this.ivCamera;
        if (imageView2 != null) {
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m287lambda$bindViews$4$comzenoappDashboardActivity(view);
                }
            });
        }
        ImageView imageView3 = this.ivAvatar;
        if (imageView3 != null) {
            imageView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m288lambda$bindViews$5$comzenoappDashboardActivity(view);
                }
            });
        }
        this.tvPointUsage = (TextView) findViewById(R.id.tvPointUsage);
        this.tvMonthlyTotal = (TextView) findViewById(R.id.tvMonthlyTotal);
        this.progressPoints = (ProgressBar) findViewById(R.id.progressPoints);
        this.tvMainBalance = (TextView) findViewById(R.id.tvMainBalance);
        this.tvData = (TextView) findViewById(R.id.tvData);
        this.tvVoice = (TextView) findViewById(R.id.tvVoice);
        this.tvPoints = (TextView) findViewById(R.id.tvPoints);
        this.tvRankName = (TextView) findViewById(R.id.tvRankName);
        this.ivRankStar = (ImageView) findViewById(R.id.ivRankStar);
        ImageButton imageButton = (ImageButton) findViewById(R.id.btnSettings);
        this.btnSettings = imageButton;
        if (imageButton != null) {
            imageButton.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda7
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m289lambda$bindViews$6$comzenoappDashboardActivity(view);
                }
            });
        }
        ImageView imageView4 = (ImageView) findViewById(R.id.btnGiftDailyQuest);
        if (imageView4 != null) {
            imageView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda8
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m290lambda$bindViews$7$comzenoappDashboardActivity(view);
                }
            });
            startGiftPulse(imageView4);
        }
        View viewFindViewById = findViewById(R.id.cardPoints);
        this.cardPoints = viewFindViewById;
        viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m291lambda$bindViews$8$comzenoappDashboardActivity(view);
            }
        });
        View viewFindViewById2 = findViewById(R.id.cardData);
        this.cardData = viewFindViewById2;
        viewFindViewById2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m292lambda$bindViews$9$comzenoappDashboardActivity(view);
            }
        });
        View viewFindViewById3 = findViewById(R.id.cardMyIDGo);
        this.cardMyIDGo = viewFindViewById3;
        viewFindViewById3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m278lambda$bindViews$10$comzenoappDashboardActivity(view);
            }
        });
        View viewFindViewById4 = findViewById(R.id.cardSoftClimbers);
        this.cardSoftClimbers = viewFindViewById4;
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m279lambda$bindViews$11$comzenoappDashboardActivity(view);
                }
            });
        }
        View viewFindViewById5 = findViewById(R.id.cardKongIsland);
        this.cardKongIsland = viewFindViewById5;
        if (viewFindViewById5 != null) {
            viewFindViewById5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda20
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m280lambda$bindViews$12$comzenoappDashboardActivity(view);
                }
            });
        }
        View viewFindViewById6 = findViewById(R.id.cardKittyFall);
        this.cardKittyFall = viewFindViewById6;
        if (viewFindViewById6 != null) {
            viewFindViewById6.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda21
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m281lambda$bindViews$13$comzenoappDashboardActivity(view);
                }
            });
        }
        ImageView imageView5 = (ImageView) findViewById(R.id.ivKongIslandIcon);
        this.ivKongIslandIcon = imageView5;
        if (imageView5 != null) {
            imageView5.setImageResource(R.drawable.ic_kong_island);
        }
        View viewFindViewById7 = findViewById(R.id.cardCarRacing);
        this.cardCarRacing = viewFindViewById7;
        if (viewFindViewById7 != null) {
            viewFindViewById7.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda22
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m282lambda$bindViews$14$comzenoappDashboardActivity(view);
                }
            });
        }
        View viewFindViewById8 = findViewById(R.id.cardBeatZoo);
        this.cardBeatZoo = viewFindViewById8;
        if (viewFindViewById8 != null) {
            viewFindViewById8.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m283lambda$bindViews$15$comzenoappDashboardActivity(view);
                }
            });
        }
        this.cardFightingFish = findViewById(R.id.cardFightingFish);
        this.miniGamesGrid = (GridLayout) findViewById(R.id.miniGamesGrid);
        View view = this.cardFightingFish;
        if (view != null) {
            view.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m284lambda$bindViews$16$comzenoappDashboardActivity(view2);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m285lambda$bindViews$2$comzenoappDashboardActivity(View view) {
        showEditNameDialog();
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m286lambda$bindViews$3$comzenoappDashboardActivity(View view) {
        showEditNameDialog();
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m287lambda$bindViews$4$comzenoappDashboardActivity(View view) {
        openGalleryForAvatar();
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m288lambda$bindViews$5$comzenoappDashboardActivity(View view) {
        openGalleryForAvatar();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m289lambda$bindViews$6$comzenoappDashboardActivity(View view) {
        try {
            new AccountManager(this).saveFromSession(this.sessionManager);
        } catch (Exception unused) {
        }
        startActivity(new Intent((Context) this, (Class<?>) AccountsActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m290lambda$bindViews$7$comzenoappDashboardActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) DailyClaimActivity.class));
    }

    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m291lambda$bindViews$8$comzenoappDashboardActivity(View view) {
        openPointsBottomSheet();
    }

    /* JADX INFO: renamed from: lambda$bindViews$9$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m292lambda$bindViews$9$comzenoappDashboardActivity(View view) {
        openDataPackages();
    }

    /* JADX INFO: renamed from: lambda$bindViews$10$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m278lambda$bindViews$10$comzenoappDashboardActivity(View view) {
        openMyIDGo();
    }

    /* JADX INFO: renamed from: lambda$bindViews$11$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m279lambda$bindViews$11$comzenoappDashboardActivity(View view) {
        openSoftClimbers();
    }

    /* JADX INFO: renamed from: lambda$bindViews$12$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m280lambda$bindViews$12$comzenoappDashboardActivity(View view) {
        openKongIsland();
    }

    /* JADX INFO: renamed from: lambda$bindViews$13$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m281lambda$bindViews$13$comzenoappDashboardActivity(View view) {
        openKittyFall();
    }

    /* JADX INFO: renamed from: lambda$bindViews$14$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m282lambda$bindViews$14$comzenoappDashboardActivity(View view) {
        openCarRacing();
    }

    /* JADX INFO: renamed from: lambda$bindViews$15$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m283lambda$bindViews$15$comzenoappDashboardActivity(View view) {
        openBeatZoo();
    }

    /* JADX INFO: renamed from: lambda$bindViews$16$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m284lambda$bindViews$16$comzenoappDashboardActivity(View view) {
        openFightingFish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openDataPackages() {
        Intent intent = new Intent((Context) this, (Class<?>) DataPackagesActivity.class);
        intent.putExtra("phone", this.sessionManager.getPhone());
        startActivity(intent);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openMyIDGo() {
        if (blockIfLocked(this.cardMyIDGo, "myidgo")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) MyIDGoActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openSoftClimbers() {
        if (blockIfLocked(this.cardSoftClimbers, "softclimber")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) SoftClimbersActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openKongIsland() {
        if (blockIfLocked(this.cardKongIsland, "kongisland")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) KongIslandActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openKittyFall() {
        if (blockIfLocked(this.cardKittyFall, "kittyfall")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) KittyFallActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openCarRacing() {
        if (blockIfLocked(this.cardCarRacing, "carracing")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) CarRacingActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openBeatZoo() {
        if (blockIfLocked(this.cardBeatZoo, "beatzoo")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) BeatZooActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openFightingFish() {
        if (blockIfLocked(this.cardFightingFish, "fightingfish")) {
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) FightingFishActivity.class));
    }

    private void openPointsBottomSheet() {
        PointsBottomSheet.newInstance(this.sessionManager.getPhone(), this.currentPoints, this.currentRank).show(getSupportFragmentManager(), "PointsBottomSheet");
    }

    private void loadSavedUserInfo() {
        if (this.tvPhone != null) {
            String phone = this.sessionManager.getPhone();
            TextView textView = this.tvPhone;
            if (phone == null) {
                phone = "";
            }
            textView.setText(phone);
        }
        if (this.tvFullName != null) {
            String fullName = this.sessionManager.getFullName();
            TextView textView2 = this.tvFullName;
            if (fullName == null || fullName.isEmpty()) {
                fullName = "Loading...";
            }
            textView2.setText(fullName);
        }
        if (this.ivAvatar != null) {
            String avatarUrl = this.sessionManager.getAvatarUrl();
            if (avatarUrl != null && !avatarUrl.isEmpty()) {
                Glide.with(this).load(avatarUrl).transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).into(this.ivAvatar);
            } else {
                this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadAllData() {
        showSkeletonLoading();
        this.pendingRequests.set(4);
        String accessToken = this.sessionManager.getAccessToken();
        String phone = this.sessionManager.getPhone();
        String deviceId = this.sessionManager.getDeviceId();
        fetchCustomer(accessToken);
        fetchLoyaltyInquiry(phone, accessToken, deviceId);
        fetchLoyaltyCsm(accessToken, deviceId);
        fetchAccountDetail(phone, accessToken, deviceId);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onRequestDone() {
        if (this.pendingRequests.decrementAndGet() == 0) {
            this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m296lambda$onRequestDone$17$comzenoappDashboardActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$onRequestDone$17$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m296lambda$onRequestDone$17$comzenoappDashboardActivity() {
        hideSkeletonLoading();
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$2, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass2 implements Callback {
        AnonymousClass2() {
        }

        public void onFailure(Call call, IOException iOException) {
            DashboardActivity.this.onRequestDone();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m300lambda$onResponse$0$comzenoappDashboardActivity$2(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$0$com-zeno-app-DashboardActivity$2, reason: not valid java name */
        /* synthetic */ void m300lambda$onResponse$0$comzenoappDashboardActivity$2(String str) {
            try {
                JSONObject jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("result");
                if (jSONObjectOptJSONObject != null) {
                    String strOptString = jSONObjectOptJSONObject.optString("fullName", "");
                    DashboardActivity.this.currentBirthDate = jSONObjectOptJSONObject.optString("birthDate", "");
                    DashboardActivity.this.currentGender = jSONObjectOptJSONObject.optString("gender", "male");
                    if (DashboardActivity.this.currentGender == null || DashboardActivity.this.currentGender.isEmpty()) {
                        DashboardActivity.this.currentGender = "male";
                    }
                    String str2 = "Unknown";
                    DashboardActivity.this.tvFullName.setText(strOptString.isEmpty() ? "Unknown" : strOptString);
                    JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("externalRefs");
                    if (jSONArrayOptJSONArray != null) {
                        int i = 0;
                        while (true) {
                            if (i >= jSONArrayOptJSONArray.length()) {
                                break;
                            }
                            JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                            if ("avatar_img".equals(jSONObject.optString("type"))) {
                                String strOptString2 = jSONObject.optString("href", "");
                                DashboardActivity.this.sessionManager.saveUserInfo(DashboardActivity.this.sessionManager.getPhone(), strOptString, strOptString2);
                                if (DashboardActivity.this.tvPhone != null) {
                                    DashboardActivity.this.tvPhone.setText(DashboardActivity.this.sessionManager.getPhone());
                                }
                                if (DashboardActivity.this.tvFullName != null) {
                                    TextView textView = DashboardActivity.this.tvFullName;
                                    if (!strOptString.isEmpty()) {
                                        str2 = strOptString;
                                    }
                                    textView.setText(str2);
                                }
                                Glide.with(DashboardActivity.this).load(strOptString2).transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).into(DashboardActivity.this.ivAvatar);
                                try {
                                    new AccountManager(DashboardActivity.this).saveFromSession(DashboardActivity.this.sessionManager);
                                } catch (Exception unused) {
                                }
                            } else {
                                i++;
                            }
                        }
                    } else {
                        DashboardActivity.this.sessionManager.saveUserInfo(DashboardActivity.this.sessionManager.getPhone(), strOptString, "");
                    }
                    if (DashboardActivity.this.tvPhone != null) {
                        DashboardActivity.this.tvPhone.setText(DashboardActivity.this.sessionManager.getPhone());
                    }
                    if (DashboardActivity.this.tvFullName != null && !strOptString.isEmpty()) {
                        DashboardActivity.this.tvFullName.setText(strOptString);
                    }
                    new AccountManager(DashboardActivity.this).saveFromSession(DashboardActivity.this.sessionManager);
                }
            } catch (Exception unused2) {
            }
            DashboardActivity.this.onRequestDone();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchCustomer(String str) {
        ApiClient.getCustomer(str, new AnonymousClass2());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:32:0x0067  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void applyRankStarColor(java.lang.String r7) {
        /*
            r6 = this;
            android.widget.ImageView r0 = r6.ivRankStar
            if (r0 != 0) goto L5
            return
        L5:
            if (r7 != 0) goto La
            java.lang.String r7 = ""
            goto L14
        La:
            java.lang.String r7 = r7.trim()
            java.util.Locale r0 = java.util.Locale.ROOT
            java.lang.String r7 = r7.toLowerCase(r0)
        L14:
            int r0 = r7.hashCode()
            r1 = 5
            r2 = 4
            r3 = 3
            r4 = 2
            r5 = 1
            switch(r0) {
                case -1199426219: goto L5d;
                case -902311155: goto L53;
                case 3178592: goto L49;
                case 3511770: goto L3f;
                case 1233099618: goto L35;
                case 1655054676: goto L2b;
                case 1874772524: goto L21;
                default: goto L20;
            }
        L20:
            goto L67
        L21:
            java.lang.String r0 = "platinum"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 2
            goto L68
        L2b:
            java.lang.String r0 = "diamond"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 3
            goto L68
        L35:
            java.lang.String r0 = "welcome"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 6
            goto L68
        L3f:
            java.lang.String r0 = "ruby"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 4
            goto L68
        L49:
            java.lang.String r0 = "gold"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 1
            goto L68
        L53:
            java.lang.String r0 = "silver"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 0
            goto L68
        L5d:
            java.lang.String r0 = "swarovski"
            boolean r7 = r7.equals(r0)
            if (r7 == 0) goto L67
            r7 = 5
            goto L68
        L67:
            r7 = -1
        L68:
            if (r7 == 0) goto L8b
            if (r7 == r5) goto L88
            if (r7 == r4) goto L84
            if (r7 == r3) goto L80
            if (r7 == r2) goto L7c
            if (r7 == r1) goto L78
            r7 = -6381922(0xffffffffff9e9e9e, float:NaN)
            goto L8e
        L78:
            r7 = -1447425(0xffffffffffe9e9ff, float:NaN)
            goto L8e
        L7c:
            r7 = -2092705(0xffffffffffe0115f, float:NaN)
            goto L8e
        L80:
            r7 = -8461328(0xffffffffff7ee3f0, float:-3.3880743E38)
            goto L8e
        L84:
            r7 = -4602162(0xffffffffffb9c6ce, float:NaN)
            goto L8e
        L88:
            r7 = -10496(0xffffffffffffd700, float:NaN)
            goto L8e
        L8b:
            r7 = -4144960(0xffffffffffc0c0c0, float:NaN)
        L8e:
            android.widget.ImageView r0 = r6.ivRankStar
            android.content.res.ColorStateList r7 = android.content.res.ColorStateList.valueOf(r7)
            r0.setImageTintList(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.DashboardActivity.applyRankStarColor(java.lang.String):void");
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$3, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass3 implements Callback {
        AnonymousClass3() {
        }

        public void onFailure(Call call, IOException iOException) {
            DashboardActivity.this.onRequestDone();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m301lambda$onResponse$0$comzenoappDashboardActivity$3(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$0$com-zeno-app-DashboardActivity$3, reason: not valid java name */
        /* synthetic */ void m301lambda$onResponse$0$comzenoappDashboardActivity$3(String str) {
            int iOptInt;
            try {
                JSONObject jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("result");
                if (jSONObjectOptJSONObject != null) {
                    DashboardActivity.this.currentRank = jSONObjectOptJSONObject.optString("rankName", "--");
                    DashboardActivity.this.currentPoints = jSONObjectOptJSONObject.optInt("exchangePoints", 0);
                    DashboardActivity.this.tvRankName.setText(DashboardActivity.this.currentRank);
                    DashboardActivity dashboardActivity = DashboardActivity.this;
                    dashboardActivity.applyRankStarColor(dashboardActivity.currentRank);
                    DashboardActivity.this.tvPoints.setText(String.valueOf(DashboardActivity.this.currentPoints));
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("extendInfo");
                    int i = 10000;
                    if (jSONObjectOptJSONObject2 != null) {
                        iOptInt = jSONObjectOptJSONObject2.optInt("exchanged", 0);
                        int iOptInt2 = jSONObjectOptJSONObject2.optInt("currentLimit", 0);
                        if (iOptInt2 <= 0) {
                            iOptInt2 = jSONObjectOptJSONObject2.optInt("monthlyLimit", 10000);
                        }
                        if (iOptInt2 > 0) {
                            i = iOptInt2;
                        }
                    } else {
                        try {
                            iOptInt = (Integer.parseInt(jSONObjectOptJSONObject.optString("progress", "0").trim()) * 10000) / 100;
                        } catch (NumberFormatException unused) {
                            iOptInt = 0;
                        }
                    }
                    DashboardActivity.this.tvPointUsage.setText(iOptInt + " used");
                    DashboardActivity.this.tvMonthlyTotal.setText(String.format(Locale.getDefault(), "%,d/%,d Total", Integer.valueOf(iOptInt), Integer.valueOf(i)));
                    DashboardActivity.this.progressPoints.setMax(i);
                    DashboardActivity.this.progressPoints.setProgress(iOptInt);
                }
            } catch (Exception unused2) {
            }
            DashboardActivity.this.onRequestDone();
        }
    }

    private void fetchLoyaltyInquiry(String str, String str2, String str3) {
        ApiClient.getLoyaltyInquiry(str, str2, str3, new AnonymousClass3());
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$4, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass4 implements Callback {
        AnonymousClass4() {
        }

        public void onFailure(Call call, IOException iOException) {
            DashboardActivity.this.onRequestDone();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$4$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m302lambda$onResponse$0$comzenoappDashboardActivity$4(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$0$com-zeno-app-DashboardActivity$4, reason: not valid java name */
        /* synthetic */ void m302lambda$onResponse$0$comzenoappDashboardActivity$4(String str) {
            try {
                JSONObject jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("result");
                if (jSONObjectOptJSONObject != null) {
                    DashboardActivity.this.currentRank = jSONObjectOptJSONObject.optString("name", "--");
                    DashboardActivity.this.tvRankName.setText(DashboardActivity.this.currentRank);
                    DashboardActivity dashboardActivity = DashboardActivity.this;
                    dashboardActivity.applyRankStarColor(dashboardActivity.currentRank);
                    JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("balances");
                    if (jSONArrayOptJSONArray != null) {
                        for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                            JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                            if ("TELCO_EXCHANGEABLE_POINTS".equals(jSONObject.optString("loyaltyBalanceCode"))) {
                                DashboardActivity.this.currentPoints = jSONObject.optInt("balance", 0);
                                DashboardActivity.this.tvPoints.setText(String.valueOf(DashboardActivity.this.currentPoints));
                            }
                        }
                    }
                }
            } catch (Exception unused) {
            }
            DashboardActivity.this.onRequestDone();
        }
    }

    private void fetchLoyaltyCsm(String str, String str2) {
        ApiClient.getLoyaltyCsm(str, str2, new AnonymousClass4());
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$5, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass5 implements Callback {
        AnonymousClass5() {
        }

        public void onFailure(Call call, IOException iOException) {
            DashboardActivity.this.onRequestDone();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$5$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m303lambda$onResponse$0$comzenoappDashboardActivity$5(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$0$com-zeno-app-DashboardActivity$5, reason: not valid java name */
        /* synthetic */ void m303lambda$onResponse$0$comzenoappDashboardActivity$5(String str) {
            JSONObject jSONObject;
            try {
                JSONArray jSONArrayOptJSONArray = new JSONObject(str).optJSONArray("result");
                if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0) {
                    int i = 0;
                    while (true) {
                        if (i >= jSONArrayOptJSONArray.length()) {
                            jSONObject = null;
                            break;
                        }
                        jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                        if (jSONObject.optBoolean("mytel", false)) {
                            break;
                        } else {
                            i++;
                        }
                    }
                    if (jSONObject == null) {
                        jSONObject = jSONArrayOptJSONArray.getJSONObject(0);
                    }
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("mainBalance");
                    if (jSONObjectOptJSONObject != null) {
                        JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("main");
                        JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject.optJSONObject("data");
                        JSONObject jSONObjectOptJSONObject4 = jSONObjectOptJSONObject.optJSONObject("voice");
                        if (jSONObjectOptJSONObject2 != null) {
                            DashboardActivity.this.tvMainBalance.setText(jSONObjectOptJSONObject2.optInt("amount", 0) + " " + jSONObjectOptJSONObject2.optString("unit", "Ks"));
                        }
                        if (jSONObjectOptJSONObject3 != null) {
                            DashboardActivity.this.tvData.setText(jSONObjectOptJSONObject3.optInt("amount", 0) + " " + jSONObjectOptJSONObject3.optString("unit", "MB"));
                        }
                        if (jSONObjectOptJSONObject4 != null) {
                            DashboardActivity.this.tvVoice.setText(jSONObjectOptJSONObject4.optInt("amount", 0) + " " + jSONObjectOptJSONObject4.optString("unit", "Min"));
                        }
                    }
                }
            } catch (Exception unused) {
            }
            DashboardActivity.this.onRequestDone();
        }
    }

    private void fetchAccountDetail(String str, String str2, String str3) {
        ApiClient.getAccountDetail(str, str2, str3, new AnonymousClass5());
    }

    private void startGiftPulse(View view) {
        try {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_X, 1.0f, 1.18f, 1.0f);
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_Y, 1.0f, 1.18f, 1.0f);
            objectAnimatorOfFloat.setDuration(900L);
            objectAnimatorOfFloat2.setDuration(900L);
            objectAnimatorOfFloat.setRepeatCount(-1);
            objectAnimatorOfFloat2.setRepeatCount(-1);
            objectAnimatorOfFloat.start();
            objectAnimatorOfFloat2.start();
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != 0) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.POST_NOTIFICATIONS"}, 1001);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmLogout() {
        ZDialog.confirm(this, "Logout", "Are you sure you want to logout?", "LOGOUT", new Runnable() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m293lambda$confirmLogout$18$comzenoappDashboardActivity();
            }
        }, "Cancel", null, null, false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$confirmLogout$18$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m293lambda$confirmLogout$18$comzenoappDashboardActivity() {
        this.sessionManager.clear();
        startActivity(new Intent((Context) this, (Class<?>) LoginActivity.class));
        finish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showEditNameDialog() {
        try {
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_edit_name);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            final EditText editText = (EditText) dialog.findViewById(R.id.etName);
            ImageView imageView = (ImageView) dialog.findViewById(R.id.btnCloseDialog);
            final Button button = (Button) dialog.findViewById(R.id.btnChangeName);
            TextView textView = (TextView) dialog.findViewById(R.id.tabName);
            TextView textView2 = (TextView) dialog.findViewById(R.id.tabPicture);
            View viewFindViewById = dialog.findViewById(R.id.panelName);
            View viewFindViewById2 = dialog.findViewById(R.id.panelPicture);
            if (editText != null && imageView != null && button != null) {
                if (textView != null) {
                    View view = (View) textView.getParent();
                    if (view != null) {
                        view.setVisibility(8);
                    } else {
                        textView.setVisibility(8);
                    }
                }
                if (textView2 != null) {
                    textView2.setVisibility(8);
                }
                if (viewFindViewById2 != null) {
                    viewFindViewById2.setVisibility(8);
                }
                if (viewFindViewById != null) {
                    viewFindViewById.setVisibility(0);
                }
                TextView textView3 = this.tvFullName;
                String string = textView3 != null ? textView3.getText().toString() : "";
                if (string != null && !string.equals("Loading...") && !string.equals("Unknown") && !string.isEmpty()) {
                    editText.setText(string);
                    editText.setSelection(string.length());
                }
                imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda16
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DashboardActivity$$ExternalSyntheticLambda17
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        this.f$0.m297lambda$showEditNameDialog$20$comzenoappDashboardActivity(editText, button, dialog, view2);
                    }
                });
                dialog.show();
                return;
            }
            Toast.makeText((Context) this, (CharSequence) "Dialog layout error", 0).show();
        } catch (Exception e) {
            Toast.makeText((Context) this, (CharSequence) ("Dialog error: " + e.getMessage()), 0).show();
        }
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$20$com-zeno-app-DashboardActivity, reason: not valid java name */
    /* synthetic */ void m297lambda$showEditNameDialog$20$comzenoappDashboardActivity(EditText editText, Button button, Dialog dialog, View view) {
        String strTrim = editText.getText().toString().trim();
        if (strTrim.isEmpty()) {
            editText.setError("နာမည် ထည့်ပါ");
            return;
        }
        button.setEnabled(false);
        button.setText("Saving...");
        updateFullName(strTrim, dialog, button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void updateFullName(String str, Dialog dialog, Button button) {
        String accessToken = this.sessionManager.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login ပြန်လုပ်ပါ", 0).show();
            if (button != null) {
                button.setEnabled(true);
                button.setText("Change Name");
                return;
            }
            return;
        }
        String str2 = this.currentBirthDate;
        if (str2 == null) {
            str2 = "";
        }
        String str3 = this.currentGender;
        ApiClient.updateCustomer(accessToken, str2, (str3 == null || str3.isEmpty()) ? "male" : this.currentGender, str, new AnonymousClass6(button, str, dialog));
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$6, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass6 implements Callback {
        final /* synthetic */ Button val$btnSave;
        final /* synthetic */ Dialog val$dialog;
        final /* synthetic */ String val$newName;

        AnonymousClass6(Button button, String str, Dialog dialog) {
            this.val$btnSave = button;
            this.val$newName = str;
            this.val$dialog = dialog;
        }

        public void onFailure(Call call, final IOException iOException) {
            Handler handler = DashboardActivity.this.uiHandler;
            final Button button = this.val$btnSave;
            handler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$6$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m304lambda$onFailure$0$comzenoappDashboardActivity$6(iOException, button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DashboardActivity$6, reason: not valid java name */
        /* synthetic */ void m304lambda$onFailure$0$comzenoappDashboardActivity$6(IOException iOException, Button button) {
            Toast.makeText((Context) DashboardActivity.this, (CharSequence) ("Network error: " + iOException.getMessage()), 1).show();
            if (button != null) {
                button.setEnabled(true);
                button.setText("Change Name");
            }
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DashboardActivity.this.uiHandler;
            final String str = this.val$newName;
            final Dialog dialog = this.val$dialog;
            final Button button = this.val$btnSave;
            handler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$6$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m305lambda$onResponse$1$comzenoappDashboardActivity$6(strString, str, dialog, button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DashboardActivity$6, reason: not valid java name */
        /* synthetic */ void m305lambda$onResponse$1$comzenoappDashboardActivity$6(String str, String str2, Dialog dialog, Button button) {
            try {
                if (str.isEmpty()) {
                    str = "{}";
                }
                JSONObject jSONObject = new JSONObject(str);
                int iOptInt = jSONObject.optInt("errorCode", -1);
                String strOptString = jSONObject.optString("message", "");
                if (iOptInt != 0 && !"SUCCESSFUL".equalsIgnoreCase(strOptString)) {
                    AppCompatActivity appCompatActivity = DashboardActivity.this;
                    if (strOptString.isEmpty()) {
                        strOptString = "ပြင်မရပါ";
                    }
                    Toast.makeText((Context) appCompatActivity, (CharSequence) strOptString, 1).show();
                    if (button != null) {
                        button.setEnabled(true);
                        button.setText("Change Name");
                        return;
                    }
                    return;
                }
                if (DashboardActivity.this.tvFullName != null) {
                    DashboardActivity.this.tvFullName.setText(str2);
                }
                DashboardActivity.this.sessionManager.saveUserInfo(DashboardActivity.this.sessionManager.getPhone(), str2, DashboardActivity.this.sessionManager.getAvatarUrl());
                try {
                    new AccountManager(DashboardActivity.this).saveFromSession(DashboardActivity.this.sessionManager);
                } catch (Exception unused) {
                }
                AppCompatActivity appCompatActivity2 = DashboardActivity.this;
                if (strOptString.isEmpty()) {
                    strOptString = "နာမည် ပြင်ပြီးပါပြီ";
                }
                Toast.makeText((Context) appCompatActivity2, (CharSequence) strOptString, 0).show();
                if (dialog != null) {
                    dialog.dismiss();
                }
            } catch (Exception e) {
                Toast.makeText((Context) DashboardActivity.this, (CharSequence) ("Error: " + e.getMessage()), 1).show();
                if (button != null) {
                    button.setEnabled(true);
                    button.setText("Change Name");
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openGalleryForAvatar() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.addFlags(1);
        try {
            startActivityForResult(Intent.createChooser(intent, "Select Image"), REQ_PICK_IMAGE);
        } catch (Exception unused) {
            Toast.makeText((Context) this, (CharSequence) "Gallery ဖွင့်မရပါ", 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onActivityResult(int i, int i2, Intent intent) {
        String stringExtra;
        super.onActivityResult(i, i2, intent);
        if (i == REQ_PICK_IMAGE && i2 == -1 && intent != null && intent.getData() != null) {
            try {
                int flags = intent.getFlags() & 3;
                if (flags != 0) {
                    try {
                        getContentResolver().takePersistableUriPermission(intent.getData(), flags);
                    } catch (Exception unused) {
                    }
                }
                Intent intent2 = new Intent((Context) this, (Class<?>) CropImageActivity.class);
                intent2.putExtra(CropImageActivity.EXTRA_IMAGE_URI, intent.getData().toString());
                intent2.addFlags(1);
                startActivityForResult(intent2, REQ_CROP_IMAGE);
                return;
            } catch (Exception e) {
                Toast.makeText((Context) this, (CharSequence) ("Crop ဖွင့်မရပါ: " + e.getMessage()), 1).show();
                return;
            }
        }
        if (i != REQ_CROP_IMAGE || i2 != -1 || intent == null || (stringExtra = intent.getStringExtra(CropImageActivity.EXTRA_CROPPED_PATH)) == null || stringExtra.isEmpty()) {
            return;
        }
        uploadProfileImageFile(stringExtra);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void uploadProfileImageFile(String str) {
        Toast.makeText((Context) this, (CharSequence) "ပုံတင်နေသည်...", 0).show();
        File file = new File(str);
        if (!file.exists()) {
            Toast.makeText((Context) this, (CharSequence) "Cropped file မတွေ့ပါ", 0).show();
            return;
        }
        String accessToken = this.sessionManager.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login ပြန်လုပ်ပါ", 0).show();
        } else {
            ApiClient.uploadAvatar(accessToken, file, new AnonymousClass7(file));
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.DashboardActivity$7, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass7 implements Callback {
        final /* synthetic */ File val$fileToUpload;

        AnonymousClass7(File file) {
            this.val$fileToUpload = file;
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DashboardActivity$7, reason: not valid java name */
        /* synthetic */ void m306lambda$onFailure$0$comzenoappDashboardActivity$7(IOException iOException) {
            Toast.makeText((Context) DashboardActivity.this, (CharSequence) ("Upload failed: " + iOException.getMessage()), 1).show();
        }

        public void onFailure(Call call, final IOException iOException) {
            DashboardActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$7$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m306lambda$onFailure$0$comzenoappDashboardActivity$7(iOException);
                }
            });
            try {
                this.val$fileToUpload.delete();
            } catch (Exception unused) {
            }
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            final int iCode = response.code();
            Handler handler = DashboardActivity.this.uiHandler;
            final File file = this.val$fileToUpload;
            handler.post(new Runnable() { // from class: com.zeno.app.DashboardActivity$7$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m307lambda$onResponse$1$comzenoappDashboardActivity$7(strString, iCode, file);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DashboardActivity$7, reason: not valid java name */
        /* synthetic */ void m307lambda$onResponse$1$comzenoappDashboardActivity$7(String str, int i, File file) {
            try {
                if (str.isEmpty()) {
                    str = "{}";
                }
                JSONObject jSONObject = new JSONObject(str);
                int iOptInt = jSONObject.optInt("errorCode", -1);
                String strOptString = jSONObject.optString("message", "");
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("result");
                String strOptString2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("url", "") : "";
                if (DashboardActivity.this.responseIsSuccessful(i, iOptInt, strOptString) && strOptString2 != null && !strOptString2.isEmpty()) {
                    DashboardActivity.this.sessionManager.saveUserInfo(DashboardActivity.this.sessionManager.getPhone(), DashboardActivity.this.sessionManager.getFullName(), strOptString2);
                    try {
                        new AccountManager(DashboardActivity.this).saveFromSession(DashboardActivity.this.sessionManager);
                    } catch (Exception unused) {
                    }
                    if (DashboardActivity.this.ivAvatar != null) {
                        Glide.with(DashboardActivity.this).load(strOptString2).transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).into(DashboardActivity.this.ivAvatar);
                    }
                    AppCompatActivity appCompatActivity = DashboardActivity.this;
                    if (strOptString.isEmpty()) {
                        strOptString = "ပရိုဖိုင်ပုံ အောင်မြင်ပါပြီ";
                    }
                    Toast.makeText((Context) appCompatActivity, (CharSequence) strOptString, 0).show();
                    DashboardActivity dashboardActivity = DashboardActivity.this;
                    dashboardActivity.fetchCustomer(dashboardActivity.sessionManager.getAccessToken());
                } else {
                    AppCompatActivity appCompatActivity2 = DashboardActivity.this;
                    if (strOptString.isEmpty()) {
                        strOptString = "ပုံတင်မရပါ";
                    }
                    Toast.makeText((Context) appCompatActivity2, (CharSequence) strOptString, 1).show();
                }
            } catch (Exception e) {
                Toast.makeText((Context) DashboardActivity.this, (CharSequence) ("Error: " + e.getMessage()), 1).show();
            }
            try {
                file.delete();
            } catch (Exception unused2) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean responseIsSuccessful(int i, int i2, String str) {
        return i >= 200 && i < 300 && (i2 == 0 || (str != null && str.toLowerCase(Locale.US).contains("success")));
    }

    private void showSkeletonLoading() {
        View view = this.profileSkeleton;
        if (view != null) {
            view.setVisibility(0);
            View view2 = this.profileContent;
            if (view2 != null) {
                view2.setVisibility(4);
            }
            this.profileSkeletonAnim = SkeletonPulse.start(this.profileSkeleton);
        }
        View view3 = this.monthlyUsageSkeleton;
        if (view3 != null) {
            view3.setVisibility(0);
            View view4 = this.monthlyUsageContent;
            if (view4 != null) {
                view4.setVisibility(8);
            }
            this.monthlySkeletonAnim = SkeletonPulse.start(this.monthlyUsageSkeleton);
        }
        View view5 = this.layoutLoading;
        if (view5 != null) {
            view5.setVisibility(0);
            View view6 = this.layoutBalances;
            if (view6 != null) {
                view6.setVisibility(8);
            }
            this.skeletonAnim = SkeletonPulse.start(this.layoutLoading);
        }
        View view7 = this.miniGamesSkeleton;
        if (view7 != null) {
            view7.setVisibility(0);
            GridLayout gridLayout = this.miniGamesGrid;
            if (gridLayout != null) {
                gridLayout.setVisibility(8);
            }
            this.miniGamesSkeletonAnim = SkeletonPulse.start(this.miniGamesSkeleton);
        }
    }

    private void hideSkeletonLoading() {
        SkeletonPulse.stop(this.profileSkeletonAnim, this.profileSkeleton);
        this.profileSkeletonAnim = null;
        View view = this.profileSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.profileContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        SkeletonPulse.stop(this.monthlySkeletonAnim, this.monthlyUsageSkeleton);
        this.monthlySkeletonAnim = null;
        View view3 = this.monthlyUsageSkeleton;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        View view4 = this.monthlyUsageContent;
        if (view4 != null) {
            view4.setVisibility(0);
        }
        SkeletonPulse.stop(this.skeletonAnim, this.layoutLoading);
        this.skeletonAnim = null;
        View view5 = this.layoutLoading;
        if (view5 != null) {
            view5.setVisibility(8);
        }
        View view6 = this.layoutBalances;
        if (view6 != null) {
            view6.setVisibility(0);
        }
        SkeletonPulse.stop(this.miniGamesSkeletonAnim, this.miniGamesSkeleton);
        this.miniGamesSkeletonAnim = null;
        View view7 = this.miniGamesSkeleton;
        if (view7 != null) {
            view7.setVisibility(8);
        }
        GridLayout gridLayout = this.miniGamesGrid;
        if (gridLayout != null) {
            gridLayout.setVisibility(0);
        }
    }
}
