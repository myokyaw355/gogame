package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SoftClimbersShopActivity extends BaseActivity {
    private static final String SC_BASE = "https://api.softclimbers.com";
    private ExecutorService exec;
    private LinearLayout llShopItems;
    private LinearLayout llShopLoading;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private ScrollView svShopItems;
    private TextView tvShopEmpty;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_sc_shop);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Shop");
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        toolbarFindViewById.setNavigationIcon(R.drawable.ic_back);
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m721lambda$onCreate$0$comzenoappSoftClimbersShopActivity(view);
            }
        });
        this.llShopLoading = (LinearLayout) findViewById(R.id.llShopLoading);
        this.tvShopEmpty = (TextView) findViewById(R.id.tvShopEmpty);
        this.svShopItems = (ScrollView) findViewById(R.id.svShopItems);
        this.llShopItems = (LinearLayout) findViewById(R.id.llShopItems);
        fetchPlans();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m721lambda$onCreate$0$comzenoappSoftClimbersShopActivity(View view) {
        finish();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void fetchPlans() {
        this.llShopLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llShopLoading);
        this.tvShopEmpty.setVisibility(8);
        this.svShopItems.setVisibility(8);
        this.llShopItems.removeAllViews();
        final String scGameToken = this.session.getScGameToken();
        if (!ok(scGameToken)) {
            showEmpty("Not logged in to SoftClimbers.\nOpen the game card first.");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m720lambda$fetchPlans$3$comzenoappSoftClimbersShopActivity(scGameToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPlans$3$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m720lambda$fetchPlans$3$comzenoappSoftClimbersShopActivity(String str) {
        boolean zOptBoolean;
        JSONObject jSONObjectOptJSONObject;
        try {
            String[] strArrDoGet = doGet("https://api.softclimbers.com/api/v1/subscription/status", str);
            if ("401".equals(strArrDoGet[1])) {
                str = reLoginSoftClimbers();
                if (!ok(str)) {
                    showEmpty("Session expired. Open game card to refresh login.");
                    return;
                }
                strArrDoGet = doGet("https://api.softclimbers.com/api/v1/subscription/status", str);
            }
            if (strArrDoGet[0] == null) {
                showEmpty("Network error. Please retry.");
                return;
            }
            final JSONArray jSONArrayOptJSONArray = null;
            try {
                jSONObjectOptJSONObject = new JSONObject(strArrDoGet[0]).optJSONObject("data");
            } catch (Exception unused) {
            }
            if (jSONObjectOptJSONObject != null) {
                zOptBoolean = jSONObjectOptJSONObject.optBoolean("subscribed", false);
                try {
                    jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("availablePlans");
                } catch (Exception unused2) {
                }
            } else {
                zOptBoolean = false;
            }
            if (!zOptBoolean) {
                this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m718lambda$fetchPlans$1$comzenoappSoftClimbersShopActivity(jSONArrayOptJSONArray);
                    }
                });
                return;
            }
            String[] strArrDoGet2 = doGet("https://api.softclimbers.com/api/v1/plans/one-time", str);
            if ("401".equals(strArrDoGet2[1])) {
                String strReLoginSoftClimbers = reLoginSoftClimbers();
                if (!ok(strReLoginSoftClimbers)) {
                    showEmpty("Session expired. Open game card to refresh login.");
                    return;
                }
                strArrDoGet2 = doGet("https://api.softclimbers.com/api/v1/plans/one-time", strReLoginSoftClimbers);
            }
            final String str2 = strArrDoGet2[0];
            if (str2 == null) {
                showEmpty("Network error. Please retry.");
            } else {
                this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m719lambda$fetchPlans$2$comzenoappSoftClimbersShopActivity(str2);
                    }
                });
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPlans$1$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m718lambda$fetchPlans$1$comzenoappSoftClimbersShopActivity(JSONArray jSONArray) {
        renderPlans(jSONArray, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseAndShow, reason: merged with bridge method [inline-methods] */
    public void m719lambda$fetchPlans$2$comzenoappSoftClimbersShopActivity(String str) {
        SkeletonPulse.stop(this.skeletonAnim, this.llShopLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llShopLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (jSONObject.optInt("code", -1) != 0) {
                showEmpty(jSONObject.optString("message", "Failed to load plans."));
            } else {
                renderPlans(jSONObject.optJSONArray("data"), true);
            }
        } catch (Exception e) {
            showEmpty("Parse error: " + e.getMessage());
        }
    }

    private void renderPlans(JSONArray jSONArray, boolean z) {
        String str;
        SkeletonPulse.stop(this.skeletonAnim, this.llShopLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llShopLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        if (jSONArray == null || jSONArray.length() == 0) {
            if (z) {
                str = "No plans available right now.";
            } else {
                str = "No subscription plans available right now.";
            }
            showEmpty(str);
            return;
        }
        this.svShopItems.setVisibility(0);
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                addPlanRow(jSONObjectOptJSONObject, z);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addPlanRow(JSONObject jSONObject, final boolean z) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_sc_shop_plan, (ViewGroup) this.llShopItems, false);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPlanName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvPlanBadgeText);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvPlanDesc);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvPlanAttempts);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.tvPlanPrice);
        final Button button = (Button) viewInflate.findViewById(R.id.btnPlanBuy);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivPlanIcon);
        final int iOptInt = jSONObject.optInt("id", -1);
        final String strOptString = jSONObject.optString("name", "Pack");
        double dOptDouble = jSONObject.optDouble("price", 0.0d);
        String strOptString2 = jSONObject.optString("currency", "KS");
        int iOptInt2 = jSONObject.optInt("dailyAttempts", 0);
        String strOptString3 = jSONObject.optString("description", "");
        String strOptString4 = jSONObject.optString("badgeText", "");
        textView.setText(strOptString);
        textView4.setText(iOptInt2 + " attempts");
        textView5.setText(String.format("%,.0f %s", Double.valueOf(dOptDouble), strOptString2));
        if (ok(strOptString4)) {
            textView2.setText(strOptString4);
            textView2.setVisibility(0);
        } else {
            textView2.setVisibility(8);
        }
        if (ok(strOptString3)) {
            textView3.setText(strOptString3);
            textView3.setVisibility(0);
        } else {
            textView3.setVisibility(8);
        }
        imageView.setImageResource(R.drawable.ic_heart);
        button.setBackgroundTintList(null);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m717lambda$addPlanRow$4$comzenoappSoftClimbersShopActivity(z, iOptInt, strOptString, button, view);
            }
        });
        this.llShopItems.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addPlanRow$4$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m717lambda$addPlanRow$4$comzenoappSoftClimbersShopActivity(boolean z, int i, String str, Button button, View view) {
        if (z) {
            purchaseOneTimePlan(i, str, button);
        } else {
            subscribeToPlan(i, str, button);
        }
    }

    private void purchaseOneTimePlan(final int i, final String str, final Button button) {
        if (i < 0) {
            return;
        }
        button.setEnabled(false);
        button.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m723lambda$purchaseOneTimePlan$6$comzenoappSoftClimbersShopActivity(i, str, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$purchaseOneTimePlan$6$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m723lambda$purchaseOneTimePlan$6$comzenoappSoftClimbersShopActivity(int i, String str, final Button button) {
        String scGameToken;
        String strOptString;
        final String str2 = "Purchase failed.";
        final boolean z = false;
        try {
            scGameToken = this.session.getScGameToken();
            if (!ok(scGameToken)) {
                scGameToken = reLoginSoftClimbers();
            }
        } catch (Exception unused) {
        }
        if (!ok(scGameToken)) {
            strOptString = "Login required.";
        } else {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("planId", i);
            String[] strArrDoPost = doPost("https://api.softclimbers.com/api/v1/attempts/purchase", jSONObject.toString(), scGameToken);
            if ("401".equals(strArrDoPost[1])) {
                String strReLoginSoftClimbers = reLoginSoftClimbers();
                if (ok(strReLoginSoftClimbers)) {
                    strArrDoPost = doPost("https://api.softclimbers.com/api/v1/attempts/purchase", jSONObject.toString(), strReLoginSoftClimbers);
                }
            }
            if (strArrDoPost[0] != null) {
                JSONObject jSONObject2 = new JSONObject(strArrDoPost[0]);
                if (jSONObject2.optInt("code", -1) == 0) {
                    try {
                        strOptString = str + " purchased!";
                        z = true;
                    } catch (Exception unused2) {
                        z = true;
                    }
                } else {
                    strOptString = jSONObject2.optString("message", "Purchase failed.");
                }
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m722lambda$purchaseOneTimePlan$5$comzenoappSoftClimbersShopActivity(str2, button, z);
                }
            });
        }
        str2 = strOptString;
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m722lambda$purchaseOneTimePlan$5$comzenoappSoftClimbersShopActivity(str2, button, z);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$purchaseOneTimePlan$5$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m722lambda$purchaseOneTimePlan$5$comzenoappSoftClimbersShopActivity(String str, Button button, boolean z) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
        button.setEnabled(!z);
        button.setText(z ? "ဝယ်ပြီး" : "ဝယ်မည်");
    }

    private void subscribeToPlan(final int i, final String str, final Button button) {
        if (i < 0) {
            return;
        }
        button.setEnabled(false);
        button.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m726lambda$subscribeToPlan$8$comzenoappSoftClimbersShopActivity(i, str, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$subscribeToPlan$8$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m726lambda$subscribeToPlan$8$comzenoappSoftClimbersShopActivity(int i, String str, final Button button) {
        String scGameToken;
        String strOptString;
        final String str2 = "Subscription failed.";
        final boolean z = false;
        try {
            scGameToken = this.session.getScGameToken();
            if (!ok(scGameToken)) {
                scGameToken = reLoginSoftClimbers();
            }
        } catch (Exception unused) {
        }
        if (!ok(scGameToken)) {
            strOptString = "Login required.";
        } else {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("planId", i);
            String[] strArrDoPost = doPost("https://api.softclimbers.com/api/v1/subscription/subscribe", jSONObject.toString(), scGameToken);
            if ("401".equals(strArrDoPost[1])) {
                String strReLoginSoftClimbers = reLoginSoftClimbers();
                if (ok(strReLoginSoftClimbers)) {
                    strArrDoPost = doPost("https://api.softclimbers.com/api/v1/subscription/subscribe", jSONObject.toString(), strReLoginSoftClimbers);
                }
            }
            if (strArrDoPost[0] != null) {
                JSONObject jSONObject2 = new JSONObject(strArrDoPost[0]);
                if (jSONObject2.optInt("code", -1) == 0) {
                    try {
                        strOptString = str + " subscribed!";
                        z = true;
                    } catch (Exception unused2) {
                        z = true;
                    }
                } else {
                    strOptString = jSONObject2.optString("message", "Subscription failed.");
                }
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m725lambda$subscribeToPlan$7$comzenoappSoftClimbersShopActivity(str2, z, button);
                }
            });
        }
        str2 = strOptString;
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m725lambda$subscribeToPlan$7$comzenoappSoftClimbersShopActivity(str2, z, button);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$subscribeToPlan$7$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m725lambda$subscribeToPlan$7$comzenoappSoftClimbersShopActivity(String str, boolean z, Button button) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
        if (z) {
            fetchPlans();
        } else {
            button.setEnabled(true);
            button.setText("ဝယ်မည်");
        }
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersShopActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m724lambda$showEmpty$9$comzenoappSoftClimbersShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$9$com-zeno-app-SoftClimbersShopActivity, reason: not valid java name */
    /* synthetic */ void m724lambda$showEmpty$9$comzenoappSoftClimbersShopActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llShopLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llShopLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svShopItems.setVisibility(8);
        this.tvShopEmpty.setText(str);
        this.tvShopEmpty.setVisibility(0);
    }

    private String[] doGet(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("Authorization", "Bearer " + str2).addHeader("access-token", str2).addHeader("user-agent", "ZenoMyID/2.0");
            String phone = this.session.getPhone();
            if (ok(phone)) {
                builderAddHeader.addHeader("phone-number", phone);
                builderAddHeader.addHeader("msisdn", phone);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                String[] strArr = {responseExecute.body() != null ? responseExecute.body().string() : "", String.valueOf(responseExecute.code())};
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return strArr;
            } finally {
            }
        } catch (Exception unused) {
            return new String[]{null, "0"};
        }
    }

    private String[] doPost(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).post(RequestBody.create(str2, MediaType.parse("application/json"))).addHeader("content-type", "application/json").addHeader("accept", "*/*").addHeader("Authorization", "Bearer " + str3).addHeader("access-token", str3).addHeader("user-agent", "ZenoMyID/2.0");
            String phone = this.session.getPhone();
            if (ok(phone)) {
                builderAddHeader.addHeader("phone-number", phone);
                builderAddHeader.addHeader("msisdn", phone);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                String[] strArr = {responseExecute.body() != null ? responseExecute.body().string() : "", String.valueOf(responseExecute.code())};
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return strArr;
            } finally {
            }
        } catch (Exception unused) {
            return new String[]{null, "0"};
        }
    }

    private String reLoginSoftClimbers() {
        JSONObject jSONObjectOptJSONObject;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        String avatarUrl = this.session.getAvatarUrl();
        String fullName = this.session.getFullName();
        if (ok(phone) && ok(accessToken)) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("msisdn", phone);
                jSONObject.put("accessToken", accessToken);
                if (!ok(avatarUrl)) {
                    avatarUrl = "";
                }
                jSONObject.put("avatar", avatarUrl);
                if (ok(fullName)) {
                    phone = fullName;
                }
                jSONObject.put("username", phone);
                jSONObject.put("lang", "mu");
                Response responseExecute = this.http.newCall(new Request.Builder().url("https://api.softclimbers.com/api/v1/auth/login").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("content-type", "application/json").build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                    if (jSONObject2.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject2.optJSONObject("data")) != null) {
                        String strOptString = jSONObjectOptJSONObject.optString("token", "");
                        if (ok(strOptString)) {
                            this.session.saveScGameToken(strOptString);
                            if (responseExecute != null) {
                                responseExecute.close();
                            }
                            return strOptString;
                        }
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                } finally {
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
