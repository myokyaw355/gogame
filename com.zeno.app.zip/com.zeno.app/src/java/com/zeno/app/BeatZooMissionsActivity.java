package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class BeatZooMissionsActivity extends BaseActivity {
    private static final String API = "https://beatzoo.mascom.vn/api/client-api";
    private static final String API_KEY = "60015110c58af6c4a6beec794ab40b89b1042b42cb5380e86daee037cf96ef8b";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String LOGIN_URL = "https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login";
    private static final String MCUID_FALLBACK = "d26116fa96257ec6304156e5a475c76b";
    private static final String TAG = "BeatZooMissions";
    private static final String TOKEN_AUTH = "https://beatzoo.mascom.vn/api/client-api/token-auth";
    private LinearLayout llContent;
    private View pbLoading;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvEmpty;
    private String jwt = "";
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newCachedThreadPool();
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).followRedirects(false).build();
    private final List<JSONObject> missions = new ArrayList();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_beat_zoo_missions);
        this.session = new SessionManager(this);
        String stringExtra = getIntent().getStringExtra("jwt");
        if (stringExtra != null && !stringExtra.isEmpty()) {
            this.jwt = stringExtra;
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m89lambda$onCreate$0$comzenoappBeatZooMissionsActivity(view);
            }
        });
        this.llContent = (LinearLayout) findViewById(R.id.llContent);
        this.pbLoading = findViewById(R.id.pbLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda3
            public final void onRefresh() {
                this.f$0.loadMissions();
            }
        });
        loadMissions();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m89lambda$onCreate$0$comzenoappBeatZooMissionsActivity(View view) {
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadMissions() {
        if (this.pbLoading != null && !this.swipeRefresh.isRefreshing()) {
            this.pbLoading.setVisibility(0);
            this.skeletonAnim = SkeletonPulse.start(this.pbLoading);
        }
        TextView textView = this.tvEmpty;
        if (textView != null) {
            textView.setVisibility(8);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m88lambda$loadMissions$3$comzenoappBeatZooMissionsActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadMissions$3$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m88lambda$loadMissions$3$comzenoappBeatZooMissionsActivity() {
        try {
            ensureJwt();
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m86lambda$loadMissions$1$comzenoappBeatZooMissionsActivity(jSONArrayFetchMissions);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "loadMissions", e);
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m87lambda$loadMissions$2$comzenoappBeatZooMissionsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadMissions$1$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m86lambda$loadMissions$1$comzenoappBeatZooMissionsActivity(JSONArray jSONArray) {
        this.missions.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                this.missions.add(jSONObjectOptJSONObject);
            }
        }
        renderMissions();
        SkeletonPulse.stop(this.skeletonAnim, this.pbLoading);
        this.skeletonAnim = null;
        View view = this.pbLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: renamed from: lambda$loadMissions$2$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m87lambda$loadMissions$2$comzenoappBeatZooMissionsActivity(Exception exc) {
        SkeletonPulse.stop(this.skeletonAnim, this.pbLoading);
        this.skeletonAnim = null;
        View view = this.pbLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        toast(exc.getMessage() != null ? exc.getMessage() : "Load failed");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderMissions() {
        LinearLayout linearLayout = this.llContent;
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        if (this.missions.isEmpty()) {
            TextView textView = this.tvEmpty;
            if (textView != null) {
                textView.setVisibility(0);
                return;
            }
            return;
        }
        TextView textView2 = this.tvEmpty;
        if (textView2 != null) {
            textView2.setVisibility(8);
        }
        LayoutInflater layoutInflater = getLayoutInflater();
        int i = -1;
        for (JSONObject jSONObject : this.missions) {
            if (jSONObject != null) {
                int iOptInt = jSONObject.optInt("day", 0);
                if (iOptInt != i) {
                    TextView textView3 = new TextView(this);
                    textView3.setText("Day " + iOptInt);
                    textView3.setTextColor(-3632086);
                    textView3.setTextSize(2, 13.0f);
                    textView3.setTypeface(null, 1);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                    layoutParams.topMargin = dp(8);
                    layoutParams.bottomMargin = dp(6);
                    textView3.setLayoutParams(layoutParams);
                    this.llContent.addView(textView3);
                    i = iOptInt;
                }
                this.llContent.addView(buildMissionRow(layoutInflater, jSONObject));
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildMissionRow(LayoutInflater layoutInflater, JSONObject jSONObject) {
        View view;
        int iOptInt;
        View viewInflate = layoutInflater.inflate(R.layout.item_reward_task, (ViewGroup) this.llContent, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvTaskName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvTaskProgress);
        ProgressBar progressBar = (ProgressBar) viewInflate.findViewById(R.id.progressBar);
        LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llTaskRewards);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.btnClaim);
        final String strOptString = jSONObject.optString("name", "Mission");
        String strOptString2 = jSONObject.optString("status", "NOT_COMPLETED");
        int iOptInt2 = jSONObject.optInt("score", 1);
        int iOptInt3 = jSONObject.optInt("current_score", 0);
        if (iOptInt2 <= 0) {
            iOptInt2 = 1;
        }
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("reward");
        String strOptString3 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("code", "gem") : "gem";
        if (jSONObjectOptJSONObject != null) {
            view = viewInflate;
            iOptInt = jSONObjectOptJSONObject.optInt("amount", 0);
        } else {
            view = viewInflate;
            iOptInt = 0;
        }
        final String strOptString4 = jSONObject.optString("id");
        textView.setText(strOptString);
        textView2.setText(iOptInt3 + " / " + iOptInt2);
        int iMin = Math.min(100, (int) ((((float) iOptInt3) * 100.0f) / ((float) iOptInt2)));
        progressBar.setProgress(iMin);
        if (imageView != null) {
            if ("ticket".equalsIgnoreCase(strOptString3)) {
                imageView.setImageResource(R.drawable.ic_mission_ticket);
            } else if ("heart".equalsIgnoreCase(strOptString3)) {
                imageView.setImageResource(R.drawable.ic_mission_heart);
            } else {
                imageView.setImageResource(R.drawable.ic_mission_gem);
            }
            imageView.setBackground(null);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        }
        if (linearLayout != null) {
            linearLayout.removeAllViews();
            TextView textView4 = new TextView(this);
            textView4.setText("+" + iOptInt + " " + strOptString3);
            textView4.setTextColor(-10929);
            textView4.setTextSize(2, 11.0f);
            textView4.setTypeface(null, 1);
            linearLayout.addView(textView4);
        }
        boolean zEqualsIgnoreCase = "CLAIMED".equalsIgnoreCase(strOptString2);
        boolean zEqualsIgnoreCase2 = "COMPLETED".equalsIgnoreCase(strOptString2);
        if (zEqualsIgnoreCase) {
            textView3.setText("Claimed");
            textView3.setBackgroundResource(R.drawable.bg_item_chip);
            textView3.setTextColor(-7829368);
            textView3.setEnabled(false);
            textView3.setOnClickListener(null);
        } else if (zEqualsIgnoreCase2) {
            textView3.setText("Claim");
            textView3.setBackgroundResource(R.drawable.bg_btn_gold);
            textView3.setTextColor(-16777216);
            textView3.setEnabled(true);
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m82lambda$buildMissionRow$4$comzenoappBeatZooMissionsActivity(strOptString4, strOptString, view2);
                }
            });
        } else {
            textView3.setText(iMin + "%");
            textView3.setBackgroundResource(R.drawable.bg_item_chip);
            textView3.setTextColor(-5592406);
            textView3.setEnabled(false);
            textView3.setOnClickListener(null);
        }
        return view;
    }

    /* JADX INFO: renamed from: lambda$buildMissionRow$4$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m82lambda$buildMissionRow$4$comzenoappBeatZooMissionsActivity(String str, String str2, View view) {
        claimOne(str, str2);
    }

    private void claimOne(final String str, final String str2) {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m85lambda$claimOne$7$comzenoappBeatZooMissionsActivity(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimOne$7$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m85lambda$claimOne$7$comzenoappBeatZooMissionsActivity(String str, final String str2) {
        try {
            ensureJwt();
            final JSONObject jSONObjectClaimMissionSync = claimMissionSync(str);
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m83lambda$claimOne$5$comzenoappBeatZooMissionsActivity(jSONArrayFetchMissions, jSONObjectClaimMissionSync, str2);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooMissionsActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m84lambda$claimOne$6$comzenoappBeatZooMissionsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$claimOne$5$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m83lambda$claimOne$5$comzenoappBeatZooMissionsActivity(JSONArray jSONArray, JSONObject jSONObject, String str) {
        this.missions.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                this.missions.add(jSONObjectOptJSONObject);
            }
        }
        renderMissions();
        if (jSONObject.optInt("status") == 1) {
            JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("data");
            JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optJSONObject("reward") : null;
            toast(str + ": " + (jSONObjectOptJSONObject3 != null ? "+" + jSONObjectOptJSONObject3.optInt("amount") + " " + jSONObjectOptJSONObject3.optString("code") : "Claimed"));
            return;
        }
        toast(jSONObject.optString("message", "Claim failed"));
    }

    /* JADX INFO: renamed from: lambda$claimOne$6$com-zeno-app-BeatZooMissionsActivity, reason: not valid java name */
    /* synthetic */ void m84lambda$claimOne$6$comzenoappBeatZooMissionsActivity(Exception exc) {
        toast(exc.getMessage() != null ? exc.getMessage() : "Claim error");
    }

    private synchronized void ensureJwt() throws Exception {
        String strDecode;
        String str = this.jwt;
        if (str == null || str.isEmpty()) {
            String accessToken = this.session.getAccessToken();
            String phone = this.session.getPhone();
            if (accessToken == null || accessToken.isEmpty()) {
                throw new Exception("Not logged in");
            }
            if (phone == null || phone.isEmpty()) {
                throw new Exception("No phone number");
            }
            String mcuid = this.session.getMcuid();
            if (mcuid == null || mcuid.isEmpty()) {
                mcuid = MCUID_FALLBACK;
            }
            String fullName = this.session.getFullName();
            if (fullName == null || fullName.isEmpty()) {
                fullName = "User";
            }
            String avatarUrl = this.session.getAvatarUrl();
            if (avatarUrl == null) {
                avatarUrl = "";
            }
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login?game-code=BEAT_ZOO&mcuid=" + mcuid + "&mcapp=myid").get().addHeader("access-token", accessToken).addHeader("phone-number", phone).addHeader("username", fullName).addHeader("avatar", avatarUrl).addHeader("lang", "mu").addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36").build()).execute();
            try {
                String strHeader = responseExecute.header("Location");
                if (strHeader == null || strHeader.isEmpty()) {
                    throw new Exception("Gateway login failed HTTP " + responseExecute.code());
                }
                if (responseExecute != null) {
                    responseExecute.close();
                }
                int iIndexOf = strHeader.indexOf("token=");
                if (iIndexOf >= 0) {
                    String strSubstring = strHeader.substring(iIndexOf + 6);
                    int iIndexOf2 = strSubstring.indexOf(38);
                    if (iIndexOf2 >= 0) {
                        strSubstring = strSubstring.substring(0, iIndexOf2);
                    }
                    strDecode = URLDecoder.decode(strSubstring, "UTF-8");
                } else {
                    strDecode = null;
                }
                if (strDecode == null || strDecode.isEmpty()) {
                    throw new Exception("No game token");
                }
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("token", strDecode);
                jSONObject.put("status", JSONObject.NULL);
                jSONObject.put("message", JSONObject.NULL);
                responseExecute = this.http.newCall(new Request.Builder().url(TOKEN_AUTH).post(RequestBody.create(jSONObject.toString(), JSON)).addHeader("Content-Type", "application/json").addHeader("x-api-key", API_KEY).build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                    if (jSONObject2.optInt("status") != 1) {
                        throw new Exception(jSONObject2.optString("message", "Auth failed"));
                    }
                    this.jwt = jSONObject2.getJSONObject("data").getString("token");
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return;
                } finally {
                }
            } finally {
            }
        }
    }

    private JSONArray fetchMissions() throws Exception {
        Response responseExecute = this.http.newCall(apiGet("/missions").build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (jSONObject.optInt("status") != 1) {
                throw new Exception(jSONObject.optString("message", "missions failed"));
            }
            JSONArray jSONArray = jSONObject.getJSONArray("data");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONArray;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONObject claimMissionSync(String str) throws Exception {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("mission_id", str);
        Response responseExecute = this.http.newCall(apiPost("/missions/claim", jSONObject.toString()).build()).execute();
        try {
            JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONObject2;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private Request.Builder apiGet(String str) {
        return new Request.Builder().url(API + str).get().addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Accept", "*/*");
    }

    private Request.Builder apiPost(String str, String str2) {
        return new Request.Builder().url(API + str).post(RequestBody.create(str2, JSON)).addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Content-Type", "application/json");
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }
}
