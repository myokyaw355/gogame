package com.zeno.app;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class PointsBottomSheet extends BottomSheetDialogFragment {
    private static final String ARG_PHONE = "phone";
    private static final String ARG_POINTS = "points";
    private static final String ARG_RANK = "rank";

    public static PointsBottomSheet newInstance(String str, int i, String str2) {
        PointsBottomSheet pointsBottomSheet = new PointsBottomSheet();
        Bundle bundle = new Bundle();
        bundle.putString(ARG_PHONE, str);
        bundle.putInt(ARG_POINTS, i);
        bundle.putString(ARG_RANK, str2);
        pointsBottomSheet.setArguments(bundle);
        return pointsBottomSheet;
    }

    public int getTheme() {
        return R.style.MyBottomSheet;
    }

    public Dialog onCreateDialog(Bundle bundle) {
        final BottomSheetDialog bottomSheetDialogOnCreateDialog = super.onCreateDialog(bundle);
        bottomSheetDialogOnCreateDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.zeno.app.PointsBottomSheet$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                PointsBottomSheet.lambda$onCreateDialog$0(bottomSheetDialogOnCreateDialog, dialogInterface);
            }
        });
        return bottomSheetDialogOnCreateDialog;
    }

    static /* synthetic */ void lambda$onCreateDialog$0(BottomSheetDialog bottomSheetDialog, DialogInterface dialogInterface) {
        FrameLayout frameLayout = (FrameLayout) bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (frameLayout != null) {
            frameLayout.setBackgroundColor(0);
            frameLayout.setBackground(null);
            BottomSheetBehavior.from(frameLayout).setState(3);
        }
        if (bottomSheetDialog.getWindow() != null) {
            bottomSheetDialog.getWindow().setNavigationBarColor(-15066598);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return layoutInflater.inflate(R.layout.bottom_sheet_points, viewGroup, false);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        final String string = getArguments() != null ? getArguments().getString(ARG_PHONE, "") : "";
        final int i = getArguments() != null ? getArguments().getInt(ARG_POINTS, 0) : 0;
        final String string2 = getArguments() != null ? getArguments().getString(ARG_RANK, "") : "";
        LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.rowPointExchange);
        LinearLayout linearLayout2 = (LinearLayout) view.findViewById(R.id.rowPointsHistory);
        LinearLayout linearLayout3 = (LinearLayout) view.findViewById(R.id.rowPointsExtend);
        ImageView imageView = (ImageView) view.findViewById(R.id.btnClose);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsBottomSheet$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m644lambda$onViewCreated$1$comzenoappPointsBottomSheet(string, i, string2, view2);
            }
        });
        linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsBottomSheet$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                this.f$0.m645lambda$onViewCreated$2$comzenoappPointsBottomSheet(string, i, view2);
            }
        });
        if (linearLayout3 != null) {
            linearLayout3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsBottomSheet$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m646lambda$onViewCreated$3$comzenoappPointsBottomSheet(view2);
                }
            });
        }
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsBottomSheet$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m647lambda$onViewCreated$4$comzenoappPointsBottomSheet(view2);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$onViewCreated$1$com-zeno-app-PointsBottomSheet, reason: not valid java name */
    /* synthetic */ void m644lambda$onViewCreated$1$comzenoappPointsBottomSheet(String str, int i, String str2, View view) {
        Intent intent = new Intent(requireContext(), (Class<?>) PointsExchangeActivity.class);
        intent.putExtra(ARG_PHONE, str);
        intent.putExtra(ARG_POINTS, i);
        intent.putExtra(ARG_RANK, str2);
        startActivity(intent);
        dismiss();
    }

    /* JADX INFO: renamed from: lambda$onViewCreated$2$com-zeno-app-PointsBottomSheet, reason: not valid java name */
    /* synthetic */ void m645lambda$onViewCreated$2$comzenoappPointsBottomSheet(String str, int i, View view) {
        Intent intent = new Intent(requireContext(), (Class<?>) PointsHistoryActivity.class);
        intent.putExtra(ARG_PHONE, str);
        intent.putExtra(ARG_POINTS, i);
        startActivity(intent);
        dismiss();
    }

    /* JADX INFO: renamed from: lambda$onViewCreated$3$com-zeno-app-PointsBottomSheet, reason: not valid java name */
    /* synthetic */ void m646lambda$onViewCreated$3$comzenoappPointsBottomSheet(View view) {
        dismiss();
        PointsExtendDialog.show(requireActivity());
    }

    /* JADX INFO: renamed from: lambda$onViewCreated$4$com-zeno-app-PointsBottomSheet, reason: not valid java name */
    /* synthetic */ void m647lambda$onViewCreated$4$comzenoappPointsBottomSheet(View view) {
        dismiss();
    }
}
