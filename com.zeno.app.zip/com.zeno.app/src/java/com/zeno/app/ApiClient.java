package com.zeno.app;

import android.content.Context;
import java.io.File;
import java.util.concurrent.TimeUnit;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public class ApiClient {
    private static final String BASE_URL = "https://apis.mytel.com.mm";
    private static final String QUEST_BASE = "https://apis.mytel.com.mm/daily-quest-v3/api/v3/daily-quest";
    private static final MediaType JSON = MediaType.parse("application/json; charset=UTF-8");
    private static volatile String appVersion = BuildConfig.VERSION_NAME;
    private static final OkHttpClient client = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build();

    public static void init(Context context) {
        try {
            String str = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
            if (str == null || str.trim().isEmpty()) {
                return;
            }
            appVersion = str.trim();
        } catch (Exception unused) {
        }
    }

    public static void checkAccount(String str, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/myid/authen/v1.0/v2/login/action/check-account?phoneNumber=" + str).get().addHeader("accept-language", "en").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getOtp(String str, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/myid/authen/v1.0/login/method/otp/get-otp?phoneNumber=" + str).get().addHeader("accept-language", "my").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void registerRequest(String str, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/myid/authen/v1.0/v2/register/request").post(RequestBody.create("{\"msisdn\":\"" + str + "\"}", JSON)).addHeader("accept-language", "my").addHeader("content-type", "application/json; charset=UTF-8").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void validateOtp(String str, String str2, String str3, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/myid/authen/v1.0/login/method/otp/validate-otp").post(RequestBody.create("{\"appVersion\":\"" + appVersion + "\",\"buildVersionApp\":\"300\",\"deviceId\":\"" + str3 + "\",\"imei\":\"" + str3 + "\",\"os\":\"ANDROID Redmi Redmi K30 5G\",\"osApp\":\"ANDROID\",\"password\":\"" + str2 + "\",\"phoneNumber\":\"" + str + "\",\"version\":\"12\"}", JSON)).addHeader("accept-language", "en").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getCustomer(String str, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/cpm/v1.0/api/customer").get().addHeader("Authorization", "Bearer " + str).addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getLoyaltyInquiry(String str, String str2, String str3, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/loyalty/api/v3.1/customer/inquiry?phoneNo=" + str).get().addHeader("Authorization", "Bearer " + str2).addHeader("device_id", str3).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("session_token", "").addHeader("language_code", "en").addHeader("country_code", "VN").addHeader("user_id", "0").addHeader("Accept-Language", "EN").addHeader("msisdn", "").addHeader("user-agent", "Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 5G Build/SKQ1.211006.001)").build()).enqueue(callback);
    }

    public static void getLoyaltyCsm(String str, String str2, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/csm/v1.0/api/loyalty").get().addHeader("Authorization", "Bearer " + str).addHeader("session_token", "").addHeader("device_id", str2).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "en").addHeader("country_code", "VN").addHeader("user_id", "0").addHeader("msisdn", "").addHeader("user-agent", "Dalvik/2.1.0 (Linux; U; Android 12; Redmi K30 5G Build/SKQ1.211006.001)").build()).enqueue(callback);
    }

    public static void getVasPackages(String str, String str2, String str3, Callback callback) {
        String str4 = "%2B95" + str.replaceFirst("^0", "");
        Request.Builder builder = new Request.Builder().url("https://apis.mytel.com.mm/csm/v1.0/api/vas-package/special-packs?msisdn=" + str4 + "&language=en").get();
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str2);
        client.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("device_id", str3).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "en").addHeader("country_code", "MM").addHeader("msisdn", "+95" + str.replaceFirst("^0", "")).addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void registerVasPackage(String str, String str2, String str3, Callback callback) {
        Request.Builder builderPost = new Request.Builder().url("https://apis.mytel.com.mm/csm/v1.0/api/vas-package/" + str + "/register").post(RequestBody.create("{\"msisdn\":\"" + ("+95" + str2.replaceFirst("^0", "")) + "\",\"isRenew\":false}", JSON));
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str3);
        client.newCall(builderPost.addHeader("Authorization", sb.toString()).addHeader("content-type", "application/json; charset=utf-8").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getVasPackageDetail(String str, String str2, String str3, String str4, Callback callback) {
        String str5 = "%2B95" + str2.replaceFirst("^0", "");
        Request.Builder builder = new Request.Builder().url("https://apis.mytel.com.mm/csm/v1.0/api/vas-package/" + str + "?msisdn=" + str5 + "&language=mu").get();
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str3);
        client.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("device_id", str4).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "my").addHeader("languageCode", "my").addHeader("accept-language", "my").addHeader("Accept-Language", "my").addHeader("country_code", "MM").addHeader("msisdn", "+95" + str2.replaceFirst("^0", "")).addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getPointsHistory(String str, String str2, String str3, String str4, Callback callback) {
        String str5 = "%2B95" + str.replaceFirst("^0", "");
        Request.Builder builder = new Request.Builder().url("https://apis.mytel.com.mm/loyalty/api/v3.1/history?phoneNo=" + str5 + "&type=" + str2 + "&page=0&size=50").get();
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str3);
        client.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("device_id", str4).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "my").addHeader("country_code", "MM").addHeader("msisdn", "+95" + str.replaceFirst("^0", "")).addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getPacks(String str, String str2, String str3, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/loyalty/api/v3.1/pack?phoneNo=" + str).get().addHeader("Authorization", "Bearer " + str2).addHeader("device_id", str3).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "en").addHeader("country_code", "MM").addHeader("msisdn", "+95" + str.replaceFirst("^0", "")).addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void exchangePack(String str, String str2, String str3, String str4, Callback callback) {
        Request.Builder builderPost = new Request.Builder().url("https://apis.mytel.com.mm/loyalty/api/v3.1/pack/exchange").post(RequestBody.create("{\"requestId\":\"" + str4 + "\",\"requestTime\":" + System.currentTimeMillis() + ",\"msisdn\":\"" + ("+95" + str.replaceFirst("^0", "")) + "\",\"rewardCode\":\"" + str2 + "\"}", JSON));
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str3);
        client.newCall(builderPost.addHeader("Authorization", sb.toString()).addHeader("accept-language", "EN").addHeader("content-type", "application/json; charset=utf-8").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void extendPoints(String str, String str2, String str3, Callback callback) {
        Request.Builder builderPost = new Request.Builder().url("https://apis.mytel.com.mm/loyalty/api/v3.1/exchanged/extend").post(RequestBody.create("{\"requestTime\":\"" + System.currentTimeMillis() + "\",\"msisdn\":\"" + str + "\",\"requestId\":\"" + str3 + "\"}", JSON));
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str2);
        client.newCall(builderPost.addHeader("Authorization", sb.toString()).addHeader("Accept-Language", "my").addHeader("content-type", "application/json").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getAccountDetail(String str, String str2, String str3, Callback callback) {
        String str4 = "%2B95" + str.replaceFirst("^0", "");
        Request.Builder builder = new Request.Builder().url("https://apis.mytel.com.mm/account-detail/api/v1.2/individual/account-main?isdn=" + str4 + "&language=en").get();
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str2);
        client.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("device_id", str3).addHeader("client_type", "1").addHeader("local_code", "95").addHeader("msisdn", "+95" + str.replaceFirst("^0", "")).addHeader("version", appVersion).addHeader("revision", "300").addHeader("language_code", "en").addHeader("country_code", "MM").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getDailyQuestMainScreen(String str, String str2, Callback callback) {
        Request.Builder builder = new Request.Builder().url("https://apis.mytel.com.mm/daily-quest-v3/api/v3/daily-quest/main-screen?clientType=Android&Platform=myid&msisdn=" + str + "&revision=16300").get();
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str2);
        client.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("country_code", "MM").addHeader("countryCode", "MM").addHeader("language_code", "my").addHeader("languageCode", "my").addHeader("accept-language", "my").addHeader("Accept-Language", "my").addHeader("countrycode", "MM").addHeader("languagecode", "my").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void postDailyQuestClaim(String str, String str2, Callback callback) {
        Request.Builder builderPost = new Request.Builder().url("https://apis.mytel.com.mm/daily-quest-v3/api/v3/daily-quest/daily-claim").post(RequestBody.create("{\"msisdn\":\"" + str.replace("%2B", "+") + "\",\"platform\":\"myid\",\"clientType\":\"Android\",\"revision\":16300}", JSON));
        StringBuilder sb = new StringBuilder("Bearer ");
        sb.append(str2);
        client.newCall(builderPost.addHeader("Authorization", sb.toString()).addHeader("country_code", "MM").addHeader("countryCode", "MM").addHeader("language_code", "my").addHeader("languageCode", "my").addHeader("accept-language", "my").addHeader("Accept-Language", "my").addHeader("countrycode", "MM").addHeader("languagecode", "my").addHeader("content-type", "application/json").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void getMiniQuestClaim(String str, String str2, String str3, Callback callback) {
        client.newCall(new Request.Builder().url(str.replace("{msisdn}", str2)).get().addHeader("Authorization", "Bearer " + str3).addHeader("country_code", "MM").addHeader("countryCode", "MM").addHeader("language_code", "my").addHeader("languageCode", "my").addHeader("accept-language", "my").addHeader("Accept-Language", "my").addHeader("countrycode", "MM").addHeader("languagecode", "my").addHeader("user-agent", "okhttp/4.12.0").build()).enqueue(callback);
    }

    public static void updateCustomer(String str, String str2, String str3, String str4, Callback callback) {
        String string;
        try {
            JSONObject jSONObject = new JSONObject();
            if (str2 == null) {
                str2 = "";
            }
            jSONObject.put("birthDate", str2);
            if (str3 == null) {
                str3 = "male";
            }
            jSONObject.put("gender", str3);
            if (str4 == null) {
                str4 = "";
            }
            jSONObject.put("fullName", str4);
            string = jSONObject.toString();
        } catch (Exception unused) {
            string = "{\"birthDate\":\"\",\"gender\":\"male\",\"fullName\":\"\"}";
        }
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/cpm/v1.0/api/customer").put(RequestBody.create(string, JSON)).addHeader("Authorization", "Bearer " + str).addHeader("Content-Type", "application/json").addHeader("Accept", "*/*").addHeader("user-agent", "MyID/17232 CFNetwork/3860.700.1 Darwin/25.6.0").build()).enqueue(callback);
    }

    public static void uploadAvatar(String str, File file, Callback callback) {
        client.newCall(new Request.Builder().url("https://apis.mytel.com.mm/cpm/v1.0/api/external-ref/upload?type=avatar_img").post(new MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("file", file.getName(), RequestBody.create(file, MediaType.parse("image/jpeg"))).build()).addHeader("Authorization", "Bearer " + str).addHeader("Accept", "*/*").addHeader("user-agent", "mocha/2.95 (iPhone; iOS 26.6; Scale/3.00)").build()).enqueue(callback);
    }
}
