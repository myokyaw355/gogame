package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class BeatZooShopActivity extends AppCompatActivity {
    private static final String API = "https://beatzoo.mascom.vn/api/client-api";
    private static final String API_KEY = "60015110c58af6c4a6beec794ab40b89b1042b42cb5380e86daee037cf96ef8b";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String TAG = "BeatZooShop";
    private JSONArray externalData;
    private JSONArray internalData;
    private String jwt;
    private LinearLayout shopList;
    private View shopLoading;
    private ValueAnimator skeletonAnim;
    private TextView tabExternal;
    private TextView tabInternal;
    private boolean externalMode = false;
    private final ExecutorService exec = Executors.newCachedThreadPool();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_beat_zoo_shop);
        this.jwt = getIntent().getStringExtra("jwt");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (getSupportActionBar() != null) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setTitle("Shop");
            }
            toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda10
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m99lambda$onCreate$0$comzenoappBeatZooShopActivity(view);
                }
            });
        }
        this.tabInternal = (TextView) findViewById(R.id.tabInternal);
        this.tabExternal = (TextView) findViewById(R.id.tabExternal);
        this.shopList = (LinearLayout) findViewById(R.id.shopList);
        this.shopLoading = findViewById(R.id.shopLoading);
        TextView textView = this.tabInternal;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m100lambda$onCreate$1$comzenoappBeatZooShopActivity(view);
                }
            });
        }
        TextView textView2 = this.tabExternal;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m101lambda$onCreate$2$comzenoappBeatZooShopActivity(view);
                }
            });
        }
        loadShop();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m99lambda$onCreate$0$comzenoappBeatZooShopActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m100lambda$onCreate$1$comzenoappBeatZooShopActivity(View view) {
        setMode(false);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m101lambda$onCreate$2$comzenoappBeatZooShopActivity(View view) {
        setMode(true);
    }

    private void setMode(boolean z) {
        this.externalMode = z;
        TextView textView = this.tabInternal;
        if (textView != null) {
            textView.setBackgroundResource(z ? R.drawable.bg_beat_mode_normal : R.drawable.bg_beat_mode_selected);
            this.tabInternal.setTextColor(z ? getColor(R.color.text_grey) : -1);
            this.tabInternal.setTypeface(null, !z ? 1 : 0);
        }
        TextView textView2 = this.tabExternal;
        if (textView2 != null) {
            textView2.setBackgroundResource(z ? R.drawable.bg_beat_mode_selected : R.drawable.bg_beat_mode_normal);
            this.tabExternal.setTextColor(z ? -1 : getColor(R.color.text_grey));
            this.tabExternal.setTypeface(null, z ? 1 : 0);
        }
        renderShop();
    }

    private Request.Builder apiGet(String str) {
        return new Request.Builder().url(API + str).get().addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Accept", "*/*");
    }

    private Request.Builder apiPost(String str, String str2) {
        return new Request.Builder().url(API + str).post(RequestBody.create(str2, JSON)).addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Content-Type", "application/json");
    }

    private void loadShop() {
        View view = this.shopLoading;
        if (view != null) {
            view.setVisibility(0);
            this.skeletonAnim = SkeletonPulse.start(this.shopLoading);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m98lambda$loadShop$5$comzenoappBeatZooShopActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadShop$5$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m98lambda$loadShop$5$comzenoappBeatZooShopActivity() {
        try {
            Response responseExecute = this.http.newCall(apiGet("/shop/items/internal").build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                String str = "{}";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                responseExecute = this.http.newCall(apiGet("/shop/items/external").build()).execute();
                try {
                    String strString2 = responseExecute.body() != null ? responseExecute.body().string() : "";
                    if (!strString2.isEmpty()) {
                        str = strString2;
                    }
                    final JSONArray jSONArrayOptJSONArray2 = new JSONObject(str).optJSONArray("data");
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda4
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m96lambda$loadShop$3$comzenoappBeatZooShopActivity(jSONArrayOptJSONArray, jSONArrayOptJSONArray2);
                        }
                    });
                } finally {
                    if (responseExecute != null) {
                        try {
                            responseExecute.close();
                        } catch (Throwable th) {
                            th.addSuppressed(th);
                        }
                    }
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadShop", e);
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m97lambda$loadShop$4$comzenoappBeatZooShopActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadShop$3$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m96lambda$loadShop$3$comzenoappBeatZooShopActivity(JSONArray jSONArray, JSONArray jSONArray2) {
        SkeletonPulse.stop(this.skeletonAnim, this.shopLoading);
        this.skeletonAnim = null;
        View view = this.shopLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        this.internalData = jSONArray;
        this.externalData = jSONArray2;
        renderShop();
    }

    /* JADX INFO: renamed from: lambda$loadShop$4$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m97lambda$loadShop$4$comzenoappBeatZooShopActivity(Exception exc) {
        SkeletonPulse.stop(this.skeletonAnim, this.shopLoading);
        this.skeletonAnim = null;
        View view = this.shopLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        toast("Shop load failed: " + exc.getMessage());
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderShop() {
        View viewBuildInternalGridCard;
        LinearLayout linearLayout = this.shopList;
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        JSONArray jSONArray = this.externalMode ? this.externalData : this.internalData;
        if (jSONArray == null || jSONArray.length() == 0) {
            TextView textView = new TextView(this);
            textView.setText("No packages");
            textView.setTextColor(-5592406);
            textView.setGravity(17);
            textView.setPadding(0, dp(32), 0, dp(32));
            this.shopList.addView(textView);
            return;
        }
        ArrayList<JSONObject> arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                arrayList.add(jSONObjectOptJSONObject);
            }
        }
        if (this.externalMode) {
            Collections.sort(arrayList, new Comparator() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda6
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return this.f$0.m102lambda$renderShop$6$comzenoappBeatZooShopActivity((JSONObject) obj, (JSONObject) obj2);
                }
            });
        }
        for (JSONObject jSONObject : arrayList) {
            String strOptString = jSONObject.optString("name", "Pack");
            TextView textView2 = new TextView(this);
            textView2.setText(strOptString);
            textView2.setTextColor(-10929);
            textView2.setTextSize(2, 14.0f);
            LinearLayout linearLayout2 = null;
            textView2.setTypeface(null, 1);
            textView2.setPadding(0, dp(8), 0, dp(8));
            this.shopList.addView(textView2);
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("items");
            if (jSONArrayOptJSONArray != null) {
                ArrayList arrayList2 = new ArrayList();
                for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i2);
                    if (jSONObjectOptJSONObject2 != null) {
                        arrayList2.add(jSONObjectOptJSONObject2);
                    }
                }
                if (this.externalMode) {
                    Collections.sort(arrayList2, new Comparator() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda7
                        @Override // java.util.Comparator
                        public final int compare(Object obj, Object obj2) {
                            return this.f$0.m103lambda$renderShop$7$comzenoappBeatZooShopActivity((JSONObject) obj, (JSONObject) obj2);
                        }
                    });
                }
                for (int i3 = 0; i3 < arrayList2.size(); i3++) {
                    JSONObject jSONObject2 = (JSONObject) arrayList2.get(i3);
                    if (jSONObject2 != null) {
                        int i4 = i3 % 2;
                        if (i4 == 0) {
                            linearLayout2 = new LinearLayout(this);
                            linearLayout2.setOrientation(0);
                            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                            this.shopList.addView(linearLayout2);
                        }
                        if (this.externalMode) {
                            viewBuildInternalGridCard = buildExternalGridCard(jSONObject2);
                        } else {
                            viewBuildInternalGridCard = buildInternalGridCard(jSONObject2);
                        }
                        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
                        if (i4 == 0) {
                            layoutParams.setMarginEnd(dp(6));
                        } else {
                            layoutParams.setMarginStart(dp(6));
                        }
                        layoutParams.bottomMargin = dp(10);
                        viewBuildInternalGridCard.setLayoutParams(layoutParams);
                        if (linearLayout2 != null) {
                            linearLayout2.addView(viewBuildInternalGridCard);
                        }
                    }
                }
            }
        }
    }

    /* JADX INFO: renamed from: lambda$renderShop$6$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ int m102lambda$renderShop$6$comzenoappBeatZooShopActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        return Integer.compare(membershipScore(jSONObject2), membershipScore(jSONObject));
    }

    /* JADX INFO: renamed from: lambda$renderShop$7$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ int m103lambda$renderShop$7$comzenoappBeatZooShopActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        return Integer.compare(membershipItemOrder(jSONObject), membershipItemOrder(jSONObject2));
    }

    private int membershipItemOrder(JSONObject jSONObject) {
        if (jSONObject == null) {
            return 50;
        }
        String lowerCase = (jSONObject.optString("name") + " " + jSONObject.optString("code")).toLowerCase(Locale.US);
        if (lowerCase.contains("daily") || lowerCase.contains("day")) {
            return 0;
        }
        return (lowerCase.contains("weekly") || lowerCase.contains("week")) ? 1 : 20;
    }

    private int membershipScore(JSONObject jSONObject) {
        if (jSONObject == null) {
            return 0;
        }
        String lowerCase = jSONObject.optString("id", "").toLowerCase(Locale.US);
        String lowerCase2 = jSONObject.optString("name", "").toLowerCase(Locale.US);
        if (lowerCase.contains("vip") || lowerCase2.contains("vip") || lowerCase2.contains("member") || lowerCase.contains("member")) {
            return 2;
        }
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("items");
        if (jSONArrayOptJSONArray != null) {
            for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null) {
                    String lowerCase3 = (jSONObjectOptJSONObject.optString("name") + " " + jSONObjectOptJSONObject.optString("code")).toLowerCase(Locale.US);
                    if (lowerCase3.contains("weekly") || lowerCase3.contains("daily") || lowerCase3.contains("member")) {
                        return 2;
                    }
                }
            }
        }
        return 0;
    }

    private int parseQty(String str) {
        if (str == null) {
            return 1;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (Character.isDigit(cCharAt)) {
                sb.append(cCharAt);
            } else if (sb.length() <= 0) {
            }
        }
        try {
            if (sb.length() > 0) {
                return Integer.parseInt(sb.toString());
            }
            return 1;
        } catch (Exception unused) {
            return 1;
        }
    }

    private boolean isHeartPack(String str, String str2) {
        StringBuilder sb = new StringBuilder();
        if (str == null) {
            str = "";
        }
        sb.append(str);
        sb.append(" ");
        if (str2 == null) {
            str2 = "";
        }
        sb.append(str2);
        return sb.toString().toLowerCase(Locale.US).contains("heart");
    }

    private boolean isTicketPack(String str, String str2) {
        StringBuilder sb = new StringBuilder();
        if (str == null) {
            str = "";
        }
        sb.append(str);
        sb.append(" ");
        if (str2 == null) {
            str2 = "";
        }
        sb.append(str2);
        return sb.toString().toLowerCase(Locale.US).contains("ticket");
    }

    private int pickTicketIcon(int i) {
        if (i <= 5) {
            return R.drawable.ic_mission_ticket;
        }
        if (i <= 15) {
            return R.drawable.ic_shop_ticket_1;
        }
        if (i <= 30) {
            return R.drawable.ic_shop_ticket_2;
        }
        return R.drawable.ic_shop_ticket_3;
    }

    private int pickHeartIcon(int i) {
        if (i <= 1) {
            return R.drawable.ic_shop_heart_1;
        }
        if (i <= 5) {
            return R.drawable.ic_shop_heart_2;
        }
        if (i <= 10) {
            return R.drawable.ic_shop_heart_3;
        }
        return R.drawable.ic_shop_heart_4;
    }

    private int pickGemIcon(int i) {
        if (i <= 1) {
            return R.drawable.ic_shop_gem_1;
        }
        if (i <= 3) {
            return R.drawable.ic_shop_gem_2;
        }
        if (i <= 10) {
            return R.drawable.ic_shop_gem_3;
        }
        return R.drawable.ic_shop_gem_4;
    }

    private int pickPackageIcon(String str, String str2, int i) {
        StringBuilder sb = new StringBuilder();
        sb.append(str != null ? str : "");
        sb.append(" ");
        sb.append(str2 != null ? str2 : "");
        String lowerCase = sb.toString().toLowerCase(Locale.US);
        if (lowerCase.contains("weekly") || lowerCase.contains("week")) {
            return R.drawable.ic_shop_member_weekly;
        }
        if (lowerCase.contains("daily") || (lowerCase.contains("day") && lowerCase.contains("member"))) {
            return R.drawable.ic_shop_member_daily;
        }
        if (lowerCase.contains("member")) {
            return R.drawable.ic_shop_member_daily;
        }
        if (lowerCase.contains("heart")) {
            return pickHeartIcon(i);
        }
        if (lowerCase.contains("ticket")) {
            return pickTicketIcon(i);
        }
        if (lowerCase.contains("gem") || lowerCase.contains("diamond")) {
            return pickGemIcon(i);
        }
        return isHeartPack(str, str2) ? pickHeartIcon(i) : isTicketPack(str, str2) ? pickTicketIcon(i) : R.drawable.ic_shop_gem_1;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildInternalGridCard(final JSONObject jSONObject) {
        final String strOptString = jSONObject.optString("name", "Item");
        final String strOptString2 = jSONObject.optString("code", "");
        final int iOptInt = jSONObject.optInt("price", 0);
        final String strOptString3 = jSONObject.optString("payment_method", "gem");
        int qty = parseQty(strOptString);
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("meta");
        if (jSONObjectOptJSONObject != null) {
            if (jSONObjectOptJSONObject.has("ticket")) {
                qty = jSONObjectOptJSONObject.optInt("ticket", qty);
            } else if (jSONObjectOptJSONObject.has("heart")) {
                qty = jSONObjectOptJSONObject.optInt("heart", qty);
            } else if (jSONObjectOptJSONObject.has("gem")) {
                qty = jSONObjectOptJSONObject.optInt("gem", qty);
            }
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        linearLayout.setPadding(dp(12), dp(14), dp(12), dp(12));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(56), dp(56));
        layoutParams.gravity = 1;
        layoutParams.bottomMargin = dp(8);
        imageView.setLayoutParams(layoutParams);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackground(null);
        imageView.setImageResource(pickPackageIcon(strOptString, strOptString2, qty));
        linearLayout.addView(imageView);
        TextView textView = new TextView(this);
        textView.setText(strOptString);
        textView.setTextColor(-1);
        textView.setTextSize(2, 13.0f);
        textView.setTypeface(null, 1);
        textView.setGravity(17);
        textView.setMaxLines(2);
        linearLayout.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = dp(10);
        linearLayout2.setLayoutParams(layoutParams2);
        linearLayout2.setPadding(dp(8), dp(10), dp(8), dp(10));
        linearLayout2.setBackgroundResource(R.drawable.bg_btn_gold);
        ImageView imageView2 = new ImageView(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(18), dp(18));
        layoutParams3.setMarginEnd(dp(6));
        imageView2.setLayoutParams(layoutParams3);
        imageView2.setImageResource(R.drawable.ic_mission_gem);
        imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView2.setBackground(null);
        linearLayout2.addView(imageView2);
        final TextView textView2 = new TextView(this);
        textView2.setText(String.format(Locale.US, "%,d", Integer.valueOf(iOptInt)));
        textView2.setTextColor(-16777216);
        textView2.setTextSize(2, 13.0f);
        textView2.setTypeface(null, 1);
        linearLayout2.addView(textView2);
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m91lambda$buildInternalGridCard$8$comzenoappBeatZooShopActivity(jSONObject, strOptString2, strOptString, iOptInt, strOptString3, textView2, view);
            }
        };
        linearLayout.setOnClickListener(onClickListener);
        linearLayout2.setOnClickListener(onClickListener);
        linearLayout.addView(linearLayout2);
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildInternalGridCard$8$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m91lambda$buildInternalGridCard$8$comzenoappBeatZooShopActivity(JSONObject jSONObject, String str, String str2, int i, String str3, TextView textView, View view) {
        confirmBuy(jSONObject, str, str2, i, str3, textView);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private LinearLayout makeRewardChip(int i, int i2) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.setMargins(dp(4), 0, dp(4), 0);
        linearLayout.setLayoutParams(layoutParams);
        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setBackground(null);
        imageView.setImageResource(i);
        linearLayout.addView(imageView);
        if (i2 > 0) {
            TextView textView = new TextView(this);
            textView.setText(String.format(Locale.US, "x%d", Integer.valueOf(i2)));
            textView.setTextColor(-10929);
            textView.setTextSize(2, 9.0f);
            textView.setGravity(17);
            textView.setTypeface(null, 1);
            linearLayout.addView(textView);
        }
        return linearLayout;
    }

    private int pickExternalIcon(JSONObject jSONObject, String str, String str2) {
        int qty;
        StringBuilder sb = new StringBuilder();
        sb.append(str != null ? str : "");
        sb.append(" ");
        if (str2 == null) {
            str2 = "";
        }
        sb.append(str2);
        String lowerCase = sb.toString().toLowerCase(Locale.US);
        if (lowerCase.contains("weekly") || lowerCase.contains("week")) {
            return R.drawable.ic_shop_member_weekly;
        }
        if (lowerCase.contains("daily") || (lowerCase.contains("day") && lowerCase.contains("member"))) {
            return R.drawable.ic_shop_member_daily;
        }
        if (lowerCase.contains("member") || lowerCase.contains("vip")) {
            return lowerCase.contains("week") ? R.drawable.ic_shop_member_weekly : R.drawable.ic_shop_member_daily;
        }
        JSONObject jSONObjectOptJSONObject = jSONObject != null ? jSONObject.optJSONObject("meta") : null;
        if (jSONObjectOptJSONObject == null || !jSONObjectOptJSONObject.has("diamond")) {
            if (jSONObject != null) {
                str = jSONObject.optString("description", str);
            }
            qty = parseQty(str);
        } else {
            qty = jSONObjectOptJSONObject.optInt("diamond", 0);
        }
        if (qty <= 400) {
            return R.drawable.ic_shop_gem_1;
        }
        if (qty <= 1100) {
            return R.drawable.ic_shop_gem_2;
        }
        if (qty <= 1800) {
            return R.drawable.ic_shop_gem_3;
        }
        return R.drawable.ic_shop_gem_4;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildExternalGridCard(final JSONObject jSONObject) {
        int i;
        String str;
        int i2;
        final String strOptString = jSONObject.optString("name", "Item");
        final String strOptString2 = jSONObject.optString("code", "");
        String strOptString3 = jSONObject.optString("description", "");
        int iOptInt = jSONObject.optInt("price", 0);
        String strOptString4 = jSONObject.optString("payment_method", "external");
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(1);
        linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        linearLayout.setPadding(dp(12), dp(14), dp(12), dp(12));
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        String lowerCase = (strOptString + " " + strOptString2).toLowerCase(Locale.US);
        boolean z = lowerCase.contains("member") || lowerCase.contains("weekly") || lowerCase.contains("daily") || lowerCase.contains("vip");
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("meta");
        if (z) {
            ImageView imageView = new ImageView(this);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(72), dp(46));
            layoutParams.gravity = 1;
            layoutParams.bottomMargin = dp(6);
            imageView.setLayoutParams(layoutParams);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setBackground(null);
            imageView.setImageResource(pickExternalIcon(jSONObject, strOptString, strOptString2));
            linearLayout.addView(imageView);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(0);
            linearLayout2.setGravity(17);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.bottomMargin = dp(6);
            linearLayout2.setLayoutParams(layoutParams2);
            if (jSONObjectOptJSONObject != null) {
                if (jSONObjectOptJSONObject.optInt("diamond", 0) > 0 || jSONObjectOptJSONObject.optInt("gem", 0) > 0) {
                    str = strOptString4;
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_gem, jSONObjectOptJSONObject.has("diamond") ? jSONObjectOptJSONObject.optInt("diamond") : jSONObjectOptJSONObject.optInt("gem")));
                } else {
                    str = strOptString4;
                }
                i = iOptInt;
                int iOptInt2 = jSONObjectOptJSONObject.optInt("tickets", jSONObjectOptJSONObject.optInt("ticket", 0));
                if (iOptInt2 > 0) {
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_ticket, iOptInt2));
                }
                int iOptInt3 = jSONObjectOptJSONObject.optInt("hearts", jSONObjectOptJSONObject.optInt("heart", 0));
                if (iOptInt3 > 0) {
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_heart, iOptInt3));
                }
            } else {
                i = iOptInt;
                str = strOptString4;
            }
            if (linearLayout2.getChildCount() == 0 && strOptString3 != null) {
                String lowerCase2 = strOptString3.toLowerCase(Locale.US);
                if (lowerCase2.contains("diamond") || lowerCase2.contains("gem")) {
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_gem, parseQty(strOptString3)));
                }
                if (lowerCase2.contains("ticket")) {
                    i2 = 0;
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_ticket, 0));
                } else {
                    i2 = 0;
                }
                if (lowerCase2.contains("heart")) {
                    linearLayout2.addView(makeRewardChip(R.drawable.ic_mission_heart, i2));
                }
            }
            linearLayout.addView(linearLayout2);
        } else {
            i = iOptInt;
            str = strOptString4;
            ImageView imageView2 = new ImageView(this);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(56), dp(56));
            layoutParams3.gravity = 1;
            layoutParams3.bottomMargin = dp(8);
            imageView2.setLayoutParams(layoutParams3);
            imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView2.setBackground(null);
            imageView2.setImageResource(pickExternalIcon(jSONObject, strOptString, strOptString2));
            linearLayout.addView(imageView2);
        }
        if (!z) {
            TextView textView = new TextView(this);
            textView.setText(strOptString);
            textView.setTextColor(-1);
            textView.setTextSize(2, 12.0f);
            textView.setTypeface(null, 1);
            textView.setGravity(17);
            textView.setMaxLines(2);
            linearLayout.addView(textView);
        }
        if (!z && strOptString3 != null && !strOptString3.isEmpty() && !strOptString3.equalsIgnoreCase(strOptString)) {
            TextView textView2 = new TextView(this);
            textView2.setText(strOptString3);
            textView2.setTextColor(-5592406);
            textView2.setTextSize(2, 10.0f);
            textView2.setGravity(17);
            textView2.setMaxLines(2);
            textView2.setPadding(0, dp(2), 0, 0);
            linearLayout.addView(textView2);
        }
        final TextView textView3 = new TextView(this);
        textView3.setText(String.format(Locale.US, "%,d Ks", Integer.valueOf(i)));
        textView3.setGravity(17);
        textView3.setTextColor(-16777216);
        textView3.setTextSize(2, 12.0f);
        textView3.setTypeface(null, 1);
        textView3.setBackgroundResource(R.drawable.bg_btn_gold);
        textView3.setPadding(dp(8), dp(10), dp(8), dp(10));
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = dp(10);
        textView3.setLayoutParams(layoutParams4);
        final int i3 = i;
        final String str2 = str;
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m90lambda$buildExternalGridCard$9$comzenoappBeatZooShopActivity(jSONObject, strOptString2, strOptString, i3, str2, textView3, view);
            }
        };
        linearLayout.setOnClickListener(onClickListener);
        textView3.setOnClickListener(onClickListener);
        linearLayout.addView(textView3);
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildExternalGridCard$9$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m90lambda$buildExternalGridCard$9$comzenoappBeatZooShopActivity(JSONObject jSONObject, String str, String str2, int i, String str3, TextView textView, View view) {
        confirmBuy(jSONObject, str, str2, i, str3, textView);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmBuy(JSONObject jSONObject, final String str, final String str2, int i, final String str3, final TextView textView) {
        String str4;
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_avatar_confirm);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(0));
            window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88f), -2);
        }
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvConfirmTitle);
        TextView textView3 = (TextView) dialog.findViewById(R.id.tvConfirmMessage);
        TextView textView4 = (TextView) dialog.findViewById(R.id.btnConfirmCancel);
        TextView textView5 = (TextView) dialog.findViewById(R.id.btnConfirmOk);
        View viewFindViewById = dialog.findViewById(R.id.ivConfirmAvatar);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(8);
        }
        if (textView2 != null) {
            textView2.setText("Buy");
        }
        if (this.externalMode) {
            str4 = String.format(Locale.US, "%,d Ks", Integer.valueOf(i));
        } else {
            str4 = String.format(Locale.US, "%,d Gem", Integer.valueOf(i));
        }
        if (textView3 != null) {
            textView3.setText(str2 + "\n" + str4 + " နဲ့ ဝယ်မလား?");
        }
        if (textView5 != null) {
            textView5.setText("Buy");
        }
        if (textView4 != null) {
            textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda15
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        View viewFindViewById2 = dialog.findViewById(R.id.btnCloseAvatarConfirm);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda16
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        if (textView5 != null) {
            textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m92lambda$confirmBuy$12$comzenoappBeatZooShopActivity(dialog, str, str2, str3, textView, view);
                }
            });
        }
        dialog.show();
    }

    /* JADX INFO: renamed from: lambda$confirmBuy$12$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m92lambda$confirmBuy$12$comzenoappBeatZooShopActivity(Dialog dialog, String str, String str2, String str3, TextView textView, View view) {
        dialog.dismiss();
        doBuy(str, str2, str3, textView);
    }

    private void doBuy(final String str, final String str2, final String str3, final TextView textView) {
        if (textView != null) {
            textView.setEnabled(false);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m95lambda$doBuy$15$comzenoappBeatZooShopActivity(str3, str, str2, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doBuy$15$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m95lambda$doBuy$15$comzenoappBeatZooShopActivity(String str, String str2, String str3, final TextView textView) {
        String str4;
        try {
            JSONObject jSONObject = new JSONObject();
            if (this.externalMode || "external".equalsIgnoreCase(str)) {
                str4 = "/payment/package";
                jSONObject.put("code", str2);
            } else {
                str4 = "/cart/buy/internal";
                jSONObject.put("item_code", str2);
                jSONObject.put("note", str3);
            }
            Response responseExecute = this.http.newCall(apiPost(str4, jSONObject.toString()).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject2 = new JSONObject(strString);
                boolean z = true;
                if (jSONObject2.optInt("status") != 1 && (jSONObject2.optJSONObject("data") == null || !jSONObject2.optJSONObject("data").has("payment_log_id"))) {
                    z = false;
                }
                final String strOptString = jSONObject2.optString("message", z ? "Purchase successful" : "Buy failed");
                this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m93lambda$doBuy$13$comzenoappBeatZooShopActivity(textView, strOptString);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooShopActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m94lambda$doBuy$14$comzenoappBeatZooShopActivity(textView, e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doBuy$13$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m93lambda$doBuy$13$comzenoappBeatZooShopActivity(TextView textView, String str) {
        if (textView != null) {
            textView.setEnabled(true);
        }
        toast(str);
    }

    /* JADX INFO: renamed from: lambda$doBuy$14$com-zeno-app-BeatZooShopActivity, reason: not valid java name */
    /* synthetic */ void m94lambda$doBuy$14$comzenoappBeatZooShopActivity(TextView textView, Exception exc) {
        if (textView != null) {
            textView.setEnabled(true);
        }
        toast("Error: " + exc.getMessage());
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
