package com.zeno.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final class LiveConfig {
    private static final int CONFIRM = 2;
    private static final long GAME_INTERVAL_MS = 3000;
    private static final long INTERVAL_MS = 8000;
    private static final String URL = "https://zenoofficial.x10.mx/myid/message.json";
    private static volatile RemoteConfig current;
    private static String lastRaw;
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(6, TimeUnit.SECONDS).readTimeout(6, TimeUnit.SECONDS).build();
    private static final CopyOnWriteArrayList<Listener> listeners = new CopyOnWriteArrayList<>();
    private static final List<WeakReference<Activity>> alive = new ArrayList();
    private static int startedCount = 0;
    private static boolean running = false;
    private static boolean closeShown = false;
    private static long reqSeq = 0;
    private static long appliedSeq = 0;
    private static final String[] GAME_KEYS = {"kongisland", "kittyfall", "softclimber", "myidgo", "beatzoo", "carracing", "fightingfish"};
    private static final HashMap<String, Integer> streak = new HashMap<>();
    private static int closeStreak = 0;
    private static WeakReference<Activity> top = new WeakReference<>(null);
    private static final Runnable tick = new Runnable() { // from class: com.zeno.app.LiveConfig.1
        @Override // java.lang.Runnable
        public void run() {
            if (LiveConfig.running) {
                long jAccess$104 = LiveConfig.access$104();
                LiveConfig.http.newCall(new Request.Builder().url("https://zenoofficial.x10.mx/myid/message.json?t=" + System.currentTimeMillis()).header("Cache-Control", "no-cache").get().build()).enqueue(new C00001(jAccess$104));
            }
        }

        /* JADX INFO: renamed from: com.zeno.app.LiveConfig$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
        class C00001 implements Callback {
            final /* synthetic */ long val$seq;

            C00001(long j) {
                this.val$seq = j;
            }

            public void onFailure(Call call, IOException iOException) {
                LiveConfig.schedule();
            }

            public void onResponse(Call call, Response response) throws IOException {
                final String strString = response.body() != null ? response.body().string() : "";
                boolean zIsSuccessful = response.isSuccessful();
                response.close();
                if (zIsSuccessful) {
                    try {
                        final RemoteConfig remoteConfig = RemoteConfig.parse(strString);
                        Handler handler = LiveConfig.main;
                        final long j = this.val$seq;
                        handler.post(new Runnable() { // from class: com.zeno.app.LiveConfig$1$1$$ExternalSyntheticLambda0
                            @Override // java.lang.Runnable
                            public final void run() {
                                LiveConfig.handle(strString, remoteConfig, j);
                            }
                        });
                    } catch (Exception unused) {
                    }
                }
                LiveConfig.schedule();
            }
        }
    };
    private static WeakReference<Activity> updateShownOn = new WeakReference<>(null);
    private static String pendingKickMsg = null;

    public interface Listener {
        void onConfig(RemoteConfig remoteConfig);
    }

    static /* synthetic */ long access$104() {
        long j = reqSeq + 1;
        reqSeq = j;
        return j;
    }

    private LiveConfig() {
    }

    public static RemoteConfig current() {
        return current;
    }

    public static void seed(String str, RemoteConfig remoteConfig) {
        if (remoteConfig == null || str == null) {
            return;
        }
        current = remoteConfig;
        lastRaw = str;
        updateStreaks(remoteConfig);
    }

    public static void addListener(Listener listener) {
        if (listener == null) {
            return;
        }
        listeners.addIfAbsent(listener);
        RemoteConfig remoteConfig = current;
        if (remoteConfig != null) {
            listener.onConfig(remoteConfig);
        }
    }

    public static void removeListener(Listener listener) {
        listeners.remove(listener);
    }

    public static void refreshNow() {
        if (startedCount > 0) {
            Handler handler = main;
            Runnable runnable = tick;
            handler.removeCallbacks(runnable);
            handler.post(runnable);
        }
    }

    static void onActivityCreated(Activity activity) {
        alive.add(new WeakReference<>(activity));
        RemoteConfig remoteConfig = current;
        if (remoteConfig == null || !isGameDisabled(activity, remoteConfig)) {
            return;
        }
        if (confirmedDisabled(gameKeyOf(activity))) {
            kick(activity);
        } else {
            refreshNow();
        }
    }

    static void onActivityDestroyed(Activity activity) {
        Iterator<WeakReference<Activity>> it = alive.iterator();
        while (it.hasNext()) {
            Activity activity2 = it.next().get();
            if (activity2 == null || activity2 == activity) {
                it.remove();
            }
        }
        stopPollingIfIdle();
    }

    static void onActivityStarted(Activity activity) {
        top = new WeakReference<>(activity);
        RemoteConfig remoteConfig = current;
        if (remoteConfig != null) {
            checkUpdate(activity, remoteConfig);
        }
        startedCount++;
        if (running) {
            return;
        }
        running = true;
        Handler handler = main;
        Runnable runnable = tick;
        handler.removeCallbacks(runnable);
        handler.post(runnable);
    }

    static void onActivityStopped(Activity activity) {
        startedCount = Math.max(0, startedCount - 1);
        stopPollingIfIdle();
    }

    private static boolean gameAlive() {
        Iterator<WeakReference<Activity>> it = alive.iterator();
        while (it.hasNext()) {
            Activity activity = it.next().get();
            if (activity != null && !activity.isFinishing() && !gameKeyOf(activity).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private static void stopPollingIfIdle() {
        if (startedCount != 0 || gameAlive()) {
            return;
        }
        running = false;
        main.removeCallbacks(tick);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void schedule() {
        main.post(new Runnable() { // from class: com.zeno.app.LiveConfig$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                LiveConfig.lambda$schedule$0();
            }
        });
    }

    static /* synthetic */ void lambda$schedule$0() {
        if (running) {
            Handler handler = main;
            Runnable runnable = tick;
            handler.removeCallbacks(runnable);
            handler.postDelayed(runnable, gameAlive() ? GAME_INTERVAL_MS : INTERVAL_MS);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void handle(String str, RemoteConfig remoteConfig, long j) {
        Activity activity;
        if (j < appliedSeq) {
            return;
        }
        appliedSeq = j;
        boolean z = true;
        boolean z2 = current == null;
        current = remoteConfig;
        updateStreaks(remoteConfig);
        if (!z2 && str.equals(lastRaw)) {
            z = false;
        }
        lastRaw = str;
        if (z) {
            Iterator<Listener> it = listeners.iterator();
            while (it.hasNext()) {
                it.next().onConfig(remoteConfig);
            }
        }
        enforce(remoteConfig);
        if (!z || (activity = top.get()) == null) {
            return;
        }
        checkUpdate(activity, remoteConfig);
    }

    private static boolean flagOf(RemoteConfig remoteConfig, String str) {
        str.hashCode();
        switch (str) {
            case "myidgo":
                return remoteConfig.showMyIDGo;
            case "beatzoo":
                return remoteConfig.showBeatZoo;
            case "carracing":
                return remoteConfig.showCarRacing;
            case "kongisland":
                return remoteConfig.showKongIsland;
            case "softclimber":
                return remoteConfig.showSoftClimber;
            case "fightingfish":
                return remoteConfig.showFightingFish;
            case "kittyfall":
                return remoteConfig.showKittyFall;
            default:
                return true;
        }
    }

    private static void updateStreaks(RemoteConfig remoteConfig) {
        String[] strArr = GAME_KEYS;
        int length = strArr.length;
        int i = 0;
        while (true) {
            int iIntValue = 1;
            if (i >= length) {
                break;
            }
            String str = strArr[i];
            HashMap<String, Integer> map = streak;
            Integer num = map.get(str);
            if (flagOf(remoteConfig, str)) {
                iIntValue = 0;
            } else if (num != null) {
                iIntValue = 1 + num.intValue();
            }
            map.put(str, Integer.valueOf(iIntValue));
            i++;
        }
        closeStreak = "close".equalsIgnoreCase(remoteConfig.status) ? closeStreak + 1 : 0;
    }

    private static boolean confirmedDisabled(String str) {
        Integer num;
        return (str == null || str.isEmpty() || (num = streak.get(str)) == null || num.intValue() < CONFIRM) ? false : true;
    }

    private static void enforce(RemoteConfig remoteConfig) {
        Activity activity = top.get();
        if (closeStreak >= CONFIRM && !closeShown && activity != null && !activity.isFinishing() && !(activity instanceof SplashActivity)) {
            closeShown = true;
            ZDialog.showCloseApp(activity, remoteConfig.closeTitle, (remoteConfig.message == null || remoteConfig.message.isEmpty()) ? "This app is currently closed. Please check back later." : remoteConfig.message);
        }
        ArrayList<Activity> arrayList = new ArrayList();
        Iterator<WeakReference<Activity>> it = alive.iterator();
        while (it.hasNext()) {
            Activity activity2 = it.next().get();
            if (activity2 != null && !activity2.isFinishing()) {
                arrayList.add(activity2);
            }
        }
        for (Activity activity3 : arrayList) {
            String strGameKeyOf = gameKeyOf(activity3);
            if (confirmedDisabled(strGameKeyOf)) {
                Log.w("ZenoLive", "kick " + activity3.getClass().getSimpleName() + " (" + strGameKeyOf + " closed x" + streak.get(strGameKeyOf) + ") raw=" + lastRaw);
                kick(activity3);
            }
        }
        if (confirmedDisabled("kittyfall")) {
            stopSvc(KittyFallService.class);
        }
        if (confirmedDisabled("kongisland")) {
            stopSvc(KongIslandService.class);
        }
        if (confirmedDisabled("softclimber")) {
            stopSvc(SoftClimbersService.class);
        }
    }

    public static boolean needsUpdate(Activity activity, RemoteConfig remoteConfig) {
        return (remoteConfig == null || remoteConfig.version == null || remoteConfig.version.isEmpty() || remoteConfig.version.equals(appVersion(activity))) ? false : true;
    }

    private static String appVersion(Activity activity) {
        try {
            return activity.getPackageManager().getPackageInfo(activity.getPackageName(), 0).versionName;
        } catch (Exception unused) {
            return "";
        }
    }

    private static void checkUpdate(Activity activity, RemoteConfig remoteConfig) {
        if ((activity instanceof SplashActivity) || activity.isFinishing() || !needsUpdate(activity, remoteConfig) || updateShownOn.get() == activity) {
            return;
        }
        updateShownOn = new WeakReference<>(activity);
        ZDialog.showUpdateRequired(activity, appVersion(activity), remoteConfig.version, remoteConfig.updateLink != null ? remoteConfig.updateLink : "", remoteConfig.updateTitle, remoteConfig.updateMessage);
    }

    private static void stopSvc(Class<?> cls) {
        Activity activity = top.get();
        if (activity == null) {
            return;
        }
        try {
            activity.getApplicationContext().stopService(new Intent(activity.getApplicationContext(), cls));
        } catch (Exception unused) {
        }
    }

    private static void kick(Activity activity) {
        RemoteConfig remoteConfig = current;
        pendingKickMsg = remoteConfig != null ? remoteConfig.lockedText(gameKeyOf(activity), "message", "ဤ Game ကို Owner မှ ယာယီပိတ်ထားပါသည်။") : "ဤ Game ကို Owner မှ ယာယီပိတ်ထားပါသည်။";
        activity.finish();
    }

    static void onActivityResumed(Activity activity) {
        View viewFindViewById;
        if (pendingKickMsg == null || activity.isFinishing()) {
            return;
        }
        RemoteConfig remoteConfig = current;
        if ((remoteConfig == null || !isGameDisabled(activity, remoteConfig)) && (viewFindViewById = activity.findViewById(android.R.id.content)) != null) {
            String str = pendingKickMsg;
            pendingKickMsg = null;
            ZSnack.make(viewFindViewById, str, 0).show();
        }
    }

    private static String gameKeyOf(Activity activity) {
        String simpleName = activity.getClass().getSimpleName();
        return simpleName.startsWith("KongIsland") ? "kongisland" : simpleName.startsWith("KittyFall") ? "kittyfall" : simpleName.startsWith("SoftClimbers") ? "softclimber" : simpleName.startsWith("MyIDGo") ? "myidgo" : simpleName.startsWith("BeatZoo") ? "beatzoo" : simpleName.startsWith("CarRacing") ? "carracing" : simpleName.startsWith("FightingFish") ? "fightingfish" : "";
    }

    private static boolean isGameDisabled(Activity activity, RemoteConfig remoteConfig) {
        String strGameKeyOf = gameKeyOf(activity);
        return (strGameKeyOf.isEmpty() || flagOf(remoteConfig, strGameKeyOf)) ? false : true;
    }
}
