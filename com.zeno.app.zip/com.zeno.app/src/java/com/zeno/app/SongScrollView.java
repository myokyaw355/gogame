package com.zeno.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewParent;
import android.widget.ScrollView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SongScrollView extends ScrollView {
    public SongScrollView(Context context) {
        super(context);
        init();
    }

    public SongScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public SongScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    private void init() {
        setFillViewport(false);
        setOverScrollMode(2);
        setVerticalScrollBarEnabled(false);
        setNestedScrollingEnabled(false);
    }

    private void lockParents(boolean z) {
        for (ViewParent parent = getParent(); parent != null; parent = parent.getParent()) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0010  */
    /* JADX WARN: Removed duplicated region for block: B:11:0x0015  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean dispatchTouchEvent(android.view.MotionEvent r4) {
        /*
            r3 = this;
            int r0 = r4.getActionMasked()
            r1 = 1
            if (r0 == 0) goto L15
            if (r0 == r1) goto L10
            r2 = 2
            if (r0 == r2) goto L15
            r1 = 3
            if (r0 == r1) goto L10
            goto L18
        L10:
            r0 = 0
            r3.lockParents(r0)
            goto L18
        L15:
            r3.lockParents(r1)
        L18:
            boolean r4 = super.dispatchTouchEvent(r4)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.SongScrollView.dispatchTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.widget.ScrollView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() == 0) {
            lockParents(true);
        }
        try {
            return super.onInterceptTouchEvent(motionEvent);
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // android.widget.ScrollView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() == 0 || motionEvent.getActionMasked() == 2) {
            lockParents(true);
        }
        try {
            return super.onTouchEvent(motionEvent);
        } catch (Exception unused) {
            return false;
        }
    }
}
