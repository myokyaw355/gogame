package com.zeno.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Property;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;
import com.bumptech.glide.request.RequestOptions;
import com.zeno.app.SoftClimbersService;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SoftClimbersActivity extends BaseActivity {
    private static final int COL_GREEN = -11751600;
    private static final int COL_GREY = -6381922;
    private static final int COL_YELLOW = -3632086;
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=UTF-8");
    static final int LOG_CLEAR = 1;
    static final int LOG_ERROR = 5;
    static final int LOG_LOGIN = 7;
    static final int LOG_PLAY = 0;
    static final int LOG_PRIZE = 6;
    static final int LOG_START = 3;
    static final int LOG_STOP = 4;
    static final int LOG_WAIT = 2;
    private static final String SC_BASE = "https://api.softclimbers.com";
    private View avatarSkeleton;
    private ValueAnimator avatarSkeletonAnim;
    private Button btnAutoPlay;
    private View btnAutoPlaySkeleton;
    private ValueAnimator btnAutoPlaySkeletonAnim;
    private View contentPlay;
    private View contentRank;
    private ExecutorService exec;
    private ImageView ivAvatar;
    private ImageView ivBuyCardIcon;
    private View levelBadgeContent;
    private View levelBadgeSkeleton;
    private ValueAnimator levelBadgeSkeletonAnim;
    private LinearLayout llError;
    private LinearLayout llLoading;
    private LinearLayout llRows;
    private View pbProfileLoading;
    private View playingCardContent;
    private View playingCardSkeleton;
    private ValueAnimator playingCardSkeletonAnim;
    private ValueAnimator profileSkeletonAnim;
    private ProgressBar progressGame;
    private ValueAnimator rankSkeletonAnim;
    private LinearLayout rankUserFooter;
    private LinearLayout rankUserRow;
    private View rowProfileContent;
    private View scMainContent;
    private View scMainSkeleton;
    private ValueAnimator scMainSkeletonAnim;
    private SessionManager session;
    private NestedScrollView svRows;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout tabPlay;
    private View tabPlayUnderline;
    private LinearLayout tabRank;
    private View tabRankUnderline;
    private Runnable timerRunnable;
    private TextView tvAutoPlayStatus;
    private TextView tvBuyCardLabel;
    private TextView tvCurrentLevel;
    private TextView tvDailyLimit;
    private TextView tvEndDate;
    private TextView tvError;
    private TextView tvGameProgress;
    private TextView tvInfoLevel;
    private TextView tvInfoScore;
    private TextView tvInfoSessionScore;
    private TextView tvInfoStarted;
    private TextView tvMonthlyTab;
    private TextView tvPlanBadge;
    private TextView tvPlayingBig;
    private TextView tvProfileName;
    private TextView tvProfilePhone;
    private TextView tvProgressLeft;
    private TextView tvProgressRight;
    private TextView tvRemaining;
    private TextView tvStatus;
    private TextView tvWeeklyTab;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build();
    private volatile boolean running = false;
    private volatile boolean stopping = false;
    private volatile String scToken = null;
    private volatile int remainingAttempts = -1;
    private volatile int selectedStartLevel = LOG_CLEAR;
    private String rankType = "WEEKLY";
    private SoftClimbersService.ServiceBinder serviceBinder = null;
    private boolean serviceBound = false;
    private final ServiceConnection conn = new AnonymousClass1();
    private final SoftClimbersService.GameCallback gameCallback = new AnonymousClass2();
    private long sessionStartMs = 0;
    private long sessionStartScore = 0;

    /* JADX INFO: Access modifiers changed from: private */
    public void addLog(String str, int i) {
    }

    private void onDone() {
    }

    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    private static class HttpResult {
        final String body;
        final int status;

        HttpResult(int i, String str) {
            this.status = i;
            this.body = str == null ? "" : str;
        }
    }

    private static class CircleCropTransform extends BitmapTransformation {
        private CircleCropTransform() {
        }

        /* synthetic */ CircleCropTransform(AnonymousClass1 anonymousClass1) {
            this();
        }

        protected Bitmap transform(BitmapPool bitmapPool, Bitmap bitmap, int i, int i2) {
            int iMin = Math.min(bitmap.getWidth(), bitmap.getHeight());
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmap, (bitmap.getWidth() - iMin) / SoftClimbersActivity.LOG_WAIT, (bitmap.getHeight() - iMin) / SoftClimbersActivity.LOG_WAIT, iMin, iMin);
            Bitmap bitmap2 = bitmapPool.get(iMin, iMin, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap2);
            Paint paint = new Paint(SoftClimbersActivity.LOG_CLEAR);
            paint.setShader(new BitmapShader(bitmapCreateBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            float f = iMin / 2.0f;
            canvas.drawCircle(f, f, f, paint);
            bitmapCreateBitmap.recycle();
            return bitmap2;
        }

        public void updateDiskCacheKey(MessageDigest messageDigest) {
            messageDigest.update("SC_CircleCrop".getBytes());
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.SoftClimbersActivity$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass1 implements ServiceConnection {
        AnonymousClass1() {
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            SoftClimbersActivity.this.serviceBinder = (SoftClimbersService.ServiceBinder) iBinder;
            SoftClimbersActivity.this.serviceBound = true;
            SoftClimbersService service = SoftClimbersActivity.this.serviceBinder.getService();
            SoftClimbersActivity softClimbersActivity = SoftClimbersActivity.this;
            if (softClimbersActivity.ok(softClimbersActivity.scToken)) {
                service.scToken = SoftClimbersActivity.this.scToken;
            }
            service.setCallback(SoftClimbersActivity.this.gameCallback);
            if (service.isRunning()) {
                SoftClimbersActivity.this.running = true;
                SoftClimbersActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m691lambda$onServiceConnected$0$comzenoappSoftClimbersActivity$1();
                    }
                });
            }
        }

        /* JADX INFO: renamed from: lambda$onServiceConnected$0$com-zeno-app-SoftClimbersActivity$1, reason: not valid java name */
        /* synthetic */ void m691lambda$onServiceConnected$0$comzenoappSoftClimbersActivity$1() {
            SoftClimbersActivity.this.setAutoPlayButtonState(true);
            SoftClimbersActivity.this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_stop);
            SoftClimbersActivity.this.btnAutoPlay.setBackgroundTintList(null);
            SoftClimbersActivity.this.btnAutoPlay.setEnabled(true);
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            SoftClimbersActivity.this.serviceBound = false;
            SoftClimbersActivity.this.serviceBinder = null;
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.SoftClimbersActivity$2, reason: invalid class name */
    class AnonymousClass2 implements SoftClimbersService.GameCallback {
        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onSubscriptionUpdate(boolean z) {
        }

        AnonymousClass2() {
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onStateChanged(final boolean z) {
            SoftClimbersActivity.this.running = z;
            SoftClimbersActivity.this.stopping = false;
            SoftClimbersActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m695lambda$onStateChanged$1$comzenoappSoftClimbersActivity$2(z);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onStateChanged$1$com-zeno-app-SoftClimbersActivity$2, reason: not valid java name */
        /* synthetic */ void m695lambda$onStateChanged$1$comzenoappSoftClimbersActivity$2(boolean z) {
            if (!z) {
                SoftClimbersActivity.this.setAutoPlayButtonState(false);
                SoftClimbersActivity.this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_autoplay);
                SoftClimbersActivity.this.btnAutoPlay.setBackgroundTintList(null);
                SoftClimbersActivity.this.btnAutoPlay.setEnabled(true);
                if (SoftClimbersActivity.this.tvAutoPlayStatus != null) {
                    SoftClimbersActivity.this.tvAutoPlayStatus.setVisibility(8);
                }
                SoftClimbersActivity.this.stopTimerUi();
                if (SoftClimbersActivity.this.serviceBinder != null) {
                    SoftClimbersActivity softClimbersActivity = SoftClimbersActivity.this;
                    softClimbersActivity.scToken = softClimbersActivity.serviceBinder.getService().getScToken();
                }
                SoftClimbersActivity.this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$2$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m694lambda$onStateChanged$0$comzenoappSoftClimbersActivity$2();
                    }
                });
                return;
            }
            SoftClimbersActivity.this.setAutoPlayButtonState(true);
            SoftClimbersActivity.this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_stop);
            SoftClimbersActivity.this.btnAutoPlay.setBackgroundTintList(null);
            SoftClimbersActivity.this.btnAutoPlay.setEnabled(true);
            if (SoftClimbersActivity.this.tvAutoPlayStatus != null) {
                SoftClimbersActivity.this.tvAutoPlayStatus.setVisibility(SoftClimbersActivity.LOG_PLAY);
                SoftClimbersActivity.this.tvAutoPlayStatus.setText("● RUNNING");
                SoftClimbersActivity.this.tvAutoPlayStatus.setTextColor(SoftClimbersActivity.COL_GREEN);
            }
            SoftClimbersActivity.this.sessionStartMs = System.currentTimeMillis();
            if (SoftClimbersActivity.this.tvInfoStarted != null) {
                SoftClimbersActivity.this.tvInfoStarted.setText(new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.getDefault()).format(new Date(SoftClimbersActivity.this.sessionStartMs)));
            }
        }

        /* JADX INFO: renamed from: lambda$onStateChanged$0$com-zeno-app-SoftClimbersActivity$2, reason: not valid java name */
        /* synthetic */ void m694lambda$onStateChanged$0$comzenoappSoftClimbersActivity$2() {
            SoftClimbersActivity softClimbersActivity = SoftClimbersActivity.this;
            if (softClimbersActivity.ok(softClimbersActivity.scToken)) {
                SoftClimbersActivity softClimbersActivity2 = SoftClimbersActivity.this;
                softClimbersActivity2.fetchSubscriptionStatus(softClimbersActivity2.scToken);
            }
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onStatsUpdated(final int i, final int i2, final long j) {
            SoftClimbersActivity.this.remainingAttempts = i;
            SoftClimbersActivity.this.selectedStartLevel = i2;
            SoftClimbersActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$2$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m696lambda$onStatsUpdated$2$comzenoappSoftClimbersActivity$2(i, i2, j);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onStatsUpdated$2$com-zeno-app-SoftClimbersActivity$2, reason: not valid java name */
        /* synthetic */ void m696lambda$onStatsUpdated$2$comzenoappSoftClimbersActivity$2(int i, int i2, long j) {
            SoftClimbersActivity.this.tvRemaining.setText(String.valueOf(i));
            SoftClimbersActivity.this.refreshLevelPicker();
            SoftClimbersActivity.this.tvCurrentLevel.setText("Lv." + i2);
            if (SoftClimbersActivity.this.tvGameProgress != null) {
                SoftClimbersActivity.this.tvGameProgress.setText("Level " + i2);
            }
            if (SoftClimbersActivity.this.tvInfoLevel != null) {
                SoftClimbersActivity.this.tvInfoLevel.setText(String.valueOf(i2));
            }
            if (SoftClimbersActivity.this.tvInfoScore != null) {
                SoftClimbersActivity.this.tvInfoScore.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
            }
            if (SoftClimbersActivity.this.tvInfoSessionScore != null) {
                long jMax = Math.max(0L, j - SoftClimbersActivity.this.sessionStartScore);
                SoftClimbersActivity.this.tvInfoSessionScore.setText("+" + String.format(Locale.getDefault(), "%,d", Long.valueOf(jMax)));
            }
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onLog(String str, int i) {
            SoftClimbersActivity.this.addLog(str, i);
        }

        /* JADX INFO: renamed from: lambda$onLevelStarted$3$com-zeno-app-SoftClimbersActivity$2, reason: not valid java name */
        /* synthetic */ void m692lambda$onLevelStarted$3$comzenoappSoftClimbersActivity$2(long j) {
            SoftClimbersActivity.this.startTimerUi(System.currentTimeMillis(), j);
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onLevelStarted(int i, final long j) {
            SoftClimbersActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$2$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m692lambda$onLevelStarted$3$comzenoappSoftClimbersActivity$2(j);
                }
            });
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onDrop(String str, double d, String str2) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("name", str);
                jSONObject.put("value", d);
                jSONObject.put("imageUrl", str2);
                SoftClimbersActivity.this.showDropToastDialog(jSONObject);
            } catch (Exception unused) {
            }
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onSynthesis(String str, String str2, String str3) {
            SoftClimbersActivity.this.showAutoSynthesisDialog(str, str2, str3);
        }

        @Override // com.zeno.app.SoftClimbersService.GameCallback
        public void onPlanDetails(final int i, final String str, final String str2) {
            SoftClimbersActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m693lambda$onPlanDetails$4$comzenoappSoftClimbersActivity$2(i, str, str2);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onPlanDetails$4$com-zeno-app-SoftClimbersActivity$2, reason: not valid java name */
        /* synthetic */ void m693lambda$onPlanDetails$4$comzenoappSoftClimbersActivity$2(int i, String str, String str2) {
            SoftClimbersActivity.this.tvDailyLimit.setText(String.valueOf(i));
            SoftClimbersActivity.this.tvPlanBadge.setText(str);
            SoftClimbersActivity.this.tvEndDate.setText("ends " + str2);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(COL_YELLOW);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_soft_climbers);
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Soft Climber");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        bindViews();
        populateFromSession();
        initLoad();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x0077  */
    @Override // com.zeno.app.BaseActivity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    protected void onResume() {
        /*
            r5 = this;
            super.onResume()
            com.zeno.app.SoftClimbersService$ServiceBinder r0 = r5.serviceBinder
            if (r0 == 0) goto L10
            com.zeno.app.SoftClimbersService r0 = r0.getService()
            com.zeno.app.SoftClimbersService$GameCallback r1 = r5.gameCallback
            r0.setCallback(r1)
        L10:
            com.zeno.app.SessionManager r0 = r5.session
            java.lang.String r0 = r0.getPhone()
            com.zeno.app.SessionManager r1 = r5.session
            java.lang.String r1 = r1.getScPlayerPhone()
            com.zeno.app.SoftClimbersService$ServiceBinder r2 = r5.serviceBinder
            r3 = 0
            if (r2 == 0) goto L2a
            com.zeno.app.SoftClimbersService r2 = r2.getService()
            java.lang.String r2 = r2.getBoundPhone()
            goto L2b
        L2a:
            r2 = r3
        L2b:
            boolean r4 = r5.ok(r0)
            if (r4 == 0) goto L77
            boolean r4 = r5.ok(r1)
            if (r4 == 0) goto L3f
            boolean r1 = phonesMatch(r0, r1)
            if (r1 != 0) goto L3f
            r1 = 1
            goto L40
        L3f:
            r1 = 0
        L40:
            boolean r4 = r5.ok(r2)
            if (r4 == 0) goto L4d
            boolean r0 = phonesMatch(r0, r2)
            if (r0 != 0) goto L4d
            goto L4f
        L4d:
            if (r1 == 0) goto L77
        L4f:
            r5.scToken = r3
            com.zeno.app.SessionManager r0 = r5.session
            r0.clearScSession()
            com.zeno.app.SoftClimbersService$ServiceBinder r0 = r5.serviceBinder
            if (r0 == 0) goto L61
            com.zeno.app.SoftClimbersService r0 = r0.getService()
            r0.clearInMemorySession()
        L61:
            android.widget.TextView r0 = r5.tvCurrentLevel
            if (r0 == 0) goto L6a
            java.lang.String r1 = "Lv.--"
            r0.setText(r1)
        L6a:
            android.widget.TextView r0 = r5.tvRemaining
            if (r0 == 0) goto L73
            java.lang.String r1 = "0"
            r0.setText(r1)
        L73:
            r5.populateFromSession()
            goto L7a
        L77:
            r5.populateFromSession()
        L7a:
            java.util.concurrent.ExecutorService r0 = r5.exec
            if (r0 == 0) goto L8e
            boolean r0 = r0.isShutdown()
            if (r0 != 0) goto L8e
            java.util.concurrent.ExecutorService r0 = r5.exec
            com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda2 r1 = new com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda2
            r1.<init>()
            r0.execute(r1)
        L8e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.SoftClimbersActivity.onResume():void");
    }

    /* JADX INFO: renamed from: lambda$onResume$0$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m684lambda$onResume$0$comzenoappSoftClimbersActivity() {
        this.scToken = resolveScToken();
        if (ok(this.scToken)) {
            this.ui.post(new SoftClimbersActivity$$ExternalSyntheticLambda21(this));
            fetchSubscriptionStatus(this.scToken);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStart() {
        super.onStart();
        bindService(new Intent((Context) this, (Class<?>) SoftClimbersService.class), this.conn, LOG_CLEAR);
    }

    protected void onStop() {
        SoftClimbersService.ServiceBinder serviceBinder;
        super.onStop();
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        serviceBinder.getService().clearCallback();
        unbindService(this.conn);
        this.serviceBound = false;
        this.serviceBinder = null;
    }

    protected void onDestroy() {
        SoftClimbersService.ServiceBinder serviceBinder;
        super.onDestroy();
        this.stopping = true;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null) {
            serviceBinder.getService().clearCallback();
            unbindService(this.conn);
            this.serviceBound = false;
            this.serviceBinder = null;
        }
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    private void bindViews() {
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        this.pbProfileLoading = findViewById(R.id.pbProfileLoading);
        this.avatarSkeleton = findViewById(R.id.avatarSkeleton);
        this.scMainSkeleton = findViewById(R.id.scMainSkeleton);
        this.scMainContent = findViewById(R.id.scMainContent);
        this.levelBadgeSkeleton = findViewById(R.id.levelBadgeSkeleton);
        this.levelBadgeContent = findViewById(R.id.levelBadgeContent);
        this.playingCardSkeleton = findViewById(R.id.playingCardSkeleton);
        this.playingCardContent = findViewById(R.id.playingCardContent);
        this.btnAutoPlaySkeleton = findViewById(R.id.btnAutoPlaySkeleton);
        this.rowProfileContent = findViewById(R.id.rowProfileContent);
        this.tvProfileName = (TextView) findViewById(R.id.tvProfileName);
        this.tvProfilePhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.tvRemaining = (TextView) findViewById(R.id.tvRemaining);
        this.tvDailyLimit = (TextView) findViewById(R.id.tvDailyLimit);
        this.tvPlanBadge = (TextView) findViewById(R.id.tvPlanBadge);
        this.tvEndDate = (TextView) findViewById(R.id.tvEndDate);
        this.tvCurrentLevel = (TextView) findViewById(R.id.tvCurrentLevel);
        this.btnAutoPlay = (Button) findViewById(R.id.btnAutoPlay);
        this.tvStatus = (TextView) findViewById(R.id.tvStatus);
        SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayout;
        this.contentPlay = swipeRefreshLayout;
        this.contentRank = findViewById(R.id.contentRank);
        this.tabPlay = (LinearLayout) findViewById(R.id.tabPlay);
        this.tabRank = (LinearLayout) findViewById(R.id.tabRank);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabRankUnderline = findViewById(R.id.tabRankUnderline);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.llError = (LinearLayout) findViewById(R.id.llError);
        this.llRows = (LinearLayout) findViewById(R.id.llRows);
        this.svRows = (NestedScrollView) findViewById(R.id.svRows);
        this.tvError = (TextView) findViewById(R.id.tvError);
        this.tvWeeklyTab = (TextView) findViewById(R.id.tvWeeklyTab);
        this.tvMonthlyTab = (TextView) findViewById(R.id.tvMonthlyTab);
        this.rankUserFooter = (LinearLayout) findViewById(R.id.rankUserFooter);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        LinearLayout linearLayout = this.tabPlay;
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m668lambda$bindViews$1$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        LinearLayout linearLayout2 = this.tabRank;
        if (linearLayout2 != null) {
            linearLayout2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda7
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m669lambda$bindViews$2$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        TextView textView = this.tvWeeklyTab;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda8
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m670lambda$bindViews$3$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        TextView textView2 = this.tvMonthlyTab;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda9
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m671lambda$bindViews$4$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        Button button = (Button) findViewById(R.id.btnRetry);
        if (button != null) {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda10
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m672lambda$bindViews$5$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        this.btnAutoPlay.setBackgroundTintList(null);
        this.btnAutoPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m673lambda$bindViews$6$comzenoappSoftClimbersActivity(view);
            }
        });
        ImageView imageView = (ImageView) findViewById(R.id.btnPrizeHistory);
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda13
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m674lambda$bindViews$7$comzenoappSoftClimbersActivity(view);
                }
            });
            startGiftPulse(imageView);
        }
        this.ivBuyCardIcon = (ImageView) findViewById(R.id.ivBuyCardIcon);
        this.tvBuyCardLabel = (TextView) findViewById(R.id.tvBuyCardLabel);
        View viewFindViewById = findViewById(R.id.btnShopCard);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda14
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m675lambda$bindViews$8$comzenoappSoftClimbersActivity(view);
                }
            });
        }
        this.swipeRefresh.setColorSchemeColors(new int[]{COL_YELLOW});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(-14803426);
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda15
            public final void onRefresh() {
                this.f$0.doRefresh();
            }
        });
        this.tvAutoPlayStatus = (TextView) findViewById(R.id.tvAutoPlayStatus);
        this.tvPlayingBig = (TextView) findViewById(R.id.tvPlayingBig);
        this.tvGameProgress = (TextView) findViewById(R.id.tvGameProgress);
        this.progressGame = (ProgressBar) findViewById(R.id.progressGame);
        this.tvInfoLevel = (TextView) findViewById(R.id.tvInfoLevel);
        this.tvInfoScore = (TextView) findViewById(R.id.tvInfoScore);
        this.tvInfoSessionScore = (TextView) findViewById(R.id.tvInfoSessionScore);
        this.tvInfoStarted = (TextView) findViewById(R.id.tvInfoStarted);
        this.tvProgressLeft = (TextView) findViewById(R.id.tvProgressLeft);
        this.tvProgressRight = (TextView) findViewById(R.id.tvProgressRight);
    }

    /* JADX INFO: renamed from: lambda$bindViews$1$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m668lambda$bindViews$1$comzenoappSoftClimbersActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m669lambda$bindViews$2$comzenoappSoftClimbersActivity(View view) {
        showRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m670lambda$bindViews$3$comzenoappSoftClimbersActivity(View view) {
        this.rankType = "WEEKLY";
        switchRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m671lambda$bindViews$4$comzenoappSoftClimbersActivity(View view) {
        this.rankType = "MONTHLY";
        switchRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m672lambda$bindViews$5$comzenoappSoftClimbersActivity(View view) {
        fetchLeaderboard(this.rankType);
    }

    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m673lambda$bindViews$6$comzenoappSoftClimbersActivity(View view) {
        if (this.running) {
            stopPlay();
        } else {
            startPlay();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m674lambda$bindViews$7$comzenoappSoftClimbersActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) SoftClimbersPrizeHistoryActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m675lambda$bindViews$8$comzenoappSoftClimbersActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) SoftClimbersShopActivity.class));
    }

    private void startAllSkeletons() {
        View view = this.pbProfileLoading;
        if (view != null) {
            view.setVisibility(LOG_PLAY);
            View view2 = this.rowProfileContent;
            if (view2 != null) {
                view2.setVisibility(8);
            }
            this.profileSkeletonAnim = SkeletonPulse.start(this.pbProfileLoading);
            View view3 = this.avatarSkeleton;
            if (view3 != null) {
                view3.setVisibility(LOG_PLAY);
                this.avatarSkeletonAnim = SkeletonPulse.start(this.avatarSkeleton);
            }
            ImageView imageView = this.ivAvatar;
            if (imageView != null) {
                imageView.setVisibility(LOG_STOP);
            }
            View view4 = this.scMainSkeleton;
            if (view4 != null) {
                view4.setVisibility(LOG_PLAY);
                View view5 = this.scMainContent;
                if (view5 != null) {
                    view5.setVisibility(8);
                }
                this.scMainSkeletonAnim = SkeletonPulse.start(this.scMainSkeleton);
            }
            View view6 = this.levelBadgeSkeleton;
            if (view6 != null) {
                view6.setVisibility(LOG_PLAY);
                View view7 = this.levelBadgeContent;
                if (view7 != null) {
                    view7.setVisibility(8);
                }
                this.levelBadgeSkeletonAnim = SkeletonPulse.start(this.levelBadgeSkeleton);
            }
            View view8 = this.playingCardSkeleton;
            if (view8 != null) {
                view8.setVisibility(LOG_PLAY);
                View view9 = this.playingCardContent;
                if (view9 != null) {
                    view9.setVisibility(8);
                }
                this.playingCardSkeletonAnim = SkeletonPulse.start(this.playingCardSkeleton);
            }
            View view10 = this.btnAutoPlaySkeleton;
            if (view10 != null) {
                view10.setVisibility(LOG_PLAY);
                Button button = this.btnAutoPlay;
                if (button != null) {
                    button.setVisibility(8);
                }
                this.btnAutoPlaySkeletonAnim = SkeletonPulse.start(this.btnAutoPlaySkeleton);
            }
        }
        TextView textView = this.tvProfileName;
        if (textView != null) {
            textView.setVisibility(LOG_STOP);
        }
        TextView textView2 = this.tvProfilePhone;
        if (textView2 != null) {
            textView2.setVisibility(LOG_STOP);
        }
    }

    private void populateFromSession() {
        startAllSkeletons();
        String phone = this.session.getPhone();
        String fullName = this.session.getFullName();
        String avatarUrl = this.session.getAvatarUrl();
        TextView textView = this.tvProfileName;
        if (textView != null) {
            if (!ok(fullName)) {
                fullName = "---";
            }
            textView.setText(fullName);
        }
        TextView textView2 = this.tvProfilePhone;
        if (textView2 != null) {
            if (!ok(phone)) {
                phone = "";
            }
            textView2.setText(phone);
        }
        loadAvatar(avatarUrl);
        int scHighestLevel = this.session.getScHighestLevel();
        this.selectedStartLevel = scHighestLevel;
        this.tvCurrentLevel.setText("Lv." + scHighestLevel);
    }

    private void loadAvatar(String str) {
        if (ok(str)) {
            Glide.with(this).load(str).apply(new RequestOptions().transform(new CircleCropTransform(null)).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(this.ivAvatar);
        } else {
            this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    private void initLoad() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m681lambda$initLoad$10$comzenoappSoftClimbersActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$initLoad$10$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m681lambda$initLoad$10$comzenoappSoftClimbersActivity() {
        this.scToken = resolveScToken();
        if (ok(this.scToken)) {
            fetchSubscriptionStatus(this.scToken);
            this.ui.post(new SoftClimbersActivity$$ExternalSyntheticLambda21(this));
        } else {
            this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda23
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m682lambda$initLoad$9$comzenoappSoftClimbersActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$initLoad$9$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m682lambda$initLoad$9$comzenoappSoftClimbersActivity() {
        this.tvRemaining.setText("--");
        this.tvPlanBadge.setText("Login required");
        stopProfileSkeleton();
        this.tvProfileName.setVisibility(LOG_PLAY);
        this.tvProfilePhone.setVisibility(LOG_PLAY);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doRefresh() {
        startAllSkeletons();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda25
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m677lambda$doRefresh$12$comzenoappSoftClimbersActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doRefresh$12$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m677lambda$doRefresh$12$comzenoappSoftClimbersActivity() {
        this.scToken = resolveScToken();
        if (ok(this.scToken)) {
            fetchSubscriptionStatus(this.scToken);
            this.ui.post(new SoftClimbersActivity$$ExternalSyntheticLambda21(this));
        } else {
            this.ui.post(new SoftClimbersActivity$$ExternalSyntheticLambda21(this));
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda22
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m676lambda$doRefresh$11$comzenoappSoftClimbersActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doRefresh$11$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m676lambda$doRefresh$11$comzenoappSoftClimbersActivity() {
        this.swipeRefresh.setRefreshing(false);
    }

    private String resolveScToken() {
        return loginToSoftClimbers();
    }

    private String loginToSoftClimbers() {
        JSONObject jSONObjectOptJSONObject;
        int iExtractHighestLevel;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        String avatarUrl = this.session.getAvatarUrl();
        String fullName = this.session.getFullName();
        if (ok(phone) && ok(accessToken)) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("msisdn", phone);
                jSONObject.put("accessToken", accessToken);
                if (!ok(avatarUrl)) {
                    avatarUrl = "";
                }
                jSONObject.put("avatar", avatarUrl);
                if (ok(fullName)) {
                    phone = fullName;
                }
                jSONObject.put("username", phone);
                jSONObject.put("lang", "mu");
                HttpResult httpResultPostReq = postReq("https://api.softclimbers.com/api/v1/auth/login", jSONObject.toString(), null);
                if (httpResultPostReq == null) {
                    return null;
                }
                JSONObject jSONObject2 = new JSONObject(httpResultPostReq.body);
                if (jSONObject2.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject2.optJSONObject("data")) != null) {
                    String strOptString = jSONObjectOptJSONObject.optString("token", "");
                    if (ok(strOptString)) {
                        this.session.saveScGameToken(strOptString);
                        JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("user");
                        if (jSONObjectOptJSONObject2 != null) {
                            final String strOptString2 = jSONObjectOptJSONObject2.optString("username", "");
                            final String strOptString3 = jSONObjectOptJSONObject2.optString("msisdn", "");
                            String strOptString4 = jSONObjectOptJSONObject2.optString("avatar", "");
                            JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2.optJSONObject("subscription");
                            if (jSONObjectOptJSONObject3 != null) {
                                applySubscriptionData(jSONObjectOptJSONObject3);
                            }
                            if (!ok(strOptString2) || strOptString2.startsWith("09") || strOptString2.startsWith("+95")) {
                                strOptString2 = null;
                            }
                            SessionManager sessionManager = this.session;
                            String str = ok(strOptString3) ? strOptString3 : null;
                            if (!ok(strOptString4)) {
                                strOptString4 = null;
                            }
                            sessionManager.saveScProfile(strOptString2, str, strOptString4);
                            this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda19
                                @Override // java.lang.Runnable
                                public final void run() {
                                    this.f$0.m683lambda$loginToSoftClimbers$13$comzenoappSoftClimbersActivity(strOptString2, strOptString3);
                                }
                            });
                            if (extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject3) >= 0) {
                                iExtractHighestLevel = extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject3);
                            } else {
                                iExtractHighestLevel = extractHighestLevel(jSONObjectOptJSONObject2, jSONObjectOptJSONObject3);
                            }
                            syncHighestLevelFromServer(iExtractHighestLevel);
                        }
                        return strOptString;
                    }
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    /* JADX INFO: renamed from: lambda$loginToSoftClimbers$13$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m683lambda$loginToSoftClimbers$13$comzenoappSoftClimbersActivity(String str, String str2) {
        if (ok(str)) {
            this.tvProfileName.setText(str);
        }
        if (ok(str2)) {
            this.tvProfilePhone.setText(str2);
        }
        loadAvatar(this.session.getAvatarUrl());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchSubscriptionStatus(String str) {
        JSONObject jSONObjectOptJSONObject;
        try {
            HttpResult req = getReq("https://api.softclimbers.com/api/v1/subscription/status", str);
            if (req != null && ok(req.body)) {
                JSONObject jSONObject = new JSONObject(req.body);
                if (jSONObject.optInt("code", -1) != 0 || (jSONObjectOptJSONObject = jSONObject.optJSONObject("data")) == null) {
                    return;
                }
                syncHighestLevelFromServer(extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject.optJSONObject("subscription")));
                boolean zOptBoolean = jSONObjectOptJSONObject.optBoolean("subscribed", false);
                updateBuyCard(zOptBoolean);
                if (zOptBoolean) {
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("subscription");
                    if (jSONObjectOptJSONObject2 != null) {
                        applySubscriptionData(jSONObjectOptJSONObject2);
                    }
                } else {
                    this.remainingAttempts = LOG_PLAY;
                    this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda4
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m680lambda$fetchSubscriptionStatus$14$comzenoappSoftClimbersActivity();
                        }
                    });
                }
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: renamed from: lambda$fetchSubscriptionStatus$14$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m680lambda$fetchSubscriptionStatus$14$comzenoappSoftClimbersActivity() {
        this.tvRemaining.setText("0");
        this.tvDailyLimit.setText("--");
        this.tvPlanBadge.setText("No plan");
        this.tvEndDate.setText("Not subscribed");
    }

    private void updateBuyCard(final boolean z) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m690lambda$updateBuyCard$15$comzenoappSoftClimbersActivity(z);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$updateBuyCard$15$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m690lambda$updateBuyCard$15$comzenoappSoftClimbersActivity(boolean z) {
        ImageView imageView = this.ivBuyCardIcon;
        if (imageView == null || this.tvBuyCardLabel == null) {
            return;
        }
        if (z) {
            imageView.setImageResource(R.drawable.ic_heart);
            this.tvBuyCardLabel.setText("ကစားကြိမ်ဝယ်မည်");
        } else {
            imageView.setImageResource(R.drawable.ic_package_sub);
            this.tvBuyCardLabel.setText("Subscription လုပ်ရန်");
        }
    }

    private int extractHighestLevel(JSONObject jSONObject, JSONObject jSONObject2) {
        String[] strArr = {"highestLevel", "highest_level", "maxLevel", "level"};
        for (int i = LOG_PLAY; i < LOG_STOP; i += LOG_CLEAR) {
            int iOptInt = jSONObject.optInt(strArr[i], -1);
            if (iOptInt > 0) {
                return iOptInt;
            }
        }
        if (jSONObject2 != null) {
            for (int i2 = LOG_PLAY; i2 < LOG_STOP; i2 += LOG_CLEAR) {
                int iOptInt2 = jSONObject2.optInt(strArr[i2], -1);
                if (iOptInt2 > 0) {
                    return iOptInt2;
                }
            }
        }
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("user");
        if (jSONObjectOptJSONObject != null) {
            for (int i3 = LOG_PLAY; i3 < LOG_STOP; i3 += LOG_CLEAR) {
                int iOptInt3 = jSONObjectOptJSONObject.optInt(strArr[i3], -1);
                if (iOptInt3 > 0) {
                    return iOptInt3;
                }
            }
        }
        return -1;
    }

    private void syncHighestLevelFromServer(final int i) {
        if (i <= 0 || this.running) {
            return;
        }
        this.selectedStartLevel = i;
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda20
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m689lambda$syncHighestLevelFromServer$16$comzenoappSoftClimbersActivity(i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$syncHighestLevelFromServer$16$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m689lambda$syncHighestLevelFromServer$16$comzenoappSoftClimbersActivity(int i) {
        this.tvCurrentLevel.setText("Lv." + i);
        refreshLevelPicker();
    }

    private void applySubscriptionData(JSONObject jSONObject) {
        final int iOptInt = jSONObject.optInt("remainingAttempts", LOG_PLAY);
        int iOptInt2 = jSONObject.optInt("dailyAttempts", LOG_PLAY);
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("dailyLimit", LOG_PLAY);
        }
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("daily_attempts", LOG_PLAY);
        }
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("totalAttempts", LOG_PLAY);
        }
        final int i = iOptInt2;
        String strOptString = jSONObject.optString("planType", "");
        if (!ok(strOptString) || strOptString.equals("null")) {
            strOptString = jSONObject.optString("plan", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("type", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("planName", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("name", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("package", "");
        }
        String upperCase = ok(strOptString) ? strOptString.toUpperCase() : "--";
        String strOptString2 = jSONObject.optString("endDate", "");
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("expiredAt", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("expiresAt", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("expireDate", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("expire_at", "");
        }
        if (ok(strOptString2) && strOptString2.contains("T")) {
            strOptString2 = strOptString2.substring(LOG_PLAY, 10);
        }
        final String str = !ok(strOptString2) ? "--" : strOptString2;
        this.remainingAttempts = iOptInt;
        final String str2 = upperCase;
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m667lambda$applySubscriptionData$17$comzenoappSoftClimbersActivity(iOptInt, i, str2, str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$applySubscriptionData$17$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m667lambda$applySubscriptionData$17$comzenoappSoftClimbersActivity(int i, int i2, String str, String str2) {
        this.tvRemaining.setText(String.valueOf(i));
        this.tvDailyLimit.setText(String.valueOf(i2));
        this.tvPlanBadge.setText(str);
        this.tvEndDate.setText("ends " + str2);
    }

    private void startPlay() {
        if (this.serviceBinder == null) {
            return;
        }
        clearLog();
        SoftClimbersService service = this.serviceBinder.getService();
        this.sessionStartScore = service.getTotalScore();
        if (ok(this.scToken)) {
            service.scToken = this.scToken;
        }
        service.remainingAttempts = this.remainingAttempts;
        service.selectedStartLevel = this.selectedStartLevel;
        service.startPlay();
        setAutoPlayButtonState(true);
        this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_stop);
        this.btnAutoPlay.setBackgroundTintList(null);
        this.running = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setAutoPlayButtonState(boolean z) {
        Button button = this.btnAutoPlay;
        if (button == null) {
            return;
        }
        if (z) {
            button.setText("ရပ်မည်");
            this.btnAutoPlay.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_stop_notif, LOG_PLAY, LOG_PLAY, LOG_PLAY);
        } else {
            button.setText("ကစားမည်");
            this.btnAutoPlay.setCompoundDrawablesWithIntrinsicBounds(LOG_PLAY, LOG_PLAY, LOG_PLAY, LOG_PLAY);
        }
    }

    private void stopPlay() {
        this.stopping = true;
        this.btnAutoPlay.setEnabled(false);
        setStatus("Stopping...", COL_YELLOW);
        SoftClimbersService.ServiceBinder serviceBinder = this.serviceBinder;
        if (serviceBinder != null) {
            serviceBinder.getService().stopPlay();
        }
    }

    private void setStatus(String str, int i) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m685lambda$setStatus$18$comzenoappSoftClimbersActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$setStatus$18$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m685lambda$setStatus$18$comzenoappSoftClimbersActivity() {
        this.tvStatus.setText("");
        this.tvStatus.setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startTimerUi(final long j, final long j2) {
        stopTimerUi();
        Runnable runnable = new Runnable() { // from class: com.zeno.app.SoftClimbersActivity.3
            @Override // java.lang.Runnable
            public void run() {
                long jCurrentTimeMillis = System.currentTimeMillis() - j;
                long jMax = Math.max(0L, j2 - jCurrentTimeMillis);
                int i = (int) (jCurrentTimeMillis / 1000);
                long j3 = j2;
                int iMin = j3 > 0 ? (int) Math.min(100L, (jCurrentTimeMillis * 100) / j3) : 100;
                long jMax2 = Math.max(0L, jMax / 1000);
                String str = String.format(Locale.getDefault(), "%02d:%02d", Long.valueOf(jMax2 / 60), Long.valueOf(jMax2 % 60));
                if (SoftClimbersActivity.this.tvPlayingBig != null) {
                    SoftClimbersActivity.this.tvPlayingBig.setText(str);
                }
                if (SoftClimbersActivity.this.progressGame != null) {
                    SoftClimbersActivity.this.progressGame.setProgress(iMin);
                }
                if (SoftClimbersActivity.this.tvProgressLeft != null) {
                    SoftClimbersActivity.this.tvProgressLeft.setText(SoftClimbersActivity.this.fmtSec(i) + " / " + SoftClimbersActivity.this.fmtMs(j2));
                }
                if (SoftClimbersActivity.this.tvProgressRight != null) {
                    SoftClimbersActivity.this.tvProgressRight.setText(iMin + "% • " + SoftClimbersActivity.this.fmtMs(jMax) + " left");
                }
                if (jMax > 0) {
                    SoftClimbersActivity.this.ui.postDelayed(this, 1000L);
                }
            }
        };
        this.timerRunnable = runnable;
        this.ui.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopTimerUi() {
        Runnable runnable = this.timerRunnable;
        if (runnable != null) {
            this.ui.removeCallbacks(runnable);
            this.timerRunnable = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    public java.lang.String fmtSec(
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r7v0 ??
        	at g9.s.h(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:18)
        	at v8.f.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:547)
        	at v8.a.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:67)
        	at v8.a.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:209)
        	at aa.e.accept(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:16)
        	at j$.util.stream.o0.accept(SourceFile:183)
        	at j$.desugar.sun.nio.fs.g.accept(SourceFile:0)
        	at j$.util.Collection$-EL.a(SourceFile:665)
        	at j$.util.stream.n6.end(SourceFile:403)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.n.end(SourceFile:5)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.m.end(SourceFile:5)
        	at j$.util.stream.a.c0(SourceFile:485)
        	at j$.util.stream.a.u0(SourceFile:474)
        	at j$.util.stream.o0.f(SourceFile:150)
        	at j$.util.stream.a.x0(SourceFile:234)
        	at j$.util.stream.i5.forEach(SourceFile:497)
        	at v8.a.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:359)
        	at com.google.firebase.remoteconfig.internal.b.call(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:78)
        	at qg.d.D(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1)
        	at qg.d.l(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:71)
        	at u8.b.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:134)
        	at u8.b.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:89)
        	at k9.c.o0(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:48)
        	at a2.x.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:149)
        	at sa.b.e(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:10)
        	at androidx.activity.d.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:143)
        	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        	at java.lang.Thread.run(Thread.java:1571)
        */

    /* JADX INFO: Access modifiers changed from: private */
    public String fmtMs(long j) {
        long j2 = j / 1000;
        if (j2 < 60) {
            return j2 + "s";
        }
        long j3 = j2 / 60;
        long j4 = j2 % 60;
        if (j4 == 0) {
            return j3 + "m";
        }
        return j3 + "m " + j4 + "s";
    }

    private void clearLog() {
        TextView textView = this.tvPlayingBig;
        if (textView != null) {
            textView.setText("00:00");
        }
        TextView textView2 = this.tvGameProgress;
        if (textView2 != null) {
            textView2.setText("Level --");
        }
        ProgressBar progressBar = this.progressGame;
        if (progressBar != null) {
            progressBar.setProgress(LOG_PLAY);
        }
        TextView textView3 = this.tvProgressLeft;
        if (textView3 != null) {
            textView3.setText("0s / 0s");
        }
        TextView textView4 = this.tvProgressRight;
        if (textView4 != null) {
            textView4.setText("0% • -- left");
        }
        TextView textView5 = this.tvInfoLevel;
        if (textView5 != null) {
            textView5.setText("∞");
        }
        TextView textView6 = this.tvInfoScore;
        if (textView6 != null) {
            textView6.setText("∞");
        }
        TextView textView7 = this.tvInfoSessionScore;
        if (textView7 != null) {
            textView7.setText("+0");
        }
        TextView textView8 = this.tvInfoStarted;
        if (textView8 != null) {
            textView8.setText("∞");
        }
        stopTimerUi();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showDropToastDialog(final JSONObject jSONObject) {
        if (jSONObject == null) {
            return;
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m687lambda$showDropToastDialog$20$comzenoappSoftClimbersActivity(jSONObject);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showDropToastDialog$20$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m687lambda$showDropToastDialog$20$comzenoappSoftClimbersActivity(JSONObject jSONObject) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
        dialog.requestWindowFeature(LOG_CLEAR);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(R.layout.dialog_sc_drop_toast);
        String strOptString = jSONObject.optString("name", "Reward");
        double dOptDouble = jSONObject.optDouble("value", 0.0d);
        String strOptString2 = jSONObject.optString("imageUrl", jSONObject.optString("iconUrl", ""));
        ImageView imageView = (ImageView) dialog.findViewById(R.id.ivDropIcon);
        TextView textView = (TextView) dialog.findViewById(R.id.tvDropTitle);
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvDropDesc);
        Button button = (Button) dialog.findViewById(R.id.btnDropOk);
        if (textView != null) {
            textView.setText(strOptString);
        }
        if (textView2 != null) {
            if (dOptDouble > 0.0d) {
                textView2.setText("x" + ((long) dOptDouble));
                textView2.setVisibility(LOG_PLAY);
            } else {
                textView2.setVisibility(8);
            }
        }
        if (imageView != null) {
            if (ok(strOptString2)) {
                Glide.with(this).load(strOptString2).apply(new RequestOptions().placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift)).into(imageView);
            } else {
                imageView.setImageResource(R.drawable.ic_gift);
            }
        }
        if (button != null) {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            window.setLayout(displayMetrics.widthPixels - (((int) (displayMetrics.density * 32.0f)) * LOG_WAIT), -2);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = 17;
            attributes.dimAmount = 0.75f;
            window.setAttributes(attributes);
            window.addFlags(LOG_WAIT);
        }
        dialog.show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showAutoSynthesisDialog(final String str, final String str2, final String str3) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m686lambda$showAutoSynthesisDialog$23$comzenoappSoftClimbersActivity(str3, str, str2);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showAutoSynthesisDialog$23$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m686lambda$showAutoSynthesisDialog$23$comzenoappSoftClimbersActivity(String str, String str2, String str3) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
        dialog.requestWindowFeature(LOG_CLEAR);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(R.layout.dialog_sc_auto_synthesis);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.ivSynthesisImage);
        AnonymousClass1 anonymousClass1 = null;
        if (imageView != null) {
            imageView.setBackgroundTintList(null);
        }
        if (imageView != null && ok(str)) {
            Glide.with(this).load(str).apply(new RequestOptions().placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift).transform(new CircleCropTransform(anonymousClass1))).into(imageView);
        }
        TextView textView = (TextView) dialog.findViewById(R.id.tvSynthesisName);
        if (textView != null && ok(str2)) {
            textView.setText(str2);
        }
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvSynthesisDesc);
        if (textView2 != null && ok(str3) && !str3.equals(str2)) {
            textView2.setText(str3);
            textView2.setVisibility(LOG_PLAY);
        }
        ImageView imageView2 = (ImageView) dialog.findViewById(R.id.ivSynthesisClose);
        Button button = (Button) dialog.findViewById(R.id.btnSynthesisOk);
        if (imageView2 != null) {
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda26
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        if (button != null) {
            button.setBackgroundTintList(null);
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda27
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            window.setLayout(displayMetrics.widthPixels - (((int) (displayMetrics.density * 24.0f)) * LOG_WAIT), -2);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = 17;
            attributes.dimAmount = 0.75f;
            window.setAttributes(attributes);
            window.addFlags(LOG_WAIT);
        }
        dialog.show();
    }

    private HttpResult postReq(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).post(RequestBody.create(str2, JSON_TYPE)).addHeader("content-type", "application/json").addHeader("accept", "*/*").addHeader("origin", "http://game.softclimbers.com").addHeader("user-agent", "ZenoMyID/2.0");
            if (ok(str3)) {
                addAuthHeaders(builderAddHeader, str3);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }

    private HttpResult getReq(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("user-agent", "ZenoMyID/2.0");
            if (ok(str2)) {
                addAuthHeaders(builderAddHeader, str2);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }

    private void addAuthHeaders(Request.Builder builder, String str) {
        String phone = this.session.getPhone();
        builder.addHeader("Authorization", "Bearer " + str);
        builder.addHeader("access-token", str);
        if (ok(phone)) {
            builder.addHeader("phone-number", phone);
            builder.addHeader("msisdn", phone);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshLevelPicker() {
        TextView textView = this.tvCurrentLevel;
        if (textView != null) {
            textView.setText("Lv." + this.selectedStartLevel);
        }
    }

    private void showPlayTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(LOG_PLAY);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(COL_YELLOW);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(LOG_PLAY);
        }
        TextView textView = (TextView) findViewById(R.id.tvTabPlay);
        TextView textView2 = (TextView) findViewById(R.id.tvTabRank);
        if (textView != null) {
            textView.setTextColor(COL_YELLOW);
        }
        if (textView2 != null) {
            textView2.setTextColor(-7829368);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(COL_YELLOW);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-7829368);
        }
    }

    private void showRankTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(LOG_PLAY);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(LOG_PLAY);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(COL_YELLOW);
        }
        TextView textView = (TextView) findViewById(R.id.tvTabPlay);
        TextView textView2 = (TextView) findViewById(R.id.tvTabRank);
        if (textView != null) {
            textView.setTextColor(-7829368);
        }
        if (textView2 != null) {
            textView2.setTextColor(COL_YELLOW);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-7829368);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(COL_YELLOW);
        }
        LinearLayout linearLayout = this.llRows;
        if (linearLayout == null || linearLayout.getChildCount() != 0) {
            return;
        }
        fetchLeaderboard(this.rankType);
    }

    private void switchRankTab() {
        highlightRankTab(this.rankType);
        fetchLeaderboard(this.rankType);
    }

    private void highlightRankTab(String str) {
        boolean zEquals = "WEEKLY".equals(str);
        TextView textView = this.tvWeeklyTab;
        if (textView == null || this.tvMonthlyTab == null) {
            return;
        }
        textView.setBackgroundResource(zEquals ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
        TextView textView2 = this.tvWeeklyTab;
        int i = COL_YELLOW;
        textView2.setTextColor(zEquals ? COL_YELLOW : -7829368);
        this.tvWeeklyTab.setTypeface(null, zEquals ? 1 : 0);
        this.tvMonthlyTab.setBackgroundResource(!zEquals ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
        TextView textView3 = this.tvMonthlyTab;
        if (zEquals) {
            i = -7829368;
        }
        textView3.setTextColor(i);
        this.tvMonthlyTab.setTypeface(null, !zEquals ? 1 : 0);
    }

    private void fetchLeaderboard(final String str) {
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout == null) {
            return;
        }
        linearLayout.setVisibility(LOG_PLAY);
        this.rankSkeletonAnim = SkeletonPulse.start(this.llLoading);
        this.llError.setVisibility(8);
        this.svRows.setVisibility(8);
        this.llRows.removeAllViews();
        LinearLayout linearLayout2 = this.rankUserFooter;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(8);
        }
        final String scGameToken = this.session.getScGameToken();
        if (!ok(scGameToken)) {
            showRankError("Not logged in to SoftClimbers.\nOpen the game card first.");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m679lambda$fetchLeaderboard$25$comzenoappSoftClimbersActivity(str, scGameToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$25$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m679lambda$fetchLeaderboard$25$comzenoappSoftClimbersActivity(String str, String str2) {
        try {
            HttpResult req = getReq("https://api.softclimbers.com/api/v1/leaderboard?type=" + str + "&page=0&size=50", str2);
            if (req != null && req.status == 401) {
                String strLoginToSoftClimbers = loginToSoftClimbers();
                if (!ok(strLoginToSoftClimbers)) {
                    showRankError("Session expired. Open game card to refresh login.");
                    return;
                }
                req = getReq("https://api.softclimbers.com/api/v1/leaderboard?type=" + str + "&page=0&size=50", strLoginToSoftClimbers);
            }
            if (req == null) {
                showRankError("Network error. Please retry.");
            } else {
                final String str3 = req.body;
                this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda28
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m678lambda$fetchLeaderboard$24$comzenoappSoftClimbersActivity(str3);
                    }
                });
            }
        } catch (Exception e) {
            showRankError("Network error: " + e.getMessage());
        }
    }

    private void showRankError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.SoftClimbersActivity$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m688lambda$showRankError$26$comzenoappSoftClimbersActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showRankError$26$com-zeno-app-SoftClimbersActivity, reason: not valid java name */
    /* synthetic */ void m688lambda$showRankError$26$comzenoappSoftClimbersActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.rankSkeletonAnim, this.llLoading);
        this.rankSkeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        NestedScrollView nestedScrollView = this.svRows;
        if (nestedScrollView != null) {
            nestedScrollView.setVisibility(8);
        }
        TextView textView = this.tvError;
        if (textView != null) {
            textView.setText(str);
        }
        LinearLayout linearLayout2 = this.llError;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(LOG_PLAY);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseAndShowLeaderboard, reason: merged with bridge method [inline-methods] */
    public void m678lambda$fetchLeaderboard$24$comzenoappSoftClimbersActivity(String str) {
        JSONArray jSONArrayOptJSONArray;
        JSONObject jSONObject;
        SkeletonPulse.stop(this.rankSkeletonAnim, this.llLoading);
        this.rankSkeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.llRows.removeAllViews();
        try {
            JSONObject jSONObject2 = new JSONObject(str);
            JSONObject jSONObjectOptJSONObject = jSONObject2.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                if (jSONObjectOptJSONObject.optJSONArray("rankings") != null) {
                    jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("rankings");
                } else {
                    jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("list") != null ? jSONObjectOptJSONObject.optJSONArray("list") : jSONObjectOptJSONObject.optJSONArray("items");
                }
            } else {
                jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
            }
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = new JSONArray();
            }
            JSONArray jSONArray = jSONArrayOptJSONArray;
            String phone = this.session.getPhone();
            int iOptInt = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("myRank", jSONObjectOptJSONObject.optInt("rank", LOG_PLAY)) : LOG_PLAY;
            String str2 = "score";
            long j = 0;
            long jOptLong = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optLong("myScore", jSONObjectOptJSONObject.optLong("score", 0L)) : 0L;
            if (jSONArray.length() == 0) {
                addRankEmptyView("No leaderboard data yet.");
                jSONObject = null;
            } else {
                jSONObject = null;
                int i = LOG_PLAY;
                while (i < jSONArray.length()) {
                    JSONObject jSONObject3 = jSONArray.getJSONObject(i);
                    int i2 = i + LOG_CLEAR;
                    int iOptInt2 = jSONObject3.optInt("rank", jSONObject3.optInt("rankNo", i2));
                    String strOptString = jSONObject3.optString("username", jSONObject3.optString("nickname", jSONObject3.optString("msisdn", "--")));
                    JSONArray jSONArray2 = jSONArray;
                    long jOptLong2 = jSONObject3.optLong(str2, jSONObject3.optLong("totalScore", jSONObject3.optLong("point", j)));
                    int iOptInt3 = jSONObject3.optInt("level", jSONObject3.optInt("lvl", LOG_PLAY));
                    String strOptString2 = jSONObject3.optString("avatar", null);
                    boolean zPhonesMatch = phonesMatch(jSONObject3.optString("msisdn", ""), phone);
                    JSONObject jSONObject4 = zPhonesMatch ? jSONObject3 : jSONObject;
                    addLeaderboardRow(iOptInt2, strOptString, jOptLong2, iOptInt3, strOptString2, zPhonesMatch);
                    i = i2;
                    j = 0;
                    str2 = str2;
                    jSONObject = jSONObject4;
                    jSONArray = jSONArray2;
                }
            }
            this.svRows.setVisibility(LOG_PLAY);
            showMyRankFooter(jSONObject, phone, iOptInt, jOptLong);
        } catch (Exception unused) {
            addRankEmptyView("Failed to parse leaderboard.");
            this.svRows.setVisibility(LOG_PLAY);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addLeaderboardRow(int i, String str, long j, int i2, String str2, boolean z) {
        String str3;
        String str4;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LOG_PLAY);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(LOG_PLAY, LOG_PLAY, LOG_PLAY, dp(8));
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setPadding(dp(10), dp(10), dp(10), dp(10));
        linearLayout.setBackgroundResource(z ? R.drawable.bg_game_count_selected : R.drawable.bg_card);
        TextView textView = new TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(32), -2);
        layoutParams2.setMarginEnd(dp(8));
        textView.setLayoutParams(layoutParams2);
        if (i > LOG_START) {
            str3 = "#" + i;
        } else if (i == LOG_CLEAR) {
            str3 = "🥇";
        } else {
            str3 = i == LOG_WAIT ? "🥈" : "🥉";
        }
        textView.setText(str3);
        textView.setTextColor(COL_YELLOW);
        textView.setTextSize(LOG_WAIT, i <= LOG_START ? 16.0f : 13.0f);
        textView.setGravity(17);
        linearLayout.addView(textView);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(36), dp(36));
        layoutParams3.setMarginEnd(dp(10));
        imageView.setLayoutParams(layoutParams3);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView.setClipToOutline(true);
        loadCircleAvatar(imageView, str2);
        linearLayout.addView(imageView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(LOG_CLEAR);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(LOG_PLAY, -2, 1.0f));
        TextView textView2 = new TextView(this);
        if (z) {
            str4 = str + " (You)";
        } else {
            str4 = str;
        }
        textView2.setText(str4);
        textView2.setTextColor((i > LOG_START && !z) ? -3355444 : -1);
        textView2.setTextSize(LOG_WAIT, i <= LOG_START ? 14.0f : 13.0f);
        if (i <= LOG_START || z) {
            textView2.setTypeface(null, LOG_CLEAR);
        }
        textView2.setMaxLines(LOG_CLEAR);
        textView2.setEllipsize(TextUtils.TruncateAt.END);
        linearLayout2.addView(textView2);
        if (i2 > 0) {
            TextView textView3 = new TextView(this);
            textView3.setText("Lv." + i2);
            textView3.setTextColor(COL_YELLOW);
            textView3.setTextSize(LOG_WAIT, 11.0f);
            linearLayout2.addView(textView3);
        }
        linearLayout.addView(linearLayout2);
        TextView textView4 = new TextView(this);
        textView4.setText(String.format(Locale.getDefault(), "%,d pts", Long.valueOf(j)));
        int i3 = -10752;
        if (i > LOG_START && !z) {
            i3 = -5592406;
        }
        textView4.setTextColor(i3);
        textView4.setTextSize(LOG_WAIT, 12.0f);
        if (i <= LOG_START || z) {
            textView4.setTypeface(null, LOG_CLEAR);
        }
        textView4.setGravity(8388613);
        linearLayout.addView(textView4);
        this.llRows.addView(linearLayout);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showMyRankFooter(JSONObject jSONObject, String str, int i, long j) {
        String fullName;
        String str2;
        LinearLayout linearLayout = this.rankUserFooter;
        if (linearLayout == null) {
            return;
        }
        if (jSONObject == null && i <= 0) {
            linearLayout.setVisibility(8);
            return;
        }
        int iOptInt = jSONObject != null ? jSONObject.optInt("rank", jSONObject.optInt("rankNo", LOG_PLAY)) : i;
        if (jSONObject != null) {
            fullName = jSONObject.optString("username", jSONObject.optString("nickname", jSONObject.optString("msisdn", str)));
        } else {
            fullName = ok(this.session.getFullName()) ? this.session.getFullName() : str;
        }
        if (fullName != null && fullName.startsWith("09") && fullName.length() >= 8) {
            fullName = fullName.substring(LOG_PLAY, LOG_STOP) + "****" + fullName.substring(fullName.length() - LOG_WAIT);
        }
        long jOptLong = jSONObject != null ? jSONObject.optLong("score", jSONObject.optLong("totalScore", jSONObject.optLong("point", 0L))) : j;
        int iOptInt2 = jSONObject != null ? jSONObject.optInt("level", jSONObject.optInt("lvl", LOG_PLAY)) : LOG_PLAY;
        String strOptString = jSONObject != null ? jSONObject.optString("avatar", null) : null;
        if ("null".equals(strOptString) || (strOptString != null && strOptString.isEmpty())) {
            strOptString = null;
        }
        if (!ok(strOptString)) {
            strOptString = this.session.getAvatarUrl();
        }
        this.rankUserRow.removeAllViews();
        TextView textView = new TextView(this);
        textView.setText("ကိုယ်တိုင်");
        textView.setTextColor(-7829368);
        textView.setTextSize(LOG_WAIT, 11.0f);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.rankUserRow.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(LOG_PLAY);
        linearLayout2.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(LOG_PLAY, dp(6), LOG_PLAY, LOG_PLAY);
        linearLayout2.setLayoutParams(layoutParams);
        TextView textView2 = new TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(40), -2);
        layoutParams2.setMarginEnd(dp(8));
        textView2.setLayoutParams(layoutParams2);
        if (iOptInt > 0) {
            str2 = "#" + iOptInt;
        } else {
            str2 = "--";
        }
        textView2.setText(str2);
        textView2.setTextColor(COL_YELLOW);
        textView2.setTextSize(LOG_WAIT, 13.0f);
        textView2.setTypeface(null, LOG_CLEAR);
        textView2.setGravity(17);
        linearLayout2.addView(textView2);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(36), dp(36));
        layoutParams3.setMarginEnd(dp(10));
        imageView.setLayoutParams(layoutParams3);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView.setClipToOutline(true);
        loadCircleAvatar(imageView, strOptString);
        linearLayout2.addView(imageView);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(LOG_CLEAR);
        linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(LOG_PLAY, -2, 1.0f));
        TextView textView3 = new TextView(this);
        textView3.setText(fullName);
        textView3.setTextColor(-1);
        textView3.setTextSize(LOG_WAIT, 13.0f);
        textView3.setTypeface(null, LOG_CLEAR);
        textView3.setMaxLines(LOG_CLEAR);
        textView3.setEllipsize(TextUtils.TruncateAt.END);
        linearLayout3.addView(textView3);
        if (iOptInt2 > 0) {
            TextView textView4 = new TextView(this);
            textView4.setText("Lv." + iOptInt2);
            textView4.setTextColor(COL_YELLOW);
            textView4.setTextSize(LOG_WAIT, 11.0f);
            linearLayout3.addView(textView4);
        }
        linearLayout2.addView(linearLayout3);
        TextView textView5 = new TextView(this);
        textView5.setText(String.format(Locale.getDefault(), "%,d pts", Long.valueOf(jOptLong)));
        textView5.setTextColor(-10752);
        textView5.setTextSize(LOG_WAIT, 12.0f);
        textView5.setTypeface(null, LOG_CLEAR);
        textView5.setGravity(8388613);
        linearLayout2.addView(textView5);
        this.rankUserRow.addView(linearLayout2);
        this.rankUserFooter.setVisibility(LOG_PLAY);
    }

    private void loadCircleAvatar(ImageView imageView, String str) {
        if (ok(str)) {
            Glide.with(this).load(str).apply(new RequestOptions().transform(new CircleCropTransform(null)).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addRankEmptyView(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(COL_GREY);
        textView.setTextSize(15.0f);
        textView.setGravity(17);
        textView.setPadding(dp(32), dp(100), dp(32), dp(100));
        this.llRows.addView(textView);
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private static boolean phonesMatch(String str, String str2) {
        if (str == null || str2 == null) {
            return false;
        }
        String strTrim = str.replace("+", "").replace(" ", "").trim();
        String strTrim2 = str2.replace("+", "").replace(" ", "").trim();
        if (strTrim.startsWith("95") && strTrim.length() > 10) {
            strTrim = "0" + strTrim.substring(LOG_WAIT);
        }
        if (strTrim2.startsWith("95") && strTrim2.length() > 10) {
            strTrim2 = "0" + strTrim2.substring(LOG_WAIT);
        }
        return strTrim.equals(strTrim2);
    }

    private void sleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }

    private void sleepInterruptible(long j) {
        long jCurrentTimeMillis = System.currentTimeMillis() + j;
        while (!this.stopping && System.currentTimeMillis() < jCurrentTimeMillis) {
            sleep(Math.min(200L, jCurrentTimeMillis - System.currentTimeMillis()));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopProfileSkeleton() {
        SkeletonPulse.stop(this.profileSkeletonAnim, this.pbProfileLoading);
        this.profileSkeletonAnim = null;
        View view = this.pbProfileLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.rowProfileContent;
        if (view2 != null) {
            view2.setVisibility(LOG_PLAY);
        }
        TextView textView = this.tvProfileName;
        if (textView != null) {
            textView.setVisibility(LOG_PLAY);
        }
        TextView textView2 = this.tvProfilePhone;
        if (textView2 != null) {
            textView2.setVisibility(LOG_PLAY);
        }
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.avatarSkeleton);
        this.avatarSkeletonAnim = null;
        View view3 = this.avatarSkeleton;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(LOG_PLAY);
        }
        SkeletonPulse.stop(this.scMainSkeletonAnim, this.scMainSkeleton);
        this.scMainSkeletonAnim = null;
        View view4 = this.scMainSkeleton;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        View view5 = this.scMainContent;
        if (view5 != null) {
            view5.setVisibility(LOG_PLAY);
        }
        SkeletonPulse.stop(this.levelBadgeSkeletonAnim, this.levelBadgeSkeleton);
        this.levelBadgeSkeletonAnim = null;
        View view6 = this.levelBadgeSkeleton;
        if (view6 != null) {
            view6.setVisibility(8);
        }
        View view7 = this.levelBadgeContent;
        if (view7 != null) {
            view7.setVisibility(LOG_PLAY);
        }
        SkeletonPulse.stop(this.playingCardSkeletonAnim, this.playingCardSkeleton);
        this.playingCardSkeletonAnim = null;
        View view8 = this.playingCardSkeleton;
        if (view8 != null) {
            view8.setVisibility(8);
        }
        View view9 = this.playingCardContent;
        if (view9 != null) {
            view9.setVisibility(LOG_PLAY);
        }
        SkeletonPulse.stop(this.btnAutoPlaySkeletonAnim, this.btnAutoPlaySkeleton);
        this.btnAutoPlaySkeletonAnim = null;
        View view10 = this.btnAutoPlaySkeleton;
        if (view10 != null) {
            view10.setVisibility(8);
        }
        Button button = this.btnAutoPlay;
        if (button != null) {
            button.setVisibility(LOG_PLAY);
        }
    }

    private void startGiftPulse(View view) {
        try {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_X, 1.0f, 1.18f, 1.0f);
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_Y, 1.0f, 1.18f, 1.0f);
            objectAnimatorOfFloat.setDuration(900L);
            objectAnimatorOfFloat2.setDuration(900L);
            objectAnimatorOfFloat.setRepeatCount(-1);
            objectAnimatorOfFloat2.setRepeatCount(-1);
            objectAnimatorOfFloat.start();
            objectAnimatorOfFloat2.start();
        } catch (Exception unused) {
        }
    }
}
