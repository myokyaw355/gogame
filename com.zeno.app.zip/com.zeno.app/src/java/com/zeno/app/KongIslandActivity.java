package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.material.snackbar.Snackbar;
import com.zeno.app.KongIslandService;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class KongIslandActivity extends BaseActivity implements KongIslandService.GameCallback {
    private static final String TAG = "KongIsland";
    private View autoPlaySkeleton;
    private ValueAnimator autoPlaySkeletonAnim;
    private View avatarSkeleton;
    private ValueAnimator avatarSkeletonAnim;
    private View balanceContent;
    private View balanceSkeleton;
    private ValueAnimator balanceSkeletonAnim;
    private Button btnAutoPlay;
    private TextView btnCount1;
    private TextView btnCount10;
    private TextView btnCount20;
    private TextView btnCount3;
    private TextView btnCount30;
    private TextView btnCount5;
    private TextView btnMonthly;
    private Button btnOpenBox;
    private TextView btnWeekly;
    private View cardExchange;
    private View cardGamePicker;
    private View cardGamePickerContainer;
    private View cardPlaying;
    private View cardShop;
    private View contentPlay;
    private View contentRank;
    private ExecutorService exec;
    private View gamePickerSkeleton;
    private ValueAnimator gamePickerSkeletonAnim;
    private ImageView ivAvatar;
    private ImageView ivEditName;
    private ImageView ivPlayingBack;
    private ImageView ivProgressKong;
    private View openBoxSkeleton;
    private ValueAnimator openBoxSkeletonAnim;
    private View pbProfileLoading;
    private ValueAnimator profileSkeletonAnim;
    private ProgressBar progressGame;
    private View progressGameContainer;
    private LinearLayout rankList;
    private View rankLoading;
    private ValueAnimator rankSkeletonAnim;
    private View rankUserFooter;
    private LinearLayout rankUserRow;
    private View rowInfoEstEnd;
    private View rowInfoTotalTime;
    private View rowProfileName;
    private View rowProgressLabels;
    private SessionManager session;
    private View shopCardsContent;
    private View shopCardsSkeleton;
    private ValueAnimator shopSkeletonAnim;
    private View spinSkeleton;
    private ValueAnimator spinSkeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private SwitchCompat switchAlwaysLoop;
    private View tabPlay;
    private View tabPlayUnderline;
    private View tabRank;
    private View tabRankUnderline;
    private Runnable timerRunnable;
    private TextView tvBanana;
    private TextView tvBoxes;
    private TextView tvGameProgress;
    private TextView tvInfoBanana;
    private TextView tvInfoEstEnd;
    private TextView tvInfoStarted;
    private TextView tvInfoTotalTime;
    private TextView tvProfileName;
    private TextView tvProfilePhone;
    private TextView tvProgressLeft;
    private TextView tvProgressRight;
    private TextView tvTickets;
    private TextView tvTimer;
    private TextView tvX2BananaPicker;
    private TextView tvX2BananaPlaying;
    private KongIslandService.ServiceBinder serviceBinder = null;
    private boolean serviceBound = false;
    private final ServiceConnection conn = new ServiceConnection() { // from class: com.zeno.app.KongIslandActivity.1
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            KongIslandActivity.this.serviceBinder = (KongIslandService.ServiceBinder) iBinder;
            KongIslandActivity.this.serviceBound = true;
            KongIslandActivity.this.serviceBinder.getService().setCallback(KongIslandActivity.this);
            KongIslandActivity.this.syncFromService();
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            KongIslandActivity.this.serviceBound = false;
            KongIslandActivity.this.serviceBinder = null;
        }
    };
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private boolean alwaysLoopEnabled = false;
    private boolean rankWeeklyActive = true;
    private volatile int selectedCount = 1;

    private static class CircleCropTransform extends BitmapTransformation {
        private CircleCropTransform() {
        }

        protected Bitmap transform(BitmapPool bitmapPool, Bitmap bitmap, int i, int i2) {
            int iMin = Math.min(bitmap.getWidth(), bitmap.getHeight());
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmap, (bitmap.getWidth() - iMin) / 2, (bitmap.getHeight() - iMin) / 2, iMin, iMin);
            Bitmap bitmap2 = bitmapPool.get(iMin, iMin, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap2);
            Paint paint = new Paint(1);
            paint.setShader(new BitmapShader(bitmapCreateBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            float f = iMin / 2.0f;
            canvas.drawCircle(f, f, f, paint);
            bitmapCreateBitmap.recycle();
            return bitmap2;
        }

        public void updateDiskCacheKey(MessageDigest messageDigest) {
            messageDigest.update("KI_CC".getBytes());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_kong_island);
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
        setSupportActionBar(findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Kong Island");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        bindViews();
        startDataSkeletons();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStart() {
        super.onStart();
        bindService(new Intent((Context) this, (Class<?>) KongIslandService.class), this.conn, 1);
    }

    protected void onStop() {
        KongIslandService.ServiceBinder serviceBinder;
        super.onStop();
        stopTimerUi();
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        serviceBinder.getService().clearCallback();
        unbindService(this.conn);
        this.serviceBound = false;
        this.serviceBinder = null;
    }

    protected void onDestroy() {
        super.onDestroy();
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        super.onResume();
        if (!this.serviceBound || this.serviceBinder == null) {
            return;
        }
        syncFromService();
        KongIslandService service = this.serviceBinder.getService();
        if (service == null || !ok(service.getKongToken())) {
            return;
        }
        service.fetchUserInfo(service.getKongToken());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void syncFromService() {
        final KongIslandService service = this.serviceBinder.getService();
        String phone = this.session.getPhone();
        String kongPlayerPhone = this.session.getKongPlayerPhone();
        if (ok(phone) && ok(kongPlayerPhone) && !phone.equals(kongPlayerPhone)) {
            service.kongToken = null;
            this.session.clearKongSession();
            this.tvProfileName.setText("---");
            this.tvProfilePhone.setText("");
            this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
        if (!service.isRunning()) {
            startGamePickerSkeleton();
        }
        if (!ok(service.getKongToken())) {
            service.initLoad();
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda34
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m542lambda$syncFromService$0$comzenoappKongIslandActivity(service);
                }
            });
            fetchProfileDirect();
        }
        if (service.isRunning()) {
            setAutoPlayBtn(true);
            SkeletonPulse.stop(this.gamePickerSkeletonAnim, this.gamePickerSkeleton);
            this.gamePickerSkeletonAnim = null;
            View view = this.gamePickerSkeleton;
            if (view != null) {
                view.setVisibility(8);
            }
            setGamePickerVisible(false);
            this.cardPlaying.setVisibility(0);
            View view2 = this.progressGameContainer;
            if (view2 != null) {
                view2.setVisibility(0);
            }
            this.progressGame.setVisibility(0);
            this.rowProgressLabels.setVisibility(0);
            this.rowInfoTotalTime.setVisibility(0);
            this.rowInfoEstEnd.setVisibility(0);
            this.tvGameProgress.setText(formatGameProgress(service.getCurrentGame(), service.getTotalGames(), service.getSessionBanana()));
            this.tvInfoBanana.setText(String.valueOf(service.getSessionBanana()));
            startTimerUi(service.getGameStartMs(), service.getCurrentGame(), service.getTotalGames(), service.getCurrentGameMs());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Rangoon"));
            this.tvInfoStarted.setText(simpleDateFormat.format(new Date(service.getSessionStartMs())));
            if (service.isAlwaysLoop() || service.getTotalGames() >= 1073741823) {
                this.tvInfoEstEnd.setText("∞ (Loop)");
                this.tvInfoTotalTime.setText("∞");
            } else {
                this.tvInfoEstEnd.setText(simpleDateFormat.format(new Date(service.getSessionStartMs() + (((long) service.getTotalGames()) * 600000))));
                this.tvInfoTotalTime.setText(fmtTotalTime(service.getTotalGames() * 10));
            }
        } else {
            setAutoPlayBtn(false);
            View view3 = this.gamePickerSkeleton;
            if (view3 == null || view3.getVisibility() != 0) {
                setGamePickerVisible(true);
            }
            this.cardPlaying.setVisibility(8);
            stopTimerUi();
        }
        onStatsChanged(service.getTotalBanana(), service.getTotalTickets(), service.getTotalBoxes(), service.getTotal2xBanana());
    }

    /* JADX INFO: renamed from: lambda$syncFromService$0$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m542lambda$syncFromService$0$comzenoappKongIslandActivity(KongIslandService kongIslandService) {
        kongIslandService.fetchUserInfo(kongIslandService.getKongToken());
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda52
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.updateOpenBoxBtn();
            }
        });
    }

    private void setGamePickerVisible(boolean z) {
        View view = this.cardGamePicker;
        if (view != null) {
            view.setVisibility(z ? 0 : 8);
        }
        View view2 = this.cardGamePickerContainer;
        if (view2 != null) {
            view2.setVisibility(z ? 0 : 8);
        }
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onStatsChanged(int i, int i2, int i3, int i4) {
        this.tvBanana.setText(String.format(Locale.getDefault(), "%,d", Integer.valueOf(i)));
        this.tvTickets.setText(String.valueOf(i2));
        this.tvBoxes.setText(String.valueOf(i3));
        TextView textView = this.tvX2BananaPicker;
        if (textView != null) {
            textView.setText(String.valueOf(i4));
        }
        TextView textView2 = this.tvX2BananaPlaying;
        if (textView2 != null) {
            textView2.setText(String.valueOf(i4));
        }
        updateOpenBoxBtn();
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onStateChanged(boolean z, int i, int i2, long j, long j2, long j3) {
        KongIslandService.ServiceBinder serviceBinder;
        if (z) {
            setAutoPlayBtn(true);
            setGamePickerVisible(false);
            this.cardPlaying.setVisibility(0);
            View view = this.progressGameContainer;
            if (view != null) {
                view.setVisibility(0);
            }
            this.progressGame.setVisibility(0);
            this.rowProgressLabels.setVisibility(0);
            this.rowInfoTotalTime.setVisibility(0);
            this.rowInfoEstEnd.setVisibility(0);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Rangoon"));
            this.tvInfoStarted.setText(simpleDateFormat.format(new Date(j3)));
            if (i2 >= 1073741823 || (this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService().isAlwaysLoop())) {
                this.tvInfoEstEnd.setText("∞ (Loop)");
                this.tvInfoTotalTime.setText("∞");
            } else {
                this.tvInfoEstEnd.setText(simpleDateFormat.format(new Date(j3 + (((long) i2) * 600000))));
                this.tvInfoTotalTime.setText(fmtTotalTime(i2 * 10));
            }
            startTimerUi(j, i, i2, j2);
            return;
        }
        setAutoPlayBtn(false);
        View view2 = this.gamePickerSkeleton;
        if (view2 == null || view2.getVisibility() != 0) {
            setGamePickerVisible(true);
        }
        this.cardPlaying.setVisibility(8);
        stopTimerUi();
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onBananaProgress(long j) {
        KongIslandService.ServiceBinder serviceBinder;
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        KongIslandService service = serviceBinder.getService();
        this.tvGameProgress.setText(formatGameProgress(service.getCurrentGame(), service.getTotalGames(), j));
        this.tvInfoBanana.setText(String.valueOf(j));
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onSessionEnded(long j, int i) {
        showSnack("✓ " + i + " ပွဲ ပြီးဆုံးပါပြီ — " + String.format(Locale.getDefault(), "%,d", Long.valueOf(j)) + " banana");
        refreshLeaderboardAfterGame();
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onMessage(String str) {
        showSnack(str);
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onProfileUpdated(final String str, final String str2, final String str3) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda21
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m532lambda$onProfileUpdated$1$comzenoappKongIslandActivity(str, str2, str3);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onProfileUpdated$1$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m532lambda$onProfileUpdated$1$comzenoappKongIslandActivity(String str, String str2, String str3) {
        TextView textView;
        TextView textView2;
        if (this.pbProfileLoading != null) {
            stopProfileSkeleton();
        }
        if (ok(str) && (textView2 = this.tvProfileName) != null) {
            textView2.setVisibility(0);
            this.tvProfileName.setText(str);
        }
        if (ok(str2) && (textView = this.tvProfilePhone) != null) {
            textView.setVisibility(0);
            this.tvProfilePhone.setText(str2);
        }
        if (ok(str3)) {
            loadAvatar(str3);
        }
        try {
            this.session.saveKongProfile(str, str2, str3);
        } catch (Exception unused) {
        }
    }

    @Override // com.zeno.app.KongIslandService.GameCallback
    public void onOpenBoxResult(String str, int i) {
        JSONArray jSONArrayOptJSONArray;
        ArrayList arrayList = new ArrayList();
        try {
            JSONObject jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("data");
            if (jSONObjectOptJSONObject != null && (jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("itemReward")) != null) {
                for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                    JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i2);
                    String strOptString = jSONObject.optString("typeItem", "");
                    arrayList.add(typeLabel(strOptString) + "|" + strOptString + "|" + jSONObject.optInt("value", 0));
                }
            }
        } catch (Exception unused) {
        }
        showOpenBoxResultDialog(i, arrayList);
    }

    private void bindViews() {
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        this.ivEditName = (ImageView) findViewById(R.id.ivEditName);
        this.tvProfileName = (TextView) findViewById(R.id.tvProfileName);
        this.tvProfilePhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.pbProfileLoading = findViewById(R.id.pbProfileLoading);
        this.avatarSkeleton = findViewById(R.id.avatarSkeleton);
        this.shopCardsSkeleton = findViewById(R.id.shopCardsSkeleton);
        this.shopCardsContent = findViewById(R.id.shopCardsContent);
        this.balanceSkeleton = findViewById(R.id.balanceSkeleton);
        this.balanceContent = findViewById(R.id.balanceContent);
        this.gamePickerSkeleton = findViewById(R.id.gamePickerSkeleton);
        this.spinSkeleton = findViewById(R.id.spinSkeleton);
        this.autoPlaySkeleton = findViewById(R.id.autoPlaySkeleton);
        this.openBoxSkeleton = findViewById(R.id.openBoxSkeleton);
        this.rowProfileName = findViewById(R.id.rowProfileName);
        this.ivEditName.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m510lambda$bindViews$2$comzenoappKongIslandActivity(view);
            }
        });
        this.tvBanana = (TextView) findViewById(R.id.tvBanana);
        this.tvTickets = (TextView) findViewById(R.id.tvTickets);
        this.tvBoxes = (TextView) findViewById(R.id.tvBoxes);
        this.tvX2BananaPicker = (TextView) findViewById(R.id.tvX2BananaPicker);
        this.tvX2BananaPlaying = (TextView) findViewById(R.id.tvX2BananaPlaying);
        this.cardShop = findViewById(R.id.cardShop);
        this.cardExchange = findViewById(R.id.cardExchange);
        this.cardGamePicker = findViewById(R.id.cardGamePicker);
        this.cardGamePickerContainer = findViewById(R.id.cardGamePickerContainer);
        this.cardPlaying = findViewById(R.id.cardPlaying);
        this.ivPlayingBack = (ImageView) findViewById(R.id.ivPlayingBack);
        this.tvTimer = (TextView) findViewById(R.id.tvTimer);
        this.tvGameProgress = (TextView) findViewById(R.id.tvGameProgress);
        this.tvProgressLeft = (TextView) findViewById(R.id.tvProgressLeft);
        this.tvProgressRight = (TextView) findViewById(R.id.tvProgressRight);
        this.progressGame = (ProgressBar) findViewById(R.id.progressGame);
        this.progressGameContainer = findViewById(R.id.progressGameContainer);
        this.ivProgressKong = (ImageView) findViewById(R.id.ivProgressKong);
        this.rowProgressLabels = findViewById(R.id.rowProgressLabels);
        this.rowInfoTotalTime = findViewById(R.id.rowInfoTotalTime);
        this.rowInfoEstEnd = findViewById(R.id.rowInfoEstEnd);
        this.tvInfoBanana = (TextView) findViewById(R.id.tvInfoBanana);
        this.tvInfoTotalTime = (TextView) findViewById(R.id.tvInfoTotalTime);
        this.tvInfoStarted = (TextView) findViewById(R.id.tvInfoStarted);
        this.tvInfoEstEnd = (TextView) findViewById(R.id.tvInfoEstEnd);
        this.btnAutoPlay = (Button) findViewById(R.id.btnAutoPlay);
        this.btnOpenBox = (Button) findViewById(R.id.btnOpenBox);
        this.switchAlwaysLoop = findViewById(R.id.switchAlwaysLoop);
        this.btnCount1 = (TextView) findViewById(R.id.btnCount1);
        this.btnCount3 = (TextView) findViewById(R.id.btnCount3);
        this.btnCount5 = (TextView) findViewById(R.id.btnCount5);
        this.btnCount10 = (TextView) findViewById(R.id.btnCount10);
        this.btnCount20 = (TextView) findViewById(R.id.btnCount20);
        this.btnCount30 = (TextView) findViewById(R.id.btnCount30);
        this.swipeRefresh = findViewById(R.id.swipeRefresh);
        this.ivPlayingBack.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda24
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m511lambda$bindViews$3$comzenoappKongIslandActivity(view);
            }
        });
        this.btnAutoPlay.setBackgroundTintList(null);
        this.btnAutoPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m512lambda$bindViews$4$comzenoappKongIslandActivity(view);
            }
        });
        if (this.switchAlwaysLoop != null) {
            boolean alwaysLoop = this.session.getAlwaysLoop("kong_island");
            this.alwaysLoopEnabled = alwaysLoop;
            this.switchAlwaysLoop.setChecked(alwaysLoop);
            setCountCardsEnabled(!this.alwaysLoopEnabled);
            this.switchAlwaysLoop.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda26
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    this.f$0.m513lambda$bindViews$5$comzenoappKongIslandActivity(compoundButton, z);
                }
            });
        }
        this.btnOpenBox.setBackgroundTintList(null);
        this.btnOpenBox.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda27
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m514lambda$bindViews$6$comzenoappKongIslandActivity(view);
            }
        });
        this.cardShop.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda28
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m515lambda$bindViews$7$comzenoappKongIslandActivity(view);
            }
        });
        this.cardExchange.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda29
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m516lambda$bindViews$8$comzenoappKongIslandActivity(view);
            }
        });
        View viewFindViewById = findViewById(R.id.btnSpin);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda30
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m517lambda$bindViews$9$comzenoappKongIslandActivity(view);
                }
            });
        }
        this.btnCount1.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda31
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m500lambda$bindViews$10$comzenoappKongIslandActivity(view);
            }
        });
        this.btnCount3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda33
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m501lambda$bindViews$11$comzenoappKongIslandActivity(view);
            }
        });
        this.btnCount5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m502lambda$bindViews$12$comzenoappKongIslandActivity(view);
            }
        });
        this.btnCount10.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m503lambda$bindViews$13$comzenoappKongIslandActivity(view);
            }
        });
        this.btnCount20.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m504lambda$bindViews$14$comzenoappKongIslandActivity(view);
            }
        });
        this.btnCount30.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m505lambda$bindViews$15$comzenoappKongIslandActivity(view);
            }
        });
        this.swipeRefresh.setColorSchemeColors(new int[]{-3632086});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(-14803426);
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda18
            public final void onRefresh() {
                this.f$0.doRefresh();
            }
        });
        this.tabPlay = findViewById(R.id.tabPlay);
        this.tabRank = findViewById(R.id.tabRank);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabRankUnderline = findViewById(R.id.tabRankUnderline);
        this.contentPlay = this.swipeRefresh;
        this.contentRank = findViewById(R.id.contentRank);
        this.btnWeekly = (TextView) findViewById(R.id.btnWeekly);
        this.btnMonthly = (TextView) findViewById(R.id.btnMonthly);
        this.rankList = (LinearLayout) findViewById(R.id.rankList);
        this.rankLoading = findViewById(R.id.rankLoading);
        this.rankUserFooter = findViewById(R.id.rankUserFooter);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        this.tabPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m506lambda$bindViews$16$comzenoappKongIslandActivity(view);
            }
        });
        this.tabRank.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m507lambda$bindViews$17$comzenoappKongIslandActivity(view);
            }
        });
        this.btnWeekly.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda22
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m508lambda$bindViews$18$comzenoappKongIslandActivity(view);
            }
        });
        this.btnMonthly.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda23
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m509lambda$bindViews$19$comzenoappKongIslandActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m510lambda$bindViews$2$comzenoappKongIslandActivity(View view) {
        showEditNameDialog();
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m511lambda$bindViews$3$comzenoappKongIslandActivity(View view) {
        stopPlay();
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m512lambda$bindViews$4$comzenoappKongIslandActivity(View view) {
        KongIslandService.ServiceBinder serviceBinder;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService().isRunning()) {
            stopPlay();
        } else {
            startPlay();
        }
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m513lambda$bindViews$5$comzenoappKongIslandActivity(CompoundButton compoundButton, boolean z) {
        KongIslandService.ServiceBinder serviceBinder;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService().isRunning()) {
            compoundButton.setChecked(this.alwaysLoopEnabled);
            return;
        }
        this.alwaysLoopEnabled = z;
        this.session.saveAlwaysLoop("kong_island", z);
        setCountCardsEnabled(!z);
        updatePlayButtonLabel();
    }

    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m514lambda$bindViews$6$comzenoappKongIslandActivity(View view) {
        if (!this.serviceBound || this.serviceBinder == null) {
            return;
        }
        showOpenBoxDialog();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m515lambda$bindViews$7$comzenoappKongIslandActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) KongIslandShopActivity.class));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m516lambda$bindViews$8$comzenoappKongIslandActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) KongIslandExchangeActivity.class));
    }

    /* JADX INFO: renamed from: lambda$bindViews$9$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m517lambda$bindViews$9$comzenoappKongIslandActivity(View view) {
        doSpin();
    }

    /* JADX INFO: renamed from: lambda$bindViews$10$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m500lambda$bindViews$10$comzenoappKongIslandActivity(View view) {
        selectCount(1);
    }

    /* JADX INFO: renamed from: lambda$bindViews$11$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m501lambda$bindViews$11$comzenoappKongIslandActivity(View view) {
        selectCount(3);
    }

    /* JADX INFO: renamed from: lambda$bindViews$12$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m502lambda$bindViews$12$comzenoappKongIslandActivity(View view) {
        selectCount(5);
    }

    /* JADX INFO: renamed from: lambda$bindViews$13$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m503lambda$bindViews$13$comzenoappKongIslandActivity(View view) {
        selectCount(10);
    }

    /* JADX INFO: renamed from: lambda$bindViews$14$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m504lambda$bindViews$14$comzenoappKongIslandActivity(View view) {
        selectCount(20);
    }

    /* JADX INFO: renamed from: lambda$bindViews$15$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m505lambda$bindViews$15$comzenoappKongIslandActivity(View view) {
        selectCount(30);
    }

    /* JADX INFO: renamed from: lambda$bindViews$16$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m506lambda$bindViews$16$comzenoappKongIslandActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$17$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m507lambda$bindViews$17$comzenoappKongIslandActivity(View view) {
        showRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$18$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m508lambda$bindViews$18$comzenoappKongIslandActivity(View view) {
        if (this.rankWeeklyActive) {
            return;
        }
        switchRankMode(true);
    }

    /* JADX INFO: renamed from: lambda$bindViews$19$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m509lambda$bindViews$19$comzenoappKongIslandActivity(View view) {
        if (this.rankWeeklyActive) {
            switchRankMode(false);
        }
    }

    private void startPlay() {
        KongIslandService.ServiceBinder serviceBinder;
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            showSnack("Service မချိတ်ဆက်ရသေး ခဏစောင့်ပါ");
        } else if (serviceBinder.getService().getTotalTickets() <= 0) {
            showNoTicketSnack();
        } else {
            this.serviceBinder.getService().startPlay(this.selectedCount, this.alwaysLoopEnabled);
        }
    }

    private void updatePlayButtonLabel() {
        KongIslandService.ServiceBinder serviceBinder;
        if (this.btnAutoPlay == null) {
            return;
        }
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService().isRunning()) {
            return;
        }
        if (this.alwaysLoopEnabled) {
            this.btnAutoPlay.setText("Auto Play Loop");
            this.btnAutoPlay.setBackgroundResource(R.drawable.bg_kong_play_btn);
        } else {
            this.btnAutoPlay.setText("ကစားမည်");
            this.btnAutoPlay.setBackgroundResource(R.drawable.bg_kong_play_btn);
        }
    }

    private String formatGameProgress(int i, int i2, long j) {
        if (i2 >= 1073741823) {
            return "Game " + i + " (Loop) — " + j;
        }
        return "Game " + i + "/" + i2 + " — " + j;
    }

    private void showNoTicketSnack() {
        View viewFindViewById = findViewById(android.R.id.content);
        if (viewFindViewById == null) {
            return;
        }
        Snackbar snackbarMake = ZSnack.make(viewFindViewById, "ကစားကြိမ်မရှိပါ", 3500);
        snackbarMake.setAction("ဝယ်ယူမည်", new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda39
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m540lambda$showNoTicketSnack$20$comzenoappKongIslandActivity(view);
            }
        });
        snackbarMake.setActionTextColor(-3632086);
        snackbarMake.show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showNoTicketSnack$20$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m540lambda$showNoTicketSnack$20$comzenoappKongIslandActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) KongIslandShopActivity.class));
    }

    private void stopPlay() {
        KongIslandService.ServiceBinder serviceBinder;
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        serviceBinder.getService().stopPlay();
    }

    private void setCountCardsEnabled(boolean z) {
        TextView[] textViewArr = {this.btnCount1, this.btnCount3, this.btnCount5, this.btnCount10, this.btnCount20, this.btnCount30};
        float f = z ? 1.0f : 0.4f;
        for (int i = 0; i < 6; i++) {
            TextView textView = textViewArr[i];
            if (textView != null) {
                textView.setEnabled(z);
                textView.setClickable(z);
                textView.setAlpha(f);
            }
        }
    }

    private void selectCount(int i) {
        KongIslandService.ServiceBinder serviceBinder;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService().isRunning()) {
            return;
        }
        this.selectedCount = i;
        int[] iArr = {1, 3, 5, 10, 20, 30};
        TextView[] textViewArr = {this.btnCount1, this.btnCount3, this.btnCount5, this.btnCount10, this.btnCount20, this.btnCount30};
        for (int i2 = 0; i2 < 6; i2++) {
            if (iArr[i2] == i) {
                textViewArr[i2].setBackgroundResource(R.drawable.bg_game_count_selected);
                textViewArr[i2].setTextColor(getResources().getColor(R.color.yellow_primary, getTheme()));
            } else {
                textViewArr[i2].setBackgroundResource(R.drawable.bg_game_count_normal);
                textViewArr[i2].setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doRefresh() {
        KongIslandService.ServiceBinder serviceBinder;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null) {
            final KongIslandService service = serviceBinder.getService();
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda49
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m522lambda$doRefresh$22$comzenoappKongIslandActivity(service);
                }
            });
            fetchProfileDirect();
            return;
        }
        this.swipeRefresh.setRefreshing(false);
    }

    /* JADX INFO: renamed from: lambda$doRefresh$22$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m522lambda$doRefresh$22$comzenoappKongIslandActivity(KongIslandService kongIslandService) {
        if (!ok(kongIslandService.getKongToken())) {
            kongIslandService.resolveKongToken();
        }
        if (ok(kongIslandService.getKongToken())) {
            kongIslandService.fetchUserInfo(kongIslandService.getKongToken());
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda32
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m521lambda$doRefresh$21$comzenoappKongIslandActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doRefresh$21$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m521lambda$doRefresh$21$comzenoappKongIslandActivity() {
        this.swipeRefresh.setRefreshing(false);
    }

    private void fetchProfileDirect() {
        final String kongToken;
        KongIslandService.ServiceBinder serviceBinder;
        if (this.serviceBound && (serviceBinder = this.serviceBinder) != null) {
            kongToken = serviceBinder.getService().getKongToken();
        } else {
            kongToken = this.session.getKongToken();
        }
        if (ok(kongToken)) {
            startDataSkeletons();
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda50
                @Override // java.lang.Runnable
                public final void run() throws Throwable {
                    this.f$0.m528lambda$fetchProfileDirect$24$comzenoappKongIslandActivity(kongToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchProfileDirect$24$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m528lambda$fetchProfileDirect$24$comzenoappKongIslandActivity(String str) throws Throwable {
        String str2;
        final String strOptString;
        final String strOptString2;
        Response responseExecute;
        String str3;
        final String str4 = null;
        try {
            responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/user/info").addHeader("Authorization", "Bearer " + str).addHeader("accept", "*/*").addHeader("user-agent", "Mozilla/5.0").build()).execute();
        } catch (Exception e) {
            e = e;
            str2 = null;
            strOptString = null;
        }
        try {
            JSONObject jSONObjectOptJSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "").optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                String strOptString3 = jSONObjectOptJSONObject.optString("playerName", null);
                try {
                    strOptString = jSONObjectOptJSONObject.optString("msisdn", null);
                    try {
                        strOptString2 = jSONObjectOptJSONObject.optString("avatar", null);
                        try {
                            this.session.saveKongProfile(strOptString3, strOptString, strOptString2);
                            str4 = strOptString3;
                        } catch (Throwable th) {
                            str3 = strOptString3;
                            str2 = strOptString2;
                            th = th;
                            str4 = str3;
                            try {
                                if (responseExecute != null) {
                                    try {
                                        responseExecute.close();
                                    } catch (Throwable th2) {
                                        th.addSuppressed(th2);
                                    }
                                }
                                throw th;
                            } catch (Exception e2) {
                                e = e2;
                                Log.w(TAG, "fetchProfileDirect: " + e.getMessage());
                                strOptString2 = str2;
                                this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda53
                                    @Override // java.lang.Runnable
                                    public final void run() {
                                        this.f$0.m527lambda$fetchProfileDirect$23$comzenoappKongIslandActivity(str4, strOptString, strOptString2);
                                    }
                                });
                            }
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        str3 = strOptString3;
                        str2 = null;
                    }
                } catch (Throwable th4) {
                    th = th4;
                    strOptString = null;
                    str4 = strOptString3;
                    str2 = null;
                }
            } else {
                strOptString2 = null;
                strOptString = null;
            }
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Exception e3) {
                    e = e3;
                    str2 = strOptString2;
                    Log.w(TAG, "fetchProfileDirect: " + e.getMessage());
                    strOptString2 = str2;
                }
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda53
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m527lambda$fetchProfileDirect$23$comzenoappKongIslandActivity(str4, strOptString, strOptString2);
                }
            });
        } catch (Throwable th5) {
            th = th5;
            str2 = null;
            strOptString = null;
        }
    }

    /* JADX INFO: renamed from: lambda$fetchProfileDirect$23$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m527lambda$fetchProfileDirect$23$comzenoappKongIslandActivity(String str, String str2, String str3) {
        stopProfileSkeleton();
        this.tvProfileName.setVisibility(0);
        this.tvProfilePhone.setVisibility(0);
        if (ok(str)) {
            this.tvProfileName.setText(str);
        }
        if (ok(str2)) {
            this.tvProfilePhone.setText(str2);
        }
        if (ok(str3)) {
            loadAvatar(str3);
        }
    }

    private void startDataSkeletons() {
        this.pbProfileLoading.setVisibility(0);
        View view = this.rowProfileName;
        if (view != null) {
            view.setVisibility(8);
        }
        TextView textView = this.tvProfilePhone;
        if (textView != null) {
            textView.setVisibility(8);
        }
        this.profileSkeletonAnim = SkeletonPulse.start(this.pbProfileLoading);
        this.tvProfileName.setVisibility(4);
        this.tvProfilePhone.setVisibility(4);
        View view2 = this.avatarSkeleton;
        if (view2 != null) {
            view2.setVisibility(0);
            this.avatarSkeletonAnim = SkeletonPulse.start(this.avatarSkeleton);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(4);
        }
        View view3 = this.shopCardsSkeleton;
        if (view3 != null) {
            view3.setVisibility(0);
            View view4 = this.shopCardsContent;
            if (view4 != null) {
                view4.setVisibility(8);
            }
            this.shopSkeletonAnim = SkeletonPulse.start(this.shopCardsSkeleton);
        }
        View view5 = this.balanceSkeleton;
        if (view5 != null) {
            view5.setVisibility(0);
            View view6 = this.balanceContent;
            if (view6 != null) {
                view6.setVisibility(8);
            }
            this.balanceSkeletonAnim = SkeletonPulse.start(this.balanceSkeleton);
        }
        if (this.gamePickerSkeleton != null) {
            startGamePickerSkeleton();
        }
        startActionSkeletons();
    }

    private void startActionSkeletons() {
        this.spinSkeletonAnim = startActionSkeleton(this.spinSkeleton, btnSpinView());
        this.autoPlaySkeletonAnim = startActionSkeleton(this.autoPlaySkeleton, this.btnAutoPlay);
        this.openBoxSkeletonAnim = startActionSkeleton(this.openBoxSkeleton, this.btnOpenBox);
    }

    private ValueAnimator startActionSkeleton(View view, View view2) {
        if (view == null) {
            return null;
        }
        view.setVisibility(0);
        if (view2 != null) {
            view2.setVisibility(4);
            view2.setEnabled(false);
        }
        return SkeletonPulse.start(view);
    }

    private View btnSpinView() {
        return findViewById(R.id.btnSpin);
    }

    private void startGamePickerSkeleton() {
        View view = this.gamePickerSkeleton;
        if (view == null) {
            return;
        }
        view.setVisibility(0);
        View view2 = this.cardGamePicker;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        SkeletonPulse.stop(this.gamePickerSkeletonAnim, this.gamePickerSkeleton);
        this.gamePickerSkeletonAnim = SkeletonPulse.start(this.gamePickerSkeleton);
    }

    private void startTimerUi(final long j, int i, int i2, final long j2) {
        stopTimerUi();
        Runnable runnable = new Runnable() { // from class: com.zeno.app.KongIslandActivity.2
            @Override // java.lang.Runnable
            public void run() {
                if (KongIslandActivity.this.serviceBound && KongIslandActivity.this.serviceBinder != null && KongIslandActivity.this.serviceBinder.getService().isRunning()) {
                    long jCurrentTimeMillis = System.currentTimeMillis() - j;
                    long jMax = Math.max(0L, j2 - jCurrentTimeMillis);
                    int i3 = (int) (jCurrentTimeMillis / 1000);
                    int iMin = (int) Math.min(100L, (jCurrentTimeMillis * 100) / j2);
                    long jMax2 = Math.max(0L, jMax / 1000);
                    KongIslandActivity.this.tvTimer.setText(String.format(Locale.getDefault(), "%02d:%02d", Long.valueOf(jMax2 / 60), Long.valueOf(jMax2 % 60)));
                    KongIslandActivity.this.progressGame.setProgress(iMin);
                    KongIslandActivity.this.updateKongProgressMarker(iMin);
                    KongIslandActivity.this.tvProgressLeft.setText(KongIslandActivity.this.fmtSec(i3) + " / " + KongIslandActivity.this.fmtMs(j2));
                    KongIslandActivity.this.tvProgressRight.setText(iMin + "% • " + KongIslandActivity.this.fmtMs(jMax) + " left");
                    if (jMax > 0) {
                        KongIslandActivity.this.timerHandler.postDelayed(this, 1000L);
                    }
                }
            }
        };
        this.timerRunnable = runnable;
        this.timerHandler.post(runnable);
    }

    private void stopTimerUi() {
        Runnable runnable = this.timerRunnable;
        if (runnable != null) {
            this.timerHandler.removeCallbacks(runnable);
            this.timerRunnable = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void doSpin() {
        KongIslandService.ServiceBinder serviceBinder;
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        KongIslandService service = serviceBinder.getService();
        if (ok(service.getKongToken())) {
            Intent intent = new Intent((Context) this, (Class<?>) SpinWheelActivity.class);
            intent.putExtra("kongToken", service.getKongToken());
            intent.putExtra("base", "https://kong.mascom.vn");
            intent.putExtra("bananas", service.getTotalBanana());
            startActivity(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateOpenBoxBtn() {
        KongIslandService.ServiceBinder serviceBinder;
        int totalBoxes = (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) ? 0 : serviceBinder.getService().getTotalBoxes();
        this.btnOpenBox.setText("OPEN BOX (" + totalBoxes + ")");
        if (totalBoxes > 0) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(-11751600);
            gradientDrawable.setCornerRadius(dp(10));
            this.btnOpenBox.setBackground(gradientDrawable);
            this.btnOpenBox.setTextColor(-1);
        } else {
            this.btnOpenBox.setBackgroundResource(R.drawable.bg_beat_song_normal);
            this.btnOpenBox.setBackgroundTintList(null);
            this.btnOpenBox.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
        }
        this.btnOpenBox.setEnabled(true);
        this.btnOpenBox.setAlpha(1.0f);
    }

    private void setAutoPlayBtn(boolean z) {
        if (z) {
            this.btnAutoPlay.setText("■  ရပ်မည်");
            this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_stop);
            SwitchCompat switchCompat = this.switchAlwaysLoop;
            if (switchCompat != null) {
                switchCompat.setEnabled(false);
                return;
            }
            return;
        }
        updatePlayButtonLabel();
        SwitchCompat switchCompat2 = this.switchAlwaysLoop;
        if (switchCompat2 != null) {
            switchCompat2.setEnabled(true);
        }
    }

    private void showSnack(String str) {
        View viewFindViewById = findViewById(android.R.id.content);
        if (viewFindViewById != null) {
            ZSnack.make(viewFindViewById, str, 2500).show();
        }
    }

    private void loadAvatar(String str) {
        if (ok(str)) {
            Glide.with(this).load(str).apply(new RequestOptions().transform(new CircleCropTransform()).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(this.ivAvatar);
        } else {
            this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    private void showPlayTab() {
        this.contentPlay.setVisibility(0);
        this.contentRank.setVisibility(8);
        this.tabPlayUnderline.setBackgroundColor(-3632086);
        this.tabRankUnderline.setBackgroundColor(0);
        TextView textView = (TextView) findViewById(R.id.tvTabPlay);
        TextView textView2 = (TextView) findViewById(R.id.tvTabRank);
        if (textView != null) {
            textView.setTextColor(-3632086);
        }
        if (textView2 != null) {
            textView2.setTextColor(-7829368);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-3632086);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-7829368);
        }
    }

    private void showRankTab() {
        this.contentPlay.setVisibility(8);
        this.contentRank.setVisibility(0);
        this.tabPlayUnderline.setBackgroundColor(0);
        this.tabRankUnderline.setBackgroundColor(-3632086);
        TextView textView = (TextView) findViewById(R.id.tvTabPlay);
        TextView textView2 = (TextView) findViewById(R.id.tvTabRank);
        if (textView != null) {
            textView.setTextColor(-7829368);
        }
        if (textView2 != null) {
            textView2.setTextColor(-3632086);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-7829368);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-3632086);
        }
        if (this.rankList.getChildCount() == 0) {
            fetchLeaderboard(true);
        }
    }

    private void switchRankMode(boolean z) {
        this.rankWeeklyActive = z;
        if (z) {
            this.btnWeekly.setBackgroundResource(R.drawable.bg_game_count_selected);
            this.btnWeekly.setTextColor(-3632086);
            this.btnWeekly.setTypeface(null, 1);
            this.btnMonthly.setBackgroundResource(R.drawable.bg_game_count_normal);
            this.btnMonthly.setTextColor(-7829368);
            this.btnMonthly.setTypeface(null, 0);
        } else {
            this.btnMonthly.setBackgroundResource(R.drawable.bg_game_count_selected);
            this.btnMonthly.setTextColor(-3632086);
            this.btnMonthly.setTypeface(null, 1);
            this.btnWeekly.setBackgroundResource(R.drawable.bg_game_count_normal);
            this.btnWeekly.setTextColor(-7829368);
            this.btnWeekly.setTypeface(null, 0);
        }
        fetchLeaderboard(z);
    }

    private void refreshLeaderboardAfterGame() {
        View view = this.contentRank;
        if (view != null && view.getVisibility() == 0) {
            fetchLeaderboard(this.rankWeeklyActive);
            return;
        }
        LinearLayout linearLayout = this.rankList;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        View view2 = this.rankUserFooter;
        if (view2 != null) {
            view2.setVisibility(8);
        }
    }

    private void fetchLeaderboard(final boolean z) {
        KongIslandService.ServiceBinder serviceBinder;
        this.rankList.removeAllViews();
        this.rankUserFooter.setVisibility(8);
        this.rankLoading.setVisibility(0);
        this.rankSkeletonAnim = SkeletonPulse.start(this.rankLoading);
        final String kongToken = (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) ? this.session.getKongToken() : serviceBinder.getService().getKongToken();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m526lambda$fetchLeaderboard$28$comzenoappKongIslandActivity(z, kongToken);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$28$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m526lambda$fetchLeaderboard$28$comzenoappKongIslandActivity(boolean z, String str) {
        KongIslandService.HttpResult req = getReq(z ? "https://kong.mascom.vn/api/leaderboard/week?page=1&size=100&preWeek=False" : "https://kong.mascom.vn/api/leaderboard/month?page=1&size=100&preMonth=False", str);
        if (req == null || req.code != 200) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda36
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m523lambda$fetchLeaderboard$25$comzenoappKongIslandActivity();
                }
            });
            return;
        }
        try {
            JSONObject jSONObjectOptJSONObject = new JSONObject(req.body).optJSONObject("data");
            final JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("ranks") : null;
            final JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("userRank") : null;
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda37
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m524lambda$fetchLeaderboard$26$comzenoappKongIslandActivity(jSONArrayOptJSONArray, jSONObjectOptJSONObject2);
                }
            });
        } catch (Exception e) {
            Log.w(TAG, "fetchLeaderboard: " + e.getMessage());
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda38
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m525lambda$fetchLeaderboard$27$comzenoappKongIslandActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$25$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m523lambda$fetchLeaderboard$25$comzenoappKongIslandActivity() {
        stopRankSkeleton();
        showSnack("Leaderboard ဖွင့်၍ မရပါ");
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$26$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m524lambda$fetchLeaderboard$26$comzenoappKongIslandActivity(JSONArray jSONArray, JSONObject jSONObject) {
        stopRankSkeleton();
        renderLeaderboard(jSONArray, jSONObject);
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$27$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m525lambda$fetchLeaderboard$27$comzenoappKongIslandActivity() {
        stopRankSkeleton();
        showSnack("Leaderboard parse error");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderLeaderboard(JSONArray jSONArray, JSONObject jSONObject) {
        String str;
        int i;
        int i2;
        String str2;
        int i3;
        JSONArray jSONArray2 = jSONArray;
        JSONObject jSONObject2 = jSONObject;
        this.rankList.removeAllViews();
        if (jSONArray2 == null) {
            return;
        }
        dp(4);
        int iDp = dp(8);
        int iDp2 = dp(10);
        dp(12);
        int iDp3 = dp(36);
        int iDp4 = dp(40);
        int i4 = 0;
        while (i4 < jSONArray.length()) {
            try {
                JSONObject jSONObject3 = jSONArray2.getJSONObject(i4);
                int iOptInt = jSONObject3.optInt("order", i4 + 1);
                long jOptLong = jSONObject3.optLong("banana", 0L);
                String strOptString = jSONObject3.optString("playerName", "---");
                String strOptString2 = jSONObject3.optString("avatar", null);
                if ("null".equals(strOptString2) || (strOptString2 != null && strOptString2.isEmpty())) {
                    strOptString2 = null;
                }
                JSONObject jSONObjectOptJSONObject = jSONObject3.optJSONObject("rankReward");
                LinearLayout linearLayout = new LinearLayout(this);
                linearLayout.setOrientation(0);
                linearLayout.setGravity(16);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                layoutParams.setMargins(0, 0, 0, dp(6));
                linearLayout.setLayoutParams(layoutParams);
                linearLayout.setPadding(iDp, iDp2, iDp, iDp2);
                linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
                if (iOptInt <= 3) {
                    ImageView imageView = new ImageView(this);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(iDp4, iDp4);
                    layoutParams2.setMarginEnd(iDp);
                    imageView.setLayoutParams(layoutParams2);
                    imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    if (iOptInt == 1) {
                        imageView.setImageResource(R.drawable.ic_medal_gold);
                    } else if (iOptInt == 2) {
                        imageView.setImageResource(R.drawable.ic_medal_silver);
                    } else {
                        imageView.setImageResource(R.drawable.ic_medal_bronze);
                    }
                    linearLayout.addView(imageView);
                } else {
                    TextView textView = new TextView(this);
                    LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(iDp4, -2);
                    layoutParams3.setMarginEnd(iDp);
                    textView.setLayoutParams(layoutParams3);
                    textView.setText(String.valueOf(iOptInt));
                    textView.setTextColor(-7829368);
                    textView.setTextSize(2, 13.0f);
                    textView.setGravity(17);
                    linearLayout.addView(textView);
                }
                ImageView imageView2 = new ImageView(this);
                LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(iDp3, iDp3);
                layoutParams4.setMarginEnd(iDp2);
                imageView2.setLayoutParams(layoutParams4);
                imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView2.setBackgroundResource(R.drawable.bg_avatar_circle);
                imageView2.setClipToOutline(true);
                if (ok(strOptString2)) {
                    i = iDp2;
                    try {
                        Glide.with(this).load(strOptString2).apply(new RequestOptions().transform(new CircleCropTransform()).placeholder(R.drawable.ic_rank_default_avatar).error(R.drawable.ic_rank_default_avatar)).into(imageView2);
                    } catch (Exception e) {
                        e = e;
                        i2 = iDp3;
                        Log.w(TAG, "renderLeaderboard row " + i4 + ": " + e.getMessage());
                        i4++;
                        jSONArray2 = jSONArray;
                        jSONObject2 = jSONObject;
                        iDp2 = i;
                        iDp3 = i2;
                    }
                } else {
                    i = iDp2;
                    imageView2.setImageResource(R.drawable.ic_rank_default_avatar);
                }
                linearLayout.addView(imageView2);
                LinearLayout linearLayout2 = new LinearLayout(this);
                linearLayout2.setOrientation(1);
                linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                TextView textView2 = new TextView(this);
                textView2.setText(strOptString);
                textView2.setTextColor(iOptInt <= 3 ? -1 : -3355444);
                textView2.setTextSize(2, iOptInt <= 3 ? 14.0f : 13.0f);
                if (iOptInt <= 3) {
                    textView2.setTypeface(null, 1);
                }
                linearLayout2.addView(textView2);
                if (jSONObjectOptJSONObject != null) {
                    double dOptDouble = jSONObjectOptJSONObject.optDouble("reward", 0.0d);
                    String strOptString3 = jSONObjectOptJSONObject.optString("rewardType", "");
                    if ("MMK".equals(strOptString3)) {
                        i2 = iDp3;
                        try {
                            str2 = String.format(Locale.getDefault(), "%,.0f MMK", Double.valueOf(dOptDouble));
                        } catch (Exception e2) {
                            e = e2;
                            Log.w(TAG, "renderLeaderboard row " + i4 + ": " + e.getMessage());
                        }
                    } else {
                        i2 = iDp3;
                        str2 = String.format(Locale.getDefault(), "%,.0f LP", Double.valueOf(dOptDouble));
                    }
                    TextView textView3 = new TextView(this);
                    try {
                        if ("MMK".equals(strOptString3)) {
                            i3 = R.drawable.ic_mmk;
                        } else {
                            i3 = R.drawable.ic_loyal_point;
                        }
                        Drawable drawable = getResources().getDrawable(i3, getTheme());
                        int i5 = (int) (getResources().getDisplayMetrics().density * 14.0f);
                        drawable.setBounds(0, 0, i5, i5);
                        SpannableString spannableString = new SpannableString("  " + str2);
                        spannableString.setSpan(new ImageSpan(drawable, 2), 0, 1, 33);
                        textView3.setText(spannableString);
                    } catch (Exception unused) {
                        textView3.setText(str2);
                    }
                    textView3.setTextColor(-3632086);
                    textView3.setTextSize(2, 11.0f);
                    linearLayout2.addView(textView3);
                } else {
                    i2 = iDp3;
                }
                linearLayout.addView(linearLayout2);
                TextView textView4 = new TextView(this);
                textView4.setText(bananaSpan(jOptLong));
                textView4.setTextColor(iOptInt <= 3 ? -10752 : -5592406);
                textView4.setTextSize(2, 12.0f);
                if (iOptInt <= 3) {
                    textView4.setTypeface(null, 1);
                }
                textView4.setGravity(8388613);
                linearLayout.addView(textView4);
                this.rankList.addView(linearLayout);
            } catch (Exception e3) {
                e = e3;
                i = iDp2;
            }
            i4++;
            jSONArray2 = jSONArray;
            jSONObject2 = jSONObject;
            iDp2 = i;
            iDp3 = i2;
        }
        JSONObject jSONObject4 = jSONObject2;
        int i6 = iDp3;
        int i7 = iDp2;
        if (jSONObject4 != null) {
            int iOptInt2 = jSONObject4.optInt("order", 0);
            long jOptLong2 = jSONObject4.optLong("banana", 0L);
            String strOptString4 = jSONObject4.optString("playerName", "---");
            String strOptString5 = jSONObject4.optString("avatar", null);
            if ("null".equals(strOptString5) || (strOptString5 != null && strOptString5.isEmpty())) {
                strOptString5 = null;
            }
            this.rankUserRow.removeAllViews();
            TextView textView5 = new TextView(this);
            textView5.setText("ကိုယ်တိုင်");
            textView5.setTextColor(-7829368);
            textView5.setTextSize(2, 11.0f);
            textView5.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            LinearLayout linearLayout3 = new LinearLayout(this);
            linearLayout3.setOrientation(0);
            linearLayout3.setGravity(16);
            linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            TextView textView6 = new TextView(this);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(iDp4, -2);
            layoutParams5.setMarginEnd(iDp);
            textView6.setLayoutParams(layoutParams5);
            if (iOptInt2 > 0) {
                str = "#" + iOptInt2;
            } else {
                str = "--";
            }
            textView6.setText(str);
            textView6.setTextColor(-3632086);
            textView6.setTextSize(2, 13.0f);
            textView6.setTypeface(null, 1);
            textView6.setGravity(17);
            linearLayout3.addView(textView6);
            ImageView imageView3 = new ImageView(this);
            LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(i6, i6);
            layoutParams6.setMarginEnd(i7);
            imageView3.setLayoutParams(layoutParams6);
            imageView3.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView3.setBackgroundResource(R.drawable.bg_avatar_circle);
            imageView3.setClipToOutline(true);
            if (ok(strOptString5)) {
                Glide.with(this).load(strOptString5).apply(new RequestOptions().transform(new CircleCropTransform()).placeholder(R.drawable.ic_rank_default_avatar).error(R.drawable.ic_rank_default_avatar)).into(imageView3);
            } else {
                imageView3.setImageResource(R.drawable.ic_rank_default_avatar);
            }
            linearLayout3.addView(imageView3);
            TextView textView7 = new TextView(this);
            textView7.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            textView7.setText(strOptString4);
            textView7.setTextColor(-1);
            textView7.setTextSize(2, 13.0f);
            textView7.setTypeface(null, 1);
            linearLayout3.addView(textView7);
            TextView textView8 = new TextView(this);
            textView8.setText(bananaSpan(jOptLong2));
            textView8.setTextColor(-10752);
            textView8.setTextSize(2, 12.0f);
            textView8.setTypeface(null, 1);
            linearLayout3.addView(textView8);
            this.rankUserRow.addView(textView5);
            this.rankUserRow.addView(linearLayout3);
            this.rankUserFooter.setVisibility(0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showOpenBoxDialog() {
        KongIslandService.ServiceBinder serviceBinder;
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        final int totalBoxes = serviceBinder.getService().getTotalBoxes();
        if (totalBoxes <= 0) {
            showSnack("Box မရှိပါ");
            return;
        }
        final int[] iArr = {1};
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setCanceledOnTouchOutside(true);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setPadding(dp(24), dp(28), dp(24), dp(24));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-14540254);
        gradientDrawable.setCornerRadius(dp(12));
        gradientDrawable.setStroke(dp(1), -13750738);
        linearLayout.setBackground(gradientDrawable);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(56), dp(56));
        layoutParams.gravity = 1;
        layoutParams.bottomMargin = dp(12);
        imageView.setLayoutParams(layoutParams);
        imageView.setImageResource(R.drawable.ic_box);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        linearLayout.addView(imageView);
        TextView textView = new TextView(this);
        textView.setText("Box ဖွင့်မည်");
        textView.setTextColor(-14003);
        textView.setTextSize(2, 18.0f);
        textView.setTypeface(null, 1);
        textView.setGravity(17);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.bottomMargin = dp(18);
        textView.setLayoutParams(layoutParams2);
        linearLayout.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(17);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.bottomMargin = dp(20);
        linearLayout2.setLayoutParams(layoutParams3);
        final TextView textView2 = new TextView(this);
        textView2.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        textView2.setText("−");
        textView2.setTextColor(-3632086);
        textView2.setTextSize(2, 22.0f);
        textView2.setGravity(17);
        textView2.setTypeface(null, 1);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(1);
        gradientDrawable2.setColor(-14013910);
        gradientDrawable2.setStroke(dp(1), -12964332);
        textView2.setBackground(gradientDrawable2);
        final TextView textView3 = new TextView(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(56), -2);
        layoutParams4.leftMargin = dp(2);
        layoutParams4.rightMargin = dp(2);
        textView3.setLayoutParams(layoutParams4);
        textView3.setText(String.valueOf(iArr[0]));
        textView3.setTextColor(-1);
        textView3.setTextSize(2, 24.0f);
        textView3.setGravity(17);
        textView3.setTypeface(null, 1);
        final TextView textView4 = new TextView(this);
        textView4.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        textView4.setText("+");
        textView4.setTextColor(-3632086);
        textView4.setTextSize(2, 22.0f);
        textView4.setGravity(17);
        textView4.setTypeface(null, 1);
        GradientDrawable gradientDrawable3 = new GradientDrawable();
        gradientDrawable3.setShape(1);
        gradientDrawable3.setColor(-14013910);
        gradientDrawable3.setStroke(dp(1), -12964332);
        textView4.setBackground(gradientDrawable3);
        linearLayout2.addView(textView2);
        linearLayout2.addView(textView3);
        linearLayout2.addView(textView4);
        linearLayout.addView(linearLayout2);
        final Runnable runnable = new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                KongIslandActivity.lambda$showOpenBoxDialog$29(textView2, iArr, textView4, totalBoxes);
            }
        };
        runnable.run();
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                KongIslandActivity.lambda$showOpenBoxDialog$30(iArr, textView3, runnable, view);
            }
        });
        textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                KongIslandActivity.lambda$showOpenBoxDialog$31(iArr, totalBoxes, textView3, runnable, view);
            }
        });
        final LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(17);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, dp(52));
        layoutParams5.bottomMargin = dp(10);
        linearLayout3.setLayoutParams(layoutParams5);
        linearLayout3.setClickable(true);
        linearLayout3.setFocusable(true);
        GradientDrawable gradientDrawable4 = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{-1529824, -3632086});
        gradientDrawable4.setCornerRadius(dp(14));
        linearLayout3.setBackground(gradientDrawable4);
        final ImageView imageView2 = new ImageView(this);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(dp(20), dp(20));
        layoutParams6.rightMargin = dp(6);
        imageView2.setLayoutParams(layoutParams6);
        imageView2.setImageResource(R.drawable.ic_box);
        imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
        linearLayout3.addView(imageView2);
        final TextView textView5 = new TextView(this);
        textView5.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        textView5.setText("OPEN");
        textView5.setTextColor(-15068672);
        textView5.setTextSize(2, 15.0f);
        textView5.setTypeface(null, 1);
        linearLayout3.addView(textView5);
        linearLayout.addView(linearLayout3);
        Button button = new Button(this);
        button.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(46)));
        button.setText("မဖွင့်တော့ဘူး");
        button.setTextColor(-8947849);
        button.setTextSize(2, 14.0f);
        button.setBackgroundTintList(null);
        button.setBackground(new ColorDrawable(0));
        linearLayout.addView(button);
        dialog.setContentView(linearLayout);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88f), -2);
            window.setGravity(17);
        }
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        linearLayout3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m541lambda$showOpenBoxDialog$33$comzenoappKongIslandActivity(linearLayout3, imageView2, textView5, dialog, iArr, view);
            }
        });
        dialog.show();
    }

    static /* synthetic */ void lambda$showOpenBoxDialog$29(TextView textView, int[] iArr, TextView textView2, int i) {
        textView.setAlpha(iArr[0] > 1 ? 1.0f : 0.35f);
        textView2.setAlpha(iArr[0] >= i ? 0.35f : 1.0f);
    }

    static /* synthetic */ void lambda$showOpenBoxDialog$30(int[] iArr, TextView textView, Runnable runnable, View view) {
        int i = iArr[0];
        if (i > 1) {
            int i2 = i - 1;
            iArr[0] = i2;
            textView.setText(String.valueOf(i2));
            runnable.run();
        }
    }

    static /* synthetic */ void lambda$showOpenBoxDialog$31(int[] iArr, int i, TextView textView, Runnable runnable, View view) {
        int i2 = iArr[0];
        if (i2 < i) {
            int i3 = i2 + 1;
            iArr[0] = i3;
            textView.setText(String.valueOf(i3));
            runnable.run();
        }
    }

    /* JADX INFO: renamed from: lambda$showOpenBoxDialog$33$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m541lambda$showOpenBoxDialog$33$comzenoappKongIslandActivity(LinearLayout linearLayout, ImageView imageView, TextView textView, Dialog dialog, int[] iArr, View view) {
        KongIslandService.ServiceBinder serviceBinder;
        linearLayout.setEnabled(false);
        imageView.setVisibility(8);
        textView.setText("ဖွင့်နေသည်…");
        dialog.dismiss();
        if (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) {
            return;
        }
        serviceBinder.getService().openBox(iArr[0]);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showOpenBoxResultDialog(int i, List<String> list) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        final Dialog dialog = new Dialog(this);
        int i2 = 1;
        dialog.requestWindowFeature(1);
        dialog.setCanceledOnTouchOutside(true);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setPadding(dp(24), dp(28), dp(24), dp(24));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-14540254);
        gradientDrawable.setCornerRadius(dp(12));
        gradientDrawable.setStroke(dp(1), -13750738);
        linearLayout.setBackground(gradientDrawable);
        TextView textView = new TextView(this);
        textView.setText("🎁  Box " + i + " ခု ဖွင့်ပြီး!");
        textView.setTextColor(-14003);
        int i3 = 2;
        textView.setTextSize(2, 18.0f);
        textView.setTypeface(null, 1);
        textView.setGravity(17);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(20);
        textView.setLayoutParams(layoutParams);
        linearLayout.addView(textView);
        if (list.isEmpty()) {
            TextView textView2 = new TextView(this);
            textView2.setText("ရလဒ်မရှိပါ");
            textView2.setTextColor(-10066330);
            textView2.setTextSize(2, 14.0f);
            textView2.setGravity(17);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.bottomMargin = dp(20);
            textView2.setLayoutParams(layoutParams2);
            linearLayout.addView(textView2);
        } else {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                String[] strArrSplit = it.next().split("\\|", 3);
                String str = strArrSplit[0];
                String str2 = "";
                String str3 = strArrSplit.length > i2 ? strArrSplit[i2] : "";
                if (strArrSplit.length > i3) {
                    str2 = strArrSplit[i3];
                }
                LinearLayout linearLayout2 = new LinearLayout(this);
                linearLayout2.setOrientation(0);
                linearLayout2.setGravity(16);
                linearLayout2.setPadding(dp(16), dp(14), dp(16), dp(14));
                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
                layoutParams3.bottomMargin = dp(8);
                linearLayout2.setLayoutParams(layoutParams3);
                linearLayout2.setBackgroundResource(R.drawable.bg_beat_song_normal);
                ImageView imageView = new ImageView(this);
                LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(32), dp(32));
                layoutParams4.setMarginEnd(dp(12));
                imageView.setLayoutParams(layoutParams4);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setImageResource(typeIcon(str3));
                linearLayout2.addView(imageView);
                TextView textView3 = new TextView(this);
                textView3.setText(str);
                textView3.setTextColor(-1118482);
                textView3.setTextSize(2, 15.0f);
                textView3.setTypeface(null, 1);
                textView3.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                linearLayout2.addView(textView3);
                TextView textView4 = new TextView(this);
                textView4.setText("x" + str2);
                textView4.setTextColor(-14003);
                textView4.setTextSize(2, 15.0f);
                textView4.setTypeface(null, 1);
                linearLayout2.addView(textView4);
                linearLayout.addView(linearLayout2);
                i2 = 1;
                i3 = 2;
            }
            View view = new View(this);
            view.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(12)));
            linearLayout.addView(view);
        }
        Button button = new Button(this);
        button.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(50)));
        button.setText("OK");
        button.setTextColor(-15068672);
        button.setTextSize(2, 15.0f);
        button.setTypeface(null, 1);
        button.setBackgroundTintList(null);
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{-1529824, -3632086});
        gradientDrawable2.setCornerRadius(dp(14));
        button.setBackground(gradientDrawable2);
        linearLayout.addView(button);
        dialog.setContentView(linearLayout);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88f), -2);
            window.setGravity(17);
        }
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view2) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private String typeLabel(String str) {
        if (str == null) {
            return "Unknown";
        }
        str.hashCode();
        switch (str) {
            case "MAGNET":
                return "Magnet";
            case "REBORN":
                return "Reborn";
            case "TICKET":
                return "Ticket";
            case "PROTECT":
                return "Protect";
            case "BANANA":
                return "Banana";
            case "X2BANANA":
                return "2x Banana";
            default:
                return str;
        }
    }

    private int typeIcon(String str) {
        if (str == null) {
            return R.drawable.ic_ticket;
        }
        str.hashCode();
        switch (str) {
        }
        return R.drawable.ic_ticket;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r18v0, types: [android.content.Context, com.zeno.app.KongIslandActivity] */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r2v21 */
    /* JADX WARN: Type inference failed for: r2v22 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v6 */
    private void showEditNameDialog() {
        ?? r2;
        try {
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            int i = R.layout.dialog_edit_name;
            dialog.setContentView(i);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            Window window = dialog.getWindow();
            r2 = i;
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
                r2 = attributes;
            }
            final EditText editText = (EditText) dialog.findViewById(R.id.etName);
            ImageView imageView = (ImageView) dialog.findViewById(R.id.btnCloseDialog);
            final Button button = (Button) dialog.findViewById(R.id.btnChangeName);
            final TextView textView = (TextView) dialog.findViewById(R.id.tabName);
            final TextView textView2 = (TextView) dialog.findViewById(R.id.tabPicture);
            final View viewFindViewById = dialog.findViewById(R.id.panelName);
            final View viewFindViewById2 = dialog.findViewById(R.id.panelPicture);
            final ProgressBar progressBar = (ProgressBar) dialog.findViewById(R.id.pbAvatarLoading);
            final GridLayout gridLayout = (GridLayout) dialog.findViewById(R.id.gridAvatars);
            try {
                if (editText != null && imageView != null && button != null && textView != null && textView2 != null && viewFindViewById != null && viewFindViewById2 != null && gridLayout != null) {
                    TextView textView3 = this.tvProfileName;
                    String string = textView3 != null ? textView3.getText().toString() : "";
                    if (string != null && !string.equals("---") && !string.isEmpty()) {
                        editText.setText(string);
                        editText.setSelection(string.length());
                    }
                    final Runnable runnable = new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda40
                        @Override // java.lang.Runnable
                        public final void run() {
                            KongIslandActivity.lambda$showEditNameDialog$35(viewFindViewById, viewFindViewById2, textView, textView2);
                        }
                    };
                    try {
                        final Runnable runnable2 = new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda41
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.m534lambda$showEditNameDialog$36$comzenoappKongIslandActivity(viewFindViewById, viewFindViewById2, textView2, textView, dialog, gridLayout, progressBar);
                            }
                        };
                        textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda42
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                runnable.run();
                            }
                        });
                        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda44
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                runnable2.run();
                            }
                        });
                        runnable.run();
                        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda45
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda46
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                this.f$0.m538lambda$showEditNameDialog$43$comzenoappKongIslandActivity(editText, button, dialog, view);
                            }
                        });
                        dialog.show();
                        return;
                    } catch (Exception e) {
                        e = e;
                        r2 = this;
                        Log.e(TAG, "showEditNameDialog", e);
                        Toast.makeText((Context) r2, "Dialog error", 0).show();
                        return;
                    }
                }
                Toast.makeText((Context) this, "Dialog layout error", 0).show();
            } catch (Exception e2) {
                e = e2;
            }
        } catch (Exception e3) {
            e = e3;
            r2 = this;
        }
    }

    static /* synthetic */ void lambda$showEditNameDialog$35(View view, View view2, TextView textView, TextView textView2) {
        view.setVisibility(0);
        view2.setVisibility(8);
        textView.setBackgroundResource(R.drawable.bg_tab_active);
        textView.setTextColor(-16777216);
        textView.setTypeface(null, 1);
        textView2.setBackgroundResource(android.R.color.transparent);
        textView2.setTextColor(-5592406);
        textView2.setTypeface(null, 0);
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$36$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m534lambda$showEditNameDialog$36$comzenoappKongIslandActivity(View view, View view2, TextView textView, TextView textView2, Dialog dialog, GridLayout gridLayout, ProgressBar progressBar) {
        view.setVisibility(8);
        view2.setVisibility(0);
        textView.setBackgroundResource(R.drawable.bg_tab_active);
        textView.setTextColor(-16777216);
        textView.setTypeface(null, 1);
        textView2.setBackgroundResource(android.R.color.transparent);
        textView2.setTextColor(-5592406);
        textView2.setTypeface(null, 0);
        loadKongAvatarsIntoGrid(dialog, gridLayout, progressBar);
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$43$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m538lambda$showEditNameDialog$43$comzenoappKongIslandActivity(EditText editText, final Button button, final Dialog dialog, View view) {
        KongIslandService.ServiceBinder serviceBinder;
        final String strTrim = editText.getText().toString().trim();
        if (strTrim.isEmpty()) {
            editText.setError("Name ထည့်ပါ");
            return;
        }
        button.setEnabled(false);
        final String kongToken = (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) ? this.session.getKongToken() : serviceBinder.getService().getKongToken();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m537lambda$showEditNameDialog$42$comzenoappKongIslandActivity(strTrim, kongToken, dialog, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$42$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m537lambda$showEditNameDialog$42$comzenoappKongIslandActivity(final String str, String str2, final Dialog dialog, final Button button) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("playerName", str);
            final KongIslandService.HttpResult httpResultPutReq = putReq("https://kong.mascom.vn/api/user/player-name", jSONObject.toString(), str2);
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda47
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m535lambda$showEditNameDialog$40$comzenoappKongIslandActivity(httpResultPutReq, str, dialog, button);
                }
            });
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda48
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m536lambda$showEditNameDialog$41$comzenoappKongIslandActivity(button, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showEditNameDialog$40$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m535lambda$showEditNameDialog$40$comzenoappKongIslandActivity(KongIslandService.HttpResult httpResult, String str, Dialog dialog, Button button) {
        if (httpResult == null || httpResult.code < 200 || httpResult.code >= 300) {
            button.setEnabled(true);
            Toast.makeText((Context) this, (CharSequence) "ပြောင်းမရပါ၊ ထပ်ကြိုးစားပါ", 0).show();
        } else {
            TextView textView = this.tvProfileName;
            if (textView != null) {
                textView.setText(str);
            }
            dialog.dismiss();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showEditNameDialog$41$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m536lambda$showEditNameDialog$41$comzenoappKongIslandActivity(Button button, Exception exc) {
        button.setEnabled(true);
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void loadKongAvatarsIntoGrid(final Dialog dialog, final GridLayout gridLayout, final ProgressBar progressBar) {
        KongIslandService.ServiceBinder serviceBinder;
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
        gridLayout.removeAllViews();
        final String kongToken = (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) ? this.session.getKongToken() : serviceBinder.getService().getKongToken();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m531lambda$loadKongAvatarsIntoGrid$46$comzenoappKongIslandActivity(kongToken, progressBar, dialog, gridLayout);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadKongAvatarsIntoGrid$46$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m531lambda$loadKongAvatarsIntoGrid$46$comzenoappKongIslandActivity(String str, final ProgressBar progressBar, final Dialog dialog, final GridLayout gridLayout) {
        JSONArray jSONArrayOptJSONArray;
        try {
            KongIslandService.HttpResult req = getReq("https://kong.mascom.vn/api/avatar/list", str);
            final JSONArray jSONArray = (req == null || req.body == null || req.body.isEmpty() || (jSONArrayOptJSONArray = new JSONObject(req.body).optJSONArray("data")) == null) ? new JSONArray() : jSONArrayOptJSONArray;
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m529lambda$loadKongAvatarsIntoGrid$44$comzenoappKongIslandActivity(progressBar, dialog, gridLayout, jSONArray);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "loadKongAvatars", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m530lambda$loadKongAvatarsIntoGrid$45$comzenoappKongIslandActivity(progressBar);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadKongAvatarsIntoGrid$44$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m529lambda$loadKongAvatarsIntoGrid$44$comzenoappKongIslandActivity(ProgressBar progressBar, Dialog dialog, GridLayout gridLayout, JSONArray jSONArray) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        if (dialog.isShowing()) {
            populateKongAvatarGrid(dialog, gridLayout, jSONArray);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadKongAvatarsIntoGrid$45$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m530lambda$loadKongAvatarsIntoGrid$45$comzenoappKongIslandActivity(ProgressBar progressBar) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        Toast.makeText((Context) this, (CharSequence) "Avatar list မရပါ", 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01bf A[Catch: Exception -> 0x0200, TRY_LEAVE, TryCatch #0 {Exception -> 0x0200, blocks: (B:32:0x00c5, B:34:0x00ed, B:36:0x00f3, B:41:0x0129, B:43:0x0135, B:80:0x01bf, B:48:0x014a, B:50:0x014f, B:55:0x0165, B:57:0x016a, B:59:0x0170, B:62:0x0177, B:67:0x018b, B:69:0x0190, B:71:0x0196, B:74:0x019d, B:76:0x01a6, B:78:0x01ab), top: B:98:0x00c5 }] */
    /* JADX WARN: Removed duplicated region for block: B:83:0x01ec  */
    /* JADX WARN: Type inference failed for: r0v8, types: [org.json.JSONObject] */
    /* JADX WARN: Type inference failed for: r11v1, types: [android.view.LayoutInflater] */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v5 */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v10 */
    /* JADX WARN: Type inference failed for: r18v11 */
    /* JADX WARN: Type inference failed for: r18v13 */
    /* JADX WARN: Type inference failed for: r18v2 */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r18v7 */
    /* JADX WARN: Type inference failed for: r18v8 */
    /* JADX WARN: Type inference failed for: r18v9 */
    /* JADX WARN: Type inference failed for: r21v0 */
    /* JADX WARN: Type inference failed for: r26v0, types: [android.view.ViewGroup, android.widget.GridLayout] */
    /* JADX WARN: Type inference failed for: r9v0 */
    /* JADX WARN: Type inference failed for: r9v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r9v2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void populateKongAvatarGrid(final android.app.Dialog r25, final android.widget.GridLayout r26, org.json.JSONArray r27) {
        /*
            Method dump skipped, instruction units count: 583
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.KongIslandActivity.populateKongAvatarGrid(android.app.Dialog, android.widget.GridLayout, org.json.JSONArray):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$populateKongAvatarGrid$47$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m533lambda$populateKongAvatarGrid$47$comzenoappKongIslandActivity(boolean z, boolean z2, String str, Dialog dialog, GridLayout gridLayout, int i, String str2, boolean z3, int i2, View view) {
        String str3;
        CharSequence charSequence;
        if (z) {
            Toast.makeText((Context) this, (CharSequence) "အခုသုံးနေတဲ့ avatar ပါ", 0).show();
            return;
        }
        if (z2) {
            showKongAvatarConfirmDialog(dialog, gridLayout, i, str2, (str == null || str.isEmpty()) ? "ဤ avatar ကို ဖွင့်ရန် လိုအပ်ချက် မပြည့်သေးပါ" : str, false);
            return;
        }
        if (!z3) {
            if (i2 <= 0) {
                showKongAvatarConfirmDialog(dialog, gridLayout, i, str2, (str == null || str.isEmpty()) ? "ဤ avatar ကို ဖွင့်ရန် လိုအပ်ချက် မပြည့်သေးပါ" : str, false);
                return;
            }
            try {
                Drawable drawableMutate = getResources().getDrawable(R.drawable.ic_banana, getTheme()).mutate();
                int i3 = (int) (getResources().getDisplayMetrics().density * 16.0f);
                drawableMutate.setBounds(0, 0, i3, i3);
                String str4 = String.valueOf(i2) + "  ";
                SpannableString spannableString = new SpannableString(str4 + "￼  နဲ့ ဝယ်ပြီး သုံးမလား?");
                ImageSpan imageSpan = new ImageSpan(drawableMutate, 0);
                int length = str4.length();
                spannableString.setSpan(imageSpan, length, length + 1, 33);
                charSequence = spannableString;
            } catch (Exception e) {
                Log.e(TAG, "confirm banana icon", e);
                str3 = i2 + " နဲ့ ဝယ်ပြီး သုံးမလား?";
                charSequence = str3;
            }
            showKongAvatarConfirmDialog(dialog, gridLayout, i, str2, charSequence, true);
        }
        str3 = "ဒီ avatar ကို သုံးမလား?";
        charSequence = str3;
        showKongAvatarConfirmDialog(dialog, gridLayout, i, str2, charSequence, true);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showKongAvatarConfirmDialog(final Dialog dialog, final GridLayout gridLayout, final int i, final String str, CharSequence charSequence, boolean z) {
        try {
            final Dialog dialog2 = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog2.requestWindowFeature(1);
            dialog2.setContentView(R.layout.dialog_avatar_confirm);
            dialog2.setCancelable(true);
            dialog2.setCanceledOnTouchOutside(true);
            Window window = dialog2.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.82f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            ImageView imageView = (ImageView) dialog2.findViewById(R.id.ivConfirmAvatar);
            TextView textView = (TextView) dialog2.findViewById(R.id.tvConfirmMessage);
            ImageView imageView2 = (ImageView) dialog2.findViewById(R.id.btnCloseAvatarConfirm);
            TextView textView2 = (TextView) dialog2.findViewById(R.id.btnConfirmCancel);
            TextView textView3 = (TextView) dialog2.findViewById(R.id.btnConfirmOk);
            if (textView != null) {
                textView.setText(charSequence);
            }
            if (imageView != null && ok(str)) {
                Glide.with(getApplicationContext()).load(str).apply(new RequestOptions().placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(imageView);
            }
            View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog2.dismiss();
                }
            };
            if (imageView2 != null) {
                imageView2.setOnClickListener(onClickListener);
            }
            if (textView2 != null) {
                textView2.setOnClickListener(onClickListener);
            }
            if (textView3 != null) {
                if (z) {
                    textView3.setText("OK");
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda1
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            this.f$0.m539lambda$showKongAvatarConfirmDialog$49$comzenoappKongIslandActivity(dialog2, dialog, gridLayout, i, str, view);
                        }
                    });
                } else {
                    textView3.setText("OK");
                    textView3.setOnClickListener(onClickListener);
                    if (textView2 != null) {
                        textView2.setVisibility(8);
                    }
                }
            }
            dialog2.show();
        } catch (Exception e) {
            Log.e(TAG, "showKongAvatarConfirmDialog", e);
            if (z) {
                buyOrUseKongAvatar(dialog, gridLayout, (ProgressBar) dialog.findViewById(R.id.pbAvatarLoading), i, str);
            }
        }
    }

    /* JADX INFO: renamed from: lambda$showKongAvatarConfirmDialog$49$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m539lambda$showKongAvatarConfirmDialog$49$comzenoappKongIslandActivity(Dialog dialog, Dialog dialog2, GridLayout gridLayout, int i, String str, View view) {
        dialog.dismiss();
        buyOrUseKongAvatar(dialog2, gridLayout, (ProgressBar) dialog2.findViewById(R.id.pbAvatarLoading), i, str);
    }

    private void buyOrUseKongAvatar(final Dialog dialog, final GridLayout gridLayout, final ProgressBar progressBar, final int i, final String str) {
        KongIslandService.ServiceBinder serviceBinder;
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
        final String kongToken = (!this.serviceBound || (serviceBinder = this.serviceBinder) == null) ? this.session.getKongToken() : serviceBinder.getService().getKongToken();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda35
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m520lambda$buyOrUseKongAvatar$52$comzenoappKongIslandActivity(i, kongToken, progressBar, str, dialog, gridLayout);
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0050  */
    /* JADX INFO: renamed from: lambda$buyOrUseKongAvatar$52$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ void m520lambda$buyOrUseKongAvatar$52$comzenoappKongIslandActivity(int r8, java.lang.String r9, final android.widget.ProgressBar r10, final java.lang.String r11, final android.app.Dialog r12, final android.widget.GridLayout r13) {
        /*
            r7 = this;
            java.lang.String r0 = "https://kong.mascom.vn/api/avatar/buy/"
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L65
            r1.<init>(r0)     // Catch: java.lang.Exception -> L65
            r1.append(r8)     // Catch: java.lang.Exception -> L65
            java.lang.String r8 = r1.toString()     // Catch: java.lang.Exception -> L65
            com.zeno.app.KongIslandService$HttpResult r8 = r7.getReq(r8, r9)     // Catch: java.lang.Exception -> L65
            r9 = 0
            if (r8 == 0) goto L53
            java.lang.String r0 = r8.body     // Catch: java.lang.Exception -> L65
            if (r0 == 0) goto L53
            r0 = 1
            org.json.JSONObject r1 = new org.json.JSONObject     // Catch: java.lang.Exception -> L44
            java.lang.String r2 = r8.body     // Catch: java.lang.Exception -> L44
            boolean r2 = r2.isEmpty()     // Catch: java.lang.Exception -> L44
            if (r2 == 0) goto L28
            java.lang.String r2 = "{}"
            goto L2a
        L28:
            java.lang.String r2 = r8.body     // Catch: java.lang.Exception -> L44
        L2a:
            r1.<init>(r2)     // Catch: java.lang.Exception -> L44
            java.lang.String r2 = "success"
            boolean r2 = r1.optBoolean(r2, r9)     // Catch: java.lang.Exception -> L44
            if (r2 != 0) goto L50
            java.lang.String r2 = "00000"
            java.lang.String r3 = "error"
            java.lang.String r1 = r1.optString(r3)     // Catch: java.lang.Exception -> L44
            boolean r8 = r2.equals(r1)     // Catch: java.lang.Exception -> L44
            if (r8 == 0) goto L51
            goto L50
        L44:
            int r1 = r8.code     // Catch: java.lang.Exception -> L65
            r2 = 200(0xc8, float:2.8E-43)
            if (r1 < r2) goto L51
            int r8 = r8.code     // Catch: java.lang.Exception -> L65
            r1 = 300(0x12c, float:4.2E-43)
            if (r8 >= r1) goto L51
        L50:
            r9 = 1
        L51:
            r3 = r9
            goto L54
        L53:
            r3 = 0
        L54:
            android.os.Handler r8 = r7.ui     // Catch: java.lang.Exception -> L65
            com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda43 r9 = new com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda43     // Catch: java.lang.Exception -> L65
            r0 = r9
            r1 = r7
            r2 = r10
            r4 = r11
            r5 = r12
            r6 = r13
            r0.<init>()     // Catch: java.lang.Exception -> L65
            r8.post(r9)     // Catch: java.lang.Exception -> L65
            goto L77
        L65:
            r8 = move-exception
            java.lang.String r9 = "KongIsland"
            java.lang.String r11 = "buyOrUseKongAvatar"
            android.util.Log.e(r9, r11, r8)
            android.os.Handler r9 = r7.ui
            com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda51 r11 = new com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda51
            r11.<init>()
            r9.post(r11)
        L77:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.KongIslandActivity.m520lambda$buyOrUseKongAvatar$52$comzenoappKongIslandActivity(int, java.lang.String, android.widget.ProgressBar, java.lang.String, android.app.Dialog, android.widget.GridLayout):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyOrUseKongAvatar$50$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m518lambda$buyOrUseKongAvatar$50$comzenoappKongIslandActivity(ProgressBar progressBar, boolean z, String str, Dialog dialog, GridLayout gridLayout) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        if (!z) {
            Toast.makeText((Context) this, (CharSequence) "Avatar ဝယ်/သုံးမရပါ", 0).show();
            return;
        }
        Toast.makeText((Context) this, (CharSequence) "Avatar ပြောင်းပြီးပါပြီ", 0).show();
        if (ok(str)) {
            loadAvatar(str);
            try {
                SessionManager sessionManager = this.session;
                TextView textView = this.tvProfileName;
                sessionManager.saveKongProfile(textView != null ? textView.getText().toString() : "", this.session.getKongPlayerPhone(), str);
            } catch (Exception unused) {
            }
        }
        loadKongAvatarsIntoGrid(dialog, gridLayout, progressBar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyOrUseKongAvatar$51$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m519lambda$buyOrUseKongAvatar$51$comzenoappKongIslandActivity(ProgressBar progressBar, Exception exc) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private KongIslandService.HttpResult getReq(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("user-agent", "Mozilla/5.0");
            if (ok(str2)) {
                builderAddHeader.addHeader("Authorization", "Bearer " + str2);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                KongIslandService.HttpResult httpResult = new KongIslandService.HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "GET: " + e.getMessage());
            return null;
        }
    }

    private KongIslandService.HttpResult putReq(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).put(RequestBody.create(str2, MediaType.parse("application/json"))).addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("user-agent", "Mozilla/5.0");
            if (ok(str3)) {
                builderAddHeader.addHeader("Authorization", "Bearer " + str3);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                KongIslandService.HttpResult httpResult = new KongIslandService.HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "PUT: " + e.getMessage());
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateKongProgressMarker(final int i) {
        ImageView imageView = this.ivProgressKong;
        if (imageView == null || this.progressGameContainer == null) {
            return;
        }
        imageView.setVisibility(0);
        this.progressGameContainer.post(new Runnable() { // from class: com.zeno.app.KongIslandActivity$$ExternalSyntheticLambda54
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m543lambda$updateKongProgressMarker$53$comzenoappKongIslandActivity(i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$updateKongProgressMarker$53$com-zeno-app-KongIslandActivity, reason: not valid java name */
    /* synthetic */ void m543lambda$updateKongProgressMarker$53$comzenoappKongIslandActivity(int i) {
        int width = this.progressGameContainer.getWidth();
        int width2 = this.ivProgressKong.getWidth();
        if (width <= 0) {
            return;
        }
        if (width2 <= 0) {
            width2 = (int) (getResources().getDisplayMetrics().density * 32.0f);
        }
        this.ivProgressKong.setTranslationX(Math.max(0, width - width2) * Math.max(0.0f, Math.min(1.0f, i / 100.0f)));
    }

    private CharSequence bananaSpan(long j) {
        String str = String.format(Locale.getDefault(), "%,d", Long.valueOf(j));
        try {
            Drawable drawable = getResources().getDrawable(R.drawable.ic_banana, getTheme());
            int i = (int) (getResources().getDisplayMetrics().density * 14.0f);
            drawable.setBounds(0, 0, i, i);
            SpannableString spannableString = new SpannableString("  " + str);
            spannableString.setSpan(new ImageSpan(drawable, 2), 0, 1, 33);
            return spannableString;
        } catch (Exception unused) {
            return str;
        }
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private int dp(int i) {
        return Math.round(TypedValue.applyDimension(1, i, getResources().getDisplayMetrics()));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    public java.lang.String fmtSec(
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r7v0 ??
        	at g9.s.h(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:18)
        	at v8.f.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:547)
        	at v8.a.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:67)
        	at v8.a.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:209)
        	at aa.e.accept(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:16)
        	at j$.util.stream.o0.accept(SourceFile:183)
        	at j$.desugar.sun.nio.fs.g.accept(SourceFile:0)
        	at j$.util.Collection$-EL.a(SourceFile:665)
        	at j$.util.stream.n6.end(SourceFile:403)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.n.end(SourceFile:5)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.m.end(SourceFile:5)
        	at j$.util.stream.a.c0(SourceFile:485)
        	at j$.util.stream.a.u0(SourceFile:474)
        	at j$.util.stream.o0.f(SourceFile:150)
        	at j$.util.stream.a.x0(SourceFile:234)
        	at j$.util.stream.i5.forEach(SourceFile:497)
        	at v8.a.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:359)
        	at com.google.firebase.remoteconfig.internal.b.call(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:78)
        	at qg.d.D(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1)
        	at qg.d.l(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:71)
        	at u8.b.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:134)
        	at u8.b.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:89)
        	at k9.c.o0(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:48)
        	at a2.x.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:149)
        	at sa.b.e(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:10)
        	at androidx.activity.d.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:143)
        	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        	at java.lang.Thread.run(Thread.java:1571)
        */

    /* JADX INFO: Access modifiers changed from: private */
    public String fmtMs(long j) {
        long j2 = j / 1000;
        if (j2 < 60) {
            return j2 + "s";
        }
        long j3 = j2 / 60;
        long j4 = j2 % 60;
        if (j4 == 0) {
            return j3 + "m";
        }
        return j3 + "m " + j4 + "s";
    }

    private String fmtTotalTime(int i) {
        if (i < 60) {
            return i + "m";
        }
        return (i / 60) + "h : " + String.format(Locale.getDefault(), "%02dm", Integer.valueOf(i % 60));
    }

    private void stopProfileSkeleton() {
        View view;
        KongIslandService.ServiceBinder serviceBinder;
        SkeletonPulse.stop(this.profileSkeletonAnim, this.pbProfileLoading);
        this.profileSkeletonAnim = null;
        View view2 = this.pbProfileLoading;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.rowProfileName;
        if (view3 != null) {
            view3.setVisibility(0);
        }
        TextView textView = this.tvProfilePhone;
        if (textView != null) {
            textView.setVisibility(0);
        }
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.avatarSkeleton);
        this.avatarSkeletonAnim = null;
        View view4 = this.avatarSkeleton;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(0);
        }
        SkeletonPulse.stop(this.shopSkeletonAnim, this.shopCardsSkeleton);
        this.shopSkeletonAnim = null;
        View view5 = this.shopCardsSkeleton;
        if (view5 != null) {
            view5.setVisibility(8);
        }
        View view6 = this.shopCardsContent;
        if (view6 != null) {
            view6.setVisibility(0);
        }
        SkeletonPulse.stop(this.balanceSkeletonAnim, this.balanceSkeleton);
        this.balanceSkeletonAnim = null;
        View view7 = this.balanceSkeleton;
        if (view7 != null) {
            view7.setVisibility(8);
        }
        View view8 = this.balanceContent;
        if (view8 != null) {
            view8.setVisibility(0);
        }
        SkeletonPulse.stop(this.gamePickerSkeletonAnim, this.gamePickerSkeleton);
        this.gamePickerSkeletonAnim = null;
        View view9 = this.gamePickerSkeleton;
        if (view9 != null) {
            view9.setVisibility(8);
        }
        boolean z = this.serviceBound && (serviceBinder = this.serviceBinder) != null && serviceBinder.getService() != null && this.serviceBinder.getService().isRunning();
        setGamePickerVisible(!z);
        if (z && (view = this.cardPlaying) != null) {
            view.setVisibility(0);
        }
        stopActionSkeleton(this.spinSkeletonAnim, this.spinSkeleton, btnSpinView());
        this.spinSkeletonAnim = null;
        stopActionSkeleton(this.autoPlaySkeletonAnim, this.autoPlaySkeleton, this.btnAutoPlay);
        this.autoPlaySkeletonAnim = null;
        stopActionSkeleton(this.openBoxSkeletonAnim, this.openBoxSkeleton, this.btnOpenBox);
        this.openBoxSkeletonAnim = null;
    }

    private void stopActionSkeleton(ValueAnimator valueAnimator, View view, View view2) {
        SkeletonPulse.stop(valueAnimator, view);
        if (view != null) {
            view.setVisibility(8);
        }
        if (view2 != null) {
            view2.setVisibility(0);
            view2.setEnabled(true);
        }
    }

    private void stopRankSkeleton() {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.rankLoading);
        this.rankSkeletonAnim = null;
        View view = this.rankLoading;
        if (view != null) {
            view.setVisibility(8);
        }
    }
}
