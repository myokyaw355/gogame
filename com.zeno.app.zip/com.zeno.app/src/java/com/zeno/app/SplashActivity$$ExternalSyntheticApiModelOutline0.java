package com.zeno.app;

import android.app.NotificationChannel;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final /* synthetic */ class SplashActivity$$ExternalSyntheticApiModelOutline0 {
    public static /* synthetic */ NotificationChannel m(String str, CharSequence charSequence, int i) {
        return new NotificationChannel(str, charSequence, i);
    }
}
