package com.zeno.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final class LockedCardOverlay extends Drawable {
    private static final int TAG = R.id.tag_locked_overlay;
    private final float density;
    private final Paint disc;
    private final Drawable lock;
    private final RectF rect;
    private final Paint ring;
    private final Paint scrim;

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
    }

    private LockedCardOverlay(Context context) {
        Paint paint = new Paint(1);
        this.scrim = paint;
        Paint paint2 = new Paint(1);
        this.ring = paint2;
        Paint paint3 = new Paint(1);
        this.disc = paint3;
        this.rect = new RectF();
        this.density = context.getResources().getDisplayMetrics().density;
        paint.setColor(Color.parseColor("#B8121212"));
        paint3.setColor(Color.parseColor("#1A1A1A"));
        paint2.setColor(Color.parseColor("#66FF3B30"));
        Drawable drawableWrap = DrawableCompat.wrap(ContextCompat.getDrawable(context, R.drawable.ic_game_lock).mutate());
        this.lock = drawableWrap;
        DrawableCompat.setTint(drawableWrap, Color.parseColor("#FF3B30"));
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Rect bounds = getBounds();
        this.rect.set(bounds);
        RectF rectF = this.rect;
        float f = this.density;
        canvas.drawRoundRect(rectF, f * 12.0f, f * 12.0f, this.scrim);
        float fExactCenterX = bounds.exactCenterX();
        float fExactCenterY = bounds.exactCenterY();
        float f2 = this.density;
        float f3 = 24.0f * f2;
        canvas.drawCircle(fExactCenterX, fExactCenterY, (f2 * 6.0f) + f3, this.ring);
        canvas.drawCircle(fExactCenterX, fExactCenterY, f3, this.disc);
        int i = (int) (this.density * 12.0f);
        int i2 = (int) fExactCenterX;
        int i3 = (int) fExactCenterY;
        this.lock.setBounds(i2 - i, i3 - i, i2 + i, i3 + i);
        this.lock.draw(canvas);
    }

    public static boolean isLocked(View view) {
        return view != null && (view.getTag(TAG) instanceof Holder);
    }

    public static void apply(View view, boolean z) {
        if (view == null) {
            return;
        }
        int i = TAG;
        Object tag = view.getTag(i);
        if (!z) {
            if (tag instanceof Holder) {
                Holder holder = (Holder) tag;
                view.getOverlay().remove(holder.overlay);
                view.removeOnLayoutChangeListener(holder.listener);
                view.setTag(i, null);
                return;
            }
            return;
        }
        if (tag instanceof Holder) {
            return;
        }
        final LockedCardOverlay lockedCardOverlay = new LockedCardOverlay(view.getContext());
        lockedCardOverlay.setBounds(0, 0, view.getWidth(), view.getHeight());
        View.OnLayoutChangeListener onLayoutChangeListener = new View.OnLayoutChangeListener() { // from class: com.zeno.app.LockedCardOverlay$$ExternalSyntheticLambda0
            @Override // android.view.View.OnLayoutChangeListener
            public final void onLayoutChange(View view2, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9) {
                this.f$0.setBounds(0, 0, view2.getWidth(), view2.getHeight());
            }
        };
        view.addOnLayoutChangeListener(onLayoutChangeListener);
        view.getOverlay().add(lockedCardOverlay);
        view.setTag(i, new Holder(lockedCardOverlay, onLayoutChangeListener));
    }

    private static final class Holder {
        final View.OnLayoutChangeListener listener;
        final LockedCardOverlay overlay;

        Holder(LockedCardOverlay lockedCardOverlay, View.OnLayoutChangeListener onLayoutChangeListener) {
            this.overlay = lockedCardOverlay;
            this.listener = onLayoutChangeListener;
        }
    }
}
