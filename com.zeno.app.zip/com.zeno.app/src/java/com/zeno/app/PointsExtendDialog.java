package com.zeno.app;

import android.app.Activity;
import android.app.Dialog;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.zeno.app.PointsExtendDialog;
import java.io.IOException;
import java.util.Locale;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class PointsExtendDialog {
    public static void show(Activity activity) {
        SessionManager sessionManager = new SessionManager(activity);
        String phone = sessionManager.getPhone();
        String accessToken = sessionManager.getAccessToken();
        String deviceId = sessionManager.getDeviceId();
        Handler handler = new Handler(Looper.getMainLooper());
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_points_extend);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            DisplayMetrics displayMetrics = activity.getResources().getDisplayMetrics();
            window.setLayout(displayMetrics.widthPixels - (((int) (displayMetrics.density * 14.0f)) * 2), -2);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = 17;
            attributes.dimAmount = 0.65f;
            window.setAttributes(attributes);
            window.addFlags(2);
        }
        TextView textView = (TextView) dialog.findViewById(R.id.tvExtendTitle);
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvExtendDesc);
        TextView textView3 = (TextView) dialog.findViewById(R.id.tvExtendQuestion);
        TextView textView4 = (TextView) dialog.findViewById(R.id.tvExtendNote);
        TextView textView5 = (TextView) dialog.findViewById(R.id.btnExtendCancel);
        TextView textView6 = (TextView) dialog.findViewById(R.id.btnExtendConfirm);
        textView.setText("လစဉ်လဲလှယ်ခွင့် ကန့်သတ်ချက်ကို ထပ်တိုးမလား?");
        textView2.setText("Loading...");
        textView3.setText("");
        textView4.setText("");
        textView6.setEnabled(false);
        textView6.setAlpha(0.5f);
        textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsExtendDialog$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
        ApiClient.getLoyaltyInquiry(phone, accessToken, deviceId, new AnonymousClass1(handler, dialog, textView2, textView3, textView4, textView6, phone, accessToken, deviceId, activity));
    }

    /* JADX INFO: renamed from: com.zeno.app.PointsExtendDialog$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
    class AnonymousClass1 implements Callback {
        final /* synthetic */ Activity val$activity;
        final /* synthetic */ TextView val$btnConfirm;
        final /* synthetic */ Dialog val$cd;
        final /* synthetic */ String val$deviceId;
        final /* synthetic */ String val$phone;
        final /* synthetic */ String val$token;
        final /* synthetic */ TextView val$tvDesc;
        final /* synthetic */ TextView val$tvNote;
        final /* synthetic */ TextView val$tvQuestion;
        final /* synthetic */ Handler val$uiHandler;

        AnonymousClass1(Handler handler, Dialog dialog, TextView textView, TextView textView2, TextView textView3, TextView textView4, String str, String str2, String str3, Activity activity) {
            this.val$uiHandler = handler;
            this.val$cd = dialog;
            this.val$tvDesc = textView;
            this.val$tvQuestion = textView2;
            this.val$tvNote = textView3;
            this.val$btnConfirm = textView4;
            this.val$phone = str;
            this.val$token = str2;
            this.val$deviceId = str3;
            this.val$activity = activity;
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = this.val$uiHandler;
            final Dialog dialog = this.val$cd;
            final TextView textView = this.val$tvDesc;
            handler.post(new Runnable() { // from class: com.zeno.app.PointsExtendDialog$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    PointsExtendDialog.AnonymousClass1.lambda$onFailure$0(dialog, textView);
                }
            });
        }

        static /* synthetic */ void lambda$onFailure$0(Dialog dialog, TextView textView) {
            if (dialog.isShowing()) {
                textView.setText("Network error. Please try again.");
            }
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            final Handler handler = this.val$uiHandler;
            final Dialog dialog = this.val$cd;
            final TextView textView = this.val$tvDesc;
            final TextView textView2 = this.val$tvQuestion;
            final TextView textView3 = this.val$tvNote;
            final TextView textView4 = this.val$btnConfirm;
            final String str = this.val$phone;
            final String str2 = this.val$token;
            final String str3 = this.val$deviceId;
            final Activity activity = this.val$activity;
            handler.post(new Runnable() { // from class: com.zeno.app.PointsExtendDialog$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m659lambda$onResponse$2$comzenoappPointsExtendDialog$1(dialog, strString, textView, textView2, textView3, textView4, str, str2, str3, handler, activity);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-PointsExtendDialog$1, reason: not valid java name */
        /* synthetic */ void m659lambda$onResponse$2$comzenoappPointsExtendDialog$1(final Dialog dialog, String str, TextView textView, TextView textView2, TextView textView3, final TextView textView4, final String str2, final String str3, final String str4, final Handler handler, final Activity activity) {
            if (dialog.isShowing()) {
                try {
                    JSONObject jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("result");
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("extendInfo") : null;
                    if (jSONObjectOptJSONObject2 == null) {
                        textView.setText("Extend info is unavailable now.");
                        return;
                    }
                    int iOptInt = jSONObjectOptJSONObject2.optInt("currentLimit", jSONObjectOptJSONObject2.optInt("monthlyLimit", 0));
                    int iOptInt2 = jSONObjectOptJSONObject2.optInt("afterLimit", iOptInt);
                    int iOptInt3 = jSONObjectOptJSONObject2.optInt("mainBalanceSpend", 0);
                    int iOptInt4 = jSONObjectOptJSONObject2.optInt("extendRemain", 0);
                    boolean zOptBoolean = jSONObjectOptJSONObject2.optBoolean("canExtend", iOptInt4 > 0);
                    textView.setText(String.format(Locale.getDefault(), "%,d > %,d points", Integer.valueOf(iOptInt), Integer.valueOf(iOptInt2)));
                    textView2.setText(String.format(Locale.getDefault(), "%,d Ks ဖြင့်ထပ်တိုးမည်", Integer.valueOf(iOptInt3)));
                    if (zOptBoolean) {
                        textView3.setText(String.format(Locale.getDefault(), "ဤ လအတွင်း နောက်ထပ် %d ကြိမ်ထပ်တိုးနိုင်ပါသည်။", Integer.valueOf(iOptInt4)));
                        textView4.setEnabled(true);
                        textView4.setAlpha(1.0f);
                    } else {
                        textView3.setText("ဤ လအတွက် ထပ်တိုးခွင့် ကုန်ဆုံးသွားပါပြီ။");
                        textView4.setEnabled(false);
                        textView4.setAlpha(0.5f);
                    }
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsExtendDialog$1$$ExternalSyntheticLambda2
                        @Override // android.view.View.OnClickListener
                        public final void onClick(View view) {
                            this.f$0.m658lambda$onResponse$1$comzenoappPointsExtendDialog$1(textView4, str2, str3, str4, handler, activity, dialog, view);
                        }
                    });
                } catch (Exception unused) {
                    textView.setText("Extend info is unavailable now.");
                }
            }
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-PointsExtendDialog$1, reason: not valid java name */
        /* synthetic */ void m658lambda$onResponse$1$comzenoappPointsExtendDialog$1(TextView textView, String str, String str2, String str3, Handler handler, Activity activity, Dialog dialog, View view) {
            textView.setEnabled(false);
            textView.setAlpha(0.5f);
            ApiClient.extendPoints(str, str2, str3, new C00011(handler, activity, textView, dialog));
        }

        /* JADX INFO: renamed from: com.zeno.app.PointsExtendDialog$1$1, reason: invalid class name and collision with other inner class name */
        class C00011 implements Callback {
            final /* synthetic */ Activity val$activity;
            final /* synthetic */ TextView val$btnConfirm;
            final /* synthetic */ Dialog val$cd;
            final /* synthetic */ Handler val$uiHandler;

            C00011(Handler handler, Activity activity, TextView textView, Dialog dialog) {
                this.val$uiHandler = handler;
                this.val$activity = activity;
                this.val$btnConfirm = textView;
                this.val$cd = dialog;
            }

            public void onFailure(Call call, IOException iOException) {
                Handler handler = this.val$uiHandler;
                final Activity activity = this.val$activity;
                final TextView textView = this.val$btnConfirm;
                handler.post(new Runnable() { // from class: com.zeno.app.PointsExtendDialog$1$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        PointsExtendDialog.AnonymousClass1.C00011.lambda$onFailure$0(activity, textView);
                    }
                });
            }

            static /* synthetic */ void lambda$onFailure$0(Activity activity, TextView textView) {
                Toast.makeText(activity, "Network error. Please try again.", 0).show();
                textView.setEnabled(true);
                textView.setAlpha(1.0f);
            }

            public void onResponse(Call call, Response response) throws IOException {
                final String strString = response.body() != null ? response.body().string() : "{}";
                Handler handler = this.val$uiHandler;
                final Activity activity = this.val$activity;
                final Dialog dialog = this.val$cd;
                final TextView textView = this.val$btnConfirm;
                handler.post(new Runnable() { // from class: com.zeno.app.PointsExtendDialog$1$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        PointsExtendDialog.AnonymousClass1.C00011.lambda$onResponse$1(strString, activity, dialog, textView);
                    }
                });
            }

            static /* synthetic */ void lambda$onResponse$1(String str, Activity activity, Dialog dialog, TextView textView) {
                try {
                    JSONObject jSONObject = new JSONObject(str);
                    String strOptString = jSONObject.optString("errorCode", "");
                    String strOptString2 = jSONObject.optString("message", "Request failed");
                    if ("00000".equals(strOptString) || "00".equals(strOptString)) {
                        Toast.makeText(activity, "Points limit extended!", 0).show();
                        dialog.dismiss();
                    } else {
                        Toast.makeText(activity, strOptString2, 0).show();
                        textView.setEnabled(true);
                        textView.setAlpha(1.0f);
                    }
                } catch (Exception unused) {
                    Toast.makeText(activity, "Request failed", 0).show();
                    textView.setEnabled(true);
                    textView.setAlpha(1.0f);
                }
            }
        }
    }
}
