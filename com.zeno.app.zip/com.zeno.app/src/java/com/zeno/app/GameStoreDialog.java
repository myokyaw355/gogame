package com.zeno.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.android.material.snackbar.Snackbar;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class GameStoreDialog {
    private static final String GAME_BASE = "https://pubapi-mygov2.mtgmm.co/v1/engine";
    private static final String MYTEL_BUY = "https://apis.mytel.com.mm/csm/v1.0/api/vas-package/";
    private static final String MYTEL_PACKS = "https://apis.mytel.com.mm/loyalty/api/v3.1/pack";
    private final Context ctx;
    private Dialog dialog;
    private LinearLayout llStoreError;
    private LinearLayout llStoreLoading;
    private final SessionManager session;
    private LinearLayout[] tabContents;
    private TextView tabIngame;
    private TextView tabOneTime;
    private TextView tabSub;
    private ScrollView[] tabs;
    private TextView tvStoreError;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newCachedThreadPool();
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).followRedirects(true).build();
    private int currentTab = 0;
    private boolean[] tabLoaded = {false, false, false};

    public GameStoreDialog(Context context, SessionManager sessionManager) {
        this.ctx = context;
        this.session = sessionManager;
    }

    public void show() {
        Dialog dialog = new Dialog(this.ctx, android.R.style.Theme.Black.NoTitleBar.Fullscreen);
        this.dialog = dialog;
        dialog.requestWindowFeature(1);
        this.dialog.setCancelable(false);
        this.dialog.setCanceledOnTouchOutside(false);
        this.dialog.setContentView(R.layout.dialog_game_store);
        Window window = this.dialog.getWindow();
        if (window != null) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.clearFlags(2);
            window.addFlags(2);
            window.setDimAmount(0.75f);
        }
        bindViews();
        setupTabs();
        loadTab(0);
        this.dialog.show();
    }

    private void bindViews() {
        this.tabSub = (TextView) this.dialog.findViewById(R.id.tabSub);
        this.tabOneTime = (TextView) this.dialog.findViewById(R.id.tabOneTime);
        this.tabIngame = (TextView) this.dialog.findViewById(R.id.tabIngame);
        this.llStoreLoading = (LinearLayout) this.dialog.findViewById(R.id.llStoreLoading);
        this.llStoreError = (LinearLayout) this.dialog.findViewById(R.id.llStoreError);
        this.tvStoreError = (TextView) this.dialog.findViewById(R.id.tvStoreError);
        this.dialog.findViewById(R.id.btnStoreRetry).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m452lambda$bindViews$0$comzenoappGameStoreDialog(view);
            }
        });
        this.tabs = new ScrollView[]{(ScrollView) this.dialog.findViewById(R.id.svTab0), (ScrollView) this.dialog.findViewById(R.id.svTab1), (ScrollView) this.dialog.findViewById(R.id.svTab2)};
        this.tabContents = new LinearLayout[]{(LinearLayout) this.dialog.findViewById(R.id.llTab0), (LinearLayout) this.dialog.findViewById(R.id.llTab1), (LinearLayout) this.dialog.findViewById(R.id.llTab2)};
    }

    /* JADX INFO: renamed from: lambda$bindViews$0$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m452lambda$bindViews$0$comzenoappGameStoreDialog(View view) {
        boolean[] zArr = this.tabLoaded;
        int i = this.currentTab;
        zArr[i] = false;
        loadTab(i);
    }

    private void setupTabs() {
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m465lambda$setupTabs$1$comzenoappGameStoreDialog(view);
            }
        };
        this.tabSub.setOnClickListener(onClickListener);
        this.tabOneTime.setOnClickListener(onClickListener);
        this.tabIngame.setOnClickListener(onClickListener);
    }

    /* JADX INFO: renamed from: lambda$setupTabs$1$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m465lambda$setupTabs$1$comzenoappGameStoreDialog(View view) {
        if (view == this.tabSub) {
            switchTab(0);
        } else if (view == this.tabOneTime) {
            switchTab(1);
        } else if (view == this.tabIngame) {
            switchTab(2);
        }
    }

    private void switchTab(int i) {
        ScrollView[] scrollViewArr;
        if (i == this.currentTab && this.tabLoaded[i]) {
            return;
        }
        this.currentTab = i;
        int[] iArr = {-6381922, -6381922, -6381922};
        iArr[i] = -1;
        this.tabSub.setTextColor(iArr[0]);
        this.tabOneTime.setTextColor(iArr[1]);
        this.tabIngame.setTextColor(iArr[2]);
        this.tabSub.setBackgroundResource(i == 0 ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);
        this.tabOneTime.setBackgroundResource(i == 1 ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);
        this.tabIngame.setBackgroundResource(i == 2 ? R.drawable.bg_tab_active : R.drawable.bg_tab_inactive);
        int i2 = 0;
        while (true) {
            scrollViewArr = this.tabs;
            if (i2 >= scrollViewArr.length) {
                break;
            }
            scrollViewArr[i2].setVisibility(8);
            i2++;
        }
        if (this.tabLoaded[i]) {
            scrollViewArr[i].setVisibility(0);
            this.llStoreLoading.setVisibility(8);
            this.llStoreError.setVisibility(8);
            return;
        }
        loadTab(i);
    }

    private void loadTab(int i) {
        this.llStoreLoading.setVisibility(0);
        this.llStoreError.setVisibility(8);
        for (ScrollView scrollView : this.tabs) {
            scrollView.setVisibility(8);
        }
        if (i == 0 || i == 1) {
            loadLoyaltyPackages(i);
        } else {
            loadIngamePackages();
        }
    }

    private void loadLoyaltyPackages(final int i) {
        final String phone = this.session.getPhone();
        final String accessToken = this.session.getAccessToken();
        if (!ok(phone)) {
            showError("Phone number not found. Please login again.");
            return;
        }
        final String str = "https://apis.mytel.com.mm/loyalty/api/v3.1/pack?phoneNo=" + encode(phone.replaceAll("^\\+?95", "0"));
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m464lambda$loadLoyaltyPackages$3$comzenoappGameStoreDialog(str, accessToken, i, phone);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadLoyaltyPackages$3$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m464lambda$loadLoyaltyPackages$3$comzenoappGameStoreDialog(String str, String str2, final int i, final String str3) {
        try {
            Request.Builder builderUrl = new Request.Builder().url(str);
            StringBuilder sb = new StringBuilder("Bearer ");
            String str4 = str2;
            if (!ok(str4)) {
                str4 = "";
            }
            sb.append(str4);
            Response responseExecute = this.http.newCall(builderUrl.addHeader("Authorization", sb.toString()).addHeader("Accept", "application/json").addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 10) MytelApp/1.0").build()).execute();
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            responseExecute.close();
            JSONObject jSONObject = new JSONObject(strString);
            String strOptString = jSONObject.optString("errorCode", "");
            if (!"00000".equals(strOptString) && !"0".equals(strOptString)) {
                showError("Packages: " + jSONObject.optString("message", "Load failed"));
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("result");
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
            }
            if (jSONArrayOptJSONArray == null) {
                showError("No packages found");
                return;
            }
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            int i2 = 0;
            while (true) {
                boolean z = true;
                if (i2 >= jSONArrayOptJSONArray.length()) {
                    break;
                }
                JSONObject jSONObject2 = jSONArrayOptJSONArray.getJSONObject(i2);
                String lowerCase = jSONObject2.optString("categoryCode", jSONObject2.optString("category", "")).toLowerCase();
                String lowerCase2 = jSONObject2.optString("vasType", jSONObject2.optString("type", "")).toLowerCase();
                boolean z2 = lowerCase.contains("sub") || lowerCase2.contains("sub") || lowerCase2.contains("recurring");
                if (!lowerCase.contains("one") && !lowerCase.contains("time") && !lowerCase2.contains("onetime") && !lowerCase2.contains("one") && !lowerCase.contains("pay")) {
                    z = false;
                }
                if (z2) {
                    arrayList.add(jSONObject2);
                } else if (z) {
                    arrayList2.add(jSONObject2);
                } else {
                    arrayList.add(jSONObject2);
                }
                i2++;
            }
            if (arrayList.isEmpty() && arrayList2.isEmpty()) {
                for (int i3 = 0; i3 < jSONArrayOptJSONArray.length(); i3++) {
                    arrayList.add(jSONArrayOptJSONArray.getJSONObject(i3));
                }
            }
            ArrayList arrayList3 = i == 0 ? arrayList : arrayList2;
            final boolean zIsEmpty = arrayList3.isEmpty();
            final ArrayList arrayList4 = i == 0 ? arrayList2 : arrayList;
            final int i4 = i == 0 ? 1 : 0;
            final ArrayList arrayList5 = arrayList3;
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m463lambda$loadLoyaltyPackages$2$comzenoappGameStoreDialog(i, zIsEmpty, arrayList5, str3, i4, arrayList4);
                }
            });
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$loadLoyaltyPackages$2$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m463lambda$loadLoyaltyPackages$2$comzenoappGameStoreDialog(int i, boolean z, List list, String str, int i2, List list2) {
        if (this.dialog.isShowing()) {
            this.llStoreLoading.setVisibility(8);
            this.tabContents[i].removeAllViews();
            if (z) {
                addEmptyView(this.tabContents[i], "No packages available");
            } else {
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    addLoyaltyItem(this.tabContents[i], (JSONObject) it.next(), str);
                }
            }
            this.tabs[i].setVisibility(0);
            boolean[] zArr = this.tabLoaded;
            zArr[i] = true;
            if (zArr[i2]) {
                return;
            }
            this.tabContents[i2].removeAllViews();
            if (list2.isEmpty()) {
                addEmptyView(this.tabContents[i2], "No packages available");
            } else {
                Iterator it2 = list2.iterator();
                while (it2.hasNext()) {
                    addLoyaltyItem(this.tabContents[i2], (JSONObject) it2.next(), str);
                }
            }
            this.tabLoaded[i2] = true;
        }
    }

    private void addLoyaltyItem(LinearLayout linearLayout, final JSONObject jSONObject, final String str) {
        final String str2;
        View viewInflate = LayoutInflater.from(this.ctx).inflate(R.layout.item_store_package, (ViewGroup) linearLayout, false);
        String str3 = "";
        final String strOptString = jSONObject.optString("id", jSONObject.optString("packId", jSONObject.optString("rewardId", "")));
        final String strOptString2 = jSONObject.optString("name", jSONObject.optString("packName", jSONObject.optString("rewardName", "Package")));
        final String strOptString3 = jSONObject.optString("vasType", jSONObject.optString("type", ""));
        String lowerCase = jSONObject.optString("categoryCode", "").toLowerCase();
        String strOptString4 = jSONObject.optString("description", "");
        if (!ok(strOptString4)) {
            try {
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("vasDescriptions");
                if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0) {
                    strOptString4 = jSONArrayOptJSONArray.getJSONObject(0).optString("description", "");
                }
            } catch (Exception unused) {
            }
        }
        int iOptInt = jSONObject.optInt("price", jSONObject.optInt("discountedPrice", jSONObject.optInt("amount", 0)));
        if (iOptInt > 0) {
            str2 = formatNumber(iOptInt) + " Ks";
        } else {
            str2 = "---";
        }
        int iOptInt2 = jSONObject.optInt("validityDay", jSONObject.optInt("validity", jSONObject.optInt("days", 0)));
        boolean z = true;
        if (iOptInt2 <= 0) {
            Matcher matcher = Pattern.compile("(\\d+)\\s*(day|d|h|min|month|m)", 2).matcher(strOptString2);
            if (matcher.find()) {
                str3 = matcher.group(1) + matcher.group(2).charAt(0);
            }
        } else if (iOptInt2 >= 30) {
            str3 = (iOptInt2 / 30) + "m";
        } else {
            str3 = iOptInt2 + "d";
        }
        if (!lowerCase.contains("sub") && !strOptString3.toLowerCase().contains("sub")) {
            z = false;
        }
        ((ImageView) viewInflate.findViewById(R.id.ivPackIcon)).setImageResource(z ? R.drawable.ic_package_sub : R.drawable.ic_package_onetime);
        ((TextView) viewInflate.findViewById(R.id.tvPackName)).setText(strOptString2);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPackDesc);
        if (ok(strOptString4) && !strOptString4.equals(strOptString2)) {
            textView.setText(strOptString4);
            textView.setVisibility(0);
        } else {
            textView.setVisibility(8);
        }
        ((TextView) viewInflate.findViewById(R.id.tvPackPrice)).setText(str2);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvPackDuration);
        if (ok(str3)) {
            textView2.setText(str3);
            textView2.setVisibility(0);
        } else {
            textView2.setVisibility(8);
        }
        ((Button) viewInflate.findViewById(R.id.btnBuyPack)).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m451lambda$addLoyaltyItem$4$comzenoappGameStoreDialog(jSONObject, strOptString, strOptString2, str, strOptString3, str2, view);
            }
        });
        linearLayout.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addLoyaltyItem$4$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m451lambda$addLoyaltyItem$4$comzenoappGameStoreDialog(JSONObject jSONObject, String str, String str2, String str3, String str4, String str5, View view) {
        confirmPurchase(jSONObject, str, str2, str3, str4, str5);
    }

    private void confirmPurchase(JSONObject jSONObject, final String str, final String str2, final String str3, final String str4, String str5) {
        showConfirmDialog(str2, "", str5, R.drawable.ic_package_sub, new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m460lambda$confirmPurchase$5$comzenoappGameStoreDialog(str, str3, str4, str2);
            }
        });
    }

    private void showConfirmDialog(String str, String str2, String str3, int i, Runnable runnable) {
        Context context = this.ctx;
        if (!ok(str2)) {
            str2 = null;
        }
        ZDialog.purchase(context, str, str2, str3, runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: buyLoyaltyPackage, reason: merged with bridge method [inline-methods] */
    public void m460lambda$confirmPurchase$5$comzenoappGameStoreDialog(final String str, final String str2, String str3, String str4) {
        final String accessToken = this.session.getAccessToken();
        showBuyLoading(true);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m458lambda$buyLoyaltyPackage$8$comzenoappGameStoreDialog(str2, str, accessToken);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyLoyaltyPackage$8$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m458lambda$buyLoyaltyPackage$8$comzenoappGameStoreDialog(String str, String str2, String str3) {
        try {
            String strReplaceAll = str.replaceAll("^0", "");
            if (!strReplaceAll.startsWith("+")) {
                strReplaceAll = "+95" + strReplaceAll;
            }
            String strSubstring = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            String strValueOf = String.valueOf(System.currentTimeMillis());
            String str4 = MYTEL_BUY + encode(str2) + "/register";
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("msisdn", strReplaceAll);
            jSONObject.put("rewardCode", str2);
            jSONObject.put("requestId", strSubstring);
            jSONObject.put("requestTime", strValueOf);
            Request.Builder builderPost = new Request.Builder().url(str4).post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json")));
            StringBuilder sb = new StringBuilder("Bearer ");
            if (!ok(str3)) {
                str3 = "";
            }
            sb.append(str3);
            Response responseExecute = this.http.newCall(builderPost.addHeader("Authorization", sb.toString()).addHeader("Content-Type", "application/json").addHeader("Accept", "application/json").build()).execute();
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            responseExecute.close();
            JSONObject jSONObject2 = new JSONObject(strString);
            String strOptString = jSONObject2.optString("errorCode", jSONObject2.optString("responseCode", "-1"));
            final String strOptString2 = jSONObject2.optString("message", jSONObject2.optString("responseMessage", "Purchase ".concat(("0".equals(strOptString) || "00000".equals(strOptString)) ? "successful!" : "failed.")));
            final boolean z = "0".equals(strOptString) || "00000".equals(strOptString) || "SUCCESS".equalsIgnoreCase(strOptString);
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m456lambda$buyLoyaltyPackage$6$comzenoappGameStoreDialog(z, strOptString2);
                }
            });
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m457lambda$buyLoyaltyPackage$7$comzenoappGameStoreDialog(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$buyLoyaltyPackage$6$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m456lambda$buyLoyaltyPackage$6$comzenoappGameStoreDialog(boolean z, String str) {
        showBuyLoading(false);
        StringBuilder sb = z ? new StringBuilder("✓ ") : new StringBuilder("✗ ");
        sb.append(str);
        showToast(sb.toString());
        if (z) {
            boolean[] zArr = this.tabLoaded;
            int i = this.currentTab;
            zArr[i] = false;
            loadTab(i);
        }
    }

    /* JADX INFO: renamed from: lambda$buyLoyaltyPackage$7$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m457lambda$buyLoyaltyPackage$7$comzenoappGameStoreDialog(Exception exc) {
        showBuyLoading(false);
        showToast("Network error: " + exc.getMessage());
    }

    private void loadIngamePackages() {
        final String gameToken = this.session.getGameToken();
        if (ok(gameToken)) {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m461lambda$loadIngamePackages$10$comzenoappGameStoreDialog(gameToken);
                }
            });
        } else {
            showError("Not logged in to game. Please start the game first.");
        }
    }

    /* JADX INFO: renamed from: lambda$loadIngamePackages$10$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m461lambda$loadIngamePackages$10$comzenoappGameStoreDialog(final String str) {
        String strString;
        try {
            String[] strArr = {"/store/categories", "/store"};
            int i = 0;
            while (true) {
                if (i >= 2) {
                    strString = null;
                    break;
                }
                Response responseExecute = this.http.newCall(new Request.Builder().url(GAME_BASE + strArr[i]).addHeader("Authorization", "Bearer " + str).addHeader("Accept", "application/json").build()).execute();
                strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
                responseExecute.close();
                if (responseExecute.code() == 200 && strString.contains("[")) {
                    break;
                } else {
                    i++;
                }
            }
            final ArrayList arrayList = new ArrayList();
            String[] strArr2 = {"ActionIngame", "INGAME", "ingame", "cat-ingame", "POWERUP"};
            if (ok(strString)) {
                JSONObject jSONObject = new JSONObject(strString.startsWith("{") ? strString : "{\"data\":" + strString + "}");
                JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = jSONObject.optJSONArray("categories");
                }
                if (jSONArrayOptJSONArray == null && strString.startsWith("[")) {
                    jSONArrayOptJSONArray = new JSONArray(strString);
                }
                if (jSONArrayOptJSONArray != null) {
                    for (int i2 = 0; i2 < jSONArrayOptJSONArray.length(); i2++) {
                        JSONObject jSONObject2 = jSONArrayOptJSONArray.getJSONObject(i2);
                        String strFetchCategoryItems = fetchCategoryItems(str, jSONObject2.optString("id", jSONObject2.optString("categoryId", jSONObject2.optString("code", ""))));
                        if (ok(strFetchCategoryItems)) {
                            parseCategoryItems(strFetchCategoryItems, arrayList);
                        }
                    }
                }
            }
            if (arrayList.isEmpty()) {
                for (int i3 = 0; i3 < 5; i3++) {
                    String strFetchCategoryItems2 = fetchCategoryItems(str, strArr2[i3]);
                    if (ok(strFetchCategoryItems2)) {
                        parseCategoryItems(strFetchCategoryItems2, arrayList);
                        if (!arrayList.isEmpty()) {
                            break;
                        }
                    }
                }
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m462lambda$loadIngamePackages$9$comzenoappGameStoreDialog(arrayList, str);
                }
            });
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$loadIngamePackages$9$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m462lambda$loadIngamePackages$9$comzenoappGameStoreDialog(List list, String str) {
        if (this.dialog.isShowing()) {
            this.llStoreLoading.setVisibility(8);
            this.tabContents[2].removeAllViews();
            if (list.isEmpty()) {
                addEmptyView(this.tabContents[2], "No ingame packages available");
            } else {
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    addIngameItem(this.tabContents[2], (JSONObject) it.next(), str);
                }
            }
            this.tabs[2].setVisibility(0);
            this.tabLoaded[2] = true;
        }
    }

    private String fetchCategoryItems(String str, String str2) {
        try {
            String[] strArr = {"https://pubapi-mygov2.mtgmm.co/v1/engine/store/category/" + str2, "https://pubapi-mygov2.mtgmm.co/v1/engine/store/" + str2};
            for (int i = 0; i < 2; i++) {
                Response responseExecute = this.http.newCall(new Request.Builder().url(strArr[i]).addHeader("Authorization", "Bearer " + str).addHeader("Accept", "application/json").build()).execute();
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                responseExecute.close();
                if (responseExecute.code() == 200 && ok(strString)) {
                    return strString;
                }
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    private void parseCategoryItems(String str, List<JSONObject> list) {
        try {
            JSONObject jSONObject = new JSONObject(str.startsWith("{") ? str : "{\"data\":" + str + "}");
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = jSONObject.optJSONArray("items");
            }
            if (jSONArrayOptJSONArray == null && str.startsWith("[")) {
                jSONArrayOptJSONArray = new JSONArray(str);
            }
            if (jSONArrayOptJSONArray != null) {
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    list.add(jSONArrayOptJSONArray.getJSONObject(i));
                }
            }
        } catch (Exception unused) {
        }
    }

    private void addIngameItem(LinearLayout linearLayout, JSONObject jSONObject, final String str) {
        String str2;
        View viewInflate = LayoutInflater.from(this.ctx).inflate(R.layout.item_store_package, (ViewGroup) linearLayout, false);
        final String strOptString = jSONObject.optString("id", jSONObject.optString("itemId", ""));
        final String strOptString2 = jSONObject.optString("name", jSONObject.optString("itemName", jSONObject.optString("title", "Item")));
        String strOptString3 = jSONObject.optString("description", jSONObject.optString("desc", ""));
        int iOptInt = jSONObject.optInt("price", jSONObject.optInt("cost", jSONObject.optInt("amount", 0)));
        String strOptString4 = jSONObject.optString("currency", jSONObject.optString("priceType", jSONObject.optString("walletType", "TURN")));
        if (iOptInt > 0) {
            str2 = iOptInt + " " + strOptString4;
        } else {
            str2 = "Free";
        }
        final String str3 = str2;
        ((ImageView) viewInflate.findViewById(R.id.ivPackIcon)).setImageResource(R.drawable.ic_package_ingame);
        ((TextView) viewInflate.findViewById(R.id.tvPackName)).setText(strOptString2);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPackDesc);
        if (!ok(strOptString3) || strOptString3.equals(strOptString2)) {
            textView.setVisibility(8);
        } else {
            textView.setText(strOptString3);
            textView.setVisibility(0);
        }
        ((TextView) viewInflate.findViewById(R.id.tvPackPrice)).setText(str3);
        viewInflate.findViewById(R.id.tvPackDuration).setVisibility(8);
        ((Button) viewInflate.findViewById(R.id.btnBuyPack)).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda14
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m450lambda$addIngameItem$11$comzenoappGameStoreDialog(strOptString, strOptString2, str3, str, view);
            }
        });
        linearLayout.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addIngameItem$11$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m450lambda$addIngameItem$11$comzenoappGameStoreDialog(String str, String str2, String str3, String str4, View view) {
        confirmIngamePurchase(str, str2, str3, str4);
    }

    private void confirmIngamePurchase(final String str, String str2, String str3, final String str4) {
        showConfirmDialog(str2, "", str3, R.drawable.ic_package_ingame, new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m459lambda$confirmIngamePurchase$12$comzenoappGameStoreDialog(str, str4);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: buyIngameItem, reason: merged with bridge method [inline-methods] */
    public void m459lambda$confirmIngamePurchase$12$comzenoappGameStoreDialog(final String str, final String str2) {
        showBuyLoading(true);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m455lambda$buyIngameItem$15$comzenoappGameStoreDialog(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyIngameItem$15$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m455lambda$buyIngameItem$15$comzenoappGameStoreDialog(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("id", str);
            jSONObject.put("itemId", str);
            final boolean z = false;
            String[] strArr = {"https://pubapi-mygov2.mtgmm.co/v1/engine/store/buy", "https://pubapi-mygov2.mtgmm.co/v1/engine/store/purchase"};
            String str3 = "{}";
            int i = 0;
            while (true) {
                if (i >= 2) {
                    break;
                }
                Response responseExecute = this.http.newCall(new Request.Builder().url(strArr[i]).post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("Authorization", "Bearer " + str2).addHeader("Content-Type", "application/json").addHeader("Accept", "application/json").build()).execute();
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
                int iCode = responseExecute.code();
                responseExecute.close();
                if (iCode == 200) {
                    str3 = strString;
                    break;
                } else {
                    i++;
                    str3 = strString;
                }
            }
            JSONObject jSONObject2 = new JSONObject(str3);
            final String strOptString = jSONObject2.optString("message", "Purchase complete");
            if (jSONObject2.isNull("error") && !jSONObject2.has("error_code")) {
                z = true;
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m453lambda$buyIngameItem$13$comzenoappGameStoreDialog(z, strOptString);
                }
            });
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m454lambda$buyIngameItem$14$comzenoappGameStoreDialog(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$buyIngameItem$13$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m453lambda$buyIngameItem$13$comzenoappGameStoreDialog(boolean z, String str) {
        showBuyLoading(false);
        StringBuilder sb = z ? new StringBuilder("✓ ") : new StringBuilder("✗ ");
        sb.append(str);
        showToast(sb.toString());
    }

    /* JADX INFO: renamed from: lambda$buyIngameItem$14$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m454lambda$buyIngameItem$14$comzenoappGameStoreDialog(Exception exc) {
        showBuyLoading(false);
        showToast("Error: " + exc.getMessage());
    }

    private void showError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreDialog$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m466lambda$showError$16$comzenoappGameStoreDialog(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$16$com-zeno-app-GameStoreDialog, reason: not valid java name */
    /* synthetic */ void m466lambda$showError$16$comzenoappGameStoreDialog(String str) {
        this.llStoreLoading.setVisibility(8);
        for (ScrollView scrollView : this.tabs) {
            scrollView.setVisibility(8);
        }
        this.tvStoreError.setText(str);
        this.llStoreError.setVisibility(0);
    }

    private void showBuyLoading(boolean z) {
        this.llStoreLoading.setVisibility(z ? 0 : 8);
    }

    private void addEmptyView(LinearLayout linearLayout, String str) {
        TextView textView = new TextView(this.ctx);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setGravity(17);
        textView.setPadding(24, 60, 24, 60);
        linearLayout.addView(textView);
    }

    private void showToast(String str) {
        Dialog dialog = this.dialog;
        if (dialog == null || !dialog.isShowing() || this.dialog.getWindow() == null) {
            return;
        }
        Snackbar snackbarMake = ZSnack.make(this.dialog.getWindow().getDecorView(), str, 0);
        snackbarMake.getView().setBackgroundColor(-13487566);
        snackbarMake.show();
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private String encode(String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        } catch (Exception unused) {
            return str;
        }
    }

    private String formatNumber(int i) {
        return String.format("%,d", Integer.valueOf(i));
    }
}
