package com.zeno.app;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import java.net.URLDecoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class KongIslandService extends Service {
    private static final String[] ALL_MAPS = {"62;7;57", "22;34;20", "78;10;42", "82;46;54", "16;55;3", "6;38;32", "69;50;28", "28;81;75", "47;11;61", "31;39;69", "4;60;55", "59;81;78", "26;81;10", "17;39;62"};
    private static final int BANANAS_TICK = 3;
    private static final long BANANA_MS = 30;
    private static final long BANANA_STALL_MS = 12000;
    static final String BASE = "https://kong.mascom.vn";
    private static final long BETWEEN_GAMES_MS = 5000;
    private static final long GAME_MS = 600000;
    private static final long PROBE_DONE_MS = 3000;
    private static final long RECONNECT_DELAY_MS = 1500;
    private static final long SEGMENT_MS = 4000;
    private static final String START_DATA = "ZbZH3MS3Hdgv6nBzZPOdM07+y9xKB3RF54XeWY4VygUDD4AOykAwXfjylRy/kbT5knHNtqbPjQSiMPszBpB4Ug==";
    private static final String TAG = "KongIslandSvc";
    private static final String WS_BASE = "wss://kong.mascom.vn/api/ws/game";
    private static final long X2_REFRESH_MS = 10000;
    static volatile KongIslandService instance;
    private ScheduledFuture<?> bananaFuture;
    private ExecutorService exec;
    private ScheduledFuture<?> logFuture;
    private ScheduledExecutorService sched;
    private ScheduledFuture<?> segmentFuture;
    private SessionManager session;
    private ScheduledFuture<?> stallWatchFuture;
    private PowerManager.WakeLock wakeLock;
    private ScheduledFuture<?> x2Future;
    private volatile long currentGameMs = GAME_MS;
    private final IBinder binder = new ServiceBinder();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(BANANA_MS, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).writeTimeout(BANANA_MS, TimeUnit.SECONDS).pingInterval(20, TimeUnit.SECONDS).retryOnConnectionFailure(true).build();
    volatile String kongToken = null;
    volatile String boundPhone = null;
    volatile boolean running = false;
    volatile boolean stopping = false;
    volatile boolean alwaysLoop = false;
    volatile int totalBanana = 0;
    volatile int totalTickets = 0;
    volatile int totalBoxes = 0;
    volatile int total2xBanana = 0;
    private volatile long serverTotal = 0;
    private volatile long serverMax = 0;
    private volatile long totalAllowed = 0;
    private volatile long bananaBaseline = 0;
    private volatile int mapIdx = 0;
    private volatile boolean probing = true;
    volatile int currentGame = 0;
    volatile int totalGames = 0;
    volatile long gameStartMs = 0;
    volatile long sessionStartMs = 0;
    volatile long sessionBanana = 0;
    private volatile WebSocket activeWs = null;
    private volatile long lastBananaAckMs = 0;
    private volatile GameCallback callback = null;

    public interface GameCallback {
        void onBananaProgress(long j);

        void onMessage(String str);

        void onOpenBoxResult(String str, int i);

        void onProfileUpdated(String str, String str2, String str3);

        void onSessionEnded(long j, int i);

        void onStateChanged(boolean z, int i, int i2, long j, long j2, long j3);

        void onStatsChanged(int i, int i2, int i3, int i4);
    }

    private void acquireWakeLock() {
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        return 2;
    }

    static /* synthetic */ long access$814(KongIslandService kongIslandService, long j) {
        long j2 = kongIslandService.totalAllowed + j;
        kongIslandService.totalAllowed = j2;
        return j2;
    }

    public class ServiceBinder extends Binder {
        public ServiceBinder() {
        }

        public KongIslandService getService() {
            return KongIslandService.this;
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        instance = this;
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
        this.sched = Executors.newScheduledThreadPool(4);
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.binder;
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        this.stopping = true;
        releaseWakeLock();
        cancelScheduled();
        closeWs();
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
        ScheduledExecutorService scheduledExecutorService = this.sched;
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdownNow();
        }
    }

    public void setCallback(GameCallback gameCallback) {
        this.callback = gameCallback;
    }

    public void clearCallback() {
        this.callback = null;
    }

    public boolean isRunning() {
        return this.running;
    }

    public boolean isAlwaysLoop() {
        return this.alwaysLoop;
    }

    public int getCurrentGame() {
        return this.currentGame;
    }

    public int getTotalGames() {
        return this.totalGames;
    }

    public long getGameStartMs() {
        return this.gameStartMs;
    }

    public long getCurrentGameMs() {
        return this.currentGameMs;
    }

    public long getSessionStartMs() {
        return this.sessionStartMs;
    }

    public long getSessionBanana() {
        return this.sessionBanana;
    }

    public int getTotalBanana() {
        return this.totalBanana;
    }

    public int getTotalTickets() {
        return this.totalTickets;
    }

    public int getTotalBoxes() {
        return this.totalBoxes;
    }

    public int getTotal2xBanana() {
        return this.total2xBanana;
    }

    public String getKongToken() {
        return this.kongToken;
    }

    public void adjust2xBanana(int i) {
        int i2 = this.total2xBanana + i;
        if (i2 < 0) {
            i2 = 0;
        }
        this.total2xBanana = i2;
        notifyStatsChanged();
    }

    public void setTotal2xBanana(int i) {
        this.total2xBanana = Math.max(0, i);
        notifyStatsChanged();
    }

    public void startPlay(int i) {
        startPlay(i, false);
    }

    public void startPlay(int i, boolean z) {
        if (this.running) {
            return;
        }
        if (!ok(this.kongToken)) {
            notifyMessage("ဝင်ရောက်မှုမရှိပါ။ ထပ်ဆောင်း Refresh ပြုလုပ်ပါ");
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.initLoad();
                }
            });
            return;
        }
        this.running = true;
        this.stopping = false;
        this.alwaysLoop = z;
        if (z) {
            i = Integer.MAX_VALUE;
        }
        this.totalGames = i;
        this.currentGame = 0;
        this.sessionBanana = 0L;
        this.sessionStartMs = System.currentTimeMillis();
        this.gameStartMs = this.sessionStartMs;
        acquireWakeLock();
        notifyStateChanged();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.playLoop();
            }
        });
    }

    public void stopPlay() {
        this.stopping = true;
        this.running = false;
        releaseWakeLock();
        cancelScheduled();
        final WebSocket webSocket = this.activeWs;
        this.activeWs = null;
        notifyStateChanged();
        if (webSocket != null) {
            wsend(webSocket, "{\"type\":\"END_GAME\",\"payload\":{\"complete\":true}}");
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m571lambda$stopPlay$0$comzenoappKongIslandService(webSocket);
                }
            });
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m572lambda$stopPlay$1$comzenoappKongIslandService();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$stopPlay$0$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m571lambda$stopPlay$0$comzenoappKongIslandService(WebSocket webSocket) {
        sleep(SEGMENT_MS);
        try {
            webSocket.close(1000, (String) null);
        } catch (Exception unused) {
        }
        if (ok(this.kongToken)) {
            fetchUserInfo(this.kongToken);
        }
    }

    /* JADX INFO: renamed from: lambda$stopPlay$1$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m572lambda$stopPlay$1$comzenoappKongIslandService() {
        if (ok(this.kongToken)) {
            fetchUserInfo(this.kongToken);
        }
    }

    public void openBox(int i) {
        if (!ok(this.kongToken) || this.totalBoxes <= 0 || i <= 0) {
            return;
        }
        final int iMin = Math.min(i, this.totalBoxes);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m567lambda$openBox$3$comzenoappKongIslandService(iMin);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$openBox$3$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m567lambda$openBox$3$comzenoappKongIslandService(final int i) {
        HttpResult req = getReq("https://kong.mascom.vn/api/event/open/" + i, this.kongToken);
        fetchUserInfo(this.kongToken);
        final String str = req != null ? req.body : "";
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m566lambda$openBox$2$comzenoappKongIslandService(str, i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$openBox$2$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m566lambda$openBox$2$comzenoappKongIslandService(String str, int i) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onOpenBoxResult(str, i);
        }
    }

    public void initLoad() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m562lambda$initLoad$4$comzenoappKongIslandService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$initLoad$4$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m562lambda$initLoad$4$comzenoappKongIslandService() {
        SessionManager sessionManager = this.session;
        this.boundPhone = sessionManager != null ? sessionManager.getPhone() : null;
        this.kongToken = resolveKongToken();
        if (ok(this.kongToken)) {
            fetchUserInfo(this.kongToken);
        }
    }

    public void clearInMemorySession() {
        this.kongToken = null;
        this.boundPhone = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playLoop() {
        int i = 0;
        while (true) {
            if (this.stopping || (!this.alwaysLoop && i >= this.totalGames)) {
                break;
            }
            if (ok(this.kongToken)) {
                try {
                    fetchUserInfo(this.kongToken);
                } catch (Exception unused) {
                }
            }
            if (this.totalTickets <= 0) {
                Log.i(TAG, "No tickets left — ending play loop");
                notifyMessage("ကစားကြိမ်ကုန်ပါပြီ");
                break;
            }
            int i2 = i + 1;
            this.currentGame = i2;
            this.gameStartMs = System.currentTimeMillis();
            notifyStateChanged();
            playOneGame(i2);
            cancelScheduled();
            closeWs();
            boolean z = this.alwaysLoop || i2 < this.totalGames;
            if (!this.stopping && z) {
                StringBuilder sb = new StringBuilder("Between games ");
                sb.append(i2);
                sb.append("→");
                sb.append(i + 2);
                sb.append(this.alwaysLoop ? " (loop)" : "");
                sb.append(" sleep 5000ms");
                Log.d(TAG, sb.toString());
                sleep(BETWEEN_GAMES_MS);
            }
            i = i2;
        }
        this.alwaysLoop = false;
        if (!this.stopping) {
            final long j = this.sessionBanana;
            final int i3 = this.currentGame;
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m569lambda$playLoop$6$comzenoappKongIslandService(j, i3);
                }
            });
            return;
        }
        this.alwaysLoop = false;
    }

    /* JADX INFO: renamed from: lambda$playLoop$6$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m569lambda$playLoop$6$comzenoappKongIslandService(long j, int i) {
        this.running = false;
        notifyStateChanged();
        notifySessionEnded(j, i);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m568lambda$playLoop$5$comzenoappKongIslandService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$playLoop$5$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m568lambda$playLoop$5$comzenoappKongIslandService() {
        if (ok(this.kongToken)) {
            fetchUserInfo(this.kongToken);
        }
    }

    private void playOneGame(int i) {
        this.gameStartMs = System.currentTimeMillis();
        long j = this.gameStartMs + this.currentGameMs;
        this.serverTotal = 0L;
        this.serverMax = 0L;
        this.totalAllowed = 0L;
        this.bananaBaseline = 0L;
        this.probing = true;
        this.mapIdx = ALL_MAPS.length;
        this.lastBananaAckMs = System.currentTimeMillis();
        int i2 = 0;
        while (!this.stopping && System.currentTimeMillis() < j) {
            i2++;
            long jCurrentTimeMillis = j - System.currentTimeMillis();
            if (jCurrentTimeMillis < 2000) {
                break;
            }
            if (i2 > 1) {
                this.bananaBaseline = Math.max(this.bananaBaseline, this.serverTotal);
            }
            Log.d(TAG, "[Game #" + i + "] WS attempt " + i2 + " remain=" + (jCurrentTimeMillis / 1000) + "s baseline=" + this.bananaBaseline);
            if (runGameWebSocket(i, j, i2 > 1) || this.stopping) {
                break;
            }
            cancelScheduled();
            closeWs();
            sleep(RECONNECT_DELAY_MS);
        }
        cancelScheduled();
        closeWs();
    }

    private boolean runGameWebSocket(int i, long j, boolean z) {
        Object obj = new Object();
        boolean[] zArr = {false};
        boolean[] zArr2 = {false};
        boolean[] zArr3 = {false};
        this.activeWs = this.http.newWebSocket(new Request.Builder().url("wss://kong.mascom.vn/api/ws/game?authToken=" + this.kongToken).addHeader("Origin", BASE).addHeader("User-Agent", "Mozilla/5.0").build(), new AnonymousClass1(zArr, zArr3, obj, j, zArr2, i));
        synchronized (obj) {
            while (!zArr[0] && !this.stopping) {
                long jCurrentTimeMillis = (j + 30000) - System.currentTimeMillis();
                if (jCurrentTimeMillis <= 0) {
                    break;
                }
                try {
                    obj.wait(Math.min(jCurrentTimeMillis, 1000L));
                } catch (InterruptedException unused) {
                }
            }
        }
        cancelScheduled();
        closeWs();
        return zArr2[0] && !zArr3[0];
    }

    /* JADX INFO: renamed from: com.zeno.app.KongIslandService$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
    class AnonymousClass1 extends WebSocketListener {
        final /* synthetic */ long val$gameDeadline;
        final /* synthetic */ boolean[] val$gameDone;
        final /* synthetic */ Object val$gameLock;
        final /* synthetic */ int val$gameNum;
        final /* synthetic */ boolean[] val$naturalEnd;
        final /* synthetic */ boolean[] val$needReconnect;

        AnonymousClass1(boolean[] zArr, boolean[] zArr2, Object obj, long j, boolean[] zArr3, int i) {
            this.val$gameDone = zArr;
            this.val$needReconnect = zArr2;
            this.val$gameLock = obj;
            this.val$gameDeadline = j;
            this.val$naturalEnd = zArr3;
            this.val$gameNum = i;
        }

        public void onOpen(final WebSocket webSocket, Response response) {
            KongIslandService.this.lastBananaAckMs = System.currentTimeMillis();
            KongIslandService.this.wsend(webSocket, "{\"type\":\"START_GAME\",\"payload\":{\"data\":\"ZbZH3MS3Hdgv6nBzZPOdM07+y9xKB3RF54XeWY4VygUDD4AOykAwXfjylRy/kbT5knHNtqbPjQSiMPszBpB4Ug==\",\"lang\":\"my\"}}");
            KongIslandService.this.useX2BananaItem(webSocket);
            if (KongIslandService.this.x2Future != null) {
                KongIslandService.this.x2Future.cancel(false);
            }
            KongIslandService kongIslandService = KongIslandService.this;
            ScheduledExecutorService scheduledExecutorService = kongIslandService.sched;
            final boolean[] zArr = this.val$gameDone;
            kongIslandService.x2Future = scheduledExecutorService.scheduleAtFixedRate(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m574lambda$onOpen$0$comzenoappKongIslandService$1(zArr, webSocket);
                }
            }, KongIslandService.X2_REFRESH_MS, KongIslandService.X2_REFRESH_MS, TimeUnit.MILLISECONDS);
            if (KongIslandService.this.bananaFuture != null) {
                KongIslandService.this.bananaFuture.cancel(false);
            }
            KongIslandService kongIslandService2 = KongIslandService.this;
            ScheduledExecutorService scheduledExecutorService2 = kongIslandService2.sched;
            final boolean[] zArr2 = this.val$gameDone;
            final boolean[] zArr3 = this.val$needReconnect;
            final Object obj = this.val$gameLock;
            kongIslandService2.bananaFuture = scheduledExecutorService2.scheduleAtFixedRate(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m575lambda$onOpen$1$comzenoappKongIslandService$1(zArr2, webSocket, zArr3, obj);
                }
            }, 0L, KongIslandService.BANANA_MS, TimeUnit.MILLISECONDS);
            if (KongIslandService.this.stallWatchFuture != null) {
                KongIslandService.this.stallWatchFuture.cancel(false);
            }
            KongIslandService kongIslandService3 = KongIslandService.this;
            ScheduledExecutorService scheduledExecutorService3 = kongIslandService3.sched;
            final boolean[] zArr4 = this.val$gameDone;
            final boolean[] zArr5 = this.val$needReconnect;
            final Object obj2 = this.val$gameLock;
            kongIslandService3.stallWatchFuture = scheduledExecutorService3.scheduleAtFixedRate(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m576lambda$onOpen$2$comzenoappKongIslandService$1(zArr4, zArr5, webSocket, obj2);
                }
            }, KongIslandService.BANANA_STALL_MS, KongIslandService.PROBE_DONE_MS, TimeUnit.MILLISECONDS);
            for (int i = 0; i < KongIslandService.ALL_MAPS.length; i++) {
                final String str = KongIslandService.ALL_MAPS[i];
                ScheduledExecutorService scheduledExecutorService4 = KongIslandService.this.sched;
                final boolean[] zArr6 = this.val$gameDone;
                scheduledExecutorService4.schedule(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m577lambda$onOpen$3$comzenoappKongIslandService$1(zArr6, webSocket, str);
                    }
                }, (((long) i) * 100) + 100, TimeUnit.MILLISECONDS);
            }
            ScheduledExecutorService scheduledExecutorService5 = KongIslandService.this.sched;
            final boolean[] zArr7 = this.val$gameDone;
            scheduledExecutorService5.schedule(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m578lambda$onOpen$4$comzenoappKongIslandService$1(zArr7, webSocket);
                }
            }, KongIslandService.PROBE_DONE_MS, TimeUnit.MILLISECONDS);
            long jMax = Math.max(500L, this.val$gameDeadline - System.currentTimeMillis());
            ScheduledExecutorService scheduledExecutorService6 = KongIslandService.this.sched;
            final boolean[] zArr8 = this.val$gameDone;
            final boolean[] zArr9 = this.val$naturalEnd;
            final Object obj3 = this.val$gameLock;
            scheduledExecutorService6.schedule(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m580lambda$onOpen$6$comzenoappKongIslandService$1(zArr8, zArr9, webSocket, obj3);
                }
            }, jMax, TimeUnit.MILLISECONDS);
        }

        /* JADX INFO: renamed from: lambda$onOpen$0$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m574lambda$onOpen$0$comzenoappKongIslandService$1(boolean[] zArr, WebSocket webSocket) {
            if (KongIslandService.this.stopping || zArr[0]) {
                return;
            }
            KongIslandService.this.useX2BananaItem(webSocket);
        }

        /* JADX INFO: renamed from: lambda$onOpen$1$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m575lambda$onOpen$1$comzenoappKongIslandService$1(boolean[] zArr, WebSocket webSocket, boolean[] zArr2, Object obj) {
            if (KongIslandService.this.stopping || zArr[0]) {
                return;
            }
            for (int i = 0; i < KongIslandService.BANANAS_TICK; i++) {
                long jCurrentTimeMillis = System.currentTimeMillis() / 1000;
                if (!KongIslandService.this.wsend(webSocket, "{\"type\":\"BANANA_COLLECTED\",\"timestamp\":" + jCurrentTimeMillis + "}")) {
                    Log.w(KongIslandService.TAG, "BANANA send failed — reconnect");
                    zArr2[0] = true;
                    KongIslandService.this.cancelBananaSeg();
                    try {
                        webSocket.close(1000, "send-fail");
                    } catch (Exception unused) {
                    }
                    synchronized (obj) {
                        zArr[0] = true;
                        obj.notifyAll();
                    }
                    return;
                }
            }
        }

        /* JADX INFO: renamed from: lambda$onOpen$2$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m576lambda$onOpen$2$comzenoappKongIslandService$1(boolean[] zArr, boolean[] zArr2, WebSocket webSocket, Object obj) {
            if (KongIslandService.this.stopping || zArr[0]) {
                return;
            }
            long jCurrentTimeMillis = System.currentTimeMillis() - KongIslandService.this.lastBananaAckMs;
            if (jCurrentTimeMillis >= KongIslandService.BANANA_STALL_MS) {
                Log.w(KongIslandService.TAG, "Banana stalled " + (jCurrentTimeMillis / 1000) + "s — reconnect");
                zArr2[0] = true;
                KongIslandService.this.cancelBananaSeg();
                try {
                    webSocket.close(1000, "stall");
                } catch (Exception unused) {
                }
                synchronized (obj) {
                    zArr[0] = true;
                    obj.notifyAll();
                }
            }
        }

        /* JADX INFO: renamed from: lambda$onOpen$3$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m577lambda$onOpen$3$comzenoappKongIslandService$1(boolean[] zArr, WebSocket webSocket, String str) {
            if (KongIslandService.this.stopping || zArr[0]) {
                return;
            }
            long jCurrentTimeMillis = System.currentTimeMillis() / 1000;
            KongIslandService.this.wsend(webSocket, "{\"type\":\"GROUND_SELECTED\",\"payload\":{\"mapList\":\"" + str + "\",\"timestamp\":" + jCurrentTimeMillis + "}}");
        }

        /* JADX INFO: renamed from: lambda$onOpen$4$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m578lambda$onOpen$4$comzenoappKongIslandService$1(boolean[] zArr, WebSocket webSocket) {
            if (KongIslandService.this.stopping || zArr[0]) {
                return;
            }
            KongIslandService.this.probing = false;
            KongIslandService.this.startBotLoop(webSocket, zArr);
        }

        /* JADX INFO: renamed from: lambda$onOpen$6$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m580lambda$onOpen$6$comzenoappKongIslandService$1(final boolean[] zArr, boolean[] zArr2, final WebSocket webSocket, final Object obj) {
            if (zArr[0]) {
                return;
            }
            zArr2[0] = true;
            KongIslandService.this.wsend(webSocket, "{\"type\":\"END_GAME\",\"payload\":{\"complete\":true}}");
            KongIslandService.this.sched.schedule(new Runnable() { // from class: com.zeno.app.KongIslandService$1$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m579lambda$onOpen$5$comzenoappKongIslandService$1(webSocket, obj, zArr);
                }
            }, KongIslandService.BETWEEN_GAMES_MS, TimeUnit.MILLISECONDS);
        }

        /* JADX INFO: renamed from: lambda$onOpen$5$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m579lambda$onOpen$5$comzenoappKongIslandService$1(WebSocket webSocket, Object obj, boolean[] zArr) {
            KongIslandService.this.cancelScheduled();
            try {
                webSocket.close(1000, (String) null);
            } catch (Exception unused) {
            }
            synchronized (obj) {
                zArr[0] = true;
                obj.notifyAll();
            }
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0053  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void onMessage(okhttp3.WebSocket r12, java.lang.String r13) {
            /*
                Method dump skipped, instruction units count: 354
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.KongIslandService.AnonymousClass1.onMessage(okhttp3.WebSocket, java.lang.String):void");
        }

        /* JADX INFO: renamed from: lambda$onMessage$7$com-zeno-app-KongIslandService$1, reason: not valid java name */
        /* synthetic */ void m573lambda$onMessage$7$comzenoappKongIslandService$1(long j) {
            GameCallback gameCallback = KongIslandService.this.callback;
            if (gameCallback != null) {
                gameCallback.onBananaProgress(j);
            }
        }

        public void onFailure(WebSocket webSocket, Throwable th, Response response) {
            StringBuilder sb = new StringBuilder("WS failure: ");
            sb.append(th != null ? th.getMessage() : "null");
            Log.w(KongIslandService.TAG, sb.toString());
            if (!this.val$naturalEnd[0] && System.currentTimeMillis() < this.val$gameDeadline - 2000) {
                this.val$needReconnect[0] = true;
            } else {
                this.val$naturalEnd[0] = true;
            }
            KongIslandService.this.cancelScheduled();
            synchronized (this.val$gameLock) {
                this.val$gameDone[0] = true;
                this.val$gameLock.notifyAll();
            }
        }

        public void onClosed(WebSocket webSocket, int i, String str) {
            if (this.val$gameDone[0]) {
                return;
            }
            if (!this.val$naturalEnd[0] && System.currentTimeMillis() < this.val$gameDeadline - 2000) {
                this.val$needReconnect[0] = true;
            }
            KongIslandService.this.cancelScheduled();
            synchronized (this.val$gameLock) {
                this.val$gameDone[0] = true;
                this.val$gameLock.notifyAll();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startBotLoop(final WebSocket webSocket, final boolean[] zArr) {
        ScheduledFuture<?> scheduledFuture = this.segmentFuture;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(false);
        }
        this.segmentFuture = this.sched.scheduleAtFixedRate(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m570lambda$startBotLoop$7$comzenoappKongIslandService(zArr, webSocket);
            }
        }, SEGMENT_MS, SEGMENT_MS, TimeUnit.MILLISECONDS);
    }

    /* JADX INFO: renamed from: lambda$startBotLoop$7$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m570lambda$startBotLoop$7$comzenoappKongIslandService(boolean[] zArr, WebSocket webSocket) {
        if (this.stopping || zArr[0]) {
            return;
        }
        String[] strArr = ALL_MAPS;
        String str = strArr[this.mapIdx % strArr.length];
        this.mapIdx++;
        wsend(webSocket, "{\"type\":\"GROUND_SELECTED\",\"payload\":{\"mapList\":\"" + str + "\",\"timestamp\":" + (System.currentTimeMillis() / 1000) + "}}");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelBananaSeg() {
        ScheduledFuture<?> scheduledFuture = this.bananaFuture;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(false);
            this.bananaFuture = null;
        }
        ScheduledFuture<?> scheduledFuture2 = this.segmentFuture;
        if (scheduledFuture2 != null) {
            scheduledFuture2.cancel(false);
            this.segmentFuture = null;
        }
        ScheduledFuture<?> scheduledFuture3 = this.x2Future;
        if (scheduledFuture3 != null) {
            scheduledFuture3.cancel(false);
            this.x2Future = null;
        }
        ScheduledFuture<?> scheduledFuture4 = this.stallWatchFuture;
        if (scheduledFuture4 != null) {
            scheduledFuture4.cancel(false);
            this.stallWatchFuture = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cancelScheduled() {
        cancelBananaSeg();
        ScheduledFuture<?> scheduledFuture = this.logFuture;
        if (scheduledFuture != null) {
            scheduledFuture.cancel(false);
            this.logFuture = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean wsend(WebSocket webSocket, String str) {
        if (webSocket == null) {
            return false;
        }
        try {
            return webSocket.send(str);
        } catch (Exception e) {
            Log.w(TAG, "wsend: " + e.getMessage());
            return false;
        }
    }

    private void closeWs() {
        WebSocket webSocket = this.activeWs;
        this.activeWs = null;
        if (webSocket == null) {
            return;
        }
        try {
            webSocket.send("{\"type\":\"END_GAME\",\"payload\":{\"complete\":true}}");
        } catch (Exception unused) {
        }
        try {
            webSocket.close(1000, (String) null);
        } catch (Exception unused2) {
        }
        sleep(400L);
    }

    String resolveKongToken() {
        HttpResult req;
        String kongToken = this.session.getKongToken();
        if (ok(kongToken)) {
            String kongPlayerPhone = this.session.getKongPlayerPhone();
            String phone = this.session.getPhone();
            if (ok(kongPlayerPhone) && ok(phone) && !kongPlayerPhone.equals(phone)) {
                Log.i(TAG, "Account changed (" + kongPlayerPhone + " → " + phone + "), forcing fresh Kong login");
                this.session.clearKongSession();
                kongToken = null;
                this.kongToken = null;
            }
        }
        return (ok(kongToken) && (req = getReq("https://kong.mascom.vn/api/user/info", kongToken)) != null && req.code == 200) ? kongToken : loginKongViaGateway();
    }

    /* JADX WARN: Removed duplicated region for block: B:49:0x0112 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:83:0x0113 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.lang.String loginKongViaGateway() {
        /*
            Method dump skipped, instruction units count: 479
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.KongIslandService.loginKongViaGateway():java.lang.String");
    }

    private String extractTokenFromUrl(String str) {
        if (!ok(str)) {
            return null;
        }
        try {
            int iIndexOf = str.indexOf("token=");
            if (iIndexOf == -1) {
                return null;
            }
            String strSubstring = str.substring(iIndexOf + 6);
            int iIndexOf2 = strSubstring.indexOf(38);
            if (iIndexOf2 != -1) {
                strSubstring = strSubstring.substring(0, iIndexOf2);
            }
            return URLDecoder.decode(strSubstring, "UTF-8");
        } catch (Exception unused) {
            return null;
        }
    }

    void fetchUserInfo(String str) {
        HttpResult req = getReq("https://kong.mascom.vn/api/user/info", str);
        if (req == null) {
            return;
        }
        try {
            JSONObject jSONObjectOptJSONObject = new JSONObject(req.body).optJSONObject("data");
            if (jSONObjectOptJSONObject == null) {
                return;
            }
            String strOptString = jSONObjectOptJSONObject.optString("avatar", null);
            String strOptString2 = jSONObjectOptJSONObject.optString("playerName", null);
            String strOptString3 = jSONObjectOptJSONObject.optString("msisdn", null);
            JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("gameData");
            int iOptInt = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optInt("totalBanana", 0) : 0;
            int iOptInt2 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optInt("totalTicket", 0) : 0;
            int iOptInt3 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optInt("totalBox", 0) : 0;
            int iOptInt4 = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optInt("total2xBanana", 0) : 0;
            this.totalBanana = iOptInt;
            this.totalTickets = iOptInt2;
            this.totalBoxes = iOptInt3;
            this.total2xBanana = iOptInt4;
            if (!ok(strOptString2)) {
                strOptString2 = this.session.getKongPlayerName();
            }
            final String str2 = strOptString2;
            if (!ok(strOptString3)) {
                strOptString3 = this.session.getKongPlayerPhone();
            }
            final String str3 = strOptString3;
            if (!ok(strOptString)) {
                strOptString = this.session.getKongPlayerAvatar();
            }
            final String str4 = strOptString;
            this.session.saveKongProfile(str2, str3, str4);
            final int i = iOptInt;
            final int i2 = iOptInt2;
            final int i3 = iOptInt3;
            final int i4 = iOptInt4;
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m561lambda$fetchUserInfo$8$comzenoappKongIslandService(i, i2, i3, i4, str2, str3, str4);
                }
            });
        } catch (Exception e) {
            Log.w(TAG, "fetchUserInfo: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$fetchUserInfo$8$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m561lambda$fetchUserInfo$8$comzenoappKongIslandService(int i, int i2, int i3, int i4, String str, String str2, String str3) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onStatsChanged(i, i2, i3, i4);
            gameCallback.onProfileUpdated(str, str2, str3);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void useX2BananaItem(WebSocket webSocket) {
        wsend(webSocket, "{\"type\":\"USE_ITEM\",\"payload\":{\"itemType\":\"X2BANANA\",\"isUserItem\":true}}");
        if (this.total2xBanana > 0) {
            this.total2xBanana--;
            notifyStatsChanged();
        }
    }

    private void notifyStatsChanged() {
        final int i = this.totalBanana;
        final int i2 = this.totalTickets;
        final int i3 = this.totalBoxes;
        final int i4 = this.total2xBanana;
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m565lambda$notifyStatsChanged$9$comzenoappKongIslandService(i, i2, i3, i4);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyStatsChanged$9$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m565lambda$notifyStatsChanged$9$comzenoappKongIslandService(int i, int i2, int i3, int i4) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onStatsChanged(i, i2, i3, i4);
        }
    }

    private void notifyStateChanged() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m564lambda$notifyStateChanged$10$comzenoappKongIslandService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyStateChanged$10$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m564lambda$notifyStateChanged$10$comzenoappKongIslandService() {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onStateChanged(this.running, this.currentGame, this.totalGames, this.gameStartMs, this.currentGameMs, this.sessionStartMs);
        }
    }

    private void notifySessionEnded(long j, int i) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onSessionEnded(j, i);
        }
    }

    private void notifyMessage(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m563lambda$notifyMessage$11$comzenoappKongIslandService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyMessage$11$com-zeno-app-KongIslandService, reason: not valid java name */
    /* synthetic */ void m563lambda$notifyMessage$11$comzenoappKongIslandService(String str) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            gameCallback.onMessage(str);
        }
    }

    static class HttpResult {
        final String body;
        final int code;

        HttpResult(int i, String str) {
            this.code = i;
            this.body = str == null ? "" : str;
        }
    }

    HttpResult getReq(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("user-agent", "Mozilla/5.0");
            if (ok(str2)) {
                builderAddHeader.addHeader("Authorization", "Bearer " + str2);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "GET " + str + ": " + e.getMessage());
            return null;
        }
    }

    HttpResult postReq(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).post(RequestBody.create(str2, MediaType.parse("application/json"))).addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("user-agent", "Mozilla/5.0");
            if (ok(str3)) {
                builderAddHeader.addHeader("Authorization", "Bearer " + str3);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "POST " + str + ": " + e.getMessage());
            return null;
        }
    }

    HttpResult putReq(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).put(RequestBody.create(str2, MediaType.parse("application/json"))).addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("user-agent", "Mozilla/5.0");
            if (ok(str3)) {
                builderAddHeader.addHeader("Authorization", "Bearer " + str3);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "PUT " + str + ": " + e.getMessage());
            return null;
        }
    }

    private void releaseWakeLock() {
        try {
            PowerManager.WakeLock wakeLock = this.wakeLock;
            if (wakeLock == null || !wakeLock.isHeld()) {
                return;
            }
            this.wakeLock.release();
        } catch (Exception unused) {
        }
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private void sleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }
}
