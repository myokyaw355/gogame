package com.zeno.app;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import com.zeno.app.SoftClimbersService;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SoftClimbersService extends Service {
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=UTF-8");
    static final String SC_BASE = "https://api.softclimbers.com";
    private static final String TAG = "SoftClimbersService";
    static volatile SoftClimbersService instance;
    private GameCallback callback;
    private ExecutorService exec;
    private SessionManager session;
    private PowerManager.WakeLock wakeLock;
    private final ServiceBinder binder = new ServiceBinder();
    volatile boolean running = false;
    volatile boolean stopping = false;
    volatile String scToken = null;
    volatile String boundPhone = null;
    volatile int remainingAttempts = -1;
    volatile int selectedStartLevel = 1;
    volatile long totalScore = 0;
    volatile int currentLevel = 1;
    volatile boolean subscribed = false;
    volatile int dailyLimit = 0;
    volatile String planEndDate = "";
    volatile String planName = "";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build();

    interface CallbackAction {
        void run(GameCallback gameCallback);
    }

    public interface GameCallback {
        void onDrop(String str, double d, String str2);

        void onLevelStarted(int i, long j);

        void onLog(String str, int i);

        void onPlanDetails(int i, String str, String str2);

        void onStateChanged(boolean z);

        void onStatsUpdated(int i, int i2, long j);

        void onSubscriptionUpdate(boolean z);

        void onSynthesis(String str, String str2, String str3);
    }

    private void acquireWakeLock() {
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        return 2;
    }

    public class ServiceBinder extends Binder {
        public ServiceBinder() {
        }

        public SoftClimbersService getService() {
            return SoftClimbersService.this;
        }
    }

    public boolean isRunning() {
        return this.running;
    }

    public int getRemainingAttempts() {
        return this.remainingAttempts;
    }

    public int getSelectedStartLevel() {
        return this.selectedStartLevel;
    }

    public long getTotalScore() {
        return this.totalScore;
    }

    public int getCurrentLevel() {
        return this.currentLevel;
    }

    public String getScToken() {
        return this.scToken;
    }

    public String getBoundPhone() {
        return this.boundPhone;
    }

    public void clearInMemorySession() {
        this.scToken = null;
        this.boundPhone = null;
        this.remainingAttempts = -1;
        this.totalScore = 0L;
        this.currentLevel = 1;
        this.subscribed = false;
        this.planName = "";
        this.planEndDate = "";
    }

    public int getDailyLimit() {
        return this.dailyLimit;
    }

    public String getPlanEndDate() {
        return this.planEndDate;
    }

    public String getPlanName() {
        return this.planName;
    }

    public void setCallback(GameCallback gameCallback) {
        this.callback = gameCallback;
    }

    public void clearCallback() {
        this.callback = null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        instance = this;
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.binder;
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        this.stopping = true;
        releaseWakeLock();
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    public void startPlay() {
        if (this.running) {
            return;
        }
        this.running = true;
        this.stopping = false;
        acquireWakeLock();
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda7
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onStateChanged(true);
            }
        });
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.runAutoPlayLoop();
            }
        });
    }

    public void stopPlay() {
        if (this.running || this.stopping) {
            this.stopping = true;
        }
    }

    public void initLoad() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m714lambda$initLoad$1$comzenoappSoftClimbersService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$initLoad$1$com-zeno-app-SoftClimbersService, reason: not valid java name */
    /* synthetic */ void m714lambda$initLoad$1$comzenoappSoftClimbersService() {
        if (!ok(this.scToken)) {
            this.scToken = resolveScToken();
        }
        if (ok(this.scToken)) {
            fetchSubscriptionStatus(this.scToken);
        }
    }

    private void fire(final CallbackAction callbackAction) {
        this.mainHandler.post(new Runnable() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m713lambda$fire$2$comzenoappSoftClimbersService(callbackAction);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fire$2$com-zeno-app-SoftClimbersService, reason: not valid java name */
    /* synthetic */ void m713lambda$fire$2$comzenoappSoftClimbersService(CallbackAction callbackAction) {
        GameCallback gameCallback = this.callback;
        if (gameCallback != null) {
            callbackAction.run(gameCallback);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Can't wrap try/catch for region: R(11:47|(2:48|(1:222)(4:52|(1:54)(1:55)|56|(2:223|58)(9:59|192|60|61|198|62|(1:210)(16:67|194|68|(13:70|190|71|72|(14:74|217|75|78|(1:80)|200|81|82|(7:84|85|86|196|87|(3:182|89|(17:91|92|215|93|94|219|95|96|208|97|98|202|99|206|114|(5:116|117|213|118|(1:122))(1:124)|123))|108)(1:112)|113|206|114|(0)(0)|123)(11:78|(0)|200|81|82|(0)(0)|113|206|114|(0)(0)|123)|152|188|153|(3:159|(1:161)|162)|165|(1:167)(1:(1:169)(1:170))|171|172)(1:129)|184|130|(2:204|132)|134|(1:136)|137|138|180|139|186|140|141)|147|148)))|149|152|188|153|(5:155|157|159|(0)|162)|165|(0)(0)|171|172) */
    /* JADX WARN: Can't wrap try/catch for region: R(13:217|75|78|(1:80)|200|81|82|(7:84|85|86|196|87|(3:182|89|(17:91|92|215|93|94|219|95|96|208|97|98|202|99|206|114|(5:116|117|213|118|(1:122))(1:124)|123))|108)(1:112)|113|206|114|(0)(0)|123) */
    /* JADX WARN: Code restructure failed: missing block: B:150:0x03a6, code lost:
    
        r28 = r2;
        r25 = r3;
        r10 = "bodySize";
     */
    /* JADX WARN: Code restructure failed: missing block: B:151:0x03ab, code lost:
    
        r3 = r25;
        r9 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x01f1, code lost:
    
        fireLog("Network error on event.", 5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x01f7, code lost:
    
        r28 = r2;
     */
    /* JADX WARN: Removed duplicated region for block: B:112:0x02c9  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x02dd  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x031e  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x0365 A[Catch: Exception -> 0x035e, TRY_LEAVE, TryCatch #12 {Exception -> 0x035e, blocks: (B:132:0x0350, B:136:0x0365), top: B:204:0x0350 }] */
    /* JADX WARN: Removed duplicated region for block: B:161:0x0414 A[Catch: Exception -> 0x042a, TryCatch #4 {Exception -> 0x042a, blocks: (B:153:0x03b4, B:155:0x03e2, B:157:0x03ea, B:159:0x03f9, B:161:0x0414, B:162:0x041b), top: B:188:0x03b4 }] */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0430  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x0447  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x0350 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0233 A[Catch: Exception -> 0x0224, TRY_LEAVE, TryCatch #19 {Exception -> 0x0224, blocks: (B:75:0x021f, B:80:0x0233), top: B:217:0x021f }] */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0250  */
    /* JADX WARN: Unreachable blocks removed: 1, instructions: 2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void runAutoPlayLoop() {
        /*
            Method dump skipped, instruction units count: 1123
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.SoftClimbersService.runAutoPlayLoop():void");
    }

    /* JADX INFO: renamed from: lambda$runAutoPlayLoop$3$com-zeno-app-SoftClimbersService, reason: not valid java name */
    /* synthetic */ void m716lambda$runAutoPlayLoop$3$comzenoappSoftClimbersService(int i, int i2, GameCallback gameCallback) {
        gameCallback.onStatsUpdated(i, i2, this.totalScore);
    }

    private void onDone() {
        this.running = false;
        this.stopping = false;
        releaseWakeLock();
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda2
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onStateChanged(false);
            }
        });
        if (ok(this.scToken)) {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m715lambda$onDone$10$comzenoappSoftClimbersService();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$onDone$10$com-zeno-app-SoftClimbersService, reason: not valid java name */
    /* synthetic */ void m715lambda$onDone$10$comzenoappSoftClimbersService() {
        fetchSubscriptionStatus(this.scToken);
    }

    private void fireLog(final String str, final int i) {
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda0
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onLog(str, i);
            }
        });
    }

    private void releaseWakeLock() {
        try {
            PowerManager.WakeLock wakeLock = this.wakeLock;
            if (wakeLock == null || !wakeLock.isHeld()) {
                return;
            }
            this.wakeLock.release();
        } catch (Exception unused) {
        }
    }

    private String resolveScToken() {
        HttpResult req;
        String scGameToken = this.session.getScGameToken();
        return (ok(scGameToken) && (req = getReq("https://api.softclimbers.com/api/v1/subscription/status", scGameToken)) != null && req.status == 200) ? scGameToken : loginToSoftClimbers();
    }

    private String loginToSoftClimbers() {
        JSONObject jSONObjectOptJSONObject;
        int iExtractHighestLevel;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        String avatarUrl = this.session.getAvatarUrl();
        String fullName = this.session.getFullName();
        if (ok(phone) && ok(accessToken)) {
            try {
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("msisdn", phone);
                jSONObject.put("accessToken", accessToken);
                if (!ok(avatarUrl)) {
                    avatarUrl = "";
                }
                jSONObject.put("avatar", avatarUrl);
                if (!ok(fullName)) {
                    fullName = phone;
                }
                jSONObject.put("username", fullName);
                jSONObject.put("lang", "mu");
                HttpResult httpResultPostReq = postReq("https://api.softclimbers.com/api/v1/auth/login", jSONObject.toString(), null);
                if (httpResultPostReq == null) {
                    return null;
                }
                JSONObject jSONObject2 = new JSONObject(httpResultPostReq.body);
                if (jSONObject2.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject2.optJSONObject("data")) != null) {
                    String strOptString = jSONObjectOptJSONObject.optString("token", "");
                    if (ok(strOptString)) {
                        this.session.saveScGameToken(strOptString);
                        this.boundPhone = phone;
                        JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("user");
                        if (jSONObjectOptJSONObject2 != null) {
                            JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject2.optJSONObject("subscription");
                            if (jSONObjectOptJSONObject3 != null) {
                                applySubscriptionData(jSONObjectOptJSONObject3);
                            }
                            long jExtractTotalScore = extractTotalScore(jSONObjectOptJSONObject2, jSONObjectOptJSONObject3) >= 0 ? extractTotalScore(jSONObjectOptJSONObject2, jSONObjectOptJSONObject3) : extractTotalScore(jSONObjectOptJSONObject, jSONObjectOptJSONObject3);
                            if (jExtractTotalScore >= 0) {
                                this.totalScore = jExtractTotalScore;
                                this.session.saveScTotalScore(jExtractTotalScore);
                            }
                            if (extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject3) >= 0) {
                                iExtractHighestLevel = extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject3);
                            } else {
                                iExtractHighestLevel = extractHighestLevel(jSONObjectOptJSONObject2, jSONObjectOptJSONObject3);
                            }
                            syncHighestLevelInternal(iExtractHighestLevel);
                        }
                        return strOptString;
                    }
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    void fetchSubscriptionStatus(String str) {
        JSONObject jSONObjectOptJSONObject;
        try {
            HttpResult req = getReq("https://api.softclimbers.com/api/v1/subscription/status", str);
            if (req != null && ok(req.body)) {
                JSONObject jSONObject = new JSONObject(req.body);
                if (jSONObject.optInt("code", -1) == 0 && (jSONObjectOptJSONObject = jSONObject.optJSONObject("data")) != null) {
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject.optJSONObject("subscription");
                    long jExtractTotalScore = extractTotalScore(jSONObjectOptJSONObject, jSONObjectOptJSONObject2);
                    if (jExtractTotalScore >= 0) {
                        this.totalScore = jExtractTotalScore;
                        this.session.saveScTotalScore(jExtractTotalScore);
                    }
                    syncHighestLevelInternal(extractHighestLevel(jSONObjectOptJSONObject, jSONObjectOptJSONObject2));
                    final boolean zOptBoolean = jSONObjectOptJSONObject.optBoolean("subscribed", false);
                    this.subscribed = zOptBoolean;
                    fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda11
                        @Override // com.zeno.app.SoftClimbersService.CallbackAction
                        public final void run(SoftClimbersService.GameCallback gameCallback) {
                            gameCallback.onSubscriptionUpdate(zOptBoolean);
                        }
                    });
                    if (zOptBoolean) {
                        JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject.optJSONObject("subscription");
                        if (jSONObjectOptJSONObject3 != null) {
                            applySubscriptionData(jSONObjectOptJSONObject3);
                            return;
                        }
                        return;
                    }
                    this.remainingAttempts = 0;
                    final long j = this.totalScore;
                    fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda12
                        @Override // com.zeno.app.SoftClimbersService.CallbackAction
                        public final void run(SoftClimbersService.GameCallback gameCallback) {
                            this.f$0.m712lambda$fetchSubscriptionStatus$13$comzenoappSoftClimbersService(j, gameCallback);
                        }
                    });
                }
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: renamed from: lambda$fetchSubscriptionStatus$13$com-zeno-app-SoftClimbersService, reason: not valid java name */
    /* synthetic */ void m712lambda$fetchSubscriptionStatus$13$comzenoappSoftClimbersService(long j, GameCallback gameCallback) {
        gameCallback.onStatsUpdated(0, this.selectedStartLevel, j);
    }

    private void applySubscriptionData(JSONObject jSONObject) {
        final int iOptInt = jSONObject.optInt("remainingAttempts", 0);
        int iOptInt2 = jSONObject.optInt("dailyAttempts", 0);
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("dailyLimit", 0);
        }
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("daily_attempts", 0);
        }
        if (iOptInt2 <= 0) {
            iOptInt2 = jSONObject.optInt("totalAttempts", 0);
        }
        String strOptString = jSONObject.optString("expiredAt", "");
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("endDate", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("expiresAt", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("expireDate", "");
        }
        if (!ok(strOptString)) {
            strOptString = jSONObject.optString("expire_at", "");
        }
        if (ok(strOptString) && strOptString.contains("T")) {
            strOptString = strOptString.substring(0, 10);
        }
        String strOptString2 = jSONObject.optString("plan", "");
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("type", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("planName", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("name", "");
        }
        if (!ok(strOptString2)) {
            strOptString2 = jSONObject.optString("package", "");
        }
        this.remainingAttempts = iOptInt;
        this.dailyLimit = iOptInt2;
        if (ok(strOptString)) {
            this.planEndDate = strOptString;
        }
        if (ok(strOptString2)) {
            this.planName = strOptString2;
        }
        final int i = this.dailyLimit;
        final String str = this.planEndDate;
        final String str2 = this.planName;
        final long j = this.totalScore;
        final int i2 = this.selectedStartLevel;
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda9
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onStatsUpdated(iOptInt, i2, j);
            }
        });
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda10
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onPlanDetails(i, str2, str);
            }
        });
    }

    private void syncHighestLevelInternal(final int i) {
        if (i <= 0 || this.running) {
            return;
        }
        this.selectedStartLevel = i;
        this.currentLevel = i;
        final int i2 = this.remainingAttempts;
        final long j = this.totalScore;
        fire(new CallbackAction() { // from class: com.zeno.app.SoftClimbersService$$ExternalSyntheticLambda5
            @Override // com.zeno.app.SoftClimbersService.CallbackAction
            public final void run(SoftClimbersService.GameCallback gameCallback) {
                gameCallback.onStatsUpdated(i2, i, j);
            }
        });
    }

    private long extractTotalScore(JSONObject jSONObject, JSONObject jSONObject2) {
        String[] strArr = {"totalAccumulatedScore", "totalScore", "accumulatedScore", "score"};
        for (int i = 0; i < 4; i++) {
            long jOptLong = jSONObject.optLong(strArr[i], -1L);
            if (jOptLong >= 0) {
                return jOptLong;
            }
        }
        if (jSONObject2 != null) {
            for (int i2 = 0; i2 < 4; i2++) {
                long jOptLong2 = jSONObject2.optLong(strArr[i2], -1L);
                if (jOptLong2 >= 0) {
                    return jOptLong2;
                }
            }
        }
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("user");
        if (jSONObjectOptJSONObject != null) {
            for (int i3 = 0; i3 < 4; i3++) {
                long jOptLong3 = jSONObjectOptJSONObject.optLong(strArr[i3], -1L);
                if (jOptLong3 >= 0) {
                    return jOptLong3;
                }
            }
        }
        long jDeepFindTotalScore = deepFindTotalScore(jSONObject);
        if (jDeepFindTotalScore >= 0) {
            return jDeepFindTotalScore;
        }
        return -1L;
    }

    private long deepFindTotalScore(Object obj) {
        if (obj instanceof JSONObject) {
            JSONObject jSONObject = (JSONObject) obj;
            Iterator<String> itKeys = jSONObject.keys();
            while (itKeys.hasNext()) {
                String next = itKeys.next();
                String lowerCase = next.toLowerCase(Locale.ROOT);
                if (lowerCase.equals("totalscore") || lowerCase.equals("totalaccumulatedscore") || lowerCase.equals("accumulatedscore") || (lowerCase.contains("total") && lowerCase.contains("score"))) {
                    long jOptLong = jSONObject.optLong(next, -1L);
                    if (jOptLong >= 0) {
                        return jOptLong;
                    }
                }
            }
            Iterator<String> itKeys2 = jSONObject.keys();
            while (itKeys2.hasNext()) {
                Object objOpt = jSONObject.opt(itKeys2.next());
                if ((objOpt instanceof JSONObject) || (objOpt instanceof JSONArray)) {
                    long jDeepFindTotalScore = deepFindTotalScore(objOpt);
                    if (jDeepFindTotalScore >= 0) {
                        return jDeepFindTotalScore;
                    }
                }
            }
        } else if (obj instanceof JSONArray) {
            JSONArray jSONArray = (JSONArray) obj;
            for (int i = 0; i < jSONArray.length(); i++) {
                long jDeepFindTotalScore2 = deepFindTotalScore(jSONArray.opt(i));
                if (jDeepFindTotalScore2 >= 0) {
                    return jDeepFindTotalScore2;
                }
            }
        }
        return -1L;
    }

    private int extractHighestLevel(JSONObject jSONObject, JSONObject jSONObject2) {
        String[] strArr = {"highestLevel", "highest_level", "maxLevel", "level"};
        for (int i = 0; i < 4; i++) {
            int iOptInt = jSONObject.optInt(strArr[i], -1);
            if (iOptInt > 0) {
                return iOptInt;
            }
        }
        if (jSONObject2 != null) {
            for (int i2 = 0; i2 < 4; i2++) {
                int iOptInt2 = jSONObject2.optInt(strArr[i2], -1);
                if (iOptInt2 > 0) {
                    return iOptInt2;
                }
            }
        }
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("user");
        if (jSONObjectOptJSONObject != null) {
            for (int i3 = 0; i3 < 4; i3++) {
                int iOptInt3 = jSONObjectOptJSONObject.optInt(strArr[i3], -1);
                if (iOptInt3 > 0) {
                    return iOptInt3;
                }
            }
        }
        return -1;
    }

    HttpResult postReq(String str, String str2, String str3) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).post(RequestBody.create(str2, JSON_TYPE)).addHeader("content-type", "application/json").addHeader("accept", "*/*").addHeader("origin", "http://game.softclimbers.com").addHeader("user-agent", "ZenoMyID/2.0");
            if (ok(str3)) {
                addAuthHeaders(builderAddHeader, str3);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "POST: " + e.getMessage());
            return null;
        }
    }

    HttpResult getReq(String str, String str2) {
        try {
            Request.Builder builderAddHeader = new Request.Builder().url(str).get().addHeader("accept", "*/*").addHeader("user-agent", "ZenoMyID/2.0");
            if (ok(str2)) {
                addAuthHeaders(builderAddHeader, str2);
            }
            Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
            try {
                HttpResult httpResult = new HttpResult(responseExecute.code(), responseExecute.body() != null ? responseExecute.body().string() : "");
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return httpResult;
            } finally {
            }
        } catch (Exception e) {
            Log.w(TAG, "GET: " + e.getMessage());
            return null;
        }
    }

    private void addAuthHeaders(Request.Builder builder, String str) {
        String phone = this.session.getPhone();
        builder.addHeader("Authorization", "Bearer " + str);
        builder.addHeader("access-token", str);
        if (ok(phone)) {
            builder.addHeader("phone-number", phone);
            builder.addHeader("msisdn", phone);
        }
    }

    static class HttpResult {
        final String body;
        final int status;

        HttpResult(int i, String str) {
            this.status = i;
            this.body = str == null ? "" : str;
        }
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private void sleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }

    private void sleepInterruptible(long j) {
        long jCurrentTimeMillis = System.currentTimeMillis() + j;
        while (!this.stopping && System.currentTimeMillis() < jCurrentTimeMillis) {
            sleep(Math.min(200L, jCurrentTimeMillis - System.currentTimeMillis()));
        }
    }
}
