package com.zeno.app;

import android.animation.ValueAnimator;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.snackbar.Snackbar;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class PointsExchangeActivity extends BaseActivity {
    private View layoutLoading;
    private LinearLayout packListContainer;
    private String phone;
    private String rank;
    private ScrollView scrollPacks;
    private SessionManager sessionManager;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout tabContainer;
    private TextView[] tabLabels;
    private LinearLayout[] tabViews;
    private int userPoints;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final String[] TAB_CODES = {"SUPER", "DATA", "SMS", "VOICE"};
    private final String[] TAB_LABELS = {"Super", "Data", "SMS", "Voice"};
    private int selectedTab = 1;
    private final List<JSONObject>[] categoryPacks = new List[4];

    static /* synthetic */ int access$820(PointsExchangeActivity pointsExchangeActivity, int i) {
        int i2 = pointsExchangeActivity.userPoints - i;
        pointsExchangeActivity.userPoints = i2;
        return i2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(R.color.yellow_primary, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_points_exchange);
        this.sessionManager = new SessionManager(this);
        this.phone = getIntent().getStringExtra("phone");
        this.userPoints = getIntent().getIntExtra("points", 0);
        this.rank = getIntent().getStringExtra("rank");
        if (this.phone == null) {
            this.phone = this.sessionManager.getPhone();
        }
        findViewById(R.id.toolbar).setTitle("Points Exchange");
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{getResources().getColor(R.color.yellow_primary, getTheme())});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.bg_card, getTheme()));
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.PointsExchangeActivity$$ExternalSyntheticLambda1
            public final void onRefresh() {
                this.f$0.loadPacks();
            }
        });
        this.layoutLoading = findViewById(R.id.layout_loading);
        this.tabContainer = (LinearLayout) findViewById(R.id.tabContainer);
        this.packListContainer = (LinearLayout) findViewById(R.id.packListContainer);
        this.scrollPacks = (ScrollView) findViewById(R.id.scrollPacks);
        this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.PointsExchangeActivity$$ExternalSyntheticLambda2
            public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                return this.f$0.m650lambda$onCreate$0$comzenoappPointsExchangeActivity(swipeRefreshLayout, view);
            }
        });
        buildTabs();
        loadPacks();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-PointsExchangeActivity, reason: not valid java name */
    /* synthetic */ boolean m650lambda$onCreate$0$comzenoappPointsExchangeActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        ScrollView scrollView = this.scrollPacks;
        View view2 = (scrollView == null || scrollView.getVisibility() != 0) ? this.layoutLoading : this.scrollPacks;
        return view2 != null && view2.canScrollVertically(-1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buildTabs() {
        String[] strArr = this.TAB_LABELS;
        this.tabViews = new LinearLayout[strArr.length];
        this.tabLabels = new TextView[strArr.length];
        this.tabContainer.removeAllViews();
        for (final int i = 0; i < this.TAB_LABELS.length; i++) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setGravity(17);
            linearLayout.setPadding(dp(4), 0, dp(4), 0);
            linearLayout.setLayoutParams(new LinearLayout.LayoutParams(0, -1, 1.0f));
            ImageView imageView = new ImageView(this);
            imageView.setId(View.generateViewId());
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(14), dp(14));
            layoutParams.setMarginEnd(dp(4));
            imageView.setLayoutParams(layoutParams);
            imageView.setImageResource(getTabIconRes(i));
            linearLayout.addView(imageView);
            TextView textView = new TextView(this);
            textView.setText(this.TAB_LABELS[i]);
            textView.setTextSize(12.0f);
            boolean z = true;
            textView.setTypeface(null, 1);
            textView.setGravity(17);
            textView.setSingleLine(true);
            linearLayout.addView(textView);
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsExchangeActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m648lambda$buildTabs$1$comzenoappPointsExchangeActivity(i, view);
                }
            });
            this.tabViews[i] = linearLayout;
            this.tabLabels[i] = textView;
            this.tabContainer.addView(linearLayout);
            if (i != this.selectedTab) {
                z = false;
            }
            applyTabStyle(i, z);
        }
    }

    /* JADX INFO: renamed from: lambda$buildTabs$1$com-zeno-app-PointsExchangeActivity, reason: not valid java name */
    /* synthetic */ void m648lambda$buildTabs$1$comzenoappPointsExchangeActivity(int i, View view) {
        selectTab(i);
    }

    private void selectTab(int i) {
        this.selectedTab = i;
        int i2 = 0;
        while (i2 < this.tabViews.length) {
            applyTabStyle(i2, i2 == i);
            i2++;
        }
        renderPacks(i);
    }

    private void applyTabStyle(int i, boolean z) {
        int i2;
        LinearLayout linearLayout = this.tabViews[i];
        TextView textView = this.tabLabels[i];
        int color = getResources().getColor(z ? R.color.text_white : R.color.text_grey, getTheme());
        if (z) {
            i2 = R.drawable.bg_beat_mode_selected;
        } else {
            i2 = R.drawable.bg_beat_mode_normal;
        }
        linearLayout.setBackgroundResource(i2);
        textView.setTextColor(color);
        if (linearLayout.getChildCount() <= 0 || !(linearLayout.getChildAt(0) instanceof ImageView)) {
            return;
        }
        ((ImageView) linearLayout.getChildAt(0)).setColorFilter(color, PorterDuff.Mode.SRC_IN);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadPacks() {
        int i = 0;
        while (true) {
            List<JSONObject>[] listArr = this.categoryPacks;
            if (i >= listArr.length) {
                showSkeletonLoading();
                ApiClient.getPacks(this.phone, this.sessionManager.getAccessToken(), this.sessionManager.getDeviceId(), new AnonymousClass1());
                return;
            }
            listArr[i] = new ArrayList();
            i++;
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.PointsExchangeActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Callback {
        AnonymousClass1() {
        }

        public void onFailure(Call call, IOException iOException) {
            PointsExchangeActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m652lambda$onFailure$0$comzenoappPointsExchangeActivity$1();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-PointsExchangeActivity$1, reason: not valid java name */
        /* synthetic */ void m652lambda$onFailure$0$comzenoappPointsExchangeActivity$1() {
            PointsExchangeActivity.this.hideSkeletonLoading();
            PointsExchangeActivity.this.swipeRefresh.setRefreshing(false);
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            if (strString.trim().startsWith("<")) {
                PointsExchangeActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m653lambda$onResponse$1$comzenoappPointsExchangeActivity$1();
                    }
                });
            } else {
                PointsExchangeActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$1$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m654lambda$onResponse$2$comzenoappPointsExchangeActivity$1(strString);
                    }
                });
            }
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-PointsExchangeActivity$1, reason: not valid java name */
        /* synthetic */ void m653lambda$onResponse$1$comzenoappPointsExchangeActivity$1() {
            PointsExchangeActivity.this.hideSkeletonLoading();
            PointsExchangeActivity.this.snack("Session expired. Pull down to retry or re-login.");
            PointsExchangeActivity.this.swipeRefresh.setRefreshing(false);
        }

        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-PointsExchangeActivity$1, reason: not valid java name */
        /* synthetic */ void m654lambda$onResponse$2$comzenoappPointsExchangeActivity$1(String str) {
            try {
                JSONArray jSONArrayOptJSONArray = new JSONObject(str).optJSONArray("result");
                if (jSONArrayOptJSONArray != null) {
                    for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                        JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                        String strOptString = jSONObject.optString("categoryCode", "");
                        JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray("rewards");
                        for (int i2 = 0; i2 < PointsExchangeActivity.this.TAB_CODES.length; i2++) {
                            if (PointsExchangeActivity.this.TAB_CODES[i2].equals(strOptString) && jSONArrayOptJSONArray2 != null) {
                                for (int i3 = 0; i3 < jSONArrayOptJSONArray2.length(); i3++) {
                                    PointsExchangeActivity.this.categoryPacks[i2].add(jSONArrayOptJSONArray2.getJSONObject(i3));
                                }
                            }
                        }
                    }
                    PointsExchangeActivity pointsExchangeActivity = PointsExchangeActivity.this;
                    pointsExchangeActivity.renderPacks(pointsExchangeActivity.selectedTab);
                }
            } catch (Exception unused) {
            }
            PointsExchangeActivity.this.hideSkeletonLoading();
            PointsExchangeActivity.this.swipeRefresh.setRefreshing(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void renderPacks(int i) {
        this.packListContainer.removeAllViews();
        List<JSONObject> list = this.categoryPacks[i];
        int i2 = 16;
        if (list == null || list.isEmpty()) {
            TextView textView = new TextView(this);
            textView.setText("No packs available");
            textView.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
            textView.setPadding(dp(16), dp(32), dp(16), dp(16));
            textView.setGravity(17);
            this.packListContainer.addView(textView);
            return;
        }
        for (JSONObject jSONObject : list) {
            final String strOptString = jSONObject.optString("rewardCode", "");
            final String strOptString2 = jSONObject.optString("rewardName", "");
            final int iOptInt = jSONObject.optInt("pointAmount", 0);
            String strOptString3 = jSONObject.optString("validityDayText", "");
            boolean z = this.userPoints >= iOptInt;
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setGravity(i2);
            linearLayout.setBackgroundResource(R.drawable.bg_card);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(0, 0, 0, dp(10));
            linearLayout.setLayoutParams(layoutParams);
            linearLayout.setPadding(dp(i2), dp(i2), dp(i2), dp(i2));
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(getTabIconRes(i));
            imageView.setColorFilter(-1, PorterDuff.Mode.SRC_IN);
            imageView.setBackgroundResource(R.drawable.bg_pack_icon);
            imageView.setPadding(dp(12), dp(12), dp(12), dp(12));
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(48), dp(48));
            layoutParams2.setMargins(0, 0, dp(14), 0);
            imageView.setLayoutParams(layoutParams2);
            linearLayout.addView(imageView);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            TextView textView2 = new TextView(this);
            textView2.setText(strOptString2);
            textView2.setTextColor(getResources().getColor(R.color.text_white, getTheme()));
            textView2.setTextSize(15.0f);
            textView2.setTypeface(null, 1);
            linearLayout2.addView(textView2);
            TextView textView3 = new TextView(this);
            textView3.setText(iOptInt + " pts   " + strOptString3);
            textView3.setTextColor(getResources().getColor(R.color.yellow_primary, getTheme()));
            textView3.setTextSize(13.0f);
            Drawable drawableMutate = getResources().getDrawable(R.drawable.ic_star, getTheme()).mutate();
            drawableMutate.setTint(getResources().getColor(R.color.yellow_primary, getTheme()));
            drawableMutate.setBounds(0, 0, dp(12), dp(12));
            textView3.setCompoundDrawables(drawableMutate, null, null, null);
            textView3.setCompoundDrawablePadding(dp(3));
            linearLayout2.addView(textView3);
            linearLayout.addView(linearLayout2);
            TextView textView4 = new TextView(this);
            textView4.setText("Exchange");
            textView4.setTextSize(13.0f);
            textView4.setTypeface(null, 1);
            textView4.setPadding(dp(14), dp(10), dp(14), dp(10));
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams3.setMargins(dp(8), 0, 0, 0);
            textView4.setLayoutParams(layoutParams3);
            if (z) {
                textView4.setBackgroundResource(R.drawable.bg_btn_exchange_active);
                textView4.setTextColor(getResources().getColor(R.color.text_white, getTheme()));
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsExchangeActivity$$ExternalSyntheticLambda3
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m651lambda$renderPacks$2$comzenoappPointsExchangeActivity(strOptString, strOptString2, iOptInt, view);
                    }
                });
            } else {
                textView4.setBackgroundResource(R.drawable.bg_btn_exchange_inactive);
                textView4.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
            }
            linearLayout.addView(textView4);
            this.packListContainer.addView(linearLayout);
            i2 = 16;
        }
    }

    /* JADX INFO: renamed from: lambda$renderPacks$2$com-zeno-app-PointsExchangeActivity, reason: not valid java name */
    /* synthetic */ void m651lambda$renderPacks$2$comzenoappPointsExchangeActivity(String str, String str2, int i, View view) {
        confirmExchange(str, str2, i);
    }

    private int getTabIconRes(int i) {
        if (i == 0) {
            return R.drawable.ic_star;
        }
        if (i == 1) {
            return R.drawable.ic_wifi;
        }
        if (i == 2) {
            return R.drawable.ic_sms;
        }
        if (i == 3) {
            return R.drawable.ic_phone;
        }
        return R.drawable.ic_gift;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmExchange(final String str, final String str2, final int i) {
        ZDialog.confirmSheet(this, "Confirm Exchange", "Exchange " + i + " pts for " + str2 + "?", "Exchange", new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m649lambda$confirmExchange$3$comzenoappPointsExchangeActivity(str, str2, i);
            }
        }, i + " pts", str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: doExchange, reason: merged with bridge method [inline-methods] */
    public void m649lambda$confirmExchange$3$comzenoappPointsExchangeActivity(String str, String str2, int i) {
        ApiClient.exchangePack(this.phone, str, this.sessionManager.getAccessToken(), this.sessionManager.getDeviceId(), new AnonymousClass2(i, str2));
    }

    /* JADX INFO: renamed from: com.zeno.app.PointsExchangeActivity$2, reason: invalid class name */
    class AnonymousClass2 implements Callback {
        final /* synthetic */ int val$pointAmt;
        final /* synthetic */ String val$rewardName;

        AnonymousClass2(int i, String str) {
            this.val$pointAmt = i;
            this.val$rewardName = str;
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-PointsExchangeActivity$2, reason: not valid java name */
        /* synthetic */ void m655lambda$onFailure$0$comzenoappPointsExchangeActivity$2(IOException iOException) {
            PointsExchangeActivity.this.snack("Exchange failed: " + iOException.getMessage());
        }

        public void onFailure(Call call, final IOException iOException) {
            PointsExchangeActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m655lambda$onFailure$0$comzenoappPointsExchangeActivity$2(iOException);
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            if (strString.trim().startsWith("<")) {
                PointsExchangeActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$2$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m656lambda$onResponse$1$comzenoappPointsExchangeActivity$2();
                    }
                });
                return;
            }
            Handler handler = PointsExchangeActivity.this.uiHandler;
            final int i = this.val$pointAmt;
            final String str = this.val$rewardName;
            handler.post(new Runnable() { // from class: com.zeno.app.PointsExchangeActivity$2$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m657lambda$onResponse$2$comzenoappPointsExchangeActivity$2(strString, i, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-PointsExchangeActivity$2, reason: not valid java name */
        /* synthetic */ void m656lambda$onResponse$1$comzenoappPointsExchangeActivity$2() {
            PointsExchangeActivity.this.snack("Session expired. Please re-login.");
        }

        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-PointsExchangeActivity$2, reason: not valid java name */
        /* synthetic */ void m657lambda$onResponse$2$comzenoappPointsExchangeActivity$2(String str, int i, String str2) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if ("00000".equals(jSONObject.optString("errorCode", ""))) {
                    PointsExchangeActivity.access$820(PointsExchangeActivity.this, i);
                    PointsExchangeActivity.this.snack("Exchange successful! " + str2);
                    PointsExchangeActivity pointsExchangeActivity = PointsExchangeActivity.this;
                    pointsExchangeActivity.renderPacks(pointsExchangeActivity.selectedTab);
                } else {
                    PointsExchangeActivity.this.snack(jSONObject.optString("message", "Exchange failed"));
                }
            } catch (Exception unused) {
                PointsExchangeActivity.this.snack("Exchange failed. Please try again.");
            }
        }
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void snack(String str) {
        Snackbar snackbarMake = Snackbar.make(findViewById(android.R.id.content), str, 0);
        View view = snackbarMake.getView();
        ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
        view.setLayoutParams(view.getLayoutParams());
        snackbarMake.show();
    }

    private void showSkeletonLoading() {
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(0);
            ScrollView scrollView = this.scrollPacks;
            if (scrollView != null) {
                scrollView.setVisibility(8);
            }
            this.skeletonAnim = SkeletonPulse.start(this.layoutLoading);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideSkeletonLoading() {
        SkeletonPulse.stop(this.skeletonAnim, this.layoutLoading);
        this.skeletonAnim = null;
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        ScrollView scrollView = this.scrollPacks;
        if (scrollView != null) {
            scrollView.setVisibility(0);
        }
    }
}
