package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.core.widget.NestedScrollView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CarRacingPackageShopActivity extends AppCompatActivity {
    private static final String GAME_BASE = "https://car-racing.mascom.vn";
    private static final String ORIGIN = "https://car-racing.mascom.vn";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12; Redmi K30 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36";
    private static final String X_REQ = "com.myentertainment.oneid";
    private String gameToken;
    private LinearLayout llLoading;
    private LinearLayout llPackages;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svPackages;
    private LinearLayout tabLicense;
    private View tabLicenseUnderline;
    private LinearLayout tabRenew;
    private View tabRenewUnderline;
    private LinearLayout tabRetail;
    private View tabRetailUnderline;
    private TextView tvEmpty;
    private TextView tvTabHint;
    private TextView tvTabLicense;
    private TextView tvTabRenew;
    private TextView tvTabRetail;
    private int currentTab = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(25, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        setContentView(R.layout.activity_car_racing_package_shop);
        this.gameToken = getIntent().getStringExtra("gameToken");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Shop");
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m199lambda$onCreate$0$comzenoappCarRacingPackageShopActivity(view);
            }
        });
        this.tabRenew = (LinearLayout) findViewById(R.id.tabRenew);
        this.tabRetail = (LinearLayout) findViewById(R.id.tabRetail);
        this.tabLicense = (LinearLayout) findViewById(R.id.tabLicense);
        this.tvTabRenew = (TextView) findViewById(R.id.tvTabRenew);
        this.tvTabRetail = (TextView) findViewById(R.id.tvTabRetail);
        this.tvTabLicense = (TextView) findViewById(R.id.tvTabLicense);
        this.tabRenewUnderline = findViewById(R.id.tabRenewUnderline);
        this.tabRetailUnderline = findViewById(R.id.tabRetailUnderline);
        this.tabLicenseUnderline = findViewById(R.id.tabLicenseUnderline);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svPackages = findViewById(R.id.svPackages);
        this.llPackages = (LinearLayout) findViewById(R.id.llPackages);
        this.tvTabHint = (TextView) findViewById(R.id.tvTabHint);
        this.tabRenew.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m200lambda$onCreate$1$comzenoappCarRacingPackageShopActivity(view);
            }
        });
        this.tabRetail.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m201lambda$onCreate$2$comzenoappCarRacingPackageShopActivity(view);
            }
        });
        this.tabLicense.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m202lambda$onCreate$3$comzenoappCarRacingPackageShopActivity(view);
            }
        });
        String str = this.gameToken;
        if (str == null || str.isEmpty()) {
            showEmpty("Login မပြီးသေးပါ");
        } else {
            fetchPackages("RENEW");
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m199lambda$onCreate$0$comzenoappCarRacingPackageShopActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m200lambda$onCreate$1$comzenoappCarRacingPackageShopActivity(View view) {
        switchTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m201lambda$onCreate$2$comzenoappCarRacingPackageShopActivity(View view) {
        switchTab(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m202lambda$onCreate$3$comzenoappCarRacingPackageShopActivity(View view) {
        switchTab(2);
    }

    private void switchTab(int i) {
        String str;
        if (this.currentTab == i) {
            return;
        }
        this.currentTab = i;
        updateTabBar();
        if (i == 0) {
            str = "RENEW";
        } else {
            str = i == 1 ? "RETAIL" : "LICENSE";
        }
        fetchPackages(str);
    }

    private void updateTabBar() {
        styleTab(this.tvTabRenew, this.tabRenewUnderline, this.currentTab == 0);
        styleTab(this.tvTabRetail, this.tabRetailUnderline, this.currentTab == 1);
        styleTab(this.tvTabLicense, this.tabLicenseUnderline, this.currentTab == 2);
    }

    private void styleTab(TextView textView, View view, boolean z) {
        if (z) {
            textView.setTextColor(-3632086);
            textView.setTypeface(null, 1);
            view.setBackgroundColor(-3632086);
        } else {
            textView.setTextColor(-7829368);
            textView.setTypeface(null, 0);
            view.setBackgroundColor(0);
        }
    }

    private void fetchPackages(final String str) {
        showLoading();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m198lambda$fetchPackages$5$comzenoappCarRacingPackageShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchPackages$5$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m198lambda$fetchPackages$5$comzenoappCarRacingPackageShopActivity(final String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/package/list?type=" + str).get().header("Authorization", "Bearer " + this.gameToken).header("Accept", "*/*").header("Content-Type", "application/json").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ).build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda6
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m197lambda$fetchPackages$4$comzenoappCarRacingPackageShopActivity(strString, str);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code());
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseAndShow, reason: merged with bridge method [inline-methods] */
    public void m197lambda$fetchPackages$4$comzenoappCarRacingPackageShopActivity(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Package list ယူ၍ မရပါ။"));
                return;
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject == null) {
                showEmpty("No data.");
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("listPackage");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                renderPackages(jSONArrayOptJSONArray, str2);
                return;
            }
            showEmpty("Package မရှိသေးပါ။");
        } catch (Exception e) {
            showEmpty("Parse error: " + e.getMessage());
        }
    }

    private void renderPackages(JSONArray jSONArray, String str) {
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.tvEmpty.setVisibility(8);
        this.llPackages.removeAllViews();
        if ("RENEW".equals(str)) {
            this.tvTabHint.setText("📅 Subscription — auto-renew ဖြစ်သည်");
        } else if ("RETAIL".equals(str)) {
            this.tvTabHint.setText("🛒 Retail — တစ်ကြိမ်ဝယ်၊ VIP လိုအပ်နိုင်သည်");
        } else {
            this.tvTabHint.setText("🪪 License — ကား + EXP bonus ရနိုင်သည်");
        }
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
            if (jSONObjectOptJSONObject != null) {
                addPackageRow(jSONObjectOptJSONObject);
            }
        }
        this.svPackages.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01de  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void addPackageRow(org.json.JSONObject r38) {
        /*
            Method dump skipped, instruction units count: 902
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CarRacingPackageShopActivity.addPackageRow(org.json.JSONObject):void");
    }

    /* JADX INFO: renamed from: lambda$addPackageRow$6$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m193lambda$addPackageRow$6$comzenoappCarRacingPackageShopActivity(String str, String str2, Button button, View view) {
        buyPackage(str, str2, button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buyPackage(final String str, final String str2, final Button button) {
        if (str == null || str.isEmpty()) {
            return;
        }
        String str3 = this.gameToken;
        if (str3 == null || str3.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ", 0).show();
            return;
        }
        button.setEnabled(false);
        button.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f$0.m196lambda$buyPackage$9$comzenoappCarRacingPackageShopActivity(str, str2, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyPackage$9$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m196lambda$buyPackage$9$comzenoappCarRacingPackageShopActivity(String str, String str2, final Button button) throws Throwable {
        final String strOptString;
        final boolean z = false;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("code", str);
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/package/buy-package").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).header("Authorization", "Bearer " + this.gameToken).header("Content-Type", "application/json").header("Accept", "*/*").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject2 = new JSONObject(strString);
                if (jSONObject2.optBoolean("success", false)) {
                    try {
                        strOptString = str2 + " ဝယ်ယူပြီးပါပြီ! 🎉";
                        z = true;
                    } catch (Throwable th) {
                        th = th;
                        z = true;
                        if (responseExecute != null) {
                            try {
                                responseExecute.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } else {
                    strOptString = jSONObject2.optString("message", "ဝယ်ယူ၍ မရပါ။");
                }
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } catch (Throwable th3) {
                th = th3;
            }
        } catch (Exception e) {
            strOptString = "Network error: " + e.getMessage();
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m195lambda$buyPackage$8$comzenoappCarRacingPackageShopActivity(strOptString, z, button);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyPackage$8$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m195lambda$buyPackage$8$comzenoappCarRacingPackageShopActivity(String str, boolean z, final Button button) {
        if (isFinishing()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        if (z) {
            button.setText("ဝယ်ပြီး");
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m194lambda$buyPackage$7$comzenoappCarRacingPackageShopActivity(button);
                }
            }, 1200L);
        } else {
            button.setEnabled(true);
            button.setText("ဝယ်မည်");
        }
    }

    /* JADX INFO: renamed from: lambda$buyPackage$7$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m194lambda$buyPackage$7$comzenoappCarRacingPackageShopActivity(Button button) {
        if (isFinishing()) {
            return;
        }
        button.setEnabled(true);
        button.setText("ဝယ်မည်");
    }

    private void showLoading() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m204lambda$showLoading$10$comzenoappCarRacingPackageShopActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showLoading$10$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m204lambda$showLoading$10$comzenoappCarRacingPackageShopActivity() {
        if (isFinishing()) {
            return;
        }
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
        this.tvEmpty.setVisibility(8);
        this.svPackages.setVisibility(8);
        this.llPackages.removeAllViews();
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingPackageShopActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m203lambda$showEmpty$11$comzenoappCarRacingPackageShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$11$com-zeno-app-CarRacingPackageShopActivity, reason: not valid java name */
    /* synthetic */ void m203lambda$showEmpty$11$comzenoappCarRacingPackageShopActivity(String str) {
        if (isFinishing()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svPackages.setVisibility(8);
        this.tvEmpty.setText(str);
        this.tvEmpty.setVisibility(0);
    }

    protected void onDestroy() {
        this.exec.shutdownNow();
        super.onDestroy();
    }
}
