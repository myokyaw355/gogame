package com.zeno.app;

import android.content.Context;
import android.content.SharedPreferences;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SessionManager {
    private static final String KEY_ACCESS_TOKEN = "access_token";
    private static final String KEY_AVATAR_URL = "avatar_url";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_EXPIRY = "expiry";
    private static final String KEY_FULL_NAME = "full_name";
    private static final String KEY_GAME_TOKEN = "game_token";
    private static final String KEY_KONG_PLAYER_AVATAR = "kong_player_avatar";
    private static final String KEY_KONG_PLAYER_NAME = "kong_player_name";
    private static final String KEY_KONG_PLAYER_PHONE = "kong_player_phone";
    private static final String KEY_KONG_TOKEN = "kong_game_token";
    private static final String KEY_MCUID = "mcuid";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_RAW_TPT_TOKEN = "raw_tpt_token";
    private static final String KEY_REFRESH_TOKEN = "refresh_token";
    private static final String KEY_SC_GAME_TOKEN = "sc_game_token";
    private static final String KEY_SC_HIGHEST_LEVEL = "sc_highest_level";
    private static final String KEY_SC_PLAYER_AVATAR = "sc_player_avatar";
    private static final String KEY_SC_PLAYER_NAME = "sc_player_name";
    private static final String KEY_SC_PLAYER_PHONE = "sc_player_phone";
    private static final String KEY_SC_TOTAL_SCORE = "sc_total_score";
    private static final String KEY_TPT_SUB = "tpt_sub";
    private static final String KEY_UUID = "uuid";
    private static final String PREF_NAME = "ZenoMyIDSession";
    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, 0);
    }

    public void saveTokens(String str, String str2, long j) {
        this.prefs.edit().putString(KEY_ACCESS_TOKEN, str).putString(KEY_REFRESH_TOKEN, str2).putLong(KEY_EXPIRY, System.currentTimeMillis() + (j * 1000)).apply();
    }

    public void saveGameSession(String str, String str2, String str3, String str4, String str5) {
        SharedPreferences.Editor editorEdit = this.prefs.edit();
        if (str != null && !str.isEmpty()) {
            editorEdit.putString(KEY_GAME_TOKEN, str);
        }
        if (str2 != null && !str2.isEmpty()) {
            editorEdit.putString(KEY_RAW_TPT_TOKEN, str2);
        }
        if (str3 != null && !str3.isEmpty()) {
            editorEdit.putString(KEY_UUID, str3);
        }
        if (str4 != null && !str4.isEmpty()) {
            editorEdit.putString(KEY_MCUID, str4);
        }
        if (str5 != null && !str5.isEmpty()) {
            editorEdit.putString(KEY_TPT_SUB, str5);
        }
        editorEdit.apply();
    }

    public void saveUserInfo(String str, String str2, String str3) {
        this.prefs.edit().putString(KEY_PHONE, str).putString(KEY_FULL_NAME, str2).putString(KEY_AVATAR_URL, str3).apply();
    }

    public void saveDeviceId(String str) {
        this.prefs.edit().putString(KEY_DEVICE_ID, str).apply();
    }

    public String getAccessToken() {
        return this.prefs.getString(KEY_ACCESS_TOKEN, null);
    }

    public String getRefreshToken() {
        return this.prefs.getString(KEY_REFRESH_TOKEN, null);
    }

    public String getGameToken() {
        return this.prefs.getString(KEY_GAME_TOKEN, null);
    }

    public String getRawTptToken() {
        return this.prefs.getString(KEY_RAW_TPT_TOKEN, null);
    }

    public String getUuid() {
        return this.prefs.getString(KEY_UUID, "");
    }

    public String getMcuid() {
        return this.prefs.getString(KEY_MCUID, "");
    }

    public String getTptSub() {
        return this.prefs.getString(KEY_TPT_SUB, "");
    }

    public String getPhone() {
        return this.prefs.getString(KEY_PHONE, "");
    }

    public String getFullName() {
        return this.prefs.getString(KEY_FULL_NAME, "");
    }

    public String getAvatarUrl() {
        return this.prefs.getString(KEY_AVATAR_URL, null);
    }

    public String getDeviceId() {
        return this.prefs.getString(KEY_DEVICE_ID, "7191a715889ab704");
    }

    public long getExpiry() {
        return this.prefs.getLong(KEY_EXPIRY, 0L);
    }

    public void setExpiry(long j) {
        this.prefs.edit().putLong(KEY_EXPIRY, j).apply();
    }

    public boolean isLoggedIn() {
        String accessToken = getAccessToken();
        return (accessToken == null || accessToken.isEmpty()) ? false : true;
    }

    public String getScGameToken() {
        return this.prefs.getString(KEY_SC_GAME_TOKEN, null);
    }

    public void saveScGameToken(String str) {
        if (str == null || str.isEmpty()) {
            return;
        }
        this.prefs.edit().putString(KEY_SC_GAME_TOKEN, str).apply();
    }

    public int getScHighestLevel() {
        return this.prefs.getInt(KEY_SC_HIGHEST_LEVEL, 1);
    }

    public void updateScHighestLevel(int i) {
        if (i > getScHighestLevel()) {
            this.prefs.edit().putInt(KEY_SC_HIGHEST_LEVEL, i).apply();
        }
    }

    public long getScTotalScore() {
        return this.prefs.getLong(KEY_SC_TOTAL_SCORE, 0L);
    }

    public void saveScTotalScore(long j) {
        if (j > 0) {
            this.prefs.edit().putLong(KEY_SC_TOTAL_SCORE, j).apply();
        }
    }

    public String getKongToken() {
        return this.prefs.getString(KEY_KONG_TOKEN, null);
    }

    public void saveKongToken(String str) {
        if (str == null || str.isEmpty()) {
            return;
        }
        this.prefs.edit().putString(KEY_KONG_TOKEN, str).apply();
    }

    public void clearKongSession() {
        this.prefs.edit().remove(KEY_KONG_TOKEN).remove(KEY_KONG_PLAYER_NAME).remove(KEY_KONG_PLAYER_PHONE).remove(KEY_KONG_PLAYER_AVATAR).apply();
    }

    public String getKongPlayerName() {
        return this.prefs.getString(KEY_KONG_PLAYER_NAME, null);
    }

    public String getKongPlayerPhone() {
        return this.prefs.getString(KEY_KONG_PLAYER_PHONE, null);
    }

    public String getKongPlayerAvatar() {
        return this.prefs.getString(KEY_KONG_PLAYER_AVATAR, null);
    }

    public void saveKongProfile(String str, String str2, String str3) {
        SharedPreferences.Editor editorEdit = this.prefs.edit();
        if (str != null && !str.isEmpty()) {
            editorEdit.putString(KEY_KONG_PLAYER_NAME, str);
        }
        if (str2 != null && !str2.isEmpty()) {
            editorEdit.putString(KEY_KONG_PLAYER_PHONE, str2);
        }
        if (str3 != null && !str3.isEmpty()) {
            editorEdit.putString(KEY_KONG_PLAYER_AVATAR, str3);
        }
        editorEdit.apply();
    }

    public String getScPlayerName() {
        return this.prefs.getString(KEY_SC_PLAYER_NAME, null);
    }

    public String getScPlayerPhone() {
        return this.prefs.getString(KEY_SC_PLAYER_PHONE, null);
    }

    public String getScPlayerAvatar() {
        return this.prefs.getString(KEY_SC_PLAYER_AVATAR, null);
    }

    public void saveScProfile(String str, String str2, String str3) {
        SharedPreferences.Editor editorEdit = this.prefs.edit();
        if (str != null && !str.isEmpty()) {
            editorEdit.putString(KEY_SC_PLAYER_NAME, str);
        }
        if (str2 != null && !str2.isEmpty()) {
            editorEdit.putString(KEY_SC_PLAYER_PHONE, str2);
        }
        if (str3 != null && !str3.isEmpty()) {
            editorEdit.putString(KEY_SC_PLAYER_AVATAR, str3);
        }
        editorEdit.apply();
    }

    public void clearScSession() {
        this.prefs.edit().remove(KEY_SC_GAME_TOKEN).remove(KEY_SC_PLAYER_NAME).remove(KEY_SC_PLAYER_PHONE).remove(KEY_SC_PLAYER_AVATAR).remove(KEY_SC_HIGHEST_LEVEL).remove(KEY_SC_TOTAL_SCORE).apply();
    }

    public void clear() {
        this.prefs.edit().clear().apply();
    }

    private static String loopKey(String str) {
        return "always_loop_" + str;
    }

    public void saveAlwaysLoop(String str, boolean z) {
        this.prefs.edit().putBoolean(loopKey(str), z).apply();
    }

    public boolean getAlwaysLoop(String str) {
        return this.prefs.getBoolean(loopKey(str), false);
    }
}
