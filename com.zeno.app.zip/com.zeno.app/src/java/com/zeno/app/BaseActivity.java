package com.zeno.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class BaseActivity extends AppCompatActivity {
    public static final String KEY_KEEP_SCREEN_ON = "keep_screen_on";
    public static final String PREFS_APP = "app_settings";

    public static boolean isKeepScreenOnEnabled(Context context) {
        return context.getSharedPreferences(PREFS_APP, 0).getBoolean(KEY_KEEP_SCREEN_ON, true);
    }

    public static void setKeepScreenOnEnabled(Context context, boolean z) {
        context.getSharedPreferences(PREFS_APP, 0).edit().putBoolean(KEY_KEEP_SCREEN_ON, z).apply();
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        applyKeepScreenOnFlag();
    }

    protected void onResume() {
        super.onResume();
        applyKeepScreenOnFlag();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void applyKeepScreenOnFlag() {
        if (isKeepScreenOnEnabled(this)) {
            getWindow().addFlags(128);
        } else {
            getWindow().clearFlags(128);
        }
    }

    protected void attachBaseContext(Context context) {
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.fontScale = 1.0f;
        super.attachBaseContext(context.createConfigurationContext(configuration));
    }

    public Resources getResources() {
        Resources resources = super.getResources();
        if (resources.getConfiguration().fontScale != 1.0f) {
            Configuration configuration = new Configuration(resources.getConfiguration());
            configuration.fontScale = 1.0f;
            resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        }
        return resources;
    }
}
