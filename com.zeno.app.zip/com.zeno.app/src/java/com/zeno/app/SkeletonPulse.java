package com.zeno.app;

import android.animation.ValueAnimator;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final class SkeletonPulse {
    public static final String TAG = "skeleton_line";

    private SkeletonPulse() {
    }

    public static ValueAnimator start(View view) {
        if (view == null) {
            return null;
        }
        final ArrayList arrayList = new ArrayList();
        collect(view, arrayList);
        if (arrayList.isEmpty()) {
            return null;
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((View) it.next()).setAlpha(0.35f);
        }
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.35f, 1.0f);
        valueAnimatorOfFloat.setDuration(900L);
        valueAnimatorOfFloat.setRepeatMode(2);
        valueAnimatorOfFloat.setRepeatCount(-1);
        valueAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
        valueAnimatorOfFloat.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() { // from class: com.zeno.app.SkeletonPulse$$ExternalSyntheticLambda0
            @Override // android.animation.ValueAnimator.AnimatorUpdateListener
            public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                SkeletonPulse.lambda$start$0(arrayList, valueAnimator);
            }
        });
        valueAnimatorOfFloat.start();
        return valueAnimatorOfFloat;
    }

    static /* synthetic */ void lambda$start$0(List list, ValueAnimator valueAnimator) {
        float fFloatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            ((View) it.next()).setAlpha(fFloatValue);
        }
    }

    public static void stop(ValueAnimator valueAnimator, View view) {
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        if (view == null) {
            return;
        }
        ArrayList arrayList = new ArrayList();
        collect(view, arrayList);
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((View) it.next()).setAlpha(1.0f);
        }
    }

    private static void collect(View view, List<View> list) {
        if (view == null) {
            return;
        }
        Object tag = view.getTag();
        if (tag != null && TAG.equals(String.valueOf(tag))) {
            list.add(view);
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                collect(viewGroup.getChildAt(i), list);
            }
        }
    }
}
