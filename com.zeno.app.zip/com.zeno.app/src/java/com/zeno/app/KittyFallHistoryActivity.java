package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.zeno.app.KittyFallService;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class KittyFallHistoryActivity extends BaseActivity {
    private final ServiceConnection connection = new ServiceConnection() { // from class: com.zeno.app.KittyFallHistoryActivity.1
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            KittyFallHistoryActivity.this.service = ((KittyFallService.ServiceBinder) iBinder).getService();
            KittyFallHistoryActivity.this.serviceBound = true;
            KittyFallHistoryActivity.this.fetchHistory();
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            KittyFallHistoryActivity.this.serviceBound = false;
            KittyFallHistoryActivity.this.service = null;
        }
    };
    private LinearLayout llError;
    private LinearLayout llLoading;
    private LinearLayout llRows;
    private KittyFallService service;
    private boolean serviceBound;
    private ValueAnimator skeletonAnim;
    private ScrollView svRows;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvError;

    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        setContentView(R.layout.activity_kitty_fall_history);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        if (toolbar != null) {
            toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallHistoryActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m488lambda$onCreate$0$comzenoappKittyFallHistoryActivity(view);
                }
            });
        }
        this.llLoading = (LinearLayout) findViewById(R.id.llKittyHistLoading);
        this.llError = (LinearLayout) findViewById(R.id.llKittyHistError);
        this.tvError = (TextView) findViewById(R.id.tvKittyHistError);
        this.svRows = (ScrollView) findViewById(R.id.svKittyHist);
        this.llRows = (LinearLayout) findViewById(R.id.llKittyHistRows);
        Button button = (Button) findViewById(R.id.btnKittyHistRetry);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallHistoryActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m489lambda$onCreate$1$comzenoappKittyFallHistoryActivity(view);
                }
            });
        }
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        if (swipeRefreshLayoutFindViewById != null) {
            swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.KittyFallHistoryActivity$$ExternalSyntheticLambda2
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return this.f$0.m490lambda$onCreate$2$comzenoappKittyFallHistoryActivity(swipeRefreshLayout, view);
                }
            });
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.KittyFallHistoryActivity$$ExternalSyntheticLambda3
                public final void onRefresh() {
                    this.f$0.refreshHistory();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-KittyFallHistoryActivity, reason: not valid java name */
    /* synthetic */ void m488lambda$onCreate$0$comzenoappKittyFallHistoryActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-KittyFallHistoryActivity, reason: not valid java name */
    /* synthetic */ void m489lambda$onCreate$1$comzenoappKittyFallHistoryActivity(View view) {
        fetchHistory();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-KittyFallHistoryActivity, reason: not valid java name */
    /* synthetic */ boolean m490lambda$onCreate$2$comzenoappKittyFallHistoryActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        ScrollView scrollView = this.svRows;
        return scrollView != null && scrollView.getVisibility() == 0 && this.svRows.canScrollVertically(-1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent((Context) this, (Class<?>) KittyFallService.class);
        startService(intent);
        bindService(intent, this.connection, 1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStop() {
        super.onStop();
        if (this.serviceBound) {
            unbindService(this.connection);
            this.serviceBound = false;
        }
        KittyFallService kittyFallService = this.service;
        if (kittyFallService == null || !kittyFallService.isRunning()) {
            stopService(new Intent((Context) this, (Class<?>) KittyFallService.class));
        }
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchHistory() {
        loadHistory();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshHistory() {
        loadHistory();
    }

    private void loadHistory() {
        if (this.service == null) {
            showError("ခဏစောင့်ပေးပါ, ပြန်ကြိုးစားပါ");
            return;
        }
        startSkeleton();
        this.llError.setVisibility(8);
        this.service.fetchHistory(new KittyFallService.HistoryCallback() { // from class: com.zeno.app.KittyFallHistoryActivity.2
            @Override // com.zeno.app.KittyFallService.HistoryCallback
            public void onHistory(List<KittyFallService.HistoryEntry> list) {
                KittyFallHistoryActivity.this.stopSkeleton();
                KittyFallHistoryActivity.this.llRows.removeAllViews();
                if (list.isEmpty()) {
                    KittyFallHistoryActivity.this.addEmptyView("မှတ်တမ်း မရှိသေးပါ");
                } else {
                    Iterator<KittyFallService.HistoryEntry> it = list.iterator();
                    while (it.hasNext()) {
                        KittyFallHistoryActivity.this.addRow(it.next());
                    }
                }
                KittyFallHistoryActivity.this.svRows.setVisibility(0);
            }

            @Override // com.zeno.app.KittyFallService.HistoryCallback
            public void onHistoryError(String str) {
                KittyFallHistoryActivity kittyFallHistoryActivity = KittyFallHistoryActivity.this;
                if (!KittyFallHistoryActivity.ok(str)) {
                    str = "History ဖွင့်၍ မရပါ";
                }
                kittyFallHistoryActivity.showError(str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addRow(KittyFallService.HistoryEntry historyEntry) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_kitty_history_row, (ViewGroup) this.llRows, false);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistDate)).setText(historyEntry.date);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistTime)).setText(historyEntry.time);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistTitle)).setText(historyEntry.title);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistDifficulty)).setText(historyEntry.difficulty);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistDesc)).setText(historyEntry.description);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistMb)).setText(historyEntry.mbValue);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistMbUnit)).setText(" " + historyEntry.mbUnit);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistScore)).setText(historyEntry.scoreValue);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistScoreUnit)).setText(" " + historyEntry.scoreUnit);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistLoyalty)).setText(historyEntry.loyaltyValue);
        ((TextView) viewInflate.findViewById(R.id.tvKittyHistLoyaltyUnit)).setText(" " + historyEntry.loyaltyUnit);
        this.llRows.addView(viewInflate);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addEmptyView(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setTextSize(16.0f);
        textView.setGravity(17);
        textView.setPadding(24, 120, 24, 120);
        this.llRows.addView(textView);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showError(String str) {
        stopSkeleton();
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        this.svRows.setVisibility(8);
        this.tvError.setText(str);
        this.llError.setVisibility(0);
    }

    private void startSkeleton() {
        if (this.llLoading == null) {
            return;
        }
        ScrollView scrollView = this.svRows;
        if (scrollView != null) {
            scrollView.setVisibility(8);
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopSkeleton() {
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean ok(String str) {
        return (str == null || str.trim().isEmpty()) ? false : true;
    }
}
