package com.zeno.app;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final /* synthetic */ class SoftClimbersActivity$$ExternalSyntheticLambda21 implements Runnable {
    public final /* synthetic */ SoftClimbersActivity f$0;

    public /* synthetic */ SoftClimbersActivity$$ExternalSyntheticLambda21(SoftClimbersActivity softClimbersActivity) {
        this.f$0 = softClimbersActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.stopProfileSkeleton();
    }
}
