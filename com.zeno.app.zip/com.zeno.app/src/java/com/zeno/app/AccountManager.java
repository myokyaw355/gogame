package com.zeno.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public class AccountManager {
    private static final String KEY_CURRENT = "current_phone";
    private static final String KEY_LIST = "accounts_json";
    private static final String PREF = "ZenoMyIDAccounts";
    private final SharedPreferences prefs;

    public AccountManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF, 0);
    }

    public static class Account {
        public String accessToken;
        public String avatarUrl;
        public String deviceId;
        public long expiry;
        public String fullName;
        public String gameToken;
        public String kongToken;
        public String mcuid;
        public String phone;
        public String rawTptToken;
        public String refreshToken;
        public String scGameToken;
        public String tptSub;
        public String uuid;

        public JSONObject toJson() throws Exception {
            JSONObject jSONObject = new JSONObject();
            String str = this.phone;
            if (str == null) {
                str = "";
            }
            jSONObject.put("phone", str);
            String str2 = this.fullName;
            if (str2 == null) {
                str2 = "";
            }
            jSONObject.put("fullName", str2);
            String str3 = this.avatarUrl;
            if (str3 == null) {
                str3 = "";
            }
            jSONObject.put("avatarUrl", str3);
            String str4 = this.accessToken;
            if (str4 == null) {
                str4 = "";
            }
            jSONObject.put("accessToken", str4);
            String str5 = this.refreshToken;
            if (str5 == null) {
                str5 = "";
            }
            jSONObject.put("refreshToken", str5);
            String str6 = this.gameToken;
            if (str6 == null) {
                str6 = "";
            }
            jSONObject.put("gameToken", str6);
            String str7 = this.rawTptToken;
            if (str7 == null) {
                str7 = "";
            }
            jSONObject.put("rawTptToken", str7);
            String str8 = this.uuid;
            if (str8 == null) {
                str8 = "";
            }
            jSONObject.put("uuid", str8);
            String str9 = this.mcuid;
            if (str9 == null) {
                str9 = "";
            }
            jSONObject.put("mcuid", str9);
            String str10 = this.tptSub;
            if (str10 == null) {
                str10 = "";
            }
            jSONObject.put("tptSub", str10);
            String str11 = this.deviceId;
            if (str11 == null) {
                str11 = "";
            }
            jSONObject.put("deviceId", str11);
            String str12 = this.scGameToken;
            if (str12 == null) {
                str12 = "";
            }
            jSONObject.put("scGameToken", str12);
            String str13 = this.kongToken;
            jSONObject.put("kongToken", str13 != null ? str13 : "");
            jSONObject.put("expiry", this.expiry);
            return jSONObject;
        }

        public static Account fromJson(JSONObject jSONObject) {
            Account account = new Account();
            account.phone = jSONObject.optString("phone", "");
            account.fullName = jSONObject.optString("fullName", "");
            account.avatarUrl = jSONObject.optString("avatarUrl", "");
            account.accessToken = jSONObject.optString("accessToken", "");
            account.refreshToken = jSONObject.optString("refreshToken", "");
            account.gameToken = jSONObject.optString("gameToken", "");
            account.rawTptToken = jSONObject.optString("rawTptToken", "");
            account.uuid = jSONObject.optString("uuid", "");
            account.mcuid = jSONObject.optString("mcuid", "");
            account.tptSub = jSONObject.optString("tptSub", "");
            account.deviceId = jSONObject.optString("deviceId", "");
            account.scGameToken = jSONObject.optString("scGameToken", "");
            account.kongToken = jSONObject.optString("kongToken", "");
            account.expiry = jSONObject.optLong("expiry", 0L);
            return account;
        }
    }

    public List<Account> getAccounts() {
        ArrayList arrayList = new ArrayList();
        try {
            JSONArray jSONArray = new JSONArray(this.prefs.getString(KEY_LIST, "[]"));
            for (int i = 0; i < jSONArray.length(); i++) {
                arrayList.add(Account.fromJson(jSONArray.getJSONObject(i)));
            }
        } catch (Exception unused) {
        }
        return arrayList;
    }

    private void saveList(List<Account> list) {
        try {
            JSONArray jSONArray = new JSONArray();
            Iterator<Account> it = list.iterator();
            while (it.hasNext()) {
                jSONArray.put(it.next().toJson());
            }
            this.prefs.edit().putString(KEY_LIST, jSONArray.toString()).apply();
        } catch (Exception unused) {
        }
    }

    public String getCurrentPhone() {
        return this.prefs.getString(KEY_CURRENT, "");
    }

    public void setCurrentPhone(String str) {
        SharedPreferences.Editor editorEdit = this.prefs.edit();
        if (str == null) {
            str = "";
        }
        editorEdit.putString(KEY_CURRENT, str).apply();
    }

    public void upsert(Account account) {
        if (account == null || account.phone == null || account.phone.isEmpty()) {
            return;
        }
        List<Account> accounts = getAccounts();
        ArrayList arrayList = new ArrayList();
        arrayList.add(account);
        for (Account account2 : accounts) {
            if (account2.phone == null || !account2.phone.equals(account.phone)) {
                arrayList.add(account2);
            }
        }
        saveList(arrayList);
        setCurrentPhone(account.phone);
    }

    public Account findByPhone(String str) {
        if (str == null) {
            return null;
        }
        for (Account account : getAccounts()) {
            if (str.equals(account.phone)) {
                return account;
            }
        }
        return null;
    }

    public void delete(String str) {
        if (str == null) {
            return;
        }
        List<Account> accounts = getAccounts();
        ArrayList arrayList = new ArrayList();
        for (Account account : accounts) {
            if (!str.equals(account.phone)) {
                arrayList.add(account);
            }
        }
        saveList(arrayList);
        if (str.equals(getCurrentPhone())) {
            setCurrentPhone(arrayList.isEmpty() ? "" : arrayList.get(0).phone);
        }
    }

    public void saveFromSession(SessionManager sessionManager) {
        if (sessionManager == null || !sessionManager.isLoggedIn()) {
            return;
        }
        Account account = new Account();
        account.phone = sessionManager.getPhone();
        account.fullName = sessionManager.getFullName();
        account.avatarUrl = sessionManager.getAvatarUrl();
        account.accessToken = sessionManager.getAccessToken();
        account.refreshToken = sessionManager.getRefreshToken();
        account.gameToken = sessionManager.getGameToken();
        account.rawTptToken = sessionManager.getRawTptToken();
        account.uuid = sessionManager.getUuid();
        account.mcuid = sessionManager.getMcuid();
        account.tptSub = sessionManager.getTptSub();
        account.deviceId = sessionManager.getDeviceId();
        account.scGameToken = sessionManager.getScGameToken();
        account.kongToken = sessionManager.getKongToken();
        account.expiry = sessionManager.getExpiry();
        upsert(account);
    }

    public void applyToSession(SessionManager sessionManager, Account account) {
        if (sessionManager == null || account == null) {
            return;
        }
        sessionManager.clear();
        if (account.accessToken != null && !account.accessToken.isEmpty()) {
            sessionManager.saveTokens(account.accessToken, account.refreshToken, account.expiry > System.currentTimeMillis() ? Math.max(1L, (account.expiry - System.currentTimeMillis()) / 1000) : 604800L);
            sessionManager.setExpiry(account.expiry);
        }
        sessionManager.saveUserInfo(account.phone, account.fullName, account.avatarUrl);
        sessionManager.saveGameSession(account.gameToken, account.rawTptToken, account.uuid, account.mcuid, account.tptSub);
        if (account.deviceId != null && !account.deviceId.isEmpty()) {
            sessionManager.saveDeviceId(account.deviceId);
        }
        if (account.scGameToken != null && !account.scGameToken.isEmpty()) {
            sessionManager.saveScGameToken(account.scGameToken);
        }
        if (account.kongToken != null && !account.kongToken.isEmpty()) {
            sessionManager.saveKongToken(account.kongToken);
        }
        setCurrentPhone(account.phone);
    }
}
