package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import com.zeno.app.SpinWheelView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SpinWheelActivity extends AppCompatActivity {
    private static final int[] SEG_BG = {-15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598};
    private static final String TAG = "SpinWheelActivity";
    private String base;
    private TextView btnAutoSpin;
    private Button btnSpin;
    private View cardLoading;
    private ValueAnimator cardSkeletonAnim;
    private View chipRow;
    private View controlsLoading;
    private ValueAnimator controlsSkeletonAnim;
    private TextView[] countChips;
    private String kongToken;
    private SpinWheelView spinWheelView;
    private TextView tvBananaBalance;
    private TextView tvFreeSpins;
    private TextView tvSpinPrice;
    private View wheelLoading;
    private ValueAnimator wheelSkeletonAnim;
    private int turnFree = 0;
    private int spinPrice = 0;
    private long bananas = 0;
    private final List<JSONObject> spinItems = new ArrayList();
    private int autoSpinCount = 1;
    private int autoRemaining = 0;
    private boolean isAutoSpinning = false;
    private final List<JSONObject> autoResults = new ArrayList();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_spin_wheel);
        this.kongToken = getIntent().getStringExtra("kongToken");
        this.base = getIntent().getStringExtra("base");
        this.bananas = getIntent().getLongExtra("bananas", 0L);
        bindViews();
        updateBananaDisplay();
        fetchSpinList();
    }

    private void bindViews() {
        this.spinWheelView = (SpinWheelView) findViewById(R.id.spinWheelView);
        this.wheelLoading = findViewById(R.id.wheelLoading);
        this.cardLoading = findViewById(R.id.cardLoading);
        this.btnSpin = (Button) findViewById(R.id.btnSpin);
        this.tvFreeSpins = (TextView) findViewById(R.id.tvFreeSpins);
        this.tvSpinPrice = (TextView) findViewById(R.id.tvSpinPrice);
        this.tvBananaBalance = (TextView) findViewById(R.id.tvBananaBalance);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m728lambda$bindViews$0$comzenoappSpinWheelActivity(view);
            }
        });
        Button button = this.btnSpin;
        if (button != null) {
            button.setVisibility(8);
            this.btnSpin.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m729lambda$bindViews$1$comzenoappSpinWheelActivity(view);
                }
            });
        }
        setupAutoSpinUi();
    }

    /* JADX INFO: renamed from: lambda$bindViews$0$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m728lambda$bindViews$0$comzenoappSpinWheelActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$bindViews$1$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m729lambda$bindViews$1$comzenoappSpinWheelActivity(View view) {
        if (this.isAutoSpinning) {
            stopAutoSpin();
        } else {
            doSpin();
        }
    }

    private void fetchSpinList() {
        this.wheelLoading.setVisibility(0);
        this.wheelSkeletonAnim = SkeletonPulse.start(this.wheelLoading);
        this.spinWheelView.setVisibility(8);
        this.cardLoading.setVisibility(0);
        this.cardSkeletonAnim = SkeletonPulse.start(this.cardLoading);
        View view = this.controlsLoading;
        if (view != null) {
            view.setVisibility(0);
            this.controlsSkeletonAnim = SkeletonPulse.start(this.controlsLoading);
        }
        this.btnSpin.setEnabled(false);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m740lambda$fetchSpinList$5$comzenoappSpinWheelActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$5$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m740lambda$fetchSpinList$5$comzenoappSpinWheelActivity() {
        HttpResult req = getReq(this.base + "/api/luckSpin/list");
        if (req == null || req.code != 200) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m737lambda$fetchSpinList$2$comzenoappSpinWheelActivity();
                }
            });
            return;
        }
        try {
            JSONObject jSONObjectOptJSONObject = new JSONObject(req.body).optJSONObject("data");
            final JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("luckySpin") : null;
            final int iOptInt = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("turnFree", 0) : 0;
            final int iOptInt2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("price", 0) : 0;
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m738lambda$fetchSpinList$3$comzenoappSpinWheelActivity(iOptInt, iOptInt2, jSONArrayOptJSONArray);
                }
            });
        } catch (Exception unused) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda19
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m739lambda$fetchSpinList$4$comzenoappSpinWheelActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$2$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m737lambda$fetchSpinList$2$comzenoappSpinWheelActivity() {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        toast("Spin list ရယူ၍မရပါ");
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$3$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m738lambda$fetchSpinList$3$comzenoappSpinWheelActivity(int i, int i2, JSONArray jSONArray) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        this.spinWheelView.setVisibility(0);
        this.turnFree = i;
        this.spinPrice = i2;
        this.tvFreeSpins.setText(String.valueOf(i));
        this.tvSpinPrice.setText(String.format(Locale.getDefault(), "%,d", Integer.valueOf(i2)));
        this.spinItems.clear();
        ArrayList arrayList = new ArrayList();
        if (jSONArray != null) {
            for (int i3 = 0; i3 < jSONArray.length(); i3++) {
                try {
                    JSONObject jSONObject = jSONArray.getJSONObject(i3);
                    this.spinItems.add(jSONObject);
                    arrayList.add(buildSegment(jSONObject, i3));
                } catch (Exception unused) {
                }
            }
        }
        this.spinWheelView.setSegments(arrayList);
        refreshSpinButton();
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$4$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m739lambda$fetchSpinList$4$comzenoappSpinWheelActivity() {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        toast("Parse error");
    }

    private void hideCardLoading() {
        SkeletonPulse.stop(this.cardSkeletonAnim, this.cardLoading);
        this.cardSkeletonAnim = null;
        View viewFindViewById = findViewById(R.id.freeSpinsSkeleton);
        View viewFindViewById2 = findViewById(R.id.spinPriceSkeleton);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(8);
        }
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(8);
        }
        TextView textView = this.tvFreeSpins;
        if (textView != null) {
            textView.setVisibility(0);
        }
        TextView textView2 = this.tvSpinPrice;
        if (textView2 != null) {
            textView2.setVisibility(0);
        }
    }

    private void hideControlsLoading() {
        SkeletonPulse.stop(this.controlsSkeletonAnim, this.controlsLoading);
        this.controlsSkeletonAnim = null;
        View view = this.controlsLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.chipRow;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        TextView[] textViewArr = this.countChips;
        if (textViewArr != null) {
            for (TextView textView : textViewArr) {
                if (textView != null) {
                    textView.setVisibility(0);
                }
            }
        }
        TextView textView2 = this.btnAutoSpin;
        if (textView2 != null) {
            textView2.setVisibility(0);
        }
    }

    private SpinWheelView.Segment buildSegment(JSONObject jSONObject, int i) {
        String strOptString = jSONObject.optString("description", "?");
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("rewards");
        int iOptInt = 0;
        if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0) {
            try {
                iOptInt = jSONArrayOptJSONArray.getJSONObject(0).optInt("value", 0);
            } catch (Exception unused) {
            }
        }
        String strRewardEmoji = rewardEmoji(strOptString);
        Bitmap bitmapRewardBitmap = rewardBitmap(strOptString);
        String str = "×" + iOptInt;
        int[] iArr = SEG_BG;
        return new SpinWheelView.Segment(strRewardEmoji, str, iArr[i % iArr.length], i % 2 == 0 ? -3632086 : -1, bitmapRewardBitmap);
    }

    private Bitmap rewardBitmap(String str) {
        if (str == null) {
            return null;
        }
        String upperCase = str.toUpperCase(Locale.ROOT);
        upperCase.hashCode();
        switch (upperCase) {
        }
        return null;
    }

    private Bitmap loadBitmap(int i) {
        try {
            return BitmapFactory.decodeResource(getResources(), i);
        } catch (Exception unused) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doSpin() {
        if (this.spinWheelView.isSpinning()) {
            return;
        }
        if (this.turnFree <= 0 && this.bananas < this.spinPrice) {
            toast("Banana မလောက်ပါ");
            if (this.isAutoSpinning) {
                finishAutoSpin();
                return;
            }
            return;
        }
        Button button = this.btnSpin;
        if (button != null) {
            button.setEnabled(false);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m732lambda$doSpin$12$comzenoappSpinWheelActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doSpin$12$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m732lambda$doSpin$12$comzenoappSpinWheelActivity() {
        final HttpResult req = getReq(this.base + "/api/luckSpin/spin");
        if (req == null || req.code != 200) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m733lambda$doSpin$6$comzenoappSpinWheelActivity(req);
                }
            });
            return;
        }
        try {
            final JSONObject jSONObjectOptJSONObject = new JSONObject(req.body).optJSONObject("data");
            int iOptInt = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("id", -1) : -1;
            final int i = 0;
            int i2 = 0;
            while (true) {
                if (i2 >= this.spinItems.size()) {
                    break;
                }
                if (this.spinItems.get(i2).optInt("id", -1) == iOptInt) {
                    i = i2;
                    break;
                }
                i2++;
            }
            int i3 = this.turnFree;
            if (i3 > 0) {
                final int i4 = i3 - 1;
                this.turnFree = i4;
                this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m734lambda$doSpin$7$comzenoappSpinWheelActivity(i4);
                    }
                });
            } else {
                this.bananas -= (long) this.spinPrice;
                updateBananaDisplay();
            }
            final int i5 = this.isAutoSpinning ? 2800 : 4500;
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m730lambda$doSpin$10$comzenoappSpinWheelActivity(i, i5, jSONObjectOptJSONObject);
                }
            });
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m731lambda$doSpin$11$comzenoappSpinWheelActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$6$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m733lambda$doSpin$6$comzenoappSpinWheelActivity(HttpResult httpResult) {
        String str;
        if (this.isAutoSpinning) {
            finishAutoSpin();
        } else {
            refreshSpinButton();
        }
        StringBuilder sb = new StringBuilder("Spin မအောင်မြင်ပါ");
        if (httpResult != null) {
            str = " (" + httpResult.code + ")";
        } else {
            str = "";
        }
        sb.append(str);
        toast(sb.toString());
    }

    /* JADX INFO: renamed from: lambda$doSpin$7$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m734lambda$doSpin$7$comzenoappSpinWheelActivity(int i) {
        this.tvFreeSpins.setText(String.valueOf(i));
    }

    /* JADX INFO: renamed from: lambda$doSpin$10$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m730lambda$doSpin$10$comzenoappSpinWheelActivity(int i, int i2, final JSONObject jSONObject) {
        this.spinWheelView.spinToIndex(i, i2, new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m736lambda$doSpin$9$comzenoappSpinWheelActivity(jSONObject);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doSpin$9$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m736lambda$doSpin$9$comzenoappSpinWheelActivity(JSONObject jSONObject) {
        if (this.isAutoSpinning) {
            if (jSONObject != null) {
                this.autoResults.add(jSONObject);
            }
            this.autoRemaining--;
            TextView textView = this.btnAutoSpin;
            if (textView != null) {
                textView.setText("STOP  (" + Math.max(this.autoRemaining, 0) + " left)");
            }
            final boolean z = this.autoRemaining > 0 && (this.turnFree > 0 || this.bananas >= ((long) this.spinPrice)) && this.isAutoSpinning;
            showResultDialog(jSONObject, new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m735lambda$doSpin$8$comzenoappSpinWheelActivity(z);
                }
            });
            return;
        }
        showResultDialog(jSONObject, null);
        refreshSpinButton();
    }

    /* JADX INFO: renamed from: lambda$doSpin$8$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m735lambda$doSpin$8$comzenoappSpinWheelActivity(boolean z) {
        if (z && this.isAutoSpinning) {
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.doSpin();
                }
            }, 400L);
        } else {
            finishAutoSpin();
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$11$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m731lambda$doSpin$11$comzenoappSpinWheelActivity(Exception exc) {
        if (this.isAutoSpinning) {
            finishAutoSpin();
        } else {
            refreshSpinButton();
        }
        toast("Error: " + exc.getMessage());
    }

    private void showResultDialog(JSONObject jSONObject) {
        showResultDialog(jSONObject, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showResultDialog(JSONObject jSONObject, final Runnable runnable) {
        String strOptString;
        int iOptInt;
        JSONObject jSONObject2;
        if (jSONObject == null || isFinishing()) {
            if (runnable != null) {
                runnable.run();
                return;
            }
            return;
        }
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_spin_result);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85f), -2);
        }
        String str = "";
        String strOptString2 = jSONObject.optString("description", "");
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("rewards");
        if (jSONArrayOptJSONArray == null || jSONArrayOptJSONArray.length() <= 0) {
            strOptString = strOptString2;
            iOptInt = 0;
        } else {
            try {
                jSONObject2 = jSONArrayOptJSONArray.getJSONObject(0);
                iOptInt = jSONObject2.optInt("value", 0);
            } catch (Exception unused) {
                iOptInt = 0;
            }
            try {
                strOptString = jSONObject2.optString("typeItem", strOptString2);
            } catch (Exception unused2) {
                strOptString = strOptString2;
            }
        }
        ImageView imageView = (ImageView) dialog.findViewById(R.id.resultIcon);
        TextView textView = (TextView) dialog.findViewById(R.id.resultEmoji);
        TextView textView2 = (TextView) dialog.findViewById(R.id.resultTitle);
        TextView textView3 = (TextView) dialog.findViewById(R.id.resultDetail);
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.llResultList);
        Button button = (Button) dialog.findViewById(R.id.btnResultClose);
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        Bitmap bitmapRewardBitmap = rewardBitmap(strOptString2);
        if (imageView != null) {
            if (bitmapRewardBitmap != null) {
                imageView.setImageBitmap(bitmapRewardBitmap);
                imageView.setVisibility(0);
                if (textView != null) {
                    textView.setVisibility(8);
                }
            } else {
                imageView.setVisibility(8);
                if (textView != null) {
                    textView.setText(rewardEmoji(strOptString2));
                    textView.setVisibility(0);
                }
            }
        }
        if (textView2 != null) {
            textView2.setText(rewardFull(strOptString));
        }
        if (textView3 != null) {
            if ("BANANA".equals(strOptString)) {
                str = String.format(Locale.getDefault(), "+%,d", Integer.valueOf(iOptInt));
            } else if (iOptInt > 1) {
                str = "×" + iOptInt;
            }
            textView3.setText(str);
            textView3.setVisibility(str.isEmpty() ? 8 : 0);
        }
        final boolean[] zArr = {false};
        final Runnable[] runnableArr = {null};
        final Runnable runnable2 = new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m743lambda$showResultDialog$13$comzenoappSpinWheelActivity(zArr, runnableArr, dialog, runnable);
            }
        };
        if (button != null) {
            button.setText("ရယူမည်");
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda7
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    runnable2.run();
                }
            });
        }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda8
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                this.f$0.m744lambda$showResultDialog$15$comzenoappSpinWheelActivity(zArr, runnableArr, runnable, dialogInterface);
            }
        });
        dialog.show();
        if (runnable != null) {
            runnableArr[0] = runnable2;
            this.ui.postDelayed(runnable2, 2000L);
        }
    }

    /* JADX INFO: renamed from: lambda$showResultDialog$13$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m743lambda$showResultDialog$13$comzenoappSpinWheelActivity(boolean[] zArr, Runnable[] runnableArr, Dialog dialog, Runnable runnable) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        Runnable runnable2 = runnableArr[0];
        if (runnable2 != null) {
            this.ui.removeCallbacks(runnable2);
        }
        try {
            dialog.dismiss();
        } catch (Exception unused) {
        }
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: renamed from: lambda$showResultDialog$15$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m744lambda$showResultDialog$15$comzenoappSpinWheelActivity(boolean[] zArr, Runnable[] runnableArr, Runnable runnable, DialogInterface dialogInterface) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        Runnable runnable2 = runnableArr[0];
        if (runnable2 != null) {
            this.ui.removeCallbacks(runnable2);
        }
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void setupAutoSpinUi() {
        Button button = this.btnSpin;
        ViewGroup viewGroup = (button == null || !(button.getParent() instanceof ViewGroup)) ? null : (ViewGroup) this.btnSpin.getParent();
        if (viewGroup == null) {
            return;
        }
        float f = getResources().getDisplayMetrics().density;
        int iIndexOfChild = viewGroup.indexOfChild(this.btnSpin);
        LinearLayout linearLayout = new LinearLayout(this);
        this.chipRow = linearLayout;
        linearLayout.setOrientation(0);
        linearLayout.setGravity(17);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int i = (int) (f * 14.0f);
        layoutParams.topMargin = i;
        int i2 = (int) (24.0f * f);
        layoutParams.leftMargin = i2;
        layoutParams.rightMargin = i2;
        linearLayout.setLayoutParams(layoutParams);
        final int[] iArr = {1, 5, 10, 20, 50};
        this.countChips = new TextView[5];
        int i3 = 0;
        for (int i4 = 5; i3 < i4; i4 = 5) {
            final int i5 = iArr[i3];
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, (int) (f * 34.0f), 1.0f);
            if (i3 > 0) {
                layoutParams2.leftMargin = (int) (6.0f * f);
            }
            textView.setLayoutParams(layoutParams2);
            textView.setGravity(17);
            textView.setText(String.valueOf(i5));
            textView.setTextSize(13.0f);
            textView.setTypeface(null, 1);
            textView.setClickable(true);
            textView.setFocusable(true);
            boolean z = i5 == this.autoSpinCount;
            textView.setBackgroundResource(z ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
            textView.setTextColor(z ? -3632086 : -6381922);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda15
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m741lambda$setupAutoSpinUi$16$comzenoappSpinWheelActivity(i5, iArr, view);
                }
            });
            this.countChips[i3] = textView;
            linearLayout.addView(textView);
            i3++;
        }
        viewGroup.addView(linearLayout, iIndexOfChild + 1);
        this.btnAutoSpin = new TextView(this);
        int i6 = (int) (48.0f * f);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, i6);
        int i7 = (int) (10.0f * f);
        layoutParams3.topMargin = i7;
        layoutParams3.leftMargin = i2;
        layoutParams3.rightMargin = i2;
        this.btnAutoSpin.setLayoutParams(layoutParams3);
        this.btnAutoSpin.setGravity(17);
        this.btnAutoSpin.setTextSize(14.0f);
        this.btnAutoSpin.setTypeface(null, 1);
        this.btnAutoSpin.setTextColor(-16777216);
        this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
        this.btnAutoSpin.setClickable(true);
        this.btnAutoSpin.setFocusable(true);
        this.btnAutoSpin.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m742lambda$setupAutoSpinUi$17$comzenoappSpinWheelActivity(view);
            }
        });
        viewGroup.addView(this.btnAutoSpin, iIndexOfChild + 2);
        updateAutoSpinLabel();
        LinearLayout linearLayout2 = new LinearLayout(this);
        this.controlsLoading = linearLayout2;
        linearLayout2.setOrientation(1);
        ((LinearLayout) this.controlsLoading).setGravity(17);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = i;
        layoutParams4.leftMargin = i2;
        layoutParams4.rightMargin = i2;
        this.controlsLoading.setLayoutParams(layoutParams4);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(17);
        for (int i8 = 0; i8 < 5; i8++) {
            View view = new View(this);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(0, (int) (f * 34.0f), 1.0f);
            if (i8 > 0) {
                layoutParams5.leftMargin = (int) (f * 6.0f);
            }
            view.setLayoutParams(layoutParams5);
            view.setTag(SkeletonPulse.TAG);
            view.setBackgroundResource(R.drawable.bg_skeleton_bar);
            linearLayout3.addView(view);
        }
        ((LinearLayout) this.controlsLoading).addView(linearLayout3);
        View view2 = new View(this);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, i6);
        layoutParams6.topMargin = i7;
        view2.setLayoutParams(layoutParams6);
        view2.setTag(SkeletonPulse.TAG);
        view2.setBackgroundResource(R.drawable.bg_skeleton_bar);
        ((LinearLayout) this.controlsLoading).addView(view2);
        for (TextView textView2 : this.countChips) {
            textView2.setVisibility(0);
        }
        View view3 = this.chipRow;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        this.btnAutoSpin.setVisibility(8);
        viewGroup.addView(this.controlsLoading, iIndexOfChild + 3);
    }

    /* JADX INFO: renamed from: lambda$setupAutoSpinUi$16$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m741lambda$setupAutoSpinUi$16$comzenoappSpinWheelActivity(int i, int[] iArr, View view) {
        if (this.isAutoSpinning) {
            return;
        }
        this.autoSpinCount = i;
        int i2 = 0;
        while (true) {
            TextView[] textViewArr = this.countChips;
            if (i2 < textViewArr.length) {
                boolean z = iArr[i2] == this.autoSpinCount;
                textViewArr[i2].setBackgroundResource(z ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
                this.countChips[i2].setTextColor(z ? -3632086 : -6381922);
                i2++;
            } else {
                updateAutoSpinLabel();
                return;
            }
        }
    }

    /* JADX INFO: renamed from: lambda$setupAutoSpinUi$17$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m742lambda$setupAutoSpinUi$17$comzenoappSpinWheelActivity(View view) {
        if (this.isAutoSpinning) {
            stopAutoSpin();
        } else {
            startAutoSpin();
        }
    }

    private void updateAutoSpinLabel() {
        if (this.btnAutoSpin == null || this.isAutoSpinning) {
            return;
        }
        int iMax = Math.max(1, this.autoSpinCount);
        int iMin = Math.min(this.turnFree, iMax);
        int i = iMax - iMin;
        long j = ((long) i) * ((long) this.spinPrice);
        try {
            Drawable drawableMutate = getResources().getDrawable(R.drawable.ic_banana, getTheme()).mutate();
            int i2 = (int) (getResources().getDisplayMetrics().density * 16.0f);
            drawableMutate.setBounds(0, 0, i2, i2);
            StringBuilder sb = new StringBuilder("AUTO SPIN");
            if (iMin > 0 && i > 0) {
                sb.append("  ");
                sb.append(iMin);
                sb.append(" Free + ");
                sb.append(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
                sb.append("  ");
            } else if (iMin > 0 && i == 0) {
                sb.append("  ");
                sb.append(iMin);
                sb.append(" Free");
            } else {
                sb.append("  ");
                sb.append(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
                sb.append("  ");
            }
            if (i <= 0 && iMin != 0) {
                this.btnAutoSpin.setText(sb.toString());
                return;
            }
            SpannableString spannableString = new SpannableString(sb.toString() + "￼");
            spannableString.setSpan(new ImageSpan(drawableMutate, 2), sb.length(), sb.length() + 1, 33);
            this.btnAutoSpin.setText(spannableString);
        } catch (Exception unused) {
            if (iMin > 0 && i > 0) {
                this.btnAutoSpin.setText(String.format(Locale.getDefault(), "AUTO SPIN  %d Free + %,d", Integer.valueOf(iMin), Long.valueOf(j)));
                return;
            }
            if (iMin > 0) {
                this.btnAutoSpin.setText("AUTO SPIN  " + iMin + " Free");
                return;
            }
            this.btnAutoSpin.setText(String.format(Locale.getDefault(), "AUTO SPIN  %,d", Long.valueOf(j)));
        }
    }

    private void startAutoSpin() {
        if (this.spinItems.isEmpty()) {
            toast("Spin data မရှိသေးပါ");
            return;
        }
        if (this.turnFree <= 0 && this.bananas < this.spinPrice) {
            toast("Banana မလောက်ပါ");
            return;
        }
        this.isAutoSpinning = true;
        this.autoRemaining = this.autoSpinCount;
        this.autoResults.clear();
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("STOP  (" + this.autoRemaining + " left)");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_stop);
            this.btnAutoSpin.setTextColor(-1);
        }
        Button button = this.btnSpin;
        if (button != null) {
            button.setEnabled(false);
        }
        doSpin();
    }

    private void stopAutoSpin() {
        this.isAutoSpinning = false;
        this.autoRemaining = 0;
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("AUTO SPIN");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
            this.btnAutoSpin.setTextColor(-16777216);
        }
        refreshSpinButton();
        this.autoResults.clear();
    }

    private void finishAutoSpin() {
        this.isAutoSpinning = false;
        this.autoRemaining = 0;
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("AUTO SPIN");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
            this.btnAutoSpin.setTextColor(-16777216);
        }
        refreshSpinButton();
        this.autoResults.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showAutoSummary() {
        if (this.autoResults.isEmpty() || isFinishing()) {
            return;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (JSONObject jSONObject : this.autoResults) {
            String strOptString = jSONObject.optString("name", "Prize");
            int iOptInt = jSONObject.optInt("value", 0);
            String str = strOptString + "|" + iOptInt;
            int[] iArr = (int[]) linkedHashMap.get(str);
            if (iArr == null) {
                linkedHashMap.put(str, new int[]{1, iOptInt});
            } else {
                iArr[0] = iArr[0] + 1;
            }
        }
        StringBuilder sb = new StringBuilder("Auto Spin ရလဒ် (");
        sb.append(this.autoResults.size());
        sb.append(" ကြိမ်)\n\n");
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            String str2 = ((String) entry.getKey()).split("\\|")[0];
            int i = ((int[]) entry.getValue())[0];
            int i2 = ((int[]) entry.getValue())[1];
            sb.append("• ");
            sb.append(str2);
            if (i2 > 0) {
                sb.append(" +");
                sb.append(i2);
            }
            if (i > 1) {
                sb.append("  ×");
                sb.append(i);
            }
            sb.append("\n");
        }
        try {
            new AlertDialog.Builder(this).setTitle("Auto Spin Complete").setMessage(sb.toString().trim()).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
        } catch (Exception unused) {
            toast("Auto done: " + this.autoResults.size() + " spins");
        }
        this.autoResults.clear();
    }

    private void refreshSpinButton() {
        Button button = this.btnSpin;
        boolean z = false;
        if (button != null) {
            button.setEnabled(false);
            this.btnSpin.setVisibility(8);
        }
        if (this.btnAutoSpin == null || this.isAutoSpinning) {
            return;
        }
        int iMax = Math.max(1, this.autoSpinCount);
        int iMin = Math.min(this.turnFree, iMax);
        long j = ((long) (iMax - iMin)) * ((long) this.spinPrice);
        if (!this.spinItems.isEmpty() && (iMin > 0 || this.bananas >= j)) {
            z = true;
        }
        this.btnAutoSpin.setEnabled(z);
        this.btnAutoSpin.setAlpha(z ? 1.0f : 0.5f);
        updateAutoSpinLabel();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void updateSpinButtonText() {
        if (this.turnFree > 0) {
            this.btnSpin.setText(String.format(Locale.getDefault(), "SPIN  %d", Integer.valueOf(this.turnFree)));
            return;
        }
        String str = "SPIN  " + String.format(Locale.getDefault(), "%,d", Integer.valueOf(this.spinPrice)) + "   ";
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(str);
        Bitmap bitmapLoadBitmap = loadBitmap(R.drawable.ic_banana);
        if (bitmapLoadBitmap != null) {
            int iDp = dp(20);
            spannableStringBuilder.setSpan(new ImageSpan((Context) this, Bitmap.createScaledBitmap(bitmapLoadBitmap, iDp, iDp, true), 1), str.length() - 1, str.length(), 33);
        }
        this.btnSpin.setText(spannableStringBuilder, TextView.BufferType.SPANNABLE);
    }

    private void updateBananaDisplay() {
        final long j = this.bananas;
        this.ui.post(new Runnable() { // from class: com.zeno.app.SpinWheelActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m745lambda$updateBananaDisplay$18$comzenoappSpinWheelActivity(j);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$updateBananaDisplay$18$com-zeno-app-SpinWheelActivity, reason: not valid java name */
    /* synthetic */ void m745lambda$updateBananaDisplay$18$comzenoappSpinWheelActivity(long j) {
        this.tvBananaBalance.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
    }

    private HttpResult getReq(String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setRequestProperty("Authorization", "Bearer " + this.kongToken);
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(15000);
            int responseCode = httpURLConnection.getResponseCode();
            InputStream inputStream = responseCode < 300 ? httpURLConnection.getInputStream() : httpURLConnection.getErrorStream();
            String string = "";
            if (inputStream != null) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                byte[] bArr = new byte[4096];
                while (true) {
                    int i = inputStream.read(bArr);
                    if (i == -1) {
                        break;
                    }
                    byteArrayOutputStream.write(bArr, 0, i);
                }
                string = byteArrayOutputStream.toString("UTF-8");
            }
            return new HttpResult(responseCode, string);
        } catch (Exception e) {
            Log.w(TAG, "getReq: " + e.getMessage());
            return null;
        }
    }

    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    static class HttpResult {
        final String body;
        final int code;

        HttpResult(int i, String str) {
            this.code = i;
            this.body = str;
        }
    }

    private String rewardEmoji(String str) {
        if (str == null) {
            return "🎁";
        }
        String upperCase = str.toUpperCase(Locale.ROOT);
        upperCase.hashCode();
        switch (upperCase) {
        }
        return "🎁";
    }

    private String rewardShort(String str) {
        if (str == null) {
            return "Prize";
        }
        String upperCase = str.toUpperCase(Locale.ROOT);
        upperCase.hashCode();
        switch (upperCase) {
            case "TURN_LUCKY_SPIN":
                return "Extra Spin";
            case "MAGNET":
                return "Magnet";
            case "REBORN":
                return "Reborn";
            case "TICKET":
                return "Ticket";
            case "GOOD_LUCK":
                return "Good Luck";
            case "PROTECT":
                return "Protect";
            case "BANANA":
                return "Banana";
            case "X2BANANA":
                return "×2 Banana";
            default:
                return str;
        }
    }

    private String rewardFull(String str) {
        if (str == null) {
            return "Prize";
        }
        String upperCase = str.toUpperCase(Locale.ROOT);
        upperCase.hashCode();
        switch (upperCase) {
            case "TURN_LUCKY_SPIN":
                return "Extra Lucky Spin";
            case "MAGNET":
                return "Magnet";
            case "REBORN":
                return "Reborn";
            case "TICKET":
                return "Ticket";
            case "GOOD_LUCK":
                return "Good Luck";
            case "PROTECT":
                return "Shield Protect";
            case "BANANA":
                return "Bananas";
            case "X2BANANA":
                return "×2 Banana Boost";
            default:
                return str;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    private int dp(int i) {
        return Math.round(TypedValue.applyDimension(1, i, getResources().getDisplayMetrics()));
    }

    protected void onDestroy() {
        this.isAutoSpinning = false;
        this.ui.removeCallbacksAndMessages(null);
        super.onDestroy();
        this.exec.shutdownNow();
    }
}
