package com.zeno.app;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public final /* synthetic */ class CropImageActivity$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ CropImageActivity f$0;

    public /* synthetic */ CropImageActivity$$ExternalSyntheticLambda0(CropImageActivity cropImageActivity) {
        this.f$0 = cropImageActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.fitImageToCropWindow();
    }
}
