package com.zeno.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CropImageActivity extends AppCompatActivity {
    public static final String EXTRA_CROPPED_PATH = "cropped_path";
    public static final String EXTRA_IMAGE_URI = "image_uri";
    public static final int OUTPUT_SIZE = 250;
    private ImageView ivCrop;
    private float lastX;
    private float lastY;
    private CropOverlayView overlay;
    private ScaleGestureDetector scaleDetector;
    private Bitmap sourceBmp;
    private final Matrix matrix = new Matrix();
    private float scale = 1.0f;
    private float minScale = 1.0f;
    private float maxScale = 6.0f;
    private boolean isDragging = false;

    static /* synthetic */ float access$032(CropImageActivity cropImageActivity, float f) {
        float f2 = cropImageActivity.scale * f;
        cropImageActivity.scale = f2;
        return f2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_crop_image);
        this.ivCrop = (ImageView) findViewById(R.id.iv_crop);
        this.overlay = (CropOverlayView) findViewById(R.id.crop_overlay);
        TextView textView = (TextView) findViewById(R.id.btn_crop_cancel);
        TextView textView2 = (TextView) findViewById(R.id.btn_crop_done);
        String stringExtra = getIntent().getStringExtra(EXTRA_IMAGE_URI);
        if (stringExtra == null || stringExtra.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "ပုံ မရပါ", 0).show();
            finish();
            return;
        }
        try {
            Bitmap bitmapLoadBitmap = loadBitmap(Uri.parse(stringExtra));
            this.sourceBmp = bitmapLoadBitmap;
            if (bitmapLoadBitmap == null) {
                Toast.makeText((Context) this, (CharSequence) "ပုံ ဖတ်မရပါ", 0).show();
                finish();
                return;
            }
            this.ivCrop.setImageBitmap(bitmapLoadBitmap);
            this.ivCrop.post(new CropImageActivity$$ExternalSyntheticLambda0(this));
            this.scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() { // from class: com.zeno.app.CropImageActivity.1
                @Override // android.view.ScaleGestureDetector.SimpleOnScaleGestureListener, android.view.ScaleGestureDetector.OnScaleGestureListener
                public boolean onScale(ScaleGestureDetector scaleGestureDetector) {
                    float scaleFactor = scaleGestureDetector.getScaleFactor();
                    float f = CropImageActivity.this.scale * scaleFactor;
                    if (f < CropImageActivity.this.minScale) {
                        scaleFactor = CropImageActivity.this.minScale / CropImageActivity.this.scale;
                    }
                    if (f > CropImageActivity.this.maxScale) {
                        scaleFactor = CropImageActivity.this.maxScale / CropImageActivity.this.scale;
                    }
                    CropImageActivity.access$032(CropImageActivity.this, scaleFactor);
                    CropImageActivity.this.matrix.postScale(scaleFactor, scaleFactor, scaleGestureDetector.getFocusX(), scaleGestureDetector.getFocusY());
                    CropImageActivity.this.ivCrop.setImageMatrix(CropImageActivity.this.matrix);
                    return true;
                }
            });
            this.ivCrop.setOnTouchListener(new View.OnTouchListener() { // from class: com.zeno.app.CropImageActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view, MotionEvent motionEvent) {
                    return this.f$0.m257lambda$onCreate$0$comzenoappCropImageActivity(view, motionEvent);
                }
            });
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CropImageActivity$$ExternalSyntheticLambda2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m258lambda$onCreate$1$comzenoappCropImageActivity(view);
                }
            });
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CropImageActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m259lambda$onCreate$2$comzenoappCropImageActivity(view);
                }
            });
        } catch (Exception unused) {
            Toast.makeText((Context) this, (CharSequence) "ပုံ ဖတ်မရပါ", 0).show();
            finish();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x004e  */
    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-CropImageActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ boolean m257lambda$onCreate$0$comzenoappCropImageActivity(android.view.View r4, android.view.MotionEvent r5) {
        /*
            r3 = this;
            android.view.ScaleGestureDetector r4 = r3.scaleDetector
            r4.onTouchEvent(r5)
            int r4 = r5.getActionMasked()
            r0 = 1
            if (r4 == 0) goto L52
            if (r4 == r0) goto L4e
            r1 = 2
            if (r4 == r1) goto L15
            r5 = 3
            if (r4 == r5) goto L4e
            goto L60
        L15:
            boolean r4 = r3.isDragging
            if (r4 == 0) goto L60
            int r4 = r5.getPointerCount()
            if (r4 != r0) goto L60
            android.view.ScaleGestureDetector r4 = r3.scaleDetector
            boolean r4 = r4.isInProgress()
            if (r4 != 0) goto L60
            float r4 = r5.getX()
            float r1 = r3.lastX
            float r4 = r4 - r1
            float r1 = r5.getY()
            float r2 = r3.lastY
            float r1 = r1 - r2
            android.graphics.Matrix r2 = r3.matrix
            r2.postTranslate(r4, r1)
            android.widget.ImageView r4 = r3.ivCrop
            android.graphics.Matrix r1 = r3.matrix
            r4.setImageMatrix(r1)
            float r4 = r5.getX()
            r3.lastX = r4
            float r4 = r5.getY()
            r3.lastY = r4
            goto L60
        L4e:
            r4 = 0
            r3.isDragging = r4
            goto L60
        L52:
            float r4 = r5.getX()
            r3.lastX = r4
            float r4 = r5.getY()
            r3.lastY = r4
            r3.isDragging = r0
        L60:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CropImageActivity.m257lambda$onCreate$0$comzenoappCropImageActivity(android.view.View, android.view.MotionEvent):boolean");
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-CropImageActivity, reason: not valid java name */
    /* synthetic */ void m258lambda$onCreate$1$comzenoappCropImageActivity(View view) {
        setResult(0);
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-CropImageActivity, reason: not valid java name */
    /* synthetic */ void m259lambda$onCreate$2$comzenoappCropImageActivity(View view) {
        doCropAndFinish();
    }

    private Bitmap loadBitmap(Uri uri) throws Exception {
        InputStream inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
        BitmapFactory.Options options = new BitmapFactory.Options();
        int i = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(inputStreamOpenInputStream, null, options);
        if (inputStreamOpenInputStream != null) {
            inputStreamOpenInputStream.close();
        }
        int i2 = options.outWidth;
        int i3 = options.outHeight;
        while (true) {
            if (i2 / i <= 2048 && i3 / i <= 2048) {
                break;
            }
            i *= 2;
        }
        BitmapFactory.Options options2 = new BitmapFactory.Options();
        options2.inSampleSize = i;
        InputStream inputStreamOpenInputStream2 = getContentResolver().openInputStream(uri);
        Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenInputStream2, null, options2);
        if (inputStreamOpenInputStream2 != null) {
            inputStreamOpenInputStream2.close();
        }
        return bitmapDecodeStream;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fitImageToCropWindow() {
        CropOverlayView cropOverlayView;
        if (this.sourceBmp == null || (cropOverlayView = this.overlay) == null) {
            return;
        }
        RectF cropRect = cropOverlayView.getCropRect();
        if (cropRect.width() <= 0.0f) {
            this.ivCrop.post(new CropImageActivity$$ExternalSyntheticLambda0(this));
            return;
        }
        float width = this.sourceBmp.getWidth();
        float height = this.sourceBmp.getHeight();
        float fWidth = cropRect.width();
        float fMax = Math.max(fWidth / width, fWidth / height);
        this.minScale = fMax;
        this.maxScale = 8.0f * fMax;
        this.scale = fMax;
        this.matrix.reset();
        this.matrix.postScale(fMax, fMax);
        this.matrix.postTranslate(cropRect.centerX() - ((width * fMax) / 2.0f), cropRect.centerY() - ((height * fMax) / 2.0f));
        this.ivCrop.setImageMatrix(this.matrix);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void doCropAndFinish() {
        if (this.sourceBmp == null) {
            return;
        }
        try {
            RectF cropRect = this.overlay.getCropRect();
            Matrix matrix = new Matrix();
            if (!this.matrix.invert(matrix)) {
                Toast.makeText((Context) this, (CharSequence) "Crop မရပါ", 0).show();
                return;
            }
            float[] fArr = {cropRect.left, cropRect.top, cropRect.right, cropRect.bottom};
            matrix.mapPoints(fArr);
            float fMin = Math.min(fArr[0], fArr[2]);
            float fMin2 = Math.min(fArr[1], fArr[3]);
            float fMax = Math.max(fArr[0], fArr[2]);
            float fMax2 = Math.max(fArr[1], fArr[3]);
            int iMax = Math.max(0, Math.round(fMin));
            int iMax2 = Math.max(0, Math.round(fMin2));
            int iMin = Math.min(Math.max(1, Math.min(this.sourceBmp.getWidth(), Math.round(fMax)) - iMax), Math.max(1, Math.min(this.sourceBmp.getHeight(), Math.round(fMax2)) - iMax2));
            if (iMax + iMin > this.sourceBmp.getWidth()) {
                iMax = Math.max(0, this.sourceBmp.getWidth() - iMin);
            }
            if (iMax2 + iMin > this.sourceBmp.getHeight()) {
                iMax2 = Math.max(0, this.sourceBmp.getHeight() - iMin);
            }
            int iMin2 = Math.min(iMin, Math.min(this.sourceBmp.getWidth() - iMax, this.sourceBmp.getHeight() - iMax2));
            if (iMin2 < 1) {
                Toast.makeText((Context) this, (CharSequence) "Crop ဧရိယာ မမှန်ပါ", 0).show();
                return;
            }
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(this.sourceBmp, iMax, iMax2, iMin2, iMin2);
            Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapCreateBitmap, OUTPUT_SIZE, OUTPUT_SIZE, true);
            if (bitmapCreateBitmap != bitmapCreateScaledBitmap) {
                bitmapCreateBitmap.recycle();
            }
            File file = new File(getCacheDir(), "profile_crop_" + System.currentTimeMillis() + ".jpg");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            bitmapCreateScaledBitmap.compress(Bitmap.CompressFormat.JPEG, 90, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            bitmapCreateScaledBitmap.recycle();
            Intent intent = new Intent();
            intent.putExtra(EXTRA_CROPPED_PATH, file.getAbsolutePath());
            setResult(-1, intent);
            finish();
        } catch (Exception e) {
            Toast.makeText((Context) this, (CharSequence) ("Crop error: " + e.getMessage()), 1).show();
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        Bitmap bitmap = this.sourceBmp;
        if (bitmap != null) {
            bitmap.isRecycled();
        }
    }
}
