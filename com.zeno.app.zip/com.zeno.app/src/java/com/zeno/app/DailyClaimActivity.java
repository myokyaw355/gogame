package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.io.IOException;
import java.util.Locale;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class DailyClaimActivity extends BaseActivity {
    private static final int C_BG = -15986924;
    private static final int C_BLUE = -1023342;
    private static final int C_CLAIM = -10929;
    private static final int C_CLAIM_TXT = -15069184;
    private static final int C_GREEN = -12345273;
    private static final int C_GREY_BG = -14013904;
    private static final int C_ORANGE = -36797;
    private static final int C_PINK = -4165520;
    private static final int C_PINK_LIGHT = -12966864;
    private static final int C_TEXT_DARK = -657931;
    private static final int C_TEXT_GREY = -6645094;
    private static final int C_WHITE = -14671836;
    private LinearLayout container;
    private CountDownTimer dailyCountdown;
    private LinearLayout hl2Container;
    private View layoutContent;
    private View layoutLoading;
    private ProgressBar loadingBar;
    private View lockOverlay;
    private LinearLayout miniQuestContainer;
    private String msisdn;
    private SessionManager sessionManager;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private String token;
    private TextView tvHeaderDate;
    private TextView tvHeaderPoints;
    private TextView tvStatus;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    static /* synthetic */ void lambda$setQuestLocked$3(View view) {
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        getWindow().setNavigationBarColor(C_BG);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_daily_claim);
        SessionManager sessionManager = new SessionManager(this);
        this.sessionManager = sessionManager;
        this.token = sessionManager.getAccessToken();
        String phone = this.sessionManager.getPhone();
        if (phone == null) {
            phone = "";
        }
        String strTrim = phone.trim();
        if (strTrim.startsWith("+95")) {
            this.msisdn = "%2B95" + strTrim.substring(3);
        } else if (strTrim.startsWith("95")) {
            this.msisdn = "%2B" + strTrim;
        } else {
            this.msisdn = "%2B95" + strTrim.replaceFirst("^0", "");
        }
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Daily Quest");
        }
        if (toolbarFindViewById != null) {
            toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m264lambda$onCreate$0$comzenoappDailyClaimActivity(view);
                }
            });
            toolbarFindViewById.setNavigationIcon(R.drawable.ic_back);
        }
        this.swipeRefresh = findViewById(R.id.swipeRefresh);
        this.loadingBar = (ProgressBar) findViewById(R.id.progressBar);
        this.layoutLoading = findViewById(R.id.layout_loading);
        this.layoutContent = findViewById(R.id.layout_content);
        this.tvStatus = (TextView) findViewById(R.id.tvStatus);
        this.container = (LinearLayout) findViewById(R.id.claimListContainer);
        this.hl2Container = (LinearLayout) findViewById(R.id.hl2Container);
        this.lockOverlay = findViewById(R.id.lockOverlay);
        this.tvHeaderDate = (TextView) findViewById(R.id.tvHeaderDate);
        this.tvHeaderPoints = (TextView) findViewById(R.id.tvHeaderPoints);
        this.swipeRefresh.setColorSchemeColors(new int[]{C_PINK});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(C_WHITE);
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda7
            public final void onRefresh() {
                this.f$0.loadMainScreen();
            }
        });
        loadMainScreen();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /* synthetic */ void m264lambda$onCreate$0$comzenoappDailyClaimActivity(View view) {
        finish();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadMainScreen() {
        showLoading(true);
        this.container.removeAllViews();
        LinearLayout linearLayout = this.hl2Container;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        this.miniQuestContainer = null;
        setQuestLocked(false);
        this.tvStatus.setVisibility(8);
        ApiClient.getDailyQuestMainScreen(this.msisdn, this.token, new AnonymousClass1());
    }

    /* JADX INFO: renamed from: com.zeno.app.DailyClaimActivity$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass1 implements Callback {
        AnonymousClass1() {
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DailyClaimActivity$1, reason: not valid java name */
        /* synthetic */ void m268lambda$onFailure$0$comzenoappDailyClaimActivity$1(IOException iOException) {
            DailyClaimActivity.this.showLoading(false);
            DailyClaimActivity.this.showStatus("ချိတ်ဆက်မှု မအောင်မြင်ပါ။\n" + iOException.getMessage());
        }

        public void onFailure(Call call, final IOException iOException) {
            DailyClaimActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m268lambda$onFailure$0$comzenoappDailyClaimActivity$1(iOException);
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final int iCode = response.code();
            final String strString = response.body() != null ? response.body().string() : "{}";
            DailyClaimActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m269lambda$onResponse$1$comzenoappDailyClaimActivity$1(strString, iCode);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DailyClaimActivity$1, reason: not valid java name */
        /* synthetic */ void m269lambda$onResponse$1$comzenoappDailyClaimActivity$1(String str, int i) {
            DailyClaimActivity.this.showLoading(false);
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optBoolean("success", false)) {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("result") != null ? jSONObject.getJSONObject("result").optJSONObject("mainScreenResponse") : null;
                    if (jSONObjectOptJSONObject == null) {
                        DailyClaimActivity.this.showStatus("ဒေတာ ရှိမနေပါ။");
                        return;
                    } else {
                        DailyClaimActivity.this.renderScreen(jSONObjectOptJSONObject);
                        return;
                    }
                }
                DailyClaimActivity.this.showStatus("Error " + i + ": " + jSONObject.optString("message", "Failed"));
            } catch (Exception e) {
                DailyClaimActivity.this.showStatus("Error: " + e.getMessage());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0234 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:76:0x0218  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x021f  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x0242  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void renderScreen(org.json.JSONObject r29) {
        /*
            Method dump skipped, instruction units count: 655
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.DailyClaimActivity.renderScreen(org.json.JSONObject):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addHl2Card(String str, String str2, View.OnClickListener onClickListener) {
        int i = (int) getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(C_WHITE);
        gradientDrawable.setCornerRadius(0.0f);
        gradientDrawable.setStroke(i, C_PINK_LIGHT);
        linearLayout.setBackground(gradientDrawable);
        int i2 = i * 14;
        linearLayout.setPadding(i * 16, i2, i2, i2);
        linearLayout.setElevation(i);
        linearLayout.setTranslationZ(i * 0.5f);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(C_TEXT_DARK);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, 1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams.setMarginEnd(i * 10);
        textView.setLayoutParams(layoutParams);
        linearLayout.addView(textView);
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setTransformationMethod(null);
        button.setText(str2);
        button.setTextSize(13.0f);
        button.setTypeface(null, 1);
        button.setPadding(0, 0, 0, 0);
        button.setElevation(0.0f);
        button.setStateListAnimator(null);
        button.setLayoutParams(new LinearLayout.LayoutParams(i * 86, i * 40));
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(C_BLUE);
        gradientDrawable2.setCornerRadius(i * 20);
        button.setBackground(gradientDrawable2);
        button.setTextColor(C_WHITE);
        if (onClickListener != null) {
            button.setOnClickListener(onClickListener);
        }
        linearLayout.addView(button);
        LinearLayout linearLayout2 = this.hl2Container;
        if (linearLayout2 != null) {
            linearLayout2.addView(linearLayout);
        } else {
            this.container.addView(linearLayout);
        }
    }

    private void setQuestLocked(boolean z) {
        View view = this.lockOverlay;
        if (view != null) {
            view.setVisibility(z ? 0 : 8);
            if (z) {
                this.lockOverlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda8
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        DailyClaimActivity.lambda$setQuestLocked$3(view2);
                    }
                });
            } else {
                this.lockOverlay.setOnClickListener(null);
            }
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setEnabled(true);
        }
        LinearLayout linearLayout = this.container;
        if (linearLayout != null) {
            linearLayout.setAlpha(1.0f);
            this.container.setEnabled(!z);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addQuestCard(String str, int i, int i2, int i3, String str2, boolean z, boolean z2, View.OnClickListener onClickListener) {
        int i4 = (int) getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(C_WHITE);
        int i5 = i4 * 14;
        gradientDrawable.setCornerRadius(i5);
        gradientDrawable.setStroke(i4, C_PINK_LIGHT);
        linearLayout.setBackground(gradientDrawable);
        linearLayout.setPadding(i5, i5, i5, i5);
        linearLayout.setElevation(i4);
        linearLayout.setTranslationZ(i4 * 0.5f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int i6 = i4 * 2;
        int i7 = i4 * 10;
        layoutParams.setMargins(i6, i6, i6, i7);
        linearLayout.setLayoutParams(layoutParams);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setGravity(16);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams2.setMarginEnd(i7);
        linearLayout3.setLayoutParams(layoutParams2);
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(C_TEXT_DARK);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, 1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.setMargins(0, 0, 0, i4 * 8);
        textView.setLayoutParams(layoutParams3);
        linearLayout3.addView(textView);
        final FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, i4 * 24));
        View view = new View(this);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(C_GREY_BG);
        float f = i4 * 12;
        gradientDrawable2.setCornerRadius(f);
        gradientDrawable2.setStroke(i4, C_PINK_LIGHT);
        view.setBackground(gradientDrawable2);
        view.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(view);
        if (i3 > 0 && i2 > 0) {
            final View view2 = new View(this);
            GradientDrawable gradientDrawable3 = new GradientDrawable();
            gradientDrawable3.setColor(z ? C_CLAIM : C_PINK);
            final float fMin = Math.min(i2, i3) / i3;
            if (fMin >= 1.0f) {
                gradientDrawable3.setCornerRadius(f);
            } else {
                gradientDrawable3.setCornerRadii(new float[]{f, f, 0.0f, 0.0f, 0.0f, 0.0f, f, f});
            }
            view2.setBackground(gradientDrawable3);
            view2.setLayoutParams(new FrameLayout.LayoutParams(0, -1));
            frameLayout.addView(view2);
            frameLayout.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    DailyClaimActivity.lambda$addQuestCard$4(frameLayout, fMin, view2);
                }
            });
        }
        TextView textView2 = new TextView(this);
        textView2.setText(i2 + "/" + i3);
        textView2.setTextColor(C_TEXT_DARK);
        textView2.setTextSize(11.0f);
        textView2.setTypeface(null, 1);
        textView2.setGravity(17);
        textView2.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(textView2);
        linearLayout3.addView(frameLayout);
        linearLayout2.addView(linearLayout3);
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setOrientation(1);
        linearLayout4.setGravity(17);
        linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(i4 * 86, -2));
        if (i > 0) {
            LinearLayout linearLayout5 = new LinearLayout(this);
            linearLayout5.setOrientation(0);
            linearLayout5.setGravity(17);
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams4.setMargins(0, 0, 0, i4 * 6);
            linearLayout5.setLayoutParams(layoutParams4);
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(R.drawable.point);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int i8 = i4 * 18;
            linearLayout5.addView(imageView, new LinearLayout.LayoutParams(i8, i8));
            TextView textView3 = new TextView(this);
            textView3.setText(" " + i);
            textView3.setTextColor(C_ORANGE);
            textView3.setTextSize(14.0f);
            textView3.setTypeface(null, 1);
            linearLayout5.addView(textView3);
            linearLayout4.addView(linearLayout5);
        }
        if (z && !z2 && onClickListener == null) {
            TextView textView4 = new TextView(this);
            textView4.setText("✓");
            textView4.setTextColor(C_GREEN);
            textView4.setTextSize(28.0f);
            textView4.setTypeface(null, 1);
            textView4.setGravity(17);
            textView4.setLayoutParams(new LinearLayout.LayoutParams(-1, i4 * 40));
            linearLayout4.addView(textView4);
        } else {
            final Button button = new Button(this);
            button.setAllCaps(false);
            button.setTransformationMethod(null);
            button.setText(str2);
            button.setTextSize(13.0f);
            boolean z3 = true;
            button.setTypeface(null, 1);
            button.setPadding(0, 0, 0, 0);
            button.setElevation(0.0f);
            button.setStateListAnimator(null);
            button.setLayoutParams(new LinearLayout.LayoutParams(-1, i4 * 40));
            int i9 = z ? C_CLAIM : C_BLUE;
            button.setTextColor(z ? C_CLAIM_TXT : C_WHITE);
            GradientDrawable gradientDrawable4 = new GradientDrawable();
            gradientDrawable4.setColor(i9);
            gradientDrawable4.setCornerRadius(i4 * 20);
            button.setBackground(gradientDrawable4);
            if (z && !z2 && onClickListener == null) {
                z3 = false;
            }
            button.setEnabled(z3);
            if (z2 && !z) {
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda5
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view3) {
                        this.f$0.m263lambda$addQuestCard$5$comzenoappDailyClaimActivity(button, view3);
                    }
                });
            } else if (onClickListener != null) {
                button.setOnClickListener(onClickListener);
            }
            linearLayout4.addView(button);
        }
        linearLayout2.addView(linearLayout4);
        linearLayout.addView(linearLayout2);
        LinearLayout linearLayout6 = this.miniQuestContainer;
        if (linearLayout6 != null) {
            linearLayout6.addView(linearLayout);
        } else {
            this.container.addView(linearLayout);
        }
    }

    static /* synthetic */ void lambda$addQuestCard$4(FrameLayout frameLayout, float f, View view) {
        int width = (int) (frameLayout.getWidth() * f);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        layoutParams.width = width;
        view.setLayoutParams(layoutParams);
    }

    /* JADX INFO: renamed from: lambda$addQuestCard$5$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /* synthetic */ void m263lambda$addQuestCard$5$comzenoappDailyClaimActivity(Button button, View view) {
        performDailyClaim(button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0286  */
    /* JADX WARN: Type inference failed for: r16v0, types: [com.zeno.app.DailyClaimActivity$2] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void addBadgeCard(java.lang.String r22, java.lang.String r23, int r24, int r25, int r26, java.lang.String r27, boolean r28, boolean r29, int r30, java.lang.String r31) {
        /*
            Method dump skipped, instruction units count: 877
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.DailyClaimActivity.addBadgeCard(java.lang.String, java.lang.String, int, int, int, java.lang.String, boolean, boolean, int, java.lang.String):void");
    }

    /* JADX INFO: renamed from: lambda$addBadgeCard$6$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /* synthetic */ void m260lambda$addBadgeCard$6$comzenoappDailyClaimActivity(Button button, View view) {
        performDailyClaim(button);
    }

    static /* synthetic */ void lambda$addBadgeCard$7(FrameLayout frameLayout, float f, View view) {
        int width = (int) (frameLayout.getWidth() * f);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        layoutParams.width = width;
        view.setLayoutParams(layoutParams);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v16 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4, types: [android.graphics.Typeface, android.text.method.TransformationMethod] */
    private void addChestCard(String str, int i, int i2, int i3, String str2, boolean z) {
        ?? r11;
        int i4 = (int) getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(C_WHITE);
        float f = i4 * 20;
        gradientDrawable.setCornerRadius(f);
        gradientDrawable.setStroke(1, -13619152);
        linearLayout.setBackground(gradientDrawable);
        int i5 = i4 * 16;
        linearLayout.setPadding(i5, i5, i5, i5);
        linearLayout.setElevation(i4);
        linearLayout.setTranslationZ(i4 * 0.5f);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int i6 = i4 * 2;
        int i7 = i4 * 10;
        layoutParams.setMargins(i6, i6, i6, i7);
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        textView.setText("GRAND");
        textView.setTextColor(-1);
        textView.setTextSize(12.0f);
        textView.setTypeface(null, 1);
        int i8 = i4 * 14;
        int i9 = i4 * 5;
        textView.setPadding(i8, i9, i8, i9);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setColor(C_ORANGE);
        gradientDrawable2.setCornerRadius(f);
        textView.setBackground(gradientDrawable2);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMargins(0, 0, 0, i7);
        textView.setLayoutParams(layoutParams2);
        linearLayout.addView(textView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.freebox);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(0, i4 * 100, 1.0f));
        linearLayout2.addView(imageView);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setGravity(1);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams3.setMarginStart(i4 * 8);
        linearLayout3.setLayoutParams(layoutParams3);
        if (i > 0) {
            LinearLayout linearLayout4 = new LinearLayout(this);
            linearLayout4.setOrientation(0);
            linearLayout4.setGravity(16);
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
            layoutParams4.setMargins(0, 0, 0, i7);
            linearLayout4.setLayoutParams(layoutParams4);
            ImageView imageView2 = new ImageView(this);
            imageView2.setImageResource(R.drawable.point);
            imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int i10 = i4 * 28;
            linearLayout4.addView(imageView2, new LinearLayout.LayoutParams(i10, i10));
            TextView textView2 = new TextView(this);
            textView2.setText("  " + i);
            textView2.setTextColor(C_ORANGE);
            textView2.setTextSize(24.0f);
            r11 = 0;
            textView2.setTypeface(null, 1);
            linearLayout4.addView(textView2);
            linearLayout3.addView(linearLayout4);
        } else {
            r11 = 0;
        }
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setTransformationMethod(r11);
        button.setText(str2);
        button.setTextSize(14.0f);
        button.setTypeface(r11, 1);
        button.setPadding(0, 0, 0, 0);
        boolean zEqualsIgnoreCase = str2.equalsIgnoreCase("PENDING");
        GradientDrawable gradientDrawable3 = new GradientDrawable();
        gradientDrawable3.setColor(zEqualsIgnoreCase ? C_GREY_BG : C_CLAIM);
        gradientDrawable3.setCornerRadius(i4 * 22);
        if (zEqualsIgnoreCase) {
            gradientDrawable3.setStroke(1, -12961214);
        }
        button.setBackground(gradientDrawable3);
        button.setTextColor(zEqualsIgnoreCase ? C_TEXT_GREY : C_CLAIM_TXT);
        button.setEnabled(!zEqualsIgnoreCase);
        button.setLayoutParams(new LinearLayout.LayoutParams(i4 * 130, i4 * 44));
        linearLayout3.addView(button);
        linearLayout2.addView(linearLayout3);
        linearLayout.addView(linearLayout2);
        TextView textView3 = new TextView(this);
        textView3.setText(str);
        textView3.setTextColor(C_TEXT_DARK);
        textView3.setTextSize(14.0f);
        textView3.setTypeface(null, 1);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        int i11 = i4 * 12;
        layoutParams5.setMargins(0, i11, 0, i7);
        textView3.setLayoutParams(layoutParams5);
        linearLayout.addView(textView3);
        final FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, i4 * 28));
        View view = new View(this);
        GradientDrawable gradientDrawable4 = new GradientDrawable();
        gradientDrawable4.setColor(C_GREY_BG);
        float f2 = i8;
        gradientDrawable4.setCornerRadius(f2);
        gradientDrawable4.setStroke(i4, -12961214);
        view.setBackground(gradientDrawable4);
        view.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(view);
        if (i3 > 0 && i2 > 0) {
            final View view2 = new View(this);
            GradientDrawable gradientDrawable5 = new GradientDrawable();
            gradientDrawable5.setColor(C_CLAIM);
            final float fMin = Math.min(i2, i3) / i3;
            if (fMin >= 1.0f) {
                gradientDrawable5.setCornerRadius(f2);
            } else {
                gradientDrawable5.setCornerRadii(new float[]{f2, f2, 0.0f, 0.0f, 0.0f, 0.0f, f2, f2});
            }
            view2.setBackground(gradientDrawable5);
            view2.setLayoutParams(new FrameLayout.LayoutParams(0, -1));
            frameLayout.addView(view2);
            frameLayout.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    DailyClaimActivity.lambda$addChestCard$8(frameLayout, fMin, view2);
                }
            });
        }
        TextView textView4 = new TextView(this);
        textView4.setText(i2 + "/" + i3);
        textView4.setTextColor(C_TEXT_DARK);
        textView4.setTextSize(12.0f);
        textView4.setTypeface(null, 1);
        textView4.setGravity(17);
        textView4.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        frameLayout.addView(textView4);
        linearLayout.addView(frameLayout);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams6.setMargins(i6, i6, i6, i4 * 4);
        linearLayout.setLayoutParams(layoutParams6);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(false);
        scrollView.setOverScrollMode(2);
        LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        layoutParams7.setMargins(0, i11, 0, 0);
        scrollView.setLayoutParams(layoutParams7);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setHorizontalScrollBarEnabled(false);
        scrollView.setScrollBarFadeDuration(0);
        scrollView.setOnTouchListener(new View.OnTouchListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view3, MotionEvent motionEvent) {
                return this.f$0.m262lambda$addChestCard$9$comzenoappDailyClaimActivity(view3, motionEvent);
            }
        });
        if (Build.VERSION.SDK_INT >= 23) {
            scrollView.setOnScrollChangeListener(new View.OnScrollChangeListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnScrollChangeListener
                public final void onScrollChange(View view3, int i12, int i13, int i14, int i15) {
                    this.f$0.m261lambda$addChestCard$10$comzenoappDailyClaimActivity(view3, i12, i13, i14, i15);
                }
            });
        }
        LinearLayout linearLayout5 = new LinearLayout(this);
        this.miniQuestContainer = linearLayout5;
        linearLayout5.setOrientation(1);
        this.miniQuestContainer.setLayoutParams(new FrameLayout.LayoutParams(-1, -2));
        scrollView.addView(this.miniQuestContainer);
        linearLayout.addView(scrollView);
        this.container.addView(linearLayout);
    }

    static /* synthetic */ void lambda$addChestCard$8(FrameLayout frameLayout, float f, View view) {
        int width = (int) (frameLayout.getWidth() * f);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        layoutParams.width = width;
        view.setLayoutParams(layoutParams);
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0012  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0026  */
    /* JADX INFO: renamed from: lambda$addChestCard$9$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ boolean m262lambda$addChestCard$9$comzenoappDailyClaimActivity(android.view.View r5, android.view.MotionEvent r6) {
        /*
            r4 = this;
            int r6 = r6.getActionMasked()
            r0 = -1
            r1 = 0
            if (r6 == 0) goto L26
            r2 = 1
            if (r6 == r2) goto L12
            r3 = 2
            if (r6 == r3) goto L26
            r3 = 3
            if (r6 == r3) goto L12
            goto L3a
        L12:
            androidx.swiperefreshlayout.widget.SwipeRefreshLayout r6 = r4.swipeRefresh
            if (r6 == 0) goto L1e
            boolean r0 = r5.canScrollVertically(r0)
            r0 = r0 ^ r2
            r6.setEnabled(r0)
        L1e:
            android.view.ViewParent r5 = r5.getParent()
            r5.requestDisallowInterceptTouchEvent(r1)
            goto L3a
        L26:
            boolean r6 = r5.canScrollVertically(r0)
            r0 = r6 ^ 1
            androidx.swiperefreshlayout.widget.SwipeRefreshLayout r2 = r4.swipeRefresh
            if (r2 == 0) goto L33
            r2.setEnabled(r0)
        L33:
            android.view.ViewParent r5 = r5.getParent()
            r5.requestDisallowInterceptTouchEvent(r6)
        L3a:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.DailyClaimActivity.m262lambda$addChestCard$9$comzenoappDailyClaimActivity(android.view.View, android.view.MotionEvent):boolean");
    }

    /* JADX INFO: renamed from: lambda$addChestCard$10$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /* synthetic */ void m261lambda$addChestCard$10$comzenoappDailyClaimActivity(View view, int i, int i2, int i3, int i4) {
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setEnabled(i2 <= 0 && !view.canScrollVertically(-1));
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addSectionLabel(int i, String str) {
        int i2 = (int) getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int i3 = i2 * 6;
        layoutParams.setMargins(0, i2 * 14, 0, i3);
        linearLayout.setLayoutParams(layoutParams);
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(i);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int i4 = i2 * 18;
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i4, i4);
        layoutParams2.setMarginEnd(i3);
        imageView.setLayoutParams(layoutParams2);
        linearLayout.addView(imageView);
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(C_TEXT_DARK);
        textView.setTextSize(13.0f);
        textView.setTypeface(null, 1);
        textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        linearLayout.addView(textView);
        this.container.addView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: performMiniQuestClaim, reason: merged with bridge method [inline-methods] */
    public void m266lambda$renderScreen$2$comzenoappDailyClaimActivity(Button button, String str, String str2) {
        button.setEnabled(false);
        button.setText("...");
        int i = (int) getResources().getDisplayMetrics().density;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(C_GREY_BG);
        gradientDrawable.setCornerRadius(i * 20);
        button.setBackground(gradientDrawable);
        ApiClient.getMiniQuestClaim(str, this.msisdn, this.token, new AnonymousClass3(button, str2));
    }

    /* JADX INFO: renamed from: com.zeno.app.DailyClaimActivity$3, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass3 implements Callback {
        final /* synthetic */ Button val$btn;
        final /* synthetic */ String val$configCode;

        AnonymousClass3(Button button, String str) {
            this.val$btn = button;
            this.val$configCode = str;
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$btn;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m270lambda$onFailure$0$comzenoappDailyClaimActivity$3(button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DailyClaimActivity$3, reason: not valid java name */
        /* synthetic */ void m270lambda$onFailure$0$comzenoappDailyClaimActivity$3(Button button) {
            button.setEnabled(true);
            button.setText("ရယူရန်");
            DailyClaimActivity.this.setColor(button, DailyClaimActivity.C_CLAIM);
            button.setTextColor(DailyClaimActivity.C_CLAIM_TXT);
            Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "ချိတ်ဆက်မှု မအောင်မြင်ပါ။", 0).show();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            final boolean zIsSuccessful = response.isSuccessful();
            Handler handler = DailyClaimActivity.this.uiHandler;
            final String str = this.val$configCode;
            final Button button = this.val$btn;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m271lambda$onResponse$1$comzenoappDailyClaimActivity$3(zIsSuccessful, str, button, strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DailyClaimActivity$3, reason: not valid java name */
        /* synthetic */ void m271lambda$onResponse$1$comzenoappDailyClaimActivity$3(boolean z, String str, Button button, String str2) {
            if (z) {
                DailyClaimActivity.this.getSharedPreferences("daily_quest", 0).edit().putBoolean("claimed_" + str, true).commit();
                ViewGroup viewGroup = (ViewGroup) button.getParent();
                if (viewGroup != null) {
                    int iIndexOfChild = viewGroup.indexOfChild(button);
                    viewGroup.removeView(button);
                    int i = (int) DailyClaimActivity.this.getResources().getDisplayMetrics().density;
                    TextView textView = new TextView(DailyClaimActivity.this);
                    textView.setText("✓");
                    textView.setTextColor(DailyClaimActivity.C_GREEN);
                    textView.setTextSize(28.0f);
                    textView.setTypeface(null, 1);
                    textView.setGravity(17);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(-1, i * 40));
                    viewGroup.addView(textView, iIndexOfChild);
                }
                try {
                    String strOptString = new JSONObject(str2).optString("message", "");
                    AppCompatActivity appCompatActivity = DailyClaimActivity.this;
                    if (strOptString.isEmpty()) {
                        strOptString = "Points ရရှိပြီးပါပြီ!";
                    }
                    Toast.makeText((Context) appCompatActivity, (CharSequence) strOptString, 1).show();
                    return;
                } catch (Exception unused) {
                    Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "Points ရရှိပြီးပါပြီ!", 1).show();
                    return;
                }
            }
            button.setEnabled(true);
            button.setText("ရယူရန်");
            DailyClaimActivity.this.setColor(button, DailyClaimActivity.C_CLAIM);
            button.setTextColor(DailyClaimActivity.C_CLAIM_TXT);
            try {
                String strOptString2 = new JSONObject(str2).optString("message", "");
                AppCompatActivity appCompatActivity2 = DailyClaimActivity.this;
                if (strOptString2.isEmpty()) {
                    strOptString2 = "မအောင်မြင်ပါ။";
                }
                Toast.makeText((Context) appCompatActivity2, (CharSequence) strOptString2, 0).show();
            } catch (Exception unused2) {
                Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "မအောင်မြင်ပါ။", 0).show();
            }
        }
    }

    private void performDailyClaim(Button button) {
        button.setEnabled(false);
        button.setText("...");
        int i = (int) getResources().getDisplayMetrics().density;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(C_GREY_BG);
        gradientDrawable.setCornerRadius(i * 21);
        button.setBackground(gradientDrawable);
        ApiClient.postDailyQuestClaim(this.msisdn, this.token, new AnonymousClass4(button));
    }

    /* JADX INFO: renamed from: com.zeno.app.DailyClaimActivity$4, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass4 implements Callback {
        final /* synthetic */ Button val$btn;

        AnonymousClass4(Button button) {
            this.val$btn = button;
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$btn;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$4$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m272lambda$onFailure$0$comzenoappDailyClaimActivity$4(button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DailyClaimActivity$4, reason: not valid java name */
        /* synthetic */ void m272lambda$onFailure$0$comzenoappDailyClaimActivity$4(Button button) {
            button.setEnabled(true);
            button.setText("ရယူရန်");
            DailyClaimActivity.this.setColor(button, DailyClaimActivity.C_CLAIM);
            button.setTextColor(DailyClaimActivity.C_CLAIM_TXT);
            Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "ချိတ်ဆက်မှု မအောင်မြင်ပါ။", 0).show();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$btn;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$4$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m273lambda$onResponse$1$comzenoappDailyClaimActivity$4(strString, button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DailyClaimActivity$4, reason: not valid java name */
        /* synthetic */ void m273lambda$onResponse$1$comzenoappDailyClaimActivity$4(String str, Button button) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optBoolean("success", false)) {
                    Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) jSONObject.optString("message", "Points ရရှိပြီးပါပြီ!"), 1).show();
                    DailyClaimActivity.this.loadMainScreen();
                } else {
                    button.setEnabled(true);
                    button.setText("ရယူရန်");
                    DailyClaimActivity.this.setColor(button, DailyClaimActivity.C_CLAIM);
                    button.setTextColor(DailyClaimActivity.C_CLAIM_TXT);
                    Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) jSONObject.optString("message", "မအောင်မြင်ပါ။"), 0).show();
                }
            } catch (Exception unused) {
                button.setEnabled(true);
                button.setText("ရယူရန်");
                DailyClaimActivity.this.setColor(button, DailyClaimActivity.C_CLAIM);
                button.setTextColor(DailyClaimActivity.C_CLAIM_TXT);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setColor(Button button, int i) {
        int i2 = (int) getResources().getDisplayMetrics().density;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(i2 * 21);
        button.setBackground(gradientDrawable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showLoading(boolean z) {
        if (z) {
            showSkeletonLoading();
            ProgressBar progressBar = this.loadingBar;
            if (progressBar != null) {
                progressBar.setVisibility(8);
            }
            TextView textView = this.tvStatus;
            if (textView != null) {
                textView.setVisibility(8);
            }
        } else {
            hideSkeletonLoading();
            ProgressBar progressBar2 = this.loadingBar;
            if (progressBar2 != null) {
                progressBar2.setVisibility(8);
            }
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    private void showSkeletonLoading() {
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(0);
            View view2 = this.layoutContent;
            if (view2 != null) {
                view2.setVisibility(8);
            }
            this.skeletonAnim = SkeletonPulse.start(this.layoutLoading);
        }
    }

    private void hideSkeletonLoading() {
        SkeletonPulse.stop(this.skeletonAnim, this.layoutLoading);
        this.skeletonAnim = null;
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.layoutContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showStatus(String str) {
        hideSkeletonLoading();
        TextView textView = this.tvStatus;
        if (textView != null) {
            textView.setText(str);
            this.tvStatus.setVisibility(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String formatCountdown(long j) {
        long j2 = j / 1000;
        return String.format("%02d:%02d:%02d", Long.valueOf(j2 / 3600), Long.valueOf((j2 % 3600) / 60), Long.valueOf(j2 % 60));
    }

    protected void onDestroy() {
        super.onDestroy();
        CountDownTimer countDownTimer = this.dailyCountdown;
        if (countDownTimer != null) {
            countDownTimer.cancel();
            this.dailyCountdown = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: buyHl2Package, reason: merged with bridge method [inline-methods] */
    public void m265lambda$renderScreen$1$comzenoappDailyClaimActivity(String str, Button button) {
        if (str == null || str.isEmpty()) {
            str = "HL2";
        }
        if (button != null) {
            button.setEnabled(false);
            button.setText("...");
        }
        String phone = this.sessionManager.getPhone();
        if (phone == null) {
            phone = "";
        }
        String strReplaceFirst = phone.replace("+95", "").replace("%2B95", "").replaceFirst("^0", "");
        String deviceId = this.sessionManager.getDeviceId();
        if (deviceId == null || deviceId.isEmpty()) {
            deviceId = "7191a715889ab704";
        }
        ApiClient.getVasPackageDetail(str, strReplaceFirst, this.token, deviceId, new AnonymousClass5(button, str, strReplaceFirst));
    }

    /* JADX INFO: renamed from: com.zeno.app.DailyClaimActivity$5, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass5 implements Callback {
        final /* synthetic */ String val$localPhone;
        final /* synthetic */ String val$packId;
        final /* synthetic */ Button val$srcBtn;

        AnonymousClass5(Button button, String str, String str2) {
            this.val$srcBtn = button;
            this.val$packId = str;
            this.val$localPhone = str2;
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$srcBtn;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$5$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m274lambda$onFailure$0$comzenoappDailyClaimActivity$5(button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DailyClaimActivity$5, reason: not valid java name */
        /* synthetic */ void m274lambda$onFailure$0$comzenoappDailyClaimActivity$5(Button button) {
            if (button != null) {
                button.setEnabled(true);
                button.setText("ဝယ်ရန်");
            }
            Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "ချိတ်ဆက်မှု မအောင်မြင်ပါ။", 0).show();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$srcBtn;
            final String str = this.val$packId;
            final String str2 = this.val$localPhone;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$5$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m275lambda$onResponse$1$comzenoappDailyClaimActivity$5(button, strString, str, str2);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DailyClaimActivity$5, reason: not valid java name */
        /* synthetic */ void m275lambda$onResponse$1$comzenoappDailyClaimActivity$5(Button button, String str, String str2, String str3) {
            String str4;
            String str5;
            JSONObject jSONObjectOptJSONObject;
            if (button != null) {
                button.setEnabled(true);
                button.setText("ဝယ်ရန်");
            }
            try {
                JSONObject jSONObjectOptJSONObject2 = new JSONObject(str).optJSONObject("result");
                if (jSONObjectOptJSONObject2 == null) {
                    Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "Package အချက်အလက် မရရှိပါ။", 0).show();
                    return;
                }
                String strOptString = jSONObjectOptJSONObject2.optString("name", "");
                double dOptDouble = jSONObjectOptJSONObject2.optDouble("price", 0.0d);
                int iOptInt = jSONObjectOptJSONObject2.optInt("validity", 0);
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject2.optJSONArray("vasDescriptions");
                if (jSONArrayOptJSONArray == null || jSONArrayOptJSONArray.length() <= 0 || (jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(0)) == null) {
                    str4 = "";
                    str5 = str4;
                } else {
                    String strOptString2 = jSONObjectOptJSONObject.optString("shortDesCription", jSONObjectOptJSONObject.optString("shortDescription", ""));
                    String strOptString3 = jSONObjectOptJSONObject.optString("description", "");
                    if (strOptString3 != null) {
                        strOptString3 = strOptString3.replace("\r\n", "\n").trim();
                    }
                    str5 = strOptString3;
                    str4 = strOptString2;
                }
                DailyClaimActivity.this.showHl2BuyDialog(str2, str3, strOptString, str4, str5, dOptDouble, iOptInt, button);
            } catch (Exception unused) {
                Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "Package အချက်အလက် မရရှိပါ။", 0).show();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showHl2BuyDialog(final String str, final String str2, String str3, String str4, String str5, double d, int i, final Button button) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_hl2_buy);
        dialog.setCancelable(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout((int) (((double) getResources().getDisplayMetrics().widthPixels) * 0.88d), -2);
        }
        TextView textView = (TextView) dialog.findViewById(R.id.tvHl2Name);
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvHl2Short);
        TextView textView3 = (TextView) dialog.findViewById(R.id.tvHl2Desc);
        TextView textView4 = (TextView) dialog.findViewById(R.id.tvHl2Validity);
        Button button2 = (Button) dialog.findViewById(R.id.btnHl2Cancel);
        final Button button3 = (Button) dialog.findViewById(R.id.btnHl2Buy);
        if (textView != null) {
            if (str3 != null && !str3.isEmpty()) {
                textView.setText(str3);
                textView.setVisibility(0);
            } else {
                textView.setVisibility(8);
            }
        }
        if (textView2 != null) {
            if (str4 != null && !str4.isEmpty()) {
                textView2.setText(str4);
                textView2.setVisibility(0);
            } else {
                textView2.setVisibility(8);
            }
        }
        if (textView3 != null) {
            if (str5 != null && !str5.isEmpty()) {
                textView3.setText(str5);
                textView3.setVisibility(0);
            } else {
                textView3.setVisibility(8);
            }
        }
        if (textView4 != null) {
            if (i > 0) {
                textView4.setText("သက်တမ်း " + i + " ရက်");
                textView4.setVisibility(0);
            } else {
                textView4.setVisibility(8);
            }
        }
        if (button3 != null) {
            if (d > 0.0d) {
                button3.setText(String.format(Locale.US, "%,.0f Ks", Double.valueOf(d)));
            } else {
                button3.setText("...");
            }
        }
        if (button2 != null) {
            button2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        if (button3 != null) {
            button3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DailyClaimActivity$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m267lambda$showHl2BuyDialog$12$comzenoappDailyClaimActivity(button3, str, str2, dialog, button, view);
                }
            });
        }
        dialog.show();
    }

    /* JADX INFO: renamed from: lambda$showHl2BuyDialog$12$com-zeno-app-DailyClaimActivity, reason: not valid java name */
    /* synthetic */ void m267lambda$showHl2BuyDialog$12$comzenoappDailyClaimActivity(Button button, String str, String str2, Dialog dialog, Button button2, View view) {
        button.setEnabled(false);
        button.setText("...");
        confirmHl2Purchase(str, str2, dialog, button, button2);
    }

    /* JADX INFO: renamed from: com.zeno.app.DailyClaimActivity$6, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass6 implements Callback {
        final /* synthetic */ Button val$btnBuy;
        final /* synthetic */ Dialog val$dialog;

        AnonymousClass6(Button button, Dialog dialog) {
            this.val$btnBuy = button;
            this.val$dialog = dialog;
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Button button = this.val$btnBuy;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$6$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m276lambda$onFailure$0$comzenoappDailyClaimActivity$6(button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DailyClaimActivity$6, reason: not valid java name */
        /* synthetic */ void m276lambda$onFailure$0$comzenoappDailyClaimActivity$6(Button button) {
            if (button != null) {
                button.setEnabled(true);
                button.setText("ပြန်ကြိုးစားမည်");
            }
            Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) "ချိတ်ဆက်မှု မအောင်မြင်ပါ", 0).show();
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DailyClaimActivity.this.uiHandler;
            final Dialog dialog = this.val$dialog;
            final Button button = this.val$btnBuy;
            handler.post(new Runnable() { // from class: com.zeno.app.DailyClaimActivity$6$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m277lambda$onResponse$1$comzenoappDailyClaimActivity$6(strString, dialog, button);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DailyClaimActivity$6, reason: not valid java name */
        /* synthetic */ void m277lambda$onResponse$1$comzenoappDailyClaimActivity$6(String str, Dialog dialog, Button button) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                int iOptInt = jSONObject.optInt("errorCode", -1);
                String strOptString = jSONObject.optString("message", "");
                if (iOptInt == 0) {
                    if (strOptString == null || strOptString.isEmpty()) {
                        strOptString = "HL2 Pack ဝယ်ယူပြီးပါပြီ";
                    }
                    Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) strOptString, 1).show();
                    if (dialog != null && dialog.isShowing()) {
                        dialog.dismiss();
                    }
                    DailyClaimActivity.this.loadMainScreen();
                    return;
                }
                if (strOptString == null || strOptString.isEmpty()) {
                    strOptString = "ဝယ်မရပါ (error " + iOptInt + ")";
                }
                Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) strOptString, 1).show();
                if (button != null) {
                    button.setEnabled(true);
                    button.setText("ပြန်ကြိုးစားမည်");
                }
            } catch (Exception e) {
                Toast.makeText((Context) DailyClaimActivity.this, (CharSequence) ("Error: " + e.getMessage()), 0).show();
                if (button != null) {
                    button.setEnabled(true);
                }
            }
        }
    }

    private void confirmHl2Purchase(String str, String str2, Dialog dialog, Button button, Button button2) {
        ApiClient.registerVasPackage(str, str2, this.token, new AnonymousClass6(button, dialog));
    }
}
