package com.zeno.app;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.zeno.app";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final int VERSION_CODE = 6;
    public static final String VERSION_NAME = "1.0.0";
}
