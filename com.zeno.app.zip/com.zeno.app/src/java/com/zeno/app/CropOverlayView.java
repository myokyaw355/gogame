package com.zeno.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public class CropOverlayView extends View {
    private final Paint borderPaint;
    private final RectF cropRect;
    private final Paint dimPaint;
    private final Path dimPath;
    private final Paint gridPaint;

    public CropOverlayView(Context context) {
        super(context);
        this.dimPaint = new Paint(1);
        this.borderPaint = new Paint(1);
        this.gridPaint = new Paint(1);
        this.dimPath = new Path();
        this.cropRect = new RectF();
        init();
    }

    public CropOverlayView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.dimPaint = new Paint(1);
        this.borderPaint = new Paint(1);
        this.gridPaint = new Paint(1);
        this.dimPath = new Path();
        this.cropRect = new RectF();
        init();
    }

    private void init() {
        this.dimPaint.setColor(Color.parseColor("#99000000"));
        this.borderPaint.setStyle(Paint.Style.STROKE);
        this.borderPaint.setStrokeWidth(dp(2.0f));
        this.borderPaint.setColor(-1);
        this.gridPaint.setStyle(Paint.Style.STROKE);
        this.gridPaint.setStrokeWidth(dp(1.0f));
        this.gridPaint.setColor(Color.parseColor("#66FFFFFF"));
        setWillNotDraw(false);
    }

    private float dp(float f) {
        return f * getResources().getDisplayMetrics().density;
    }

    public RectF getCropRect() {
        return new RectF(this.cropRect);
    }

    @Override // android.view.View
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        float fMin = Math.min(i, i2) * 0.82f;
        float f = (i - fMin) / 2.0f;
        float f2 = (i2 - fMin) / 2.0f;
        this.cropRect.set(f, f2, f + fMin, fMin + f2);
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (width == 0 || height == 0) {
            return;
        }
        this.dimPath.reset();
        this.dimPath.addRect(0.0f, 0.0f, width, height, Path.Direction.CW);
        this.dimPath.addRect(this.cropRect, Path.Direction.CCW);
        this.dimPath.setFillType(Path.FillType.EVEN_ODD);
        canvas.drawPath(this.dimPath, this.dimPaint);
        canvas.drawRect(this.cropRect, this.borderPaint);
        float fWidth = this.cropRect.width() / 3.0f;
        float fHeight = this.cropRect.height() / 3.0f;
        for (int i = 1; i <= 2; i++) {
            float f = i;
            float f2 = fWidth * f;
            canvas.drawLine(this.cropRect.left + f2, this.cropRect.top, this.cropRect.left + f2, this.cropRect.bottom, this.gridPaint);
            float f3 = f * fHeight;
            canvas.drawLine(this.cropRect.left, this.cropRect.top + f3, this.cropRect.right, this.cropRect.top + f3, this.gridPaint);
        }
    }
}
