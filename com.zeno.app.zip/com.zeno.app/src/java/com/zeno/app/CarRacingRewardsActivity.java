package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CarRacingRewardsActivity extends AppCompatActivity {
    private static final String GAME_BASE = "https://car-racing.mascom.vn";
    private static final String ORIGIN = "https://car-racing.mascom.vn";
    private static final String TAG = "CRRewards";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12; Redmi K30 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36";
    private static final String X_REQ = "com.myentertainment.oneid";
    private String gameToken;
    private LinearLayout llContent;
    private View pbLoading;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tabAchievement;
    private TextView tabDaily;
    private TextView tabDailyLogin;
    private TextView tabWeekly;
    private TextView tvEmpty;
    private int currentTab = 0;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newFixedThreadPool(2);
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        setContentView(R.layout.activity_car_racing_rewards);
        String stringExtra = getIntent().getStringExtra("gameToken");
        this.gameToken = stringExtra;
        if (stringExtra == null) {
            this.gameToken = "";
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m225lambda$onCreate$0$comzenoappCarRacingRewardsActivity(view);
            }
        });
        this.tabAchievement = (TextView) findViewById(R.id.tabAchievement);
        this.tabDailyLogin = (TextView) findViewById(R.id.tabDailyLogin);
        this.tabDaily = (TextView) findViewById(R.id.tabDaily);
        this.tabWeekly = (TextView) findViewById(R.id.tabWeekly);
        this.llContent = (LinearLayout) findViewById(R.id.llContent);
        this.pbLoading = findViewById(R.id.pbLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda14
            public final void onRefresh() {
                this.f$0.reloadCurrentTab();
            }
        });
        this.tabAchievement.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m226lambda$onCreate$1$comzenoappCarRacingRewardsActivity(view);
            }
        });
        this.tabDailyLogin.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m227lambda$onCreate$2$comzenoappCarRacingRewardsActivity(view);
            }
        });
        this.tabDaily.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m228lambda$onCreate$3$comzenoappCarRacingRewardsActivity(view);
            }
        });
        this.tabWeekly.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda18
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m229lambda$onCreate$4$comzenoappCarRacingRewardsActivity(view);
            }
        });
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m225lambda$onCreate$0$comzenoappCarRacingRewardsActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m226lambda$onCreate$1$comzenoappCarRacingRewardsActivity(View view) {
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m227lambda$onCreate$2$comzenoappCarRacingRewardsActivity(View view) {
        selectTab(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m228lambda$onCreate$3$comzenoappCarRacingRewardsActivity(View view) {
        selectTab(2);
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m229lambda$onCreate$4$comzenoappCarRacingRewardsActivity(View view) {
        selectTab(3);
    }

    private void selectTab(int i) {
        this.currentTab = i;
        styleTab(this.tabAchievement, i == 0);
        styleTab(this.tabDailyLogin, i == 1);
        styleTab(this.tabDaily, i == 2);
        styleTab(this.tabWeekly, i == 3);
        reloadCurrentTab();
    }

    private void styleTab(TextView textView, boolean z) {
        if (z) {
            textView.setBackgroundResource(R.drawable.bg_game_count_selected);
            textView.setTextColor(-3632086);
            textView.setTypeface(null, 1);
        } else {
            textView.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView.setTextColor(-6381922);
            textView.setTypeface(null, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void reloadCurrentTab() {
        this.llContent.removeAllViews();
        this.tvEmpty.setVisibility(8);
        setLoading(true);
        int i = this.currentTab;
        if (i == 0) {
            loadAchievements();
            return;
        }
        if (i == 1) {
            loadDailyLogin();
        } else if (i == 2) {
            loadUserTasks("DAILY");
        } else {
            if (i != 3) {
                return;
            }
            loadUserTasks("WEEKLY");
        }
    }

    private void setLoading(boolean z) {
        if (z) {
            View view = this.pbLoading;
            if (view != null) {
                view.setVisibility(0);
            }
            LinearLayout linearLayout = this.llContent;
            if (linearLayout != null) {
                linearLayout.setVisibility(8);
            }
            ValueAnimator valueAnimator = this.skeletonAnim;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            View view2 = this.pbLoading;
            if (view2 != null) {
                this.skeletonAnim = SkeletonPulse.start(view2);
                return;
            }
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.pbLoading);
        this.skeletonAnim = null;
        View view3 = this.pbLoading;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.llContent;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(0);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    private Request.Builder authGet(String str) {
        return new Request.Builder().url("https://car-racing.mascom.vn" + str).header("Authorization", "Bearer " + this.gameToken).header("Accept", "*/*").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ).get();
    }

    private Request.Builder authPost(String str) {
        return new Request.Builder().url("https://car-racing.mascom.vn" + str).header("Authorization", "Bearer " + this.gameToken).header("Accept", "*/*").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ).post(RequestBody.create("{}", MediaType.parse("application/json")));
    }

    private Object glideModel(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        try {
            return new GlideUrl(str, new LazyHeaders.Builder().addHeader("User-Agent", USER_AGENT).addHeader("Referer", "https://car-racing.mascom.vn/").build());
        } catch (Exception unused) {
            return str;
        }
    }

    private void loadImage(ImageView imageView, String str) {
        Object objGlideModel = glideModel(str);
        if (objGlideModel == null) {
            imageView.setImageResource(R.drawable.ic_gift);
        } else {
            Glide.with(getApplicationContext()).load(objGlideModel).placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift).into(imageView);
        }
    }

    private void loadAchievements() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m218lambda$loadAchievements$7$comzenoappCarRacingRewardsActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadAchievements$7$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m218lambda$loadAchievements$7$comzenoappCarRacingRewardsActivity() {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/achievement").build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                final JSONArray jSONArraySortAchievements = sortAchievements(jSONArrayOptJSONArray);
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m216lambda$loadAchievements$5$comzenoappCarRacingRewardsActivity(jSONArraySortAchievements);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadAchievements", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m217lambda$loadAchievements$6$comzenoappCarRacingRewardsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAchievements$5$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m216lambda$loadAchievements$5$comzenoappCarRacingRewardsActivity(JSONArray jSONArray) {
        setLoading(false);
        if (jSONArray.length() == 0) {
            this.tvEmpty.setVisibility(0);
        } else {
            renderAchievements(jSONArray);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadAchievements$6$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m217lambda$loadAchievements$6$comzenoappCarRacingRewardsActivity(Exception exc) {
        setLoading(false);
        Toast.makeText((Context) this, (CharSequence) ("Load failed: " + exc.getMessage()), 0).show();
    }

    private JSONArray sortAchievements(JSONArray jSONArray) throws Exception {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(jSONArray.getJSONObject(i));
        }
        arrayList.sort(new Comparator() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda12
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return this.f$0.m232lambda$sortAchievements$8$comzenoappCarRacingRewardsActivity((JSONObject) obj, (JSONObject) obj2);
            }
        });
        JSONArray jSONArray2 = new JSONArray();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            jSONArray2.put((JSONObject) it.next());
        }
        return jSONArray2;
    }

    /* JADX INFO: renamed from: lambda$sortAchievements$8$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ int m232lambda$sortAchievements$8$comzenoappCarRacingRewardsActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        return Integer.compare(scoreAch(jSONObject), scoreAch(jSONObject2));
    }

    private int scoreAch(JSONObject jSONObject) {
        boolean zOptBoolean = jSONObject.optBoolean("isClaimed", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("isCompleted", false);
        if (!zOptBoolean2 || zOptBoolean) {
            return !zOptBoolean2 ? 1 : 2;
        }
        return 0;
    }

    private void renderAchievements(JSONArray jSONArray) {
        LayoutInflater layoutInflater;
        int i;
        int i2;
        JSONObject jSONObject;
        View viewInflate;
        ImageView imageView;
        TextView textView;
        TextView textView2;
        ProgressBar progressBar;
        LinearLayout linearLayout;
        final TextView textView3;
        final int iOptInt;
        String strOptString;
        int iOptInt2;
        int iOptInt3;
        boolean zOptBoolean;
        boolean zOptBoolean2;
        final JSONObject jSONObjectOptJSONObject;
        View view;
        int iMin;
        this.llContent.removeAllViews();
        LayoutInflater layoutInflater2 = getLayoutInflater();
        boolean z = false;
        int i3 = 0;
        while (i3 < jSONArray.length()) {
            try {
                jSONObject = jSONArray.getJSONObject(i3);
                viewInflate = layoutInflater2.inflate(R.layout.item_reward_task, this.llContent, z);
                imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
                textView = (TextView) viewInflate.findViewById(R.id.tvTaskName);
                textView2 = (TextView) viewInflate.findViewById(R.id.tvTaskProgress);
                progressBar = (ProgressBar) viewInflate.findViewById(R.id.progressBar);
                linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llTaskRewards);
                textView3 = (TextView) viewInflate.findViewById(R.id.btnClaim);
                iOptInt = jSONObject.optInt("id");
                strOptString = jSONObject.optString("name", "—");
                iOptInt2 = jSONObject.optInt("target", 1);
                layoutInflater = layoutInflater2;
                try {
                    iOptInt3 = jSONObject.optInt("progress", 0);
                    zOptBoolean = jSONObject.optBoolean("isClaimed", false);
                    i = i3;
                } catch (Exception e) {
                    e = e;
                    i = i3;
                }
            } catch (Exception e2) {
                e = e2;
                layoutInflater = layoutInflater2;
                i = i3;
            }
            try {
                zOptBoolean2 = jSONObject.optBoolean("isCompleted", false);
            } catch (Exception e3) {
                e = e3;
                StringBuilder sb = new StringBuilder("render ach ");
                i2 = i;
                sb.append(i2);
                Log.e(TAG, sb.toString(), e);
            }
            try {
                jSONObjectOptJSONObject = jSONObject.optJSONObject("reward");
                String strOptString2 = "";
                if (jSONObjectOptJSONObject != null) {
                    view = viewInflate;
                    strOptString2 = jSONObjectOptJSONObject.optString("icon", "");
                } else {
                    view = viewInflate;
                }
                textView.setText(strOptString);
                textView2.setText(iOptInt3 + " / " + iOptInt2);
                iMin = iOptInt2 > 0 ? Math.min(100, (int) ((iOptInt3 * 100.0f) / iOptInt2)) : 0;
                progressBar.setProgress(iMin);
                loadImage(imageView, strOptString2);
                if (jSONObjectOptJSONObject != null) {
                    JSONArray jSONArray2 = new JSONArray();
                    jSONArray2.put(jSONObjectOptJSONObject);
                    bindRewardIcons(linearLayout, jSONArray2);
                }
            } catch (Exception e4) {
                e = e4;
                StringBuilder sb2 = new StringBuilder("render ach ");
                i2 = i;
                sb2.append(i2);
                Log.e(TAG, sb2.toString(), e);
            }
            if (zOptBoolean) {
                textView3.setText("Claimed");
                textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView3.setTextColor(-7829368);
                textView3.setEnabled(false);
            } else if (zOptBoolean2) {
                textView3.setText("Claim");
                textView3.setBackgroundResource(R.drawable.bg_btn_gold);
                textView3.setTextColor(-16777216);
                textView3.setEnabled(true);
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        this.f$0.m230lambda$renderAchievements$9$comzenoappCarRacingRewardsActivity(iOptInt, textView3, jSONObjectOptJSONObject, view2);
                    }
                });
            } else {
                textView3.setText(iMin + "%");
                textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView3.setTextColor(-5592406);
                textView3.setEnabled(false);
                this.llContent.addView(view);
                i2 = i;
                i3 = i2 + 1;
                layoutInflater2 = layoutInflater;
                z = false;
            }
            this.llContent.addView(view);
            i2 = i;
            i3 = i2 + 1;
            layoutInflater2 = layoutInflater;
            z = false;
        }
    }

    /* JADX INFO: renamed from: lambda$renderAchievements$9$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m230lambda$renderAchievements$9$comzenoappCarRacingRewardsActivity(int i, TextView textView, JSONObject jSONObject, View view) {
        claimAchievement(i, textView, jSONObject);
    }

    private void claimAchievement(final int i, final TextView textView, final JSONObject jSONObject) {
        textView.setEnabled(false);
        textView.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda31
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m209lambda$claimAchievement$12$comzenoappCarRacingRewardsActivity(i, jSONObject, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimAchievement$12$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m209lambda$claimAchievement$12$comzenoappCarRacingRewardsActivity(int i, JSONObject jSONObject, final TextView textView) {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/achievement/claim/" + i).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject2 = new JSONObject(strString);
                final boolean z = jSONObject2.optBoolean("success", false) || "00000".equals(jSONObject2.optString("error"));
                final JSONArray jSONArrayOptJSONArray = jSONObject2.optJSONArray("data");
                if (jSONArrayOptJSONArray == null && jSONObject != null) {
                    jSONArrayOptJSONArray = new JSONArray();
                    jSONArrayOptJSONArray.put(jSONObject);
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda22
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m207lambda$claimAchievement$10$comzenoappCarRacingRewardsActivity(z, jSONArrayOptJSONArray, textView);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda25
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m208lambda$claimAchievement$11$comzenoappCarRacingRewardsActivity(textView, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimAchievement$10$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m207lambda$claimAchievement$10$comzenoappCarRacingRewardsActivity(boolean z, JSONArray jSONArray, TextView textView) {
        if (z) {
            showClaimRewardsDialog(jSONArray);
            reloadCurrentTab();
        } else {
            textView.setEnabled(true);
            textView.setText("Claim");
            Toast.makeText((Context) this, (CharSequence) "Claim failed", 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimAchievement$11$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m208lambda$claimAchievement$11$comzenoappCarRacingRewardsActivity(TextView textView, Exception exc) {
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void loadDailyLogin() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m221lambda$loadDailyLogin$15$comzenoappCarRacingRewardsActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadDailyLogin$15$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m221lambda$loadDailyLogin$15$comzenoappCarRacingRewardsActivity() {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/task/daily-login").build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda19
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m219lambda$loadDailyLogin$13$comzenoappCarRacingRewardsActivity(jSONArrayOptJSONArray);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadDailyLogin", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda20
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m220lambda$loadDailyLogin$14$comzenoappCarRacingRewardsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadDailyLogin$13$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m219lambda$loadDailyLogin$13$comzenoappCarRacingRewardsActivity(JSONArray jSONArray) {
        setLoading(false);
        if (jSONArray.length() == 0) {
            this.tvEmpty.setVisibility(0);
        } else {
            renderDailyLogin(jSONArray);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadDailyLogin$14$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m220lambda$loadDailyLogin$14$comzenoappCarRacingRewardsActivity(Exception exc) {
        setLoading(false);
        Toast.makeText((Context) this, (CharSequence) ("Load failed: " + exc.getMessage()), 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderDailyLogin(JSONArray jSONArray) {
        int i;
        this.llContent.removeAllViews();
        TextView textView = new TextView(this);
        textView.setText("Daily Login Rewards");
        textView.setTextColor(-1);
        textView.setTextSize(15.0f);
        textView.setTypeface(null, 1);
        textView.setPadding(4, 4, 4, 12);
        this.llContent.addView(textView);
        int length = jSONArray.length();
        int i2 = length / 3;
        int i3 = length % 3;
        int i4 = (int) (getResources().getDisplayMetrics().density * 6.0f);
        LayoutInflater layoutInflater = getLayoutInflater();
        float f = 1.0f;
        int i5 = -2;
        int i6 = 0;
        if (i2 > 0) {
            GridLayout gridLayout = new GridLayout(this);
            gridLayout.setColumnCount(3);
            gridLayout.setUseDefaultMargins(false);
            gridLayout.setAlignmentMode(0);
            gridLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            int i7 = i2 * 3;
            int i8 = 0;
            while (i8 < i7) {
                try {
                    View viewBuildDailyLoginCell = buildDailyLoginCell(layoutInflater, jSONArray.getJSONObject(i8), gridLayout);
                    GridLayout.LayoutParams layoutParams = new GridLayout.LayoutParams();
                    layoutParams.width = i6;
                    layoutParams.height = i5;
                    layoutParams.columnSpec = GridLayout.spec(i8 % 3, f);
                    layoutParams.rowSpec = GridLayout.spec(i8 / 3);
                    i = i7;
                    try {
                        layoutParams.setMargins(i4 / 2, i4 / 2, i4 / 2, i4 / 2);
                        viewBuildDailyLoginCell.setLayoutParams(layoutParams);
                        gridLayout.addView(viewBuildDailyLoginCell);
                    } catch (Exception e) {
                        e = e;
                        Log.e(TAG, "render daily login " + i8, e);
                    }
                } catch (Exception e2) {
                    e = e2;
                    i = i7;
                }
                i8++;
                i7 = i;
                f = 1.0f;
                i5 = -2;
                i6 = 0;
            }
            this.llContent.addView(gridLayout);
        }
        if (i3 > 0) {
            int iMin = Math.min(i3, 2);
            GridLayout gridLayout2 = new GridLayout(this);
            gridLayout2.setColumnCount(iMin);
            gridLayout2.setUseDefaultMargins(false);
            gridLayout2.setAlignmentMode(0);
            gridLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
            int i9 = i2 * 3;
            for (int i10 = i9; i10 < length; i10++) {
                try {
                    View viewBuildDailyLoginCell2 = buildDailyLoginCell(layoutInflater, jSONArray.getJSONObject(i10), gridLayout2);
                    GridLayout.LayoutParams layoutParams2 = new GridLayout.LayoutParams();
                    layoutParams2.width = 0;
                    layoutParams2.height = -2;
                    int i11 = i10 - i9;
                    layoutParams2.columnSpec = GridLayout.spec(i11 % iMin, 1.0f);
                    layoutParams2.rowSpec = GridLayout.spec(i11 / iMin);
                    layoutParams2.setMargins(i4 / 2, i4 / 2, i4 / 2, i4 / 2);
                    viewBuildDailyLoginCell2.setLayoutParams(layoutParams2);
                    gridLayout2.addView(viewBuildDailyLoginCell2);
                } catch (Exception e3) {
                    Log.e(TAG, "render daily login last " + i10, e3);
                }
            }
            this.llContent.addView(gridLayout2);
        }
    }

    private View buildDailyLoginCell(LayoutInflater layoutInflater, JSONObject jSONObject, ViewGroup viewGroup) {
        View viewInflate = layoutInflater.inflate(R.layout.item_daily_login, viewGroup, false);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvDay);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivDayIcon);
        LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llDayRewards);
        final TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvDayStatus);
        final int iOptInt = jSONObject.optInt("id");
        String strOptString = jSONObject.optString("name", "Day");
        String strOptString2 = jSONObject.optString("iconReward", "");
        boolean zOptBoolean = jSONObject.optBoolean("completed", false);
        boolean zOptBoolean2 = jSONObject.optBoolean("claimed", false);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("reward");
        if (textView != null) {
            textView.setText(strOptString);
        }
        if (strOptString2 != null && !strOptString2.isEmpty() && !"null".equals(strOptString2)) {
            loadImage(imageView, strOptString2);
        } else if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0) {
            try {
                loadImage(imageView, jSONArrayOptJSONArray.getJSONObject(0).optString("icon", ""));
            } catch (Exception unused) {
            }
        }
        bindRewardIcons(linearLayout, jSONArrayOptJSONArray);
        if (textView2 != null) {
            if (zOptBoolean2) {
                textView2.setText("✓");
                textView2.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView2.setTextColor(-11751600);
                textView2.setEnabled(false);
            } else if (zOptBoolean) {
                textView2.setText("Claim");
                textView2.setBackgroundResource(R.drawable.bg_btn_gold);
                textView2.setTextColor(-16777216);
                textView2.setEnabled(true);
                textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda30
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m206lambda$buildDailyLoginCell$16$comzenoappCarRacingRewardsActivity(iOptInt, textView2, view);
                    }
                });
            } else {
                textView2.setText("Locked");
                textView2.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView2.setTextColor(-10066330);
                textView2.setEnabled(false);
            }
        }
        return viewInflate;
    }

    /* JADX INFO: renamed from: lambda$buildDailyLoginCell$16$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m206lambda$buildDailyLoginCell$16$comzenoappCarRacingRewardsActivity(int i, TextView textView, View view) {
        claimDailyLogin(i, textView);
    }

    private void claimDailyLogin(final int i, final TextView textView) {
        textView.setEnabled(false);
        textView.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m212lambda$claimDailyLogin$19$comzenoappCarRacingRewardsActivity(i, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimDailyLogin$19$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m212lambda$claimDailyLogin$19$comzenoappCarRacingRewardsActivity(int i, final TextView textView) {
        try {
            Response responseExecute = this.http.newCall(authPost("/api/task/daily-login/claim/" + i).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject = new JSONObject(strString);
                final boolean z = jSONObject.optBoolean("success", false) || "00000".equals(jSONObject.optString("error"));
                final JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda28
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m210lambda$claimDailyLogin$17$comzenoappCarRacingRewardsActivity(z, jSONArrayOptJSONArray, textView);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda29
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m211lambda$claimDailyLogin$18$comzenoappCarRacingRewardsActivity(textView, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimDailyLogin$17$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m210lambda$claimDailyLogin$17$comzenoappCarRacingRewardsActivity(boolean z, JSONArray jSONArray, TextView textView) {
        if (z) {
            showClaimRewardsDialog(jSONArray);
            reloadCurrentTab();
        } else {
            textView.setEnabled(true);
            textView.setText("Claim");
            Toast.makeText((Context) this, (CharSequence) "Claim failed", 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimDailyLogin$18$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m211lambda$claimDailyLogin$18$comzenoappCarRacingRewardsActivity(TextView textView, Exception exc) {
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void loadUserTasks(final String str) {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m224lambda$loadUserTasks$22$comzenoappCarRacingRewardsActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadUserTasks$22$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m224lambda$loadUserTasks$22$comzenoappCarRacingRewardsActivity(final String str) {
        try {
            Response responseExecute = this.http.newCall(authGet("/api/task/user/" + str).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final JSONObject jSONObjectOptJSONObject = new JSONObject(strString).optJSONObject("data");
                if (jSONObjectOptJSONObject == null) {
                    jSONObjectOptJSONObject = new JSONObject();
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m222lambda$loadUserTasks$20$comzenoappCarRacingRewardsActivity(jSONObjectOptJSONObject, str);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadUserTasks " + str, e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m223lambda$loadUserTasks$21$comzenoappCarRacingRewardsActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadUserTasks$20$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m222lambda$loadUserTasks$20$comzenoappCarRacingRewardsActivity(JSONObject jSONObject, String str) {
        setLoading(false);
        renderUserTasks(jSONObject, str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadUserTasks$21$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m223lambda$loadUserTasks$21$comzenoappCarRacingRewardsActivity(Exception exc) {
        setLoading(false);
        Toast.makeText((Context) this, (CharSequence) ("Load failed: " + exc.getMessage()), 0).show();
    }

    private void renderUserTasks(JSONObject jSONObject, String str) {
        JSONArray jSONArrayOptJSONArray;
        this.llContent.removeAllViews();
        LayoutInflater layoutInflater = getLayoutInflater();
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("milestoneTasks");
        if (jSONObjectOptJSONObject != null && (jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("tasks")) != null && jSONArrayOptJSONArray.length() > 0) {
            this.llContent.addView(sectionHeader("Milestones"));
            for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                try {
                    addTaskRow(layoutInflater, jSONArrayOptJSONArray.getJSONObject(i), true);
                } catch (Exception unused) {
                }
            }
        }
        JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray("userTasks");
        if (jSONArrayOptJSONArray2 != null && jSONArrayOptJSONArray2.length() > 0) {
            this.llContent.addView(sectionHeader(str.equals("WEEKLY") ? "Weekly Tasks" : "Daily Tasks"));
            try {
                ArrayList arrayList = new ArrayList();
                for (int i2 = 0; i2 < jSONArrayOptJSONArray2.length(); i2++) {
                    arrayList.add(jSONArrayOptJSONArray2.getJSONObject(i2));
                }
                arrayList.sort(new Comparator() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda21
                    @Override // java.util.Comparator
                    public final int compare(Object obj, Object obj2) {
                        return this.f$0.m231lambda$renderUserTasks$23$comzenoappCarRacingRewardsActivity((JSONObject) obj, (JSONObject) obj2);
                    }
                });
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    addTaskRow(layoutInflater, (JSONObject) it.next(), false);
                }
            } catch (Exception e) {
                Log.e(TAG, "sort tasks", e);
            }
        }
        if (this.llContent.getChildCount() == 0) {
            this.tvEmpty.setVisibility(0);
        }
    }

    /* JADX INFO: renamed from: lambda$renderUserTasks$23$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ int m231lambda$renderUserTasks$23$comzenoappCarRacingRewardsActivity(JSONObject jSONObject, JSONObject jSONObject2) {
        boolean zCanClaimTask = canClaimTask(jSONObject);
        if (zCanClaimTask != canClaimTask(jSONObject2)) {
            return zCanClaimTask ? -1 : 1;
        }
        boolean zOptBoolean = jSONObject.optBoolean("claimed", false);
        if (zOptBoolean != jSONObject2.optBoolean("claimed", false)) {
            return zOptBoolean ? 1 : -1;
        }
        return 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private TextView sectionHeader(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-1);
        textView.setTextSize(14.0f);
        textView.setTypeface(null, 1);
        textView.setPadding(4, 12, 4, 8);
        return textView;
    }

    private boolean canClaimTask(JSONObject jSONObject) {
        return !jSONObject.optBoolean("claimed", false) && jSONObject.optInt("progress", 0) >= jSONObject.optInt("target", 1);
    }

    private void addTaskRow(LayoutInflater layoutInflater, JSONObject jSONObject, boolean z) {
        View viewInflate = layoutInflater.inflate(R.layout.item_reward_task, (ViewGroup) this.llContent, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvTaskName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvTaskProgress);
        ProgressBar progressBar = (ProgressBar) viewInflate.findViewById(R.id.progressBar);
        LinearLayout linearLayout = (LinearLayout) viewInflate.findViewById(R.id.llTaskRewards);
        final TextView textView3 = (TextView) viewInflate.findViewById(R.id.btnClaim);
        final int iOptInt = jSONObject.optInt("id");
        String strOptString = jSONObject.optString("name", "—");
        int iOptInt2 = jSONObject.optInt("target", 1);
        int iOptInt3 = jSONObject.optInt("progress", 0);
        boolean zOptBoolean = jSONObject.optBoolean("claimed", false);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("reward");
        textView.setText(strOptString);
        textView2.setText(iOptInt3 + " / " + iOptInt2);
        int iMin = iOptInt2 > 0 ? Math.min(100, (int) ((iOptInt3 * 100.0f) / iOptInt2)) : 0;
        progressBar.setProgress(iMin);
        String strOptString2 = "";
        if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0 && jSONArrayOptJSONArray.optJSONObject(0) != null) {
            strOptString2 = jSONArrayOptJSONArray.optJSONObject(0).optString("icon", "");
        }
        loadImage(imageView, strOptString2);
        bindRewardIcons(linearLayout, jSONArrayOptJSONArray);
        boolean z2 = !zOptBoolean && iOptInt3 >= iOptInt2;
        if (zOptBoolean) {
            textView3.setText("Claimed");
            textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView3.setTextColor(-7829368);
            textView3.setEnabled(false);
        } else if (z2) {
            textView3.setText("Claim");
            textView3.setBackgroundResource(R.drawable.bg_btn_gold);
            textView3.setTextColor(-16777216);
            textView3.setEnabled(true);
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda27
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m205lambda$addTaskRow$24$comzenoappCarRacingRewardsActivity(iOptInt, textView3, view);
                }
            });
        } else {
            textView3.setText(iMin + "%");
            textView3.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView3.setTextColor(-5592406);
            textView3.setEnabled(false);
        }
        this.llContent.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addTaskRow$24$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m205lambda$addTaskRow$24$comzenoappCarRacingRewardsActivity(int i, TextView textView, View view) {
        claimUserTask(i, textView);
    }

    private void claimUserTask(final int i, final TextView textView) {
        textView.setEnabled(false);
        textView.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m215lambda$claimUserTask$27$comzenoappCarRacingRewardsActivity(i, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimUserTask$27$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m215lambda$claimUserTask$27$comzenoappCarRacingRewardsActivity(int i, final TextView textView) {
        try {
            Response responseExecute = this.http.newCall(authPost("/api/task/user/claim/" + i).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject = new JSONObject(strString);
                final boolean z = jSONObject.optBoolean("success", false) || "00000".equals(jSONObject.optString("error"));
                final JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
                final String strOptString = jSONObject.optString("message", "Claim failed");
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda23
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m213lambda$claimUserTask$25$comzenoappCarRacingRewardsActivity(z, jSONArrayOptJSONArray, textView, strOptString);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda24
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m214lambda$claimUserTask$26$comzenoappCarRacingRewardsActivity(textView, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimUserTask$25$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m213lambda$claimUserTask$25$comzenoappCarRacingRewardsActivity(boolean z, JSONArray jSONArray, TextView textView, String str) {
        if (z) {
            showClaimRewardsDialog(jSONArray);
            reloadCurrentTab();
        } else {
            textView.setEnabled(true);
            textView.setText("Claim");
            Toast.makeText((Context) this, (CharSequence) str, 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$claimUserTask$26$com-zeno-app-CarRacingRewardsActivity, reason: not valid java name */
    /* synthetic */ void m214lambda$claimUserTask$26$comzenoappCarRacingRewardsActivity(TextView textView, Exception exc) {
        textView.setEnabled(true);
        textView.setText("Claim");
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showClaimRewardsDialog(JSONArray jSONArray) {
        if (isFinishing()) {
            return;
        }
        if (jSONArray == null || jSONArray.length() == 0) {
            Toast.makeText((Context) this, (CharSequence) "Claimed!", 0).show();
            return;
        }
        try {
            if (jSONArray.length() == 1) {
                showSingleRewardDialog(jSONArray.getJSONObject(0));
                return;
            }
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_rewards);
            dialog.setCancelable(true);
            LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.llRewardsTop);
            LinearLayout linearLayout2 = (LinearLayout) dialog.findViewById(R.id.llRewardsBottom);
            Button button = (Button) dialog.findViewById(R.id.btnRewardsOk);
            int iMin = Math.min(jSONArray.length(), 6);
            int iMin2 = Math.min(iMin, 3);
            int i = iMin - iMin2;
            for (int i2 = 0; i2 < iMin2; i2++) {
                addRewardDialogItem(linearLayout, jSONArray.getJSONObject(i2));
            }
            for (int i3 = 0; i3 < i; i3++) {
                addRewardDialogItem(linearLayout2, jSONArray.getJSONObject(iMin2 + i3));
            }
            if (linearLayout2 != null) {
                linearLayout2.setVisibility(i > 0 ? 0 : 8);
            }
            if (button != null) {
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda26
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout(getResources().getDisplayMetrics().widthPixels - (((int) (getResources().getDisplayMetrics().density * 20.0f)) * 2), -2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.gravity = 17;
                attributes.dimAmount = 0.7f;
                window.setAttributes(attributes);
                window.addFlags(2);
            }
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "showClaimRewardsDialog", e);
            Toast.makeText((Context) this, (CharSequence) "Claimed!", 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showSingleRewardDialog(JSONObject jSONObject) {
        String str;
        try {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_spin_result);
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85f), -2);
            }
            String strOptString = jSONObject.optString("code", "");
            String strOptString2 = jSONObject.optString("name", rewardTitle(strOptString));
            int iOptDouble = (int) jSONObject.optDouble("value", 0.0d);
            String strOptString3 = jSONObject.optString("icon", "");
            ImageView imageView = (ImageView) dialog.findViewById(R.id.resultIcon);
            TextView textView = (TextView) dialog.findViewById(R.id.resultEmoji);
            TextView textView2 = (TextView) dialog.findViewById(R.id.resultTitle);
            TextView textView3 = (TextView) dialog.findViewById(R.id.resultDetail);
            Button button = (Button) dialog.findViewById(R.id.btnResultClose);
            boolean zEqualsIgnoreCase = "TURN_LUCKY_SPIN".equalsIgnoreCase(strOptString);
            if (imageView != null) {
                if (strOptString3 != null && !strOptString3.isEmpty()) {
                    loadImage(imageView, strOptString3);
                    imageView.setVisibility(0);
                    if (textView != null) {
                        textView.setVisibility(8);
                    }
                } else {
                    imageView.setVisibility(8);
                    if (textView != null) {
                        textView.setText(rewardEmoji(strOptString));
                        textView.setVisibility(0);
                    }
                }
            }
            if (textView2 != null) {
                textView2.setText(strOptString2);
            }
            if (textView3 != null) {
                if (zEqualsIgnoreCase) {
                    if (iOptDouble > 0) {
                        str = "+" + iOptDouble + " Spin";
                    } else {
                        str = "+1 Spin";
                    }
                    textView3.setText(str);
                    textView3.setVisibility(0);
                } else if (iOptDouble > 0) {
                    textView3.setText("+" + String.format(Locale.getDefault(), "%,d", Integer.valueOf(iOptDouble)));
                    textView3.setVisibility(0);
                } else {
                    textView3.setVisibility(8);
                }
            }
            if (button != null) {
                button.setText("ရယူမည်");
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingRewardsActivity$$ExternalSyntheticLambda9
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "showSingleRewardDialog", e);
            Toast.makeText((Context) this, (CharSequence) "Claimed!", 0).show();
        }
    }

    private void addRewardDialogItem(LinearLayout linearLayout, JSONObject jSONObject) {
        if (linearLayout == null || jSONObject == null) {
            return;
        }
        try {
            View viewInflate = getLayoutInflater().inflate(R.layout.item_reward_dialog, (ViewGroup) linearLayout, false);
            ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
            TextView textView = (TextView) viewInflate.findViewById(R.id.tvRewardAmt);
            String strOptString = jSONObject.optString("code", "");
            String strOptString2 = jSONObject.optString("name", rewardTitle(strOptString));
            int iOptDouble = (int) jSONObject.optDouble("value", 0.0d);
            String strOptString3 = jSONObject.optString("icon", "");
            boolean zEqualsIgnoreCase = "TURN_LUCKY_SPIN".equalsIgnoreCase(strOptString);
            if (imageView != null) {
                loadImage(imageView, strOptString3);
            }
            if (textView != null) {
                if (zEqualsIgnoreCase) {
                    StringBuilder sb = new StringBuilder();
                    if (iOptDouble <= 0) {
                        iOptDouble = 1;
                    }
                    sb.append(iOptDouble);
                    sb.append(" Spin");
                    textView.setText(sb.toString());
                } else {
                    textView.setText(iOptDouble + " " + strOptString2);
                }
            }
            linearLayout.addView(viewInflate);
        } catch (Exception e) {
            Log.e(TAG, "addRewardDialogItem", e);
        }
    }

    private String rewardEmoji(String str) {
        String upperCase = str == null ? "" : str.toUpperCase(Locale.US);
        upperCase.hashCode();
        switch (upperCase) {
            case "TURN_LUCKY_SPIN":
                return "🎰";
            case "LP":
                return "⭐";
            case "GEM":
                return "💎";
            case "COIN":
                return "🪙";
            case "DATA":
                return "📶";
            default:
                return "🎁";
        }
    }

    private String rewardTitle(String str) {
        String upperCase;
        upperCase = str == null ? "" : str.toUpperCase(Locale.US);
        upperCase.hashCode();
        switch (upperCase) {
            case "TURN_LUCKY_SPIN":
                return "Lucky Spin";
            case "LP":
                return "Loyalty Points";
            case "GEM":
                return "Gem";
            case "COIN":
                return "Coin";
            case "DATA":
                return "Data";
            default:
                return upperCase.isEmpty() ? "Reward" : upperCase;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void bindRewardIcons(LinearLayout linearLayout, JSONArray jSONArray) {
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        if (jSONArray == null || jSONArray.length() == 0) {
            return;
        }
        float f = getResources().getDisplayMetrics().density;
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                String strOptString = jSONObject.optString("icon", "");
                String strOptString2 = jSONObject.optString("code", "");
                int iOptDouble = (int) jSONObject.optDouble("value", 0.0d);
                if (i > 0) {
                    TextView textView = new TextView(this);
                    textView.setText("  ");
                    textView.setTextSize(11.0f);
                    linearLayout.addView(textView);
                }
                ImageView imageView = new ImageView(this);
                int i2 = (int) (16.0f * f);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(i2, i2);
                layoutParams.rightMargin = (int) (3.0f * f);
                imageView.setLayoutParams(layoutParams);
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                loadImage(imageView, strOptString);
                linearLayout.addView(imageView);
                TextView textView2 = new TextView(this);
                if ("TURN_LUCKY_SPIN".equalsIgnoreCase(strOptString2)) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("x");
                    if (iOptDouble <= 0) {
                        iOptDouble = 1;
                    }
                    sb.append(iOptDouble);
                    textView2.setText(sb.toString());
                } else if ("DATA".equalsIgnoreCase(strOptString2)) {
                    textView2.setText(iOptDouble + " MB");
                } else if ("LP".equalsIgnoreCase(strOptString2)) {
                    textView2.setText(iOptDouble + " LP");
                } else {
                    textView2.setText(String.valueOf(iOptDouble));
                }
                textView2.setTextColor(-3632086);
                textView2.setTextSize(11.0f);
                textView2.setTypeface(null, 1);
                linearLayout.addView(textView2);
            } catch (Exception e) {
                Log.e(TAG, "bindRewardIcons", e);
            }
        }
    }

    private String formatReward(String str, double d) {
        String upperCase;
        int i;
        upperCase = str == null ? "" : str.toUpperCase(Locale.US);
        i = (int) d;
        upperCase.hashCode();
        switch (upperCase) {
            case "TURN_LUCKY_SPIN":
                return "🎰 x" + i;
            case "LP":
                return "⭐ " + i + " LP";
            case "GEM":
                return "💎 " + i;
            case "COIN":
                return "🪙 " + i;
            case "DATA":
                return "📶 " + i + " MB";
            default:
                return upperCase + " " + i;
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }
}
