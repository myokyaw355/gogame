package com.zeno.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.util.Property;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class BeatZooActivity extends BaseActivity {
    private static final String API = "https://beatzoo.mascom.vn/api/client-api";
    private static final String API_KEY = "60015110c58af6c4a6beec794ab40b89b1042b42cb5380e86daee037cf96ef8b";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String LOGIN_URL = "https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login";
    private static final String MCUID_FALLBACK = "d26116fa96257ec6304156e5a475c76b";
    private static final String SONG_CDN = "https://beatzoo.mascom.vn/songs/";
    private static final String TAG = "BeatZoo";
    private static final String TOKEN_AUTH = "https://beatzoo.mascom.vn/api/client-api/token-auth";
    private View autoPlaySkeleton;
    private ValueAnimator autoPlaySkeletonAnim;
    private View balanceCard;
    private View balanceCardSkeleton;
    private ValueAnimator balanceCardSkeletonAnim;
    private TextView btnClaimAll;
    private ImageView btnGiftMissions;
    private TextView btnModeEasy;
    private TextView btnModeHard;
    private TextView btnMonthly;
    private ImageView btnMute;
    private TextView btnPlay;
    private TextView btnWeekly;
    private ExecutorService exec;
    private LinearLayout headerPlayOnly;
    private ImageView ivAvatar;
    private ImageView ivEditName;
    private String jwt;
    private MediaPlayer mediaPlayer;
    private LinearLayout missionList;
    private View modeRow;
    private View modeSkeleton;
    private ValueAnimator modeSkeletonAnim;
    private LinearLayout panelMissions;
    private LinearLayout panelPlay;
    private ProgressBar playProgress;
    private String previewSongId;
    private View profileCard;
    private View profileCardSkeleton;
    private ValueAnimator profileCardSkeletonAnim;
    private LinearLayout rankList;
    private View rankLoading;
    private ValueAnimator rankSkeletonAnim;
    private View rankUserFooter;
    private LinearLayout rankUserRow;
    private JSONObject selectedSong;
    private View selectedSongInfoCard;
    private SessionManager session;
    private boolean songGestureDragged;
    private LinearLayout songList;
    private View songListSkeleton;
    private SongScrollView songScrollView;
    private ValueAnimator songSkeletonAnim;
    private float songTouchDownX;
    private float songTouchDownY;
    private boolean songTouchDragging;
    private float songTouchLastY;
    private SwipeRefreshLayout swipeRefresh;
    private View tabMissions;
    private View tabMissionsUnderline;
    private View tabPlay;
    private View tabPlayUnderline;
    private TextView tvGem;
    private TextView tvHeart;
    private TextView tvPlayStatus;
    private TextView tvProfileName;
    private TextView tvProfilePhone;
    private TextView tvSongMode;
    private TextView tvSongName;
    private TextView tvSongScore;
    private TextView tvTabMissions;
    private TextView tvTabPlay;
    private TextView tvTicket;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).followRedirects(false).followSslRedirects(false).build();
    private String mode = "easy";
    private final List<JSONObject> songs = new ArrayList();
    private final List<JSONObject> missions = new ArrayList();
    private final AtomicBoolean playing = new AtomicBoolean(false);
    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private volatile int gameAudioDurationSec = 0;
    private volatile boolean gameAudioCompleted = false;
    private boolean muted = false;
    private boolean gameAudioActive = false;
    private String rankType = "weekly";
    private int songTouchSlop = 16;
    private String profileName = "";
    private String profilePhone = "";
    private String profileAvatar = "";

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_beat_zoo);
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda38
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m28lambda$onCreate$0$comzenoappBeatZooActivity(view);
            }
        });
        bindViews();
        startHeaderCardSkeletons();
        setupTabs();
        setupModeButtons();
        TextView textView = this.btnPlay;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda40
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m29lambda$onCreate$1$comzenoappBeatZooActivity(view);
                }
            });
        }
        TextView textView2 = this.btnClaimAll;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda41
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m30lambda$onCreate$2$comzenoappBeatZooActivity(view);
                }
            });
        }
        ImageView imageView = this.btnGiftMissions;
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda42
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m31lambda$onCreate$3$comzenoappBeatZooActivity(view);
                }
            });
            startGiftPulse(this.btnGiftMissions);
        }
        View viewFindViewById = findViewById(R.id.btnBeatSpin);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda43
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m32lambda$onCreate$4$comzenoappBeatZooActivity(view);
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.btnOpenShop);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda45
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m33lambda$onCreate$5$comzenoappBeatZooActivity(view);
                }
            });
        }
        TextView textView3 = this.btnWeekly;
        if (textView3 != null) {
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda46
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m34lambda$onCreate$6$comzenoappBeatZooActivity(view);
                }
            });
        }
        TextView textView4 = this.btnMonthly;
        if (textView4 != null) {
            textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda47
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m35lambda$onCreate$7$comzenoappBeatZooActivity(view);
                }
            });
        }
        this.songScrollView = (SongScrollView) findViewById(R.id.songScroll);
        this.songTouchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        final ScrollView scrollView = (ScrollView) findViewById(R.id.mainScroll);
        SongScrollView songScrollView = this.songScrollView;
        if (songScrollView != null) {
            songScrollView.setOnTouchListener(new View.OnTouchListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda48
                @Override // android.view.View.OnTouchListener
                public final boolean onTouch(View view, MotionEvent motionEvent) {
                    return this.f$0.m36lambda$onCreate$8$comzenoappBeatZooActivity(scrollView, view, motionEvent);
                }
            });
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda49
                public final void onRefresh() {
                    this.f$0.refreshAll();
                }
            });
            final NestedScrollView nestedScrollViewFindViewById = findViewById(R.id.rankScroll);
            if (nestedScrollViewFindViewById != null) {
                nestedScrollViewFindViewById.setNestedScrollingEnabled(false);
            }
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda39
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout2, View view) {
                    return this.f$0.m37lambda$onCreate$9$comzenoappBeatZooActivity(nestedScrollViewFindViewById, scrollView, swipeRefreshLayout2, view);
                }
            });
        }
        refreshAll();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m28lambda$onCreate$0$comzenoappBeatZooActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m29lambda$onCreate$1$comzenoappBeatZooActivity(View view) {
        if (this.playing.get()) {
            onStopClicked();
        } else {
            onPlayClicked();
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m30lambda$onCreate$2$comzenoappBeatZooActivity(View view) {
        claimAllCompleted();
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m31lambda$onCreate$3$comzenoappBeatZooActivity(View view) {
        openMissionsPage();
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m32lambda$onCreate$4$comzenoappBeatZooActivity(View view) {
        openBeatSpin();
    }

    /* JADX INFO: renamed from: lambda$onCreate$5$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m33lambda$onCreate$5$comzenoappBeatZooActivity(View view) {
        openBeatShop();
    }

    /* JADX INFO: renamed from: lambda$onCreate$6$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m34lambda$onCreate$6$comzenoappBeatZooActivity(View view) {
        setRankType("weekly");
    }

    /* JADX INFO: renamed from: lambda$onCreate$7$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m35lambda$onCreate$7$comzenoappBeatZooActivity(View view) {
        setRankType("monthly");
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0011  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0019  */
    /* JADX INFO: renamed from: lambda$onCreate$8$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ boolean m36lambda$onCreate$8$comzenoappBeatZooActivity(android.widget.ScrollView r3, android.view.View r4, android.view.MotionEvent r5) {
        /*
            r2 = this;
            int r4 = r5.getActionMasked()
            r5 = 0
            r0 = 1
            if (r4 == 0) goto L19
            if (r4 == r0) goto L11
            r1 = 2
            if (r4 == r1) goto L19
            r3 = 3
            if (r4 == r3) goto L11
            goto L25
        L11:
            androidx.swiperefreshlayout.widget.SwipeRefreshLayout r3 = r2.swipeRefresh
            if (r3 == 0) goto L25
            r3.setEnabled(r0)
            goto L25
        L19:
            androidx.swiperefreshlayout.widget.SwipeRefreshLayout r4 = r2.swipeRefresh
            if (r4 == 0) goto L20
            r4.setEnabled(r5)
        L20:
            if (r3 == 0) goto L25
            r3.requestDisallowInterceptTouchEvent(r0)
        L25:
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.BeatZooActivity.m36lambda$onCreate$8$comzenoappBeatZooActivity(android.widget.ScrollView, android.view.View, android.view.MotionEvent):boolean");
    }

    /* JADX INFO: renamed from: lambda$onCreate$9$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ boolean m37lambda$onCreate$9$comzenoappBeatZooActivity(NestedScrollView nestedScrollView, ScrollView scrollView, SwipeRefreshLayout swipeRefreshLayout, View view) {
        SongScrollView songScrollView = this.songScrollView;
        if (songScrollView != null && songScrollView.getVisibility() == 0 && this.songScrollView.canScrollVertically(-1)) {
            return true;
        }
        if (nestedScrollView != null && nestedScrollView.getVisibility() == 0 && nestedScrollView.canScrollVertically(-1)) {
            return true;
        }
        return scrollView != null && scrollView.getVisibility() == 0 && scrollView.canScrollVertically(-1);
    }

    private void bindViews() {
        this.swipeRefresh = findViewById(R.id.swipeRefresh);
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        this.tvProfileName = (TextView) findViewById(R.id.tvProfileName);
        this.tvProfilePhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.profileCard = findViewById(R.id.beatProfileCard);
        this.balanceCard = findViewById(R.id.beatBalanceCard);
        ImageView imageView = (ImageView) findViewById(R.id.ivEditName);
        this.ivEditName = imageView;
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda54
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m11lambda$bindViews$10$comzenoappBeatZooActivity(view);
                }
            });
        }
        this.tvGem = (TextView) findViewById(R.id.tvGem);
        this.tvTicket = (TextView) findViewById(R.id.tvTicket);
        this.tvHeart = (TextView) findViewById(R.id.tvHeart);
        this.btnModeEasy = (TextView) findViewById(R.id.btnModeEasy);
        this.btnModeHard = (TextView) findViewById(R.id.btnModeHard);
        this.btnPlay = (TextView) findViewById(R.id.btnPlay);
        this.btnMute = (ImageView) findViewById(R.id.btnMute);
        this.btnClaimAll = (TextView) findViewById(R.id.btnClaimAll);
        this.btnGiftMissions = (ImageView) findViewById(R.id.btnGiftMissions);
        this.btnWeekly = (TextView) findViewById(R.id.btnWeekly);
        this.btnMonthly = (TextView) findViewById(R.id.btnMonthly);
        this.rankList = (LinearLayout) findViewById(R.id.rankList);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        this.rankUserFooter = findViewById(R.id.rankUserFooter);
        this.rankLoading = findViewById(R.id.rankLoading);
        this.songListSkeleton = findViewById(R.id.songListSkeleton);
        this.modeSkeleton = findViewById(R.id.modeSkeleton);
        this.modeRow = findViewById(R.id.modeRow);
        this.autoPlaySkeleton = findViewById(R.id.autoPlaySkeleton);
        ImageView imageView2 = this.btnMute;
        if (imageView2 != null) {
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda56
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m12lambda$bindViews$11$comzenoappBeatZooActivity(view);
                }
            });
        }
        this.tvSongName = (TextView) findViewById(R.id.tvSongName);
        this.tvSongMode = (TextView) findViewById(R.id.tvSongMode);
        this.tvSongScore = (TextView) findViewById(R.id.tvSongScore);
        this.tvPlayStatus = (TextView) findViewById(R.id.tvPlayStatus);
        this.selectedSongInfoCard = findViewById(R.id.selectedSongInfoCard);
        this.songList = (LinearLayout) findViewById(R.id.songList);
        this.missionList = (LinearLayout) findViewById(R.id.missionList);
        this.panelPlay = (LinearLayout) findViewById(R.id.panelPlay);
        this.panelMissions = (LinearLayout) findViewById(R.id.panelMissions);
        this.headerPlayOnly = (LinearLayout) findViewById(R.id.headerPlayOnly);
        ProgressBar progressBar = (ProgressBar) findViewById(R.id.playProgress);
        this.playProgress = progressBar;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        View view = this.selectedSongInfoCard;
        if (view != null) {
            view.setVisibility(8);
        }
        this.tabPlay = findViewById(R.id.tabPlay);
        this.tabMissions = findViewById(R.id.tabMissions);
        this.tvTabPlay = (TextView) findViewById(R.id.tvTabPlay);
        this.tvTabMissions = (TextView) findViewById(R.id.tvTabMissions);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabMissionsUnderline = findViewById(R.id.tabMissionsUnderline);
    }

    /* JADX INFO: renamed from: lambda$bindViews$10$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m11lambda$bindViews$10$comzenoappBeatZooActivity(View view) {
        showEditNameDialog();
    }

    /* JADX INFO: renamed from: lambda$bindViews$11$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m12lambda$bindViews$11$comzenoappBeatZooActivity(View view) {
        toggleMute();
    }

    private void setupTabs() {
        View view = this.tabPlay;
        if (view != null) {
            view.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda36
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m63lambda$setupTabs$12$comzenoappBeatZooActivity(view2);
                }
            });
        }
        View view2 = this.tabMissions;
        if (view2 != null) {
            view2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda37
                @Override // android.view.View.OnClickListener
                public final void onClick(View view3) {
                    this.f$0.m64lambda$setupTabs$13$comzenoappBeatZooActivity(view3);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$setupTabs$12$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m63lambda$setupTabs$12$comzenoappBeatZooActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$setupTabs$13$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m64lambda$setupTabs$13$comzenoappBeatZooActivity(View view) {
        showMissionsTab();
    }

    private void showPlayTab() {
        LinearLayout linearLayout = this.headerPlayOnly;
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
        }
        LinearLayout linearLayout2 = this.panelPlay;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(0);
        }
        LinearLayout linearLayout3 = this.panelMissions;
        if (linearLayout3 != null) {
            linearLayout3.setVisibility(8);
        }
        View viewFindViewById = findViewById(R.id.mainScroll);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(0);
        }
        TextView textView = this.tvTabPlay;
        if (textView != null) {
            textView.setTextColor(getColor(R.color.yellow_primary));
            this.tvTabPlay.setTypeface(null, 1);
        }
        TextView textView2 = this.tvTabMissions;
        if (textView2 != null) {
            textView2.setTextColor(getColor(R.color.text_grey));
            this.tvTabMissions.setTypeface(null, 0);
        }
        View view = this.tabPlayUnderline;
        if (view != null) {
            view.setBackgroundColor(-3632086);
        }
        View view2 = this.tabMissionsUnderline;
        if (view2 != null) {
            view2.setBackgroundColor(0);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-3632086);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-6381922);
        }
    }

    private void showMissionsTab() {
        LinearLayout linearLayout = this.headerPlayOnly;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.panelPlay;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(8);
        }
        LinearLayout linearLayout3 = this.panelMissions;
        if (linearLayout3 != null) {
            linearLayout3.setVisibility(0);
        }
        View viewFindViewById = findViewById(R.id.mainScroll);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(8);
        }
        TextView textView = this.tvTabMissions;
        if (textView != null) {
            textView.setTextColor(getColor(R.color.yellow_primary));
            this.tvTabMissions.setTypeface(null, 1);
        }
        TextView textView2 = this.tvTabPlay;
        if (textView2 != null) {
            textView2.setTextColor(getColor(R.color.text_grey));
            this.tvTabPlay.setTypeface(null, 0);
        }
        View view = this.tabMissionsUnderline;
        if (view != null) {
            view.setBackgroundColor(-3632086);
        }
        View view2 = this.tabPlayUnderline;
        if (view2 != null) {
            view2.setBackgroundColor(0);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-6381922);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-3632086);
        }
        loadLeaderboard();
    }

    private void setRankType(String str) {
        this.rankType = str;
        if ("weekly".equals(str)) {
            TextView textView = this.btnWeekly;
            if (textView != null) {
                textView.setBackgroundResource(R.drawable.bg_beat_mode_selected);
                this.btnWeekly.setTextColor(-1);
            }
            TextView textView2 = this.btnMonthly;
            if (textView2 != null) {
                textView2.setBackgroundResource(R.drawable.bg_beat_mode_normal);
                this.btnMonthly.setTextColor(getColor(R.color.text_grey));
            }
        } else {
            TextView textView3 = this.btnMonthly;
            if (textView3 != null) {
                textView3.setBackgroundResource(R.drawable.bg_beat_mode_selected);
                this.btnMonthly.setTextColor(-1);
            }
            TextView textView4 = this.btnWeekly;
            if (textView4 != null) {
                textView4.setBackgroundResource(R.drawable.bg_beat_mode_normal);
                this.btnWeekly.setTextColor(getColor(R.color.text_grey));
            }
        }
        loadLeaderboard();
    }

    private void loadLeaderboard() {
        View view = this.rankLoading;
        if (view != null) {
            view.setVisibility(0);
            this.rankSkeletonAnim = SkeletonPulse.start(this.rankLoading);
        }
        LinearLayout linearLayout = this.rankList;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        View view2 = this.rankUserFooter;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda58
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m27lambda$loadLeaderboard$16$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadLeaderboard$16$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m27lambda$loadLeaderboard$16$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            Response responseExecute = this.http.newCall(apiGet("/leaderboard?type=" + this.rankType).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject = new JSONObject(strString);
                final JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
                final JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("userData");
                this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda70
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m25lambda$loadLeaderboard$14$comzenoappBeatZooActivity(jSONArrayOptJSONArray, jSONObjectOptJSONObject);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda71
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m26lambda$loadLeaderboard$15$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadLeaderboard$14$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m25lambda$loadLeaderboard$14$comzenoappBeatZooActivity(JSONArray jSONArray, JSONObject jSONObject) {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.rankLoading);
        this.rankSkeletonAnim = null;
        View view = this.rankLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        renderLeaderboard(jSONArray, jSONObject);
    }

    /* JADX INFO: renamed from: lambda$loadLeaderboard$15$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m26lambda$loadLeaderboard$15$comzenoappBeatZooActivity(Exception exc) {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.rankLoading);
        this.rankSkeletonAnim = null;
        View view = this.rankLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        toast("Rank: " + exc.getMessage());
    }

    private void renderLeaderboard(JSONArray jSONArray, JSONObject jSONObject) {
        LinearLayout linearLayout;
        LinearLayout linearLayout2 = this.rankList;
        if (linearLayout2 == null) {
            return;
        }
        linearLayout2.removeAllViews();
        if (jSONArray != null) {
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null) {
                    this.rankList.addView(buildRankRow(jSONObjectOptJSONObject, false));
                }
            }
        }
        if (jSONObject == null || (linearLayout = this.rankUserRow) == null || this.rankUserFooter == null) {
            return;
        }
        linearLayout.removeAllViews();
        this.rankUserRow.addView(buildRankRow(jSONObject, true));
        this.rankUserFooter.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildRankRow(JSONObject jSONObject, boolean z) {
        int iOptInt = jSONObject.optInt("rank", 0);
        int iOptInt2 = jSONObject.optInt("score", 0);
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("user");
        String strOptString = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("name", "Unknown") : "Unknown";
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        int iDp = z ? dp(4) : dp(10);
        int iDp2 = z ? dp(4) : dp(10);
        linearLayout.setPadding(iDp2, iDp, iDp2, iDp);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = z ? 0 : dp(6);
        linearLayout.setLayoutParams(layoutParams);
        if (!z) {
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        }
        TextView textView = new TextView(this);
        int iDp3 = dp(z ? 32 : 40);
        textView.setLayoutParams(new LinearLayout.LayoutParams(iDp3, iDp3));
        textView.setGravity(17);
        textView.setText(String.valueOf(iOptInt));
        textView.setTextColor(-1);
        textView.setTextSize(2, 13.0f);
        textView.setTypeface(null, 1);
        if (iOptInt == 1) {
            textView.setBackgroundResource(R.drawable.bg_rank_gold);
        } else if (iOptInt == 2) {
            textView.setBackgroundResource(R.drawable.bg_rank_silver);
        } else if (iOptInt == 3) {
            textView.setBackgroundResource(R.drawable.bg_rank_bronze);
        } else {
            textView.setBackgroundResource(R.drawable.bg_rank_default);
        }
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -2, 1.0f);
        layoutParams2.setMarginStart(dp(10));
        textView2.setLayoutParams(layoutParams2);
        textView2.setText(strOptString);
        textView2.setTextColor(-1);
        textView2.setTextSize(2, 13.0f);
        textView2.setSingleLine(true);
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(this);
        textView3.setText(String.format(Locale.US, "%,d", Integer.valueOf(iOptInt2)));
        textView3.setTextColor(-10929);
        textView3.setTextSize(2, 13.0f);
        textView3.setTypeface(null, 1);
        linearLayout.addView(textView3);
        return linearLayout;
    }

    private void startGiftPulse(View view) {
        try {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_X, 1.0f, 1.18f, 1.0f);
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_Y, 1.0f, 1.18f, 1.0f);
            objectAnimatorOfFloat.setDuration(900L);
            objectAnimatorOfFloat2.setDuration(900L);
            objectAnimatorOfFloat.setRepeatCount(-1);
            objectAnimatorOfFloat2.setRepeatCount(-1);
            objectAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
            objectAnimatorOfFloat2.setInterpolator(new AccelerateDecelerateInterpolator());
            objectAnimatorOfFloat.start();
            objectAnimatorOfFloat2.start();
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showMissionsDialog() {
        try {
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            linearLayout.setBackgroundResource(R.drawable.bg_atom_dialog);
            linearLayout.setPadding(dp(16), dp(16), dp(16), dp(16));
            RelativeLayout relativeLayout = new RelativeLayout(this);
            TextView textView = new TextView(this);
            textView.setText("Missions");
            textView.setTextColor(-1);
            textView.setTextSize(2, 16.0f);
            textView.setTypeface(null, 1);
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
            layoutParams.addRule(13);
            textView.setLayoutParams(layoutParams);
            relativeLayout.addView(textView);
            ImageView imageView = new ImageView(this);
            imageView.setImageResource(R.drawable.ic_close_circle);
            RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(dp(28), dp(28));
            layoutParams2.addRule(21);
            imageView.setLayoutParams(layoutParams2);
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda23
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
            relativeLayout.addView(imageView);
            linearLayout.addView(relativeLayout);
            TextView textView2 = new TextView(this);
            textView2.setText("Claim All Completed");
            textView2.setGravity(17);
            textView2.setTextColor(-1);
            textView2.setTypeface(null, 1);
            textView2.setBackgroundResource(R.drawable.bg_btn_gold);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, dp(44));
            layoutParams3.topMargin = dp(12);
            layoutParams3.bottomMargin = dp(12);
            textView2.setLayoutParams(layoutParams3);
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda24
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m70lambda$showMissionsDialog$18$comzenoappBeatZooActivity(dialog, view);
                }
            });
            linearLayout.addView(textView2);
            ScrollView scrollView = new ScrollView(this);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            for (JSONObject jSONObject : this.missions) {
                if (jSONObject != null) {
                    linearLayout2.addView(buildMissionRow(jSONObject));
                }
            }
            if (this.missions.isEmpty()) {
                TextView textView3 = new TextView(this);
                textView3.setText("No missions");
                textView3.setTextColor(-5592406);
                textView3.setGravity(17);
                textView3.setPadding(0, dp(24), 0, dp(24));
                linearLayout2.addView(textView3);
            }
            scrollView.addView(linearLayout2);
            linearLayout.addView(scrollView, new LinearLayout.LayoutParams(-1, dp(360)));
            dialog.setContentView(linearLayout);
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.92f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            dialog.show();
            this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda25
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m72lambda$showMissionsDialog$20$comzenoappBeatZooActivity();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "showMissionsDialog", e);
            toast("Missions error");
        }
    }

    /* JADX INFO: renamed from: lambda$showMissionsDialog$18$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m70lambda$showMissionsDialog$18$comzenoappBeatZooActivity(Dialog dialog, View view) {
        claimAllCompleted();
        dialog.dismiss();
    }

    /* JADX INFO: renamed from: lambda$showMissionsDialog$20$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m72lambda$showMissionsDialog$20$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda34
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m71lambda$showMissionsDialog$19$comzenoappBeatZooActivity(jSONArrayFetchMissions);
                }
            });
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: renamed from: lambda$showMissionsDialog$19$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m71lambda$showMissionsDialog$19$comzenoappBeatZooActivity(JSONArray jSONArray) {
        this.missions.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            this.missions.add(jSONArray.optJSONObject(i));
        }
    }

    private void setupModeButtons() {
        TextView textView = this.btnModeEasy;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda61
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m61lambda$setupModeButtons$21$comzenoappBeatZooActivity(view);
                }
            });
        }
        TextView textView2 = this.btnModeHard;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda62
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m62lambda$setupModeButtons$22$comzenoappBeatZooActivity(view);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$setupModeButtons$21$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m61lambda$setupModeButtons$21$comzenoappBeatZooActivity(View view) {
        setMode("easy");
    }

    /* JADX INFO: renamed from: lambda$setupModeButtons$22$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m62lambda$setupModeButtons$22$comzenoappBeatZooActivity(View view) {
        setMode("hard");
    }

    private void setMode(String str) {
        this.mode = str;
        if ("easy".equals(str)) {
            TextView textView = this.btnModeEasy;
            if (textView != null) {
                textView.setBackgroundResource(R.drawable.bg_beat_mode_selected);
                this.btnModeEasy.setTextColor(-1);
            }
            TextView textView2 = this.btnModeHard;
            if (textView2 != null) {
                textView2.setBackgroundResource(R.drawable.bg_beat_mode_normal);
                this.btnModeHard.setTextColor(getColor(R.color.text_grey));
            }
        } else {
            TextView textView3 = this.btnModeHard;
            if (textView3 != null) {
                textView3.setBackgroundResource(R.drawable.bg_beat_mode_selected);
                this.btnModeHard.setTextColor(-1);
            }
            TextView textView4 = this.btnModeEasy;
            if (textView4 != null) {
                textView4.setBackgroundResource(R.drawable.bg_beat_mode_normal);
                this.btnModeEasy.setTextColor(getColor(R.color.text_grey));
            }
        }
        updateSelectedSongLabel();
        if (this.songList != null) {
            renderSongs();
        }
    }

    private void updateSelectedSongLabel() {
        if (this.selectedSong == null) {
            View view = this.selectedSongInfoCard;
            if (view != null) {
                view.setVisibility(8);
                return;
            }
            return;
        }
        View view2 = this.selectedSongInfoCard;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        String strOptString = this.selectedSong.optString("name", "Song");
        JSONObject jSONObjectOptJSONObject = this.selectedSong.optJSONObject("mode_scores");
        int iOptInt = 10000;
        if (jSONObjectOptJSONObject != null) {
            iOptInt = "hard".equals(this.mode) ? jSONObjectOptJSONObject.optInt("hard", 10000) : jSONObjectOptJSONObject.optInt("easy", 2500);
        } else if (!"hard".equals(this.mode)) {
            iOptInt = 2500;
        }
        String str = "hard".equals(this.mode) ? "Hard" : "Easy";
        TextView textView = this.tvSongName;
        if (textView != null) {
            textView.setText(strOptString);
        }
        TextView textView2 = this.tvSongMode;
        if (textView2 != null) {
            textView2.setText(str);
        }
        TextView textView3 = this.tvSongScore;
        if (textView3 != null) {
            textView3.setText(iOptInt + " Max");
        }
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        super.onResume();
        if (this.gameAudioActive) {
            return;
        }
        startHeaderCardSkeletons();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m48lambda$onResume$25$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onResume$25$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m48lambda$onResume$25$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final JSONObject jSONObjectFetchBalances = fetchBalances();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda59
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m46lambda$onResume$23$comzenoappBeatZooActivity(jSONObjectFetchBalances);
                }
            });
        } catch (Exception unused) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda60
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m47lambda$onResume$24$comzenoappBeatZooActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$onResume$23$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m46lambda$onResume$23$comzenoappBeatZooActivity(JSONObject jSONObject) {
        applyProfile();
        applyBalances(jSONObject);
    }

    /* JADX INFO: renamed from: lambda$onResume$24$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m47lambda$onResume$24$comzenoappBeatZooActivity() {
        stopProfileCardSkeleton();
        stopBalanceCardSkeleton();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshAll() {
        startHeaderCardSkeletons();
        View view = this.songListSkeleton;
        if (view != null) {
            view.setVisibility(0);
            LinearLayout linearLayout = this.songList;
            if (linearLayout != null) {
                linearLayout.setVisibility(8);
            }
            SongScrollView songScrollView = this.songScrollView;
            if (songScrollView != null) {
                songScrollView.setVisibility(8);
            }
            this.songSkeletonAnim = SkeletonPulse.start(this.songListSkeleton);
        }
        View view2 = this.modeSkeleton;
        if (view2 != null) {
            view2.setVisibility(0);
            View view3 = this.modeRow;
            if (view3 != null) {
                view3.setVisibility(4);
            }
            this.modeSkeletonAnim = SkeletonPulse.start(this.modeSkeleton);
        }
        View view4 = this.autoPlaySkeleton;
        if (view4 != null) {
            view4.setVisibility(0);
            TextView textView = this.btnPlay;
            if (textView != null) {
                textView.setVisibility(4);
                this.btnPlay.setEnabled(false);
            }
            this.autoPlaySkeletonAnim = SkeletonPulse.start(this.autoPlaySkeleton);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(true);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda65
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m60lambda$refreshAll$28$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$refreshAll$28$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m60lambda$refreshAll$28$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final JSONObject jSONObjectFetchBalances = fetchBalances();
            final JSONArray jSONArrayFetchSongs = fetchSongs();
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m58lambda$refreshAll$26$comzenoappBeatZooActivity(jSONObjectFetchBalances, jSONArrayFetchSongs, jSONArrayFetchMissions);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda12
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m59lambda$refreshAll$27$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$refreshAll$26$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m58lambda$refreshAll$26$comzenoappBeatZooActivity(JSONObject jSONObject, JSONArray jSONArray, JSONArray jSONArray2) {
        try {
            applyProfile();
            applyBalances(jSONObject);
            this.songs.clear();
            if (jSONArray != null) {
                for (int i = 0; i < jSONArray.length(); i++) {
                    this.songs.add(jSONArray.optJSONObject(i));
                }
            }
            this.missions.clear();
            if (jSONArray2 != null) {
                for (int i2 = 0; i2 < jSONArray2.length(); i2++) {
                    this.missions.add(jSONArray2.optJSONObject(i2));
                }
            }
            if (this.songList != null) {
                renderSongs();
            }
            if (this.missionList != null) {
                renderMissions();
            }
        } catch (Exception e) {
            Log.e(TAG, "refreshAll UI", e);
            toast("UI: " + e.getMessage());
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: renamed from: lambda$refreshAll$27$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m59lambda$refreshAll$27$comzenoappBeatZooActivity(Exception exc) {
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        toast("Error: " + exc.getMessage());
    }

    private void openMissionsPage() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda67
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m57lambda$openMissionsPage$31$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$openMissionsPage$31$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m57lambda$openMissionsPage$31$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final String str = this.jwt;
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda20
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m55lambda$openMissionsPage$29$comzenoappBeatZooActivity(str);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m56lambda$openMissionsPage$30$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$openMissionsPage$29$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m55lambda$openMissionsPage$29$comzenoappBeatZooActivity(String str) {
        Intent intent = new Intent((Context) this, (Class<?>) BeatZooMissionsActivity.class);
        intent.putExtra("jwt", str);
        startActivity(intent);
    }

    /* JADX INFO: renamed from: lambda$openMissionsPage$30$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m56lambda$openMissionsPage$30$comzenoappBeatZooActivity(Exception exc) {
        toast("Missions: " + exc.getMessage());
    }

    private void openBeatSpin() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda30
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m54lambda$openBeatSpin$34$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$openBeatSpin$34$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m54lambda$openBeatSpin$34$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final String str = this.jwt;
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda27
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m52lambda$openBeatSpin$32$comzenoappBeatZooActivity(str);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda28
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m53lambda$openBeatSpin$33$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$openBeatSpin$32$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m52lambda$openBeatSpin$32$comzenoappBeatZooActivity(String str) {
        Intent intent = new Intent((Context) this, (Class<?>) BeatZooSpinActivity.class);
        intent.putExtra("jwt", str);
        startActivity(intent);
    }

    /* JADX INFO: renamed from: lambda$openBeatSpin$33$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m53lambda$openBeatSpin$33$comzenoappBeatZooActivity(Exception exc) {
        toast("Spin: " + exc.getMessage());
    }

    private void openBeatShop() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda57
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m51lambda$openBeatShop$37$comzenoappBeatZooActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$openBeatShop$37$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m51lambda$openBeatShop$37$comzenoappBeatZooActivity() {
        try {
            ensureJwt();
            final String str = this.jwt;
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda31
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m49lambda$openBeatShop$35$comzenoappBeatZooActivity(str);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda32
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m50lambda$openBeatShop$36$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$openBeatShop$35$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m49lambda$openBeatShop$35$comzenoappBeatZooActivity(String str) {
        Intent intent = new Intent((Context) this, (Class<?>) BeatZooShopActivity.class);
        intent.putExtra("jwt", str);
        startActivity(intent);
    }

    /* JADX INFO: renamed from: lambda$openBeatShop$36$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m50lambda$openBeatShop$36$comzenoappBeatZooActivity(Exception exc) {
        toast("Shop: " + exc.getMessage());
    }

    private synchronized void ensureJwt() throws Exception {
        String strDecode;
        String str = this.jwt;
        if (str == null || str.isEmpty()) {
            String accessToken = this.session.getAccessToken();
            String phone = this.session.getPhone();
            if (accessToken == null || accessToken.isEmpty()) {
                throw new Exception("Not logged in (no access token)");
            }
            if (phone == null || phone.isEmpty()) {
                throw new Exception("No phone number");
            }
            String mcuid = this.session.getMcuid();
            if (mcuid == null || mcuid.isEmpty()) {
                mcuid = MCUID_FALLBACK;
            }
            String fullName = this.session.getFullName();
            if (fullName == null || fullName.isEmpty()) {
                fullName = "User";
            }
            String avatarUrl = this.session.getAvatarUrl();
            if (avatarUrl == null) {
                avatarUrl = "";
            }
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login?game-code=BEAT_ZOO&mcuid=" + mcuid + "&mcapp=myid").get().addHeader("access-token", accessToken).addHeader("phone-number", phone).addHeader("username", fullName).addHeader("avatar", avatarUrl).addHeader("lang", "mu").addHeader("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36").build()).execute();
            try {
                String strHeader = responseExecute.header("Location");
                if (strHeader == null || strHeader.isEmpty()) {
                    throw new Exception("Gateway login failed HTTP " + responseExecute.code());
                }
                if (responseExecute != null) {
                    responseExecute.close();
                }
                int iIndexOf = strHeader.indexOf("token=");
                if (iIndexOf >= 0) {
                    String strSubstring = strHeader.substring(iIndexOf + 6);
                    int iIndexOf2 = strSubstring.indexOf(38);
                    if (iIndexOf2 >= 0) {
                        strSubstring = strSubstring.substring(0, iIndexOf2);
                    }
                    strDecode = URLDecoder.decode(strSubstring, "UTF-8");
                } else {
                    strDecode = null;
                }
                if (strDecode == null || strDecode.isEmpty()) {
                    throw new Exception("No game token in redirect");
                }
                JSONObject jSONObject = new JSONObject();
                jSONObject.put("token", strDecode);
                jSONObject.put("status", JSONObject.NULL);
                jSONObject.put("message", JSONObject.NULL);
                responseExecute = this.http.newCall(new Request.Builder().url(TOKEN_AUTH).post(RequestBody.create(jSONObject.toString(), JSON)).addHeader("Content-Type", "application/json").addHeader("x-api-key", API_KEY).build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                    if (jSONObject2.optInt("status") != 1) {
                        throw new Exception(jSONObject2.optString("message", "Auth failed"));
                    }
                    JSONObject jSONObject3 = jSONObject2.getJSONObject("data");
                    this.jwt = jSONObject3.getString("token");
                    JSONObject jSONObjectOptJSONObject = jSONObject3.optJSONObject("user");
                    if (jSONObjectOptJSONObject != null) {
                        this.profileName = jSONObjectOptJSONObject.optString("name", "");
                        this.profilePhone = jSONObjectOptJSONObject.optString("phone", "");
                    }
                    String strOptString = jSONObject3.optString("avatar", "");
                    if (strOptString != null && !strOptString.isEmpty() && !"null".equals(strOptString)) {
                        this.profileAvatar = strOptString;
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return;
                } finally {
                }
            } finally {
            }
        }
    }

    private Request.Builder apiGet(String str) {
        return new Request.Builder().url(API + str).get().addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Accept", "*/*");
    }

    private Request.Builder apiPost(String str, String str2) {
        return new Request.Builder().url(API + str).post(RequestBody.create(str2, JSON)).addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Content-Type", "application/json");
    }

    private Request.Builder apiPut(String str, String str2) {
        return new Request.Builder().url(API + str).put(RequestBody.create(str2, JSON)).addHeader("Authorization", "Bearer " + this.jwt).addHeader("x-api-key", API_KEY).addHeader("Content-Type", "application/json");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showEditNameDialog() {
        try {
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_edit_name);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            final EditText editText = (EditText) dialog.findViewById(R.id.etName);
            ImageView imageView = (ImageView) dialog.findViewById(R.id.btnCloseDialog);
            final Button button = (Button) dialog.findViewById(R.id.btnChangeName);
            TextView textView = (TextView) dialog.findViewById(R.id.tabName);
            TextView textView2 = (TextView) dialog.findViewById(R.id.tabPicture);
            View viewFindViewById = dialog.findViewById(R.id.panelName);
            View viewFindViewById2 = dialog.findViewById(R.id.panelPicture);
            if (editText != null && imageView != null && button != null) {
                if (textView != null) {
                    View view = (View) textView.getParent();
                    if (view != null) {
                        view.setVisibility(8);
                    } else {
                        textView.setVisibility(8);
                    }
                }
                if (textView2 != null) {
                    textView2.setVisibility(8);
                }
                if (viewFindViewById2 != null) {
                    viewFindViewById2.setVisibility(8);
                }
                if (viewFindViewById != null) {
                    viewFindViewById.setVisibility(0);
                }
                TextView textView3 = this.tvProfileName;
                String string = textView3 != null ? textView3.getText().toString() : "";
                if (string != null && !string.equals("—") && !string.equals("---") && !string.isEmpty()) {
                    editText.setText(string);
                    editText.setSelection(string.length());
                }
                imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda22
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        dialog.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda33
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view2) {
                        this.f$0.m69lambda$showEditNameDialog$42$comzenoappBeatZooActivity(editText, button, dialog, view2);
                    }
                });
                dialog.show();
                return;
            }
            toast("Dialog layout error");
        } catch (Exception e) {
            Log.e(TAG, "showEditNameDialog", e);
            toast("Dialog error");
        }
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$42$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m69lambda$showEditNameDialog$42$comzenoappBeatZooActivity(EditText editText, final Button button, final Dialog dialog, View view) {
        final String strTrim = editText.getText().toString().trim();
        if (strTrim.isEmpty()) {
            editText.setError("Name ထည့်ပါ");
        } else {
            button.setEnabled(false);
            this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda66
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m68lambda$showEditNameDialog$41$comzenoappBeatZooActivity(strTrim, dialog, button);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$41$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m68lambda$showEditNameDialog$41$comzenoappBeatZooActivity(String str, final Dialog dialog, final Button button) {
        try {
            ensureJwt();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("name", str);
            Response responseExecute = this.http.newCall(apiPost("/name", jSONObject.toString()).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject2 = new JSONObject(strString);
                final boolean z = jSONObject2.optInt("status") == 1;
                final String strOptString = jSONObject2.optString("message", z ? "Name updated successfully" : "ပြောင်းမရပါ");
                final String strOptString2 = jSONObject2.optJSONObject("data") != null ? jSONObject2.optJSONObject("data").optString("name", str) : str;
                this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda52
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m66lambda$showEditNameDialog$39$comzenoappBeatZooActivity(z, strOptString2, dialog, strOptString, button);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda53
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m67lambda$showEditNameDialog$40$comzenoappBeatZooActivity(button, e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$39$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m66lambda$showEditNameDialog$39$comzenoappBeatZooActivity(boolean z, String str, Dialog dialog, String str2, Button button) {
        if (!z) {
            button.setEnabled(true);
            toast(str2);
            return;
        }
        this.profileName = str;
        TextView textView = this.tvProfileName;
        if (textView != null) {
            textView.setText(str);
        }
        try {
            SessionManager sessionManager = this.session;
            sessionManager.saveUserInfo(sessionManager.getPhone(), str, this.session.getAvatarUrl());
        } catch (Exception unused) {
        }
        dialog.dismiss();
        toast(str2);
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$40$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m67lambda$showEditNameDialog$40$comzenoappBeatZooActivity(Button button, Exception exc) {
        button.setEnabled(true);
        toast("Error: " + exc.getMessage());
    }

    private JSONObject fetchBalances() throws Exception {
        JSONObject jSONObject = new JSONObject();
        String[] strArr = {"gem", "ticket", "heart"};
        for (int i = 0; i < 3; i++) {
            String str = strArr[i];
            Response responseExecute = this.http.newCall(apiGet("/currency/" + str + "/balance").build()).execute();
            try {
                JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
                if (jSONObject2.optInt("status") == 1) {
                    jSONObject.put(str, jSONObject2.getJSONObject("data").optInt("balance", 0));
                }
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } catch (Throwable th) {
                if (responseExecute != null) {
                    try {
                        responseExecute.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        return jSONObject;
    }

    private JSONArray fetchSongs() throws Exception {
        Response responseExecute = this.http.newCall(apiGet("/songs/top").build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (jSONObject.optInt("status") != 1) {
                throw new Exception(jSONObject.optString("message", "songs failed"));
            }
            JSONArray jSONArray = jSONObject.getJSONArray("data");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONArray;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONArray fetchMissions() throws Exception {
        Response responseExecute = this.http.newCall(apiGet("/missions").build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (jSONObject.optInt("status") != 1) {
                throw new Exception(jSONObject.optString("message", "missions failed"));
            }
            JSONArray jSONArray = jSONObject.getJSONArray("data");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONArray;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private void applyBalances(JSONObject jSONObject) {
        this.tvGem.setText(String.valueOf(jSONObject.optInt("gem", 0)));
        this.tvTicket.setText(String.valueOf(jSONObject.optInt("ticket", 0)));
        this.tvHeart.setText(String.valueOf(jSONObject.optInt("heart", 0)));
        stopBalanceCardSkeleton();
    }

    private void applyProfile() {
        String fullName = this.profileName;
        if (fullName == null || fullName.isEmpty()) {
            fullName = this.session.getFullName();
        }
        if (fullName == null || fullName.isEmpty()) {
            fullName = "Player";
        }
        String phone = this.profilePhone;
        if (phone == null || phone.isEmpty()) {
            phone = this.session.getPhone();
        }
        if (phone == null) {
            phone = "";
        }
        TextView textView = this.tvProfileName;
        if (textView != null) {
            textView.setText(fullName);
        }
        TextView textView2 = this.tvProfilePhone;
        if (textView2 != null) {
            textView2.setText(phone);
        }
        String avatarUrl = this.session.getAvatarUrl();
        if (avatarUrl == null || avatarUrl.isEmpty() || "null".equals(avatarUrl)) {
            String str = this.profileAvatar;
            avatarUrl = (str == null || !str.startsWith("http")) ? null : this.profileAvatar;
        }
        if (this.ivAvatar != null) {
            if (avatarUrl != null && !avatarUrl.isEmpty()) {
                Glide.with(this).load(avatarUrl).apply(new RequestOptions().circleCrop().placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(this.ivAvatar);
            } else {
                this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
            }
        }
        stopProfileCardSkeleton();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View skeletonBlock(int i, int i2, boolean z) {
        View view = new View(this);
        view.setTag(SkeletonPulse.TAG);
        view.setBackgroundResource(z ? R.drawable.bg_skeleton_circle : R.drawable.bg_skeleton_bar);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(i), dp(i2)));
        return view;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startHeaderCardSkeletons() {
        if (this.headerPlayOnly == null) {
            return;
        }
        int i = -2;
        if (this.profileCard != null && this.profileCardSkeleton == null) {
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setGravity(16);
            linearLayout.setPadding(dp(14), dp(14), dp(14), dp(14));
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(0, 0, 0, dp(10));
            linearLayout.setLayoutParams(layoutParams);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(52), dp(52));
            layoutParams2.setMargins(0, 0, dp(12), 0);
            linearLayout.addView(skeletonBlock(52, 52, true), layoutParams2);
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            linearLayout2.setGravity(16);
            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            View viewSkeletonBlock = skeletonBlock(108, 16, false);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(108), dp(16));
            layoutParams3.setMargins(0, 0, 0, dp(7));
            linearLayout2.addView(viewSkeletonBlock, layoutParams3);
            linearLayout2.addView(skeletonBlock(78, 11, false));
            linearLayout.addView(linearLayout2);
            View viewSkeletonBlock2 = skeletonBlock(56, 40, false);
            LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(56), dp(40));
            layoutParams4.setMargins(dp(8), 0, 0, 0);
            linearLayout.addView(viewSkeletonBlock2, layoutParams4);
            View viewSkeletonBlock3 = skeletonBlock(56, 40, false);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(dp(56), dp(40));
            layoutParams5.setMargins(dp(8), 0, 0, 0);
            linearLayout.addView(viewSkeletonBlock3, layoutParams5);
            int iIndexOfChild = this.headerPlayOnly.indexOfChild(this.profileCard);
            this.profileCard.setVisibility(8);
            this.headerPlayOnly.addView(linearLayout, Math.max(0, iIndexOfChild));
            this.profileCardSkeleton = linearLayout;
            this.profileCardSkeletonAnim = SkeletonPulse.start(linearLayout);
        }
        if (this.balanceCard == null || this.balanceCardSkeleton != null) {
            return;
        }
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setPadding(dp(14), dp(14), dp(14), dp(14));
        linearLayout3.setBackgroundResource(R.drawable.bg_beat_song_normal);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams6.setMargins(0, 0, 0, dp(10));
        linearLayout3.setLayoutParams(layoutParams6);
        int i2 = 0;
        while (i2 < 3) {
            LinearLayout linearLayout4 = new LinearLayout(this);
            linearLayout4.setOrientation(1);
            linearLayout4.setGravity(17);
            linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(0, i, 1.0f));
            linearLayout4.addView(skeletonBlock(28, 28, true));
            View viewSkeletonBlock4 = skeletonBlock(48, 16, false);
            LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(dp(48), dp(16));
            layoutParams7.setMargins(0, dp(6), 0, dp(4));
            linearLayout4.addView(viewSkeletonBlock4, layoutParams7);
            linearLayout4.addView(skeletonBlock(40, 10, false));
            linearLayout3.addView(linearLayout4);
            if (i2 < 2) {
                View view = new View(this);
                view.setBackgroundColor(-14013910);
                linearLayout3.addView(view, new LinearLayout.LayoutParams(dp(1), -1));
            }
            i2++;
            i = -2;
        }
        int iIndexOfChild2 = this.headerPlayOnly.indexOfChild(this.balanceCard);
        this.balanceCard.setVisibility(8);
        this.headerPlayOnly.addView(linearLayout3, Math.max(0, iIndexOfChild2));
        this.balanceCardSkeleton = linearLayout3;
        this.balanceCardSkeletonAnim = SkeletonPulse.start(linearLayout3);
    }

    private void stopProfileCardSkeleton() {
        View view = this.profileCardSkeleton;
        if (view != null) {
            SkeletonPulse.stop(this.profileCardSkeletonAnim, view);
            this.profileCardSkeletonAnim = null;
            this.headerPlayOnly.removeView(this.profileCardSkeleton);
            this.profileCardSkeleton = null;
        }
        View view2 = this.profileCard;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    private void stopBalanceCardSkeleton() {
        View view = this.balanceCardSkeleton;
        if (view != null) {
            SkeletonPulse.stop(this.balanceCardSkeletonAnim, view);
            this.balanceCardSkeletonAnim = null;
            this.headerPlayOnly.removeView(this.balanceCardSkeleton);
            this.balanceCardSkeleton = null;
        }
        View view2 = this.balanceCard;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    private void handleSongScrollTouch(View view, MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.songTouchDownX = motionEvent.getRawX();
            this.songTouchDownY = motionEvent.getRawY();
            this.songTouchLastY = motionEvent.getRawY();
            this.songTouchDragging = false;
            this.songGestureDragged = false;
            disallowOutsideSongScroll(true);
            SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
            if (swipeRefreshLayout != null) {
                swipeRefreshLayout.setEnabled(false);
                return;
            }
            return;
        }
        if (actionMasked != 1) {
            if (actionMasked == 2) {
                float fAbs = Math.abs(motionEvent.getRawX() - this.songTouchDownX);
                float fAbs2 = Math.abs(motionEvent.getRawY() - this.songTouchDownY);
                if (!this.songTouchDragging && fAbs2 > this.songTouchSlop && fAbs2 >= fAbs) {
                    this.songTouchDragging = true;
                    this.songGestureDragged = true;
                }
                if (this.songTouchDragging) {
                    disallowOutsideSongScroll(true);
                    return;
                }
                return;
            }
            if (actionMasked != 3) {
                return;
            }
        }
        disallowOutsideSongScroll(false);
        SwipeRefreshLayout swipeRefreshLayout2 = this.swipeRefresh;
        if (swipeRefreshLayout2 != null) {
            swipeRefreshLayout2.setEnabled(true);
        }
        if (this.songTouchDragging) {
            view.setPressed(false);
        }
        this.songTouchDragging = false;
    }

    private void disallowOutsideSongScroll(boolean z) {
        SongScrollView songScrollView = this.songScrollView;
        if (songScrollView == null) {
            return;
        }
        for (ViewParent parent = songScrollView.getParent(); parent != null; parent = parent.getParent()) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renderSongs() {
        stopSongSkeleton();
        LinearLayout linearLayout = this.songList;
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        int iMin = Math.min(this.songs.size(), 40);
        for (int i = 0; i < iMin; i++) {
            JSONObject jSONObject = this.songs.get(i);
            if (jSONObject != null) {
                this.songList.addView(buildSongRow(jSONObject, i));
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildSongRow(final JSONObject jSONObject, int i) {
        int iOptInt;
        int i2;
        final boolean zOptBoolean = jSONObject.optBoolean("unlocked", false);
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("price");
        int iOptInt2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("amount", 0) : 0;
        boolean z = iOptInt2 == 0;
        JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("mode_scores");
        JSONObject jSONObjectOptJSONObject3 = jSONObject.optJSONObject("progress");
        int iOptInt3 = 10000;
        if (jSONObjectOptJSONObject2 != null) {
            iOptInt3 = "hard".equals(this.mode) ? jSONObjectOptJSONObject2.optInt("hard", 10000) : jSONObjectOptJSONObject2.optInt("easy", 2500);
        } else if (!"hard".equals(this.mode)) {
            iOptInt3 = 2500;
        }
        if (jSONObjectOptJSONObject3 != null) {
            iOptInt = "hard".equals(this.mode) ? jSONObjectOptJSONObject3.optInt("hard", 0) : jSONObjectOptJSONObject3.optInt("easy", 0);
        } else {
            iOptInt = 0;
        }
        final String strOptString = jSONObject.optString("id");
        String strOptString2 = jSONObject.optString("name", "Song");
        final String strOptString3 = jSONObject.optString("song_url", "");
        boolean zEquals = strOptString.equals(this.previewSongId);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(dp(12), dp(11), dp(10), dp(11));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(6);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        JSONObject jSONObject2 = this.selectedSong;
        if ((jSONObject2 == null || !strOptString.equals(jSONObject2.optString("id"))) && !zEquals) {
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        } else if (zOptBoolean) {
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_selected_green);
        } else {
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_selected_red);
        }
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(18), dp(18));
        layoutParams2.setMarginEnd(dp(8));
        imageView.setLayoutParams(layoutParams2);
        imageView.setImageResource(zOptBoolean ? R.drawable.ic_lock_open : R.drawable.ic_lock_closed);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        linearLayout.addView(imageView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView = new TextView(this);
        textView.setText(strOptString2);
        textView.setTextColor(-1);
        textView.setTextSize(2, 13.0f);
        linearLayout2.addView(textView);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        if (z) {
            TextView textView2 = new TextView(this);
            textView2.setText("FREE");
            textView2.setTextColor(-1);
            textView2.setTextSize(2, 13.0f);
            linearLayout3.addView(textView2);
        } else {
            TextView textView3 = new TextView(this);
            textView3.setText(String.valueOf(iOptInt2));
            textView3.setTextColor(-1);
            textView3.setTextSize(2, 13.0f);
            linearLayout3.addView(textView3);
            ImageView imageView2 = new ImageView(this);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(14), dp(14));
            layoutParams3.setMarginStart(dp(2));
            layoutParams3.setMarginEnd(dp(4));
            imageView2.setLayoutParams(layoutParams3);
            imageView2.setImageResource(R.drawable.ic_beat_gem);
            imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
            linearLayout3.addView(imageView2);
        }
        TextView textView4 = new TextView(this);
        textView4.setText(String.format(Locale.US, " Score: %d/%d", Integer.valueOf(iOptInt), Integer.valueOf(iOptInt3)));
        textView4.setTextColor(-1);
        textView4.setTextSize(2, 13.0f);
        linearLayout3.addView(textView4);
        linearLayout2.addView(linearLayout3);
        linearLayout.addView(linearLayout2);
        FrameLayout frameLayout = new FrameLayout(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(42), dp(42));
        layoutParams4.setMarginStart(dp(8));
        frameLayout.setLayoutParams(layoutParams4);
        if (zEquals) {
            i2 = R.drawable.bg_beat_play_circle_red;
        } else {
            i2 = R.drawable.bg_beat_play_circle_green;
        }
        frameLayout.setBackgroundResource(i2);
        ImageView imageView3 = new ImageView(this);
        imageView3.setLayoutParams(new FrameLayout.LayoutParams(dp(18), dp(18), 17));
        imageView3.setImageResource(zEquals ? R.drawable.ic_pause : R.drawable.ic_play);
        imageView3.setColorFilter(-1);
        frameLayout.addView(imageView3);
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda50
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m14lambda$buildSongRow$43$comzenoappBeatZooActivity(jSONObject, strOptString, strOptString3, view);
            }
        });
        linearLayout.addView(frameLayout);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda51
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m15lambda$buildSongRow$44$comzenoappBeatZooActivity(strOptString, zOptBoolean, jSONObject, view);
            }
        });
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildSongRow$43$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m14lambda$buildSongRow$43$comzenoappBeatZooActivity(JSONObject jSONObject, String str, String str2, View view) {
        togglePreview(jSONObject, str, str2);
    }

    /* JADX INFO: renamed from: lambda$buildSongRow$44$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m15lambda$buildSongRow$44$comzenoappBeatZooActivity(String str, boolean z, JSONObject jSONObject, View view) {
        String str2;
        if (this.playing.get() && ((str2 = this.previewSongId) == null || !str.equals(str2))) {
            toast("Game playing — stop first");
        } else {
            if (!z) {
                showBuySongDialog(jSONObject);
                return;
            }
            this.selectedSong = jSONObject;
            updateSelectedSongLabel();
            renderSongs();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showBuySongDialog(JSONObject jSONObject) {
        String str;
        String str2;
        TextView textView;
        try {
            String strOptString = jSONObject.optString("id");
            String strOptString2 = jSONObject.optString("name", "Song");
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("price");
            int iOptInt = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("amount", 0) : 0;
            String strOptString3 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("currency_code", "gem") : "gem";
            if ("gem".equalsIgnoreCase(strOptString3)) {
                str = "Gem";
            } else {
                str = "ticket".equalsIgnoreCase(strOptString3) ? "Ticket" : strOptString3;
            }
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_avatar_confirm);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            ImageView imageView = (ImageView) dialog.findViewById(R.id.ivConfirmAvatar);
            TextView textView2 = (TextView) dialog.findViewById(R.id.tvConfirmMessage);
            TextView textView3 = (TextView) dialog.findViewById(R.id.tvConfirmTitle);
            ImageView imageView2 = (ImageView) dialog.findViewById(R.id.btnCloseAvatarConfirm);
            TextView textView4 = (TextView) dialog.findViewById(R.id.btnConfirmCancel);
            final TextView textView5 = (TextView) dialog.findViewById(R.id.btnConfirmOk);
            if (textView3 != null) {
                textView3.setText("Song");
            }
            if (imageView != null) {
                imageView.setImageResource(R.drawable.ic_music);
                imageView.setColorFilter(-1);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                str2 = strOptString;
                textView = textView4;
                imageView.setPadding(dp(12), dp(12), dp(12), dp(12));
            } else {
                str2 = strOptString;
                textView = textView4;
            }
            if (textView2 != null) {
                if ("gem".equalsIgnoreCase(strOptString3)) {
                    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
                    spannableStringBuilder.append((CharSequence) String.valueOf(iOptInt)).append((CharSequence) " ");
                    int length = spannableStringBuilder.length();
                    spannableStringBuilder.append((CharSequence) " ");
                    int length2 = spannableStringBuilder.length();
                    Drawable drawable = getResources().getDrawable(R.drawable.ic_beat_gem, getTheme());
                    int iDp = dp(16);
                    drawable.setBounds(0, 0, iDp, iDp);
                    spannableStringBuilder.setSpan(new ImageSpan(drawable, 2), length, length2, 33);
                    spannableStringBuilder.append((CharSequence) " နဲ့ ဝယ်ပြီး သုံးမလား?\n").append((CharSequence) strOptString2);
                    textView2.setText(spannableStringBuilder);
                } else {
                    textView2.setText(String.format(Locale.US, "%d %s နဲ့ ဝယ်ပြီး သုံးမလား?\n%s", Integer.valueOf(iOptInt), str, strOptString2));
                }
            }
            if (textView5 != null) {
                textView5.setText("Buy");
            }
            if (imageView2 != null) {
                imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda76
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
            if (textView != null) {
                textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda77
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
            if (textView5 != null) {
                final String str3 = str2;
                textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda2
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m65lambda$showBuySongDialog$47$comzenoappBeatZooActivity(textView5, str3, dialog, view);
                    }
                });
            }
            dialog.show();
        } catch (Exception e) {
            Log.e(TAG, "showBuySongDialog", e);
            toast("Dialog error");
        }
    }

    /* JADX INFO: renamed from: lambda$showBuySongDialog$47$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m65lambda$showBuySongDialog$47$comzenoappBeatZooActivity(TextView textView, String str, Dialog dialog, View view) {
        textView.setEnabled(false);
        buySong(str, dialog, textView);
    }

    private void buySong(final String str, final Dialog dialog, final TextView textView) {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m18lambda$buySong$50$comzenoappBeatZooActivity(str, dialog, textView);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buySong$50$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m18lambda$buySong$50$comzenoappBeatZooActivity(String str, final Dialog dialog, final TextView textView) {
        try {
            ensureJwt();
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("song_id", str);
            Response responseExecute = this.http.newCall(apiPost("/songs/buy", jSONObject.toString()).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject2 = new JSONObject(strString);
                final boolean z = jSONObject2.optInt("status") == 1;
                final String strOptString = jSONObject2.optString("message", z ? "Purchased" : "Buy failed");
                this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda73
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m16lambda$buySong$48$comzenoappBeatZooActivity(z, dialog, strOptString, textView);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda74
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m17lambda$buySong$49$comzenoappBeatZooActivity(textView, e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$buySong$48$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m16lambda$buySong$48$comzenoappBeatZooActivity(boolean z, Dialog dialog, String str, TextView textView) {
        if (!z) {
            if (textView != null) {
                textView.setEnabled(true);
            }
            toast(str);
        } else {
            if (dialog != null) {
                dialog.dismiss();
            }
            toast(str);
            refreshAll();
        }
    }

    /* JADX INFO: renamed from: lambda$buySong$49$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m17lambda$buySong$49$comzenoappBeatZooActivity(TextView textView, Exception exc) {
        if (textView != null) {
            textView.setEnabled(true);
        }
        toast("Error: " + exc.getMessage());
    }

    private String mediaUrl(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        return SONG_CDN + str.replaceFirst("^/+", "");
    }

    private void stopPreview() {
        releasePlayer();
        this.previewSongId = null;
        this.gameAudioActive = false;
        this.main.post(new BeatZooActivity$$ExternalSyntheticLambda44(this));
    }

    private void releasePlayer() {
        try {
            MediaPlayer mediaPlayer = this.mediaPlayer;
            if (mediaPlayer != null) {
                try {
                    mediaPlayer.stop();
                } catch (Exception unused) {
                }
                this.mediaPlayer.release();
            }
        } catch (Exception unused2) {
        }
        this.mediaPlayer = null;
    }

    private void togglePreview(JSONObject jSONObject, String str, String str2) {
        if (this.playing.get()) {
            toast("Game playing — use Sound button");
            return;
        }
        if (str.equals(this.previewSongId)) {
            stopPreview();
            return;
        }
        if (this.previewSongId != null) {
            releasePlayer();
            this.previewSongId = null;
            this.gameAudioActive = false;
        }
        releasePlayer();
        this.previewSongId = str;
        this.selectedSong = jSONObject;
        updateSelectedSongLabel();
        renderSongs();
        final String strMediaUrl = mediaUrl(str2);
        if (strMediaUrl == null) {
            toast("No audio URL");
            this.previewSongId = null;
            this.main.post(new BeatZooActivity$$ExternalSyntheticLambda44(this));
        } else {
            toast("Loading audio…");
            this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda55
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m80lambda$togglePreview$51$comzenoappBeatZooActivity(strMediaUrl);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$togglePreview$51$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m80lambda$togglePreview$51$comzenoappBeatZooActivity(String str) {
        startPlayer(str, false);
    }

    private void startPlayer(String str, final boolean z) {
        try {
            releasePlayer();
            if (z) {
                this.gameAudioDurationSec = 0;
                this.gameAudioCompleted = false;
            }
            MediaPlayer mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(new AudioAttributes.Builder().setUsage(1).setContentType(2).build());
            mediaPlayer.setDataSource(str);
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda13
                @Override // android.media.MediaPlayer.OnPreparedListener
                public final void onPrepared(MediaPlayer mediaPlayer2) {
                    this.f$0.m74lambda$startPlayer$53$comzenoappBeatZooActivity(z, mediaPlayer2);
                }
            });
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda14
                @Override // android.media.MediaPlayer.OnCompletionListener
                public final void onCompletion(MediaPlayer mediaPlayer2) {
                    this.f$0.m76lambda$startPlayer$55$comzenoappBeatZooActivity(z, mediaPlayer2);
                }
            });
            mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda15
                @Override // android.media.MediaPlayer.OnErrorListener
                public final boolean onError(MediaPlayer mediaPlayer2, int i, int i2) {
                    return this.f$0.m78lambda$startPlayer$57$comzenoappBeatZooActivity(mediaPlayer2, i, i2);
                }
            });
            this.mediaPlayer = mediaPlayer;
            mediaPlayer.prepareAsync();
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m79lambda$startPlayer$58$comzenoappBeatZooActivity(e);
                }
            });
            releasePlayer();
        }
    }

    /* JADX INFO: renamed from: lambda$startPlayer$53$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m74lambda$startPlayer$53$comzenoappBeatZooActivity(final boolean z, MediaPlayer mediaPlayer) {
        if (z) {
            try {
                int duration = mediaPlayer.getDuration();
                if (duration > 0) {
                    this.gameAudioDurationSec = (int) Math.ceil(((double) duration) / 1000.0d);
                }
            } catch (Exception unused) {
            }
        }
        if (this.muted) {
            mediaPlayer.setVolume(0.0f, 0.0f);
        } else {
            mediaPlayer.setVolume(1.0f, 1.0f);
        }
        mediaPlayer.start();
        this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda75
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m73lambda$startPlayer$52$comzenoappBeatZooActivity(z);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$startPlayer$52$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m73lambda$startPlayer$52$comzenoappBeatZooActivity(boolean z) {
        if (z) {
            this.gameAudioActive = true;
            ImageView imageView = this.btnMute;
            if (imageView != null) {
                imageView.setVisibility(0);
                this.btnMute.setImageResource(this.muted ? R.drawable.ic_volume_off : R.drawable.ic_volume_on);
            }
        }
        renderSongs();
    }

    /* JADX INFO: renamed from: lambda$startPlayer$55$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m76lambda$startPlayer$55$comzenoappBeatZooActivity(final boolean z, MediaPlayer mediaPlayer) {
        if (z) {
            this.gameAudioCompleted = true;
        }
        this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda26
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m75lambda$startPlayer$54$comzenoappBeatZooActivity(z);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$startPlayer$54$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m75lambda$startPlayer$54$comzenoappBeatZooActivity(boolean z) {
        if (z) {
            return;
        }
        this.previewSongId = null;
        releasePlayer();
        renderSongs();
    }

    /* JADX INFO: renamed from: lambda$startPlayer$56$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m77lambda$startPlayer$56$comzenoappBeatZooActivity() {
        toast("Audio error");
    }

    /* JADX INFO: renamed from: lambda$startPlayer$57$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ boolean m78lambda$startPlayer$57$comzenoappBeatZooActivity(MediaPlayer mediaPlayer, int i, int i2) {
        this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda69
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m77lambda$startPlayer$56$comzenoappBeatZooActivity();
            }
        });
        releasePlayer();
        return true;
    }

    /* JADX INFO: renamed from: lambda$startPlayer$58$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m79lambda$startPlayer$58$comzenoappBeatZooActivity(Exception exc) {
        toast("Audio: " + exc.getMessage());
    }

    private void toggleMute() {
        boolean z = !this.muted;
        this.muted = z;
        MediaPlayer mediaPlayer = this.mediaPlayer;
        if (mediaPlayer != null) {
            float f = z ? 0.0f : 1.0f;
            try {
                mediaPlayer.setVolume(f, f);
            } catch (Exception unused) {
            }
        }
        ImageView imageView = this.btnMute;
        if (imageView != null) {
            imageView.setImageResource(this.muted ? R.drawable.ic_volume_off : R.drawable.ic_volume_on);
        }
        toast(this.muted ? "Sound off" : "Sound on");
    }

    private void setPlayButtonIdle() {
        TextView textView = this.btnPlay;
        if (textView == null) {
            return;
        }
        textView.setText("ကစားမည်");
        this.btnPlay.setBackgroundResource(R.drawable.bg_btn_gold);
        this.btnPlay.setEnabled(true);
        this.btnPlay.setAlpha(1.0f);
    }

    private void setPlayButtonStop() {
        TextView textView = this.btnPlay;
        if (textView == null) {
            return;
        }
        textView.setText("ရပ်မည်");
        this.btnPlay.setBackgroundResource(R.drawable.bg_beat_btn_stop);
        this.btnPlay.setEnabled(true);
        this.btnPlay.setAlpha(1.0f);
    }

    private void onStopClicked() {
        if (this.playing.get()) {
            this.stopRequested.set(true);
            this.tvPlayStatus.setText("Stopping...");
            this.btnPlay.setEnabled(false);
            this.btnPlay.setAlpha(0.5f);
            stopPreview();
        }
    }

    private void onPlayClicked() {
        int iNextInt;
        if (this.playing.get()) {
            toast("Already playing...");
            return;
        }
        JSONObject jSONObject = this.selectedSong;
        if (jSONObject == null) {
            toast("Select a song first");
            return;
        }
        if (!jSONObject.optBoolean("unlocked", false)) {
            toast("Song is locked");
            return;
        }
        this.playing.set(true);
        this.stopRequested.set(false);
        setPlayButtonStop();
        ProgressBar progressBar = this.playProgress;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        this.tvPlayStatus.setText("Starting...");
        final String strOptString = this.selectedSong.optString("id");
        final String strOptString2 = this.selectedSong.optString("name");
        final String strOptString3 = this.selectedSong.optString("song_url", "");
        boolean zEquals = "hard".equals(this.mode);
        JSONObject jSONObjectOptJSONObject = this.selectedSong.optJSONObject("mode_scores");
        int iOptInt = 10000;
        if (jSONObjectOptJSONObject != null) {
            iOptInt = zEquals ? jSONObjectOptJSONObject.optInt("hard", 10000) : jSONObjectOptJSONObject.optInt("easy", 2500);
        } else if (!zEquals) {
            iOptInt = 2500;
        }
        if (zEquals) {
            iNextInt = ThreadLocalRandom.current().nextInt(455, 511);
        } else {
            iNextInt = ThreadLocalRandom.current().nextInt(230, 281);
        }
        final int iMax = Math.max(0, iOptInt - iNextInt);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda29
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m45lambda$onPlayClicked$66$comzenoappBeatZooActivity(strOptString, strOptString3, strOptString2, iMax);
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x01be  */
    /* JADX WARN: Removed duplicated region for block: B:101:0x01c3  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x01d3  */
    /* JADX INFO: renamed from: lambda$onPlayClicked$66$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    /* synthetic */ void m45lambda$onPlayClicked$66$comzenoappBeatZooActivity(final java.lang.String r17, java.lang.String r18, final java.lang.String r19, final int r20) {
        /*
            Method dump skipped, instruction units count: 479
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.BeatZooActivity.m45lambda$onPlayClicked$66$comzenoappBeatZooActivity(java.lang.String, java.lang.String, java.lang.String, int):void");
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$59$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m38lambda$onPlayClicked$59$comzenoappBeatZooActivity(JSONObject jSONObject) {
        this.tvPlayStatus.setText("Ticket " + jSONObject.optInt("balance_before") + " → " + jSONObject.optInt("balance_after"));
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$60$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m39lambda$onPlayClicked$60$comzenoappBeatZooActivity(String str, String str2) {
        this.previewSongId = str;
        startPlayer(str2, true);
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$61$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m40lambda$onPlayClicked$61$comzenoappBeatZooActivity(String str, int i) {
        this.tvPlayStatus.setText("Playing " + str + " (" + i + "s)...");
        ImageView imageView = this.btnMute;
        if (imageView != null) {
            imageView.setVisibility(0);
            this.btnMute.setImageResource(this.muted ? R.drawable.ic_volume_off : R.drawable.ic_volume_on);
        }
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$62$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m41lambda$onPlayClicked$62$comzenoappBeatZooActivity(int i, int i2) {
        ProgressBar progressBar = this.playProgress;
        if (progressBar != null) {
            progressBar.setProgress((int) ((i * 100.0f) / i2));
        }
        this.tvPlayStatus.setText(String.format(Locale.US, "End Time: %d/%ds", Integer.valueOf(i), Integer.valueOf(i2)));
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$63$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m42lambda$onPlayClicked$63$comzenoappBeatZooActivity() {
        stopPreview();
        ImageView imageView = this.btnMute;
        if (imageView != null) {
            imageView.setVisibility(8);
        }
        ProgressBar progressBar = this.playProgress;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        this.playing.set(false);
        this.stopRequested.set(false);
        setPlayButtonIdle();
        this.tvPlayStatus.setText("Stopped");
        toast("Stopped");
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$64$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m43lambda$onPlayClicked$64$comzenoappBeatZooActivity(JSONObject jSONObject, JSONArray jSONArray, int i) {
        applyProfile();
        applyBalances(jSONObject);
        this.songs.clear();
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            this.songs.add(jSONArray.optJSONObject(i2));
        }
        renderSongs();
        stopPreview();
        ImageView imageView = this.btnMute;
        if (imageView != null) {
            imageView.setVisibility(8);
        }
        this.tvPlayStatus.setText(String.format(Locale.US, "Success: %d Score (%s Mode)", Integer.valueOf(i), "hard".equals(this.mode) ? "Hard" : "Easy"));
        ProgressBar progressBar = this.playProgress;
        if (progressBar != null) {
            progressBar.setProgress(100);
        }
        this.playing.set(false);
        this.stopRequested.set(false);
        setPlayButtonIdle();
        toast("Play finished");
    }

    /* JADX INFO: renamed from: lambda$onPlayClicked$65$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m44lambda$onPlayClicked$65$comzenoappBeatZooActivity(boolean z, String str) {
        String str2;
        stopPreview();
        ImageView imageView = this.btnMute;
        if (imageView != null) {
            imageView.setVisibility(8);
        }
        ProgressBar progressBar = this.playProgress;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        this.playing.set(false);
        this.stopRequested.set(false);
        setPlayButtonIdle();
        TextView textView = this.tvPlayStatus;
        if (z) {
            str2 = "Stopped";
        } else {
            str2 = "Error: " + str;
        }
        textView.setText(str2);
        if (!z) {
            toast(str);
        } else {
            toast("Stopped");
        }
    }

    private int probeDurationSec(String str) {
        if (str == null || str.isEmpty()) {
            return 0;
        }
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(SONG_CDN + str.replaceFirst("^/+", "")).openConnection();
            httpURLConnection.setRequestMethod("HEAD");
            httpURLConnection.setConnectTimeout(8000);
            httpURLConnection.setReadTimeout(8000);
            httpURLConnection.connect();
            long contentLengthLong = httpURLConnection.getContentLengthLong();
            httpURLConnection.disconnect();
            if (contentLengthLong > 0) {
                int iCeil = (int) Math.ceil(contentLengthLong / 16000.0d);
                if (iCeil > 30 && iCeil < 600) {
                    return iCeil;
                }
            }
        } catch (Exception unused) {
        }
        if (str.contains("pink-venom")) {
            return 97;
        }
        if (str.contains("way-thwar")) {
            return 102;
        }
        return str.contains("simp-for-you") ? 91 : 120;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void renderMissions() {
        LinearLayout linearLayout = this.missionList;
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        Integer numValueOf = null;
        for (JSONObject jSONObject : this.missions) {
            if (jSONObject != null) {
                int iOptInt = jSONObject.optInt("day", 0);
                if (numValueOf == null || iOptInt != numValueOf.intValue()) {
                    numValueOf = Integer.valueOf(iOptInt);
                    TextView textView = new TextView(this);
                    textView.setText("── Day " + iOptInt + " ──");
                    textView.setTextColor(getColor(R.color.yellow_primary));
                    textView.setTextSize(2, 13.0f);
                    textView.setTypeface(null, 1);
                    textView.setPadding(0, dp(8), 0, dp(6));
                    this.missionList.addView(textView);
                }
                this.missionList.addView(buildMissionRow(jSONObject));
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildMissionRow(final JSONObject jSONObject) {
        String str;
        String str2;
        String strOptString = jSONObject.optString("status", "NOT_COMPLETED");
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("reward");
        if (jSONObjectOptJSONObject != null) {
            str = jSONObjectOptJSONObject.optInt("amount") + " " + jSONObjectOptJSONObject.optString("code");
        } else {
            str = "-";
        }
        if ("COMPLETED".equals(strOptString)) {
            str2 = "[OK]";
        } else {
            str2 = "CLAIMED".equals(strOptString) ? "[DONE]" : "[ ]";
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(12), dp(10), dp(12), dp(10));
        linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(8);
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        textView.setText(str2 + " " + jSONObject.optString("name"));
        textView.setTextColor(-1);
        textView.setTextSize(2, 13.0f);
        textView.setTypeface(null, 1);
        linearLayout.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(String.format(Locale.US, "%s  %d/%d  +%s", strOptString, Integer.valueOf(jSONObject.optInt("current_score", 0)), Integer.valueOf(jSONObject.optInt("score", 0)), str));
        textView2.setTextColor(getColor(R.color.text_grey));
        textView2.setTextSize(2, 12.0f);
        textView2.setPadding(0, dp(4), 0, 0);
        linearLayout.addView(textView2);
        if ("COMPLETED".equals(strOptString)) {
            TextView textView3 = new TextView(this);
            textView3.setText("Claim");
            textView3.setTextColor(-1);
            textView3.setGravity(17);
            textView3.setBackgroundResource(R.drawable.bg_btn_gold);
            textView3.setPadding(dp(12), dp(8), dp(12), dp(8));
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.topMargin = dp(8);
            textView3.setLayoutParams(layoutParams2);
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda72
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m13lambda$buildMissionRow$67$comzenoappBeatZooActivity(jSONObject, view);
                }
            });
            linearLayout.addView(textView3);
        }
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildMissionRow$67$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m13lambda$buildMissionRow$67$comzenoappBeatZooActivity(JSONObject jSONObject, View view) {
        claimOne(jSONObject.optString("id"), jSONObject.optString("name"));
    }

    private void claimAllCompleted() {
        final ArrayList arrayList = new ArrayList();
        for (JSONObject jSONObject : this.missions) {
            if (jSONObject != null && "COMPLETED".equals(jSONObject.optString("status"))) {
                arrayList.add(jSONObject);
            }
        }
        if (arrayList.isEmpty()) {
            toast("No completed missions");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda68
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m21lambda$claimAllCompleted$70$comzenoappBeatZooActivity(arrayList);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$claimAllCompleted$70$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m21lambda$claimAllCompleted$70$comzenoappBeatZooActivity(final List list) {
        try {
            ensureJwt();
            Iterator it = list.iterator();
            while (it.hasNext()) {
                claimMissionSync(((JSONObject) it.next()).optString("id"));
            }
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            final JSONObject jSONObjectFetchBalances = fetchBalances();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m19lambda$claimAllCompleted$68$comzenoappBeatZooActivity(jSONArrayFetchMissions, jSONObjectFetchBalances, list);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m20lambda$claimAllCompleted$69$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$claimAllCompleted$68$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m19lambda$claimAllCompleted$68$comzenoappBeatZooActivity(JSONArray jSONArray, JSONObject jSONObject, List list) {
        this.missions.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            this.missions.add(jSONArray.optJSONObject(i));
        }
        applyBalances(jSONObject);
        renderMissions();
        toast("Claimed " + list.size());
    }

    /* JADX INFO: renamed from: lambda$claimAllCompleted$69$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m20lambda$claimAllCompleted$69$comzenoappBeatZooActivity(Exception exc) {
        toast(exc.getMessage());
    }

    private void claimOne(final String str, final String str2) {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda35
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m24lambda$claimOne$73$comzenoappBeatZooActivity(str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$claimOne$73$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m24lambda$claimOne$73$comzenoappBeatZooActivity(String str, final String str2) {
        try {
            ensureJwt();
            final JSONObject jSONObjectClaimMissionSync = claimMissionSync(str);
            final JSONArray jSONArrayFetchMissions = fetchMissions();
            final JSONObject jSONObjectFetchBalances = fetchBalances();
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda63
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m22lambda$claimOne$71$comzenoappBeatZooActivity(jSONArrayFetchMissions, jSONObjectFetchBalances, jSONObjectClaimMissionSync, str2);
                }
            });
        } catch (Exception e) {
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooActivity$$ExternalSyntheticLambda64
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m23lambda$claimOne$72$comzenoappBeatZooActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$claimOne$71$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m22lambda$claimOne$71$comzenoappBeatZooActivity(JSONArray jSONArray, JSONObject jSONObject, JSONObject jSONObject2, String str) {
        this.missions.clear();
        for (int i = 0; i < jSONArray.length(); i++) {
            this.missions.add(jSONArray.optJSONObject(i));
        }
        applyBalances(jSONObject);
        renderMissions();
        if (jSONObject2.optInt("status") == 1) {
            JSONObject jSONObjectOptJSONObject = jSONObject2.optJSONObject("data");
            JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("reward") : null;
            toast(str + ": " + (jSONObjectOptJSONObject2 != null ? "+" + jSONObjectOptJSONObject2.optInt("amount") + " " + jSONObjectOptJSONObject2.optString("code") : "Claimed"));
            return;
        }
        toast(jSONObject2.optString("message", "Claim failed"));
    }

    /* JADX INFO: renamed from: lambda$claimOne$72$com-zeno-app-BeatZooActivity, reason: not valid java name */
    /* synthetic */ void m23lambda$claimOne$72$comzenoappBeatZooActivity(Exception exc) {
        toast(exc.getMessage());
    }

    private JSONObject claimMissionSync(String str) throws Exception {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("mission_id", str);
        Response responseExecute = this.http.newCall(apiPost("/missions/claim", jSONObject.toString()).build()).execute();
        try {
            JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONObject2;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        if (str == null) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    protected void onDestroy() {
        super.onDestroy();
        releasePlayer();
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    private void stopSongSkeleton() {
        SkeletonPulse.stop(this.songSkeletonAnim, this.songListSkeleton);
        this.songSkeletonAnim = null;
        View view = this.songListSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        LinearLayout linearLayout = this.songList;
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
        }
        SongScrollView songScrollView = this.songScrollView;
        if (songScrollView != null) {
            songScrollView.setVisibility(0);
        }
        SkeletonPulse.stop(this.modeSkeletonAnim, this.modeSkeleton);
        this.modeSkeletonAnim = null;
        View view2 = this.modeSkeleton;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.modeRow;
        if (view3 != null) {
            view3.setVisibility(0);
        }
        SkeletonPulse.stop(this.autoPlaySkeletonAnim, this.autoPlaySkeleton);
        this.autoPlaySkeletonAnim = null;
        View view4 = this.autoPlaySkeleton;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        TextView textView = this.btnPlay;
        if (textView != null) {
            textView.setVisibility(0);
            if (this.playing.get()) {
                return;
            }
            this.btnPlay.setEnabled(true);
        }
    }
}
