package com.zeno.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewParent;
import androidx.core.widget.NestedScrollView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class LockableNestedScrollView extends NestedScrollView {
    private boolean locked;

    public LockableNestedScrollView(Context context) {
        super(context);
        this.locked = false;
    }

    public LockableNestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.locked = false;
    }

    public LockableNestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.locked = false;
    }

    private void lockParents(boolean z) {
        for (ViewParent parent = getParent(); parent != null; parent = parent.getParent()) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
        this.locked = z;
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0014  */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0018  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean dispatchTouchEvent(android.view.MotionEvent r5) {
        /*
            r4 = this;
            int r0 = r5.getActionMasked()
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L18
            if (r0 == r1) goto L14
            r3 = 2
            if (r0 == r3) goto L18
            r3 = 3
            if (r0 == r3) goto L14
            r3 = 5
            if (r0 == r3) goto L18
            goto L1b
        L14:
            r4.lockParents(r2)
            goto L1b
        L18:
            r4.lockParents(r1)
        L1b:
            boolean r5 = super.dispatchTouchEvent(r5)     // Catch: java.lang.Exception -> L20
            return r5
        L20:
            r4.lockParents(r2)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.LockableNestedScrollView.dispatchTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0 || actionMasked == 2) {
            lockParents(true);
        } else if (actionMasked == 1 || actionMasked == 3) {
            lockParents(false);
        }
        try {
            return super.onInterceptTouchEvent(motionEvent);
        } catch (Exception unused) {
            return false;
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0 || actionMasked == 2) {
            lockParents(true);
        } else if (actionMasked == 1 || actionMasked == 3) {
            lockParents(false);
        }
        try {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0) {
                return true;
            }
            return zOnTouchEvent;
        } catch (Exception unused) {
            return false;
        }
    }

    protected void onDetachedFromWindow() {
        lockParents(false);
        super.onDetachedFromWindow();
    }
}
