package com.zeno.app;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SongListLayout extends LinearLayout {
    public void setParentScroll(ScrollView scrollView) {
    }

    public void setRefreshCallbacks(Runnable runnable, Runnable runnable2) {
    }

    public SongListLayout(Context context) {
        super(context);
        setOrientation(1);
    }

    public SongListLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOrientation(1);
    }

    public SongListLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setOrientation(1);
    }
}
