package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import com.zeno.app.SpinWheelView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class BeatZooSpinActivity extends AppCompatActivity {
    private static final String API = "https://beatzoo.mascom.vn/api/client-api";
    private static final String API_KEY = "60015110c58af6c4a6beec794ab40b89b1042b42cb5380e86daee037cf96ef8b";
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final int[] SEG_BG = {-15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440};
    private static final String TAG = "BeatZooSpin";
    private View balanceCard;
    private View balanceCardSkeleton;
    private ValueAnimator balanceSkeletonAnim;
    private TextView btnSpin;
    private View btnSpinSkeleton;
    private ValueAnimator btnSpinSkeletonAnim;
    private Bitmap iconGem;
    private Bitmap iconHeart;
    private Bitmap iconTicket;
    private String jwt;
    private SpinWheelView spinWheelView;
    private TextView tvGem;
    private TextView tvHeart;
    private TextView tvTicket;
    private View wheelLoading;
    private ValueAnimator wheelSkeletonAnim;
    private int remainingSpins = 0;
    private final List<JSONObject> prizes = new ArrayList();
    private boolean spinning = false;
    private final ExecutorService exec = Executors.newCachedThreadPool();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_beat_zoo_spin);
        this.jwt = getIntent().getStringExtra("jwt");
        View viewFindViewById = findViewById(R.id.btnBack);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m111lambda$onCreate$0$comzenoappBeatZooSpinActivity(view);
                }
            });
        }
        this.spinWheelView = (SpinWheelView) findViewById(R.id.spinWheelView);
        this.wheelLoading = findViewById(R.id.wheelLoading);
        this.btnSpin = (TextView) findViewById(R.id.btnSpin);
        this.btnSpinSkeleton = findViewById(R.id.btnSpinSkeleton);
        this.tvGem = (TextView) findViewById(R.id.tvGem);
        this.tvTicket = (TextView) findViewById(R.id.tvTicket);
        this.tvHeart = (TextView) findViewById(R.id.tvHeart);
        this.balanceCard = findViewById(R.id.balanceCard);
        this.iconGem = BitmapFactory.decodeResource(getResources(), R.drawable.ic_spin_gem);
        this.iconTicket = BitmapFactory.decodeResource(getResources(), R.drawable.ic_spin_ticket);
        this.iconHeart = BitmapFactory.decodeResource(getResources(), R.drawable.ic_spin_heart);
        TextView textView = this.btnSpin;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m112lambda$onCreate$1$comzenoappBeatZooSpinActivity(view);
                }
            });
        }
        loadAll();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m111lambda$onCreate$0$comzenoappBeatZooSpinActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m112lambda$onCreate$1$comzenoappBeatZooSpinActivity(View view) {
        doSpin();
    }

    private void loadAll() {
        startBalanceSkeleton();
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(0);
            this.wheelSkeletonAnim = SkeletonPulse.start(this.wheelLoading);
        }
        SpinWheelView spinWheelView = this.spinWheelView;
        if (spinWheelView != null) {
            spinWheelView.setVisibility(8);
        }
        TextView textView = this.btnSpin;
        if (textView != null) {
            textView.setVisibility(8);
        }
        View view2 = this.btnSpinSkeleton;
        if (view2 != null) {
            view2.setVisibility(0);
            this.btnSpinSkeletonAnim = SkeletonPulse.start(this.btnSpinSkeleton);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m110lambda$loadAll$4$comzenoappBeatZooSpinActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadAll$4$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m110lambda$loadAll$4$comzenoappBeatZooSpinActivity() {
        try {
            JSONArray jSONArrayFetchPrizes = fetchPrizes();
            JSONObject jSONObjectFetchBalances = fetchBalances();
            final int iOptInt = jSONObjectFetchBalances.optInt("ticket", 0);
            final int iOptInt2 = jSONObjectFetchBalances.optInt("gem", 0);
            final int iOptInt3 = jSONObjectFetchBalances.optInt("heart", 0);
            final ArrayList arrayList = new ArrayList();
            final ArrayList arrayList2 = new ArrayList();
            if (jSONArrayFetchPrizes != null) {
                for (int i = 0; i < jSONArrayFetchPrizes.length(); i++) {
                    JSONObject jSONObjectOptJSONObject = jSONArrayFetchPrizes.optJSONObject(i);
                    if (jSONObjectOptJSONObject != null && jSONObjectOptJSONObject.optBoolean("is_active", true)) {
                        arrayList2.add(jSONObjectOptJSONObject);
                        arrayList.add(buildSegment(jSONObjectOptJSONObject, arrayList.size()));
                    }
                }
            }
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m108lambda$loadAll$2$comzenoappBeatZooSpinActivity(arrayList, arrayList2, iOptInt, iOptInt2, iOptInt3);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "loadAll", e);
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m109lambda$loadAll$3$comzenoappBeatZooSpinActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$2$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m108lambda$loadAll$2$comzenoappBeatZooSpinActivity(List list, List list2, int i, int i2, int i3) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        SpinWheelView spinWheelView = this.spinWheelView;
        if (spinWheelView != null) {
            spinWheelView.setVisibility(0);
            this.spinWheelView.setSegments(list);
        }
        this.prizes.clear();
        this.prizes.addAll(list2);
        this.remainingSpins = i;
        TextView textView = this.tvGem;
        if (textView != null) {
            textView.setText(String.valueOf(i2));
        }
        TextView textView2 = this.tvTicket;
        if (textView2 != null) {
            textView2.setText(String.valueOf(i));
        }
        TextView textView3 = this.tvHeart;
        if (textView3 != null) {
            textView3.setText(String.valueOf(i3));
        }
        stopBalanceSkeleton();
        refreshSpinButton();
    }

    /* JADX INFO: renamed from: lambda$loadAll$3$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m109lambda$loadAll$3$comzenoappBeatZooSpinActivity(Exception exc) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        stopBalanceSkeleton();
        hideBtnSpinSkeleton();
        toast(exc.getMessage() != null ? exc.getMessage() : "Load failed");
    }

    private void hideBtnSpinSkeleton() {
        SkeletonPulse.stop(this.btnSpinSkeletonAnim, this.btnSpinSkeleton);
        this.btnSpinSkeletonAnim = null;
        View view = this.btnSpinSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        TextView textView = this.btnSpin;
        if (textView != null) {
            textView.setVisibility(0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View skeletonBlock(int i, int i2, boolean z) {
        View view = new View(this);
        view.setTag(SkeletonPulse.TAG);
        view.setBackgroundResource(z ? R.drawable.bg_skeleton_circle : R.drawable.bg_skeleton_bar);
        view.setLayoutParams(new LinearLayout.LayoutParams(dp(i), dp(i2)));
        return view;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startBalanceSkeleton() {
        ViewGroup viewGroup;
        View view = this.balanceCard;
        if (view == null || this.balanceCardSkeleton != null || (viewGroup = (ViewGroup) view.getParent()) == null) {
            return;
        }
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(dp(14), dp(14), dp(14), dp(14));
        linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 0, 0, dp(16));
        linearLayout.setLayoutParams(layoutParams);
        for (int i = 0; i < 3; i++) {
            LinearLayout linearLayout2 = new LinearLayout(this);
            linearLayout2.setOrientation(1);
            linearLayout2.setGravity(17);
            linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            linearLayout2.addView(skeletonBlock(28, 28, true));
            View viewSkeletonBlock = skeletonBlock(44, 18, false);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(44), dp(18));
            layoutParams2.setMargins(0, dp(6), 0, dp(4));
            linearLayout2.addView(viewSkeletonBlock, layoutParams2);
            linearLayout2.addView(skeletonBlock(40, 10, false));
            linearLayout.addView(linearLayout2);
            if (i < 2) {
                View view2 = new View(this);
                view2.setBackgroundColor(-14013910);
                linearLayout.addView(view2, new LinearLayout.LayoutParams(dp(1), -1));
            }
        }
        int iIndexOfChild = viewGroup.indexOfChild(this.balanceCard);
        this.balanceCard.setVisibility(8);
        viewGroup.addView(linearLayout, Math.max(0, iIndexOfChild));
        this.balanceCardSkeleton = linearLayout;
        this.balanceSkeletonAnim = SkeletonPulse.start(linearLayout);
    }

    private void stopBalanceSkeleton() {
        View view = this.balanceCardSkeleton;
        if (view != null) {
            SkeletonPulse.stop(this.balanceSkeletonAnim, view);
            this.balanceSkeletonAnim = null;
            ViewGroup viewGroup = (ViewGroup) this.balanceCardSkeleton.getParent();
            if (viewGroup != null) {
                viewGroup.removeView(this.balanceCardSkeleton);
            }
            this.balanceCardSkeleton = null;
        }
        View view2 = this.balanceCard;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private SpinWheelView.Segment buildSegment(JSONObject jSONObject, int i) {
        Bitmap bitmap;
        JSONObject jSONObjectOptJSONObject;
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("rewards");
        String strOptString = "gem";
        int iOptInt = 0;
        if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0 && (jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(0)) != null) {
            strOptString = jSONObjectOptJSONObject.optString("currency_code", "gem");
            iOptInt = jSONObjectOptJSONObject.optInt("amount", 0);
        }
        String str = "x" + iOptInt;
        if ("ticket".equalsIgnoreCase(strOptString)) {
            bitmap = this.iconTicket;
        } else if ("heart".equalsIgnoreCase(strOptString)) {
            bitmap = this.iconHeart;
        } else {
            bitmap = this.iconGem;
        }
        Bitmap bitmap2 = bitmap;
        int[] iArr = SEG_BG;
        return new SpinWheelView.Segment("", str, iArr[i % iArr.length], -1, bitmap2);
    }

    private void refreshSpinButton() {
        String str;
        if (this.btnSpin == null) {
            return;
        }
        hideBtnSpinSkeleton();
        boolean z = (this.prizes.isEmpty() || this.remainingSpins <= 0 || this.spinning) ? false : true;
        this.btnSpin.setEnabled(z);
        this.btnSpin.setAlpha(z ? 1.0f : 0.5f);
        TextView textView = this.btnSpin;
        if (this.remainingSpins > 0) {
            str = "SPIN  ·  " + this.remainingSpins + " ticket";
        } else {
            str = "No Tickets";
        }
        textView.setText(str);
        this.btnSpin.setVisibility(0);
    }

    private void doSpin() {
        if (this.spinning) {
            return;
        }
        if (this.remainingSpins <= 0) {
            toast("Ticket မရှိပါ");
        } else {
            if (this.prizes.isEmpty()) {
                toast("Prizes မရှိပါ");
                return;
            }
            this.spinning = true;
            refreshSpinButton();
            this.exec.execute(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m107lambda$doSpin$8$comzenoappBeatZooSpinActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$8$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m107lambda$doSpin$8$comzenoappBeatZooSpinActivity() {
        final int iOptInt;
        final int i;
        final int i2;
        try {
            JSONObject jSONObjectSpinSync = spinSync();
            if (jSONObjectSpinSync.optInt("status") != 1) {
                throw new Exception(jSONObjectSpinSync.optString("message", "Spin failed"));
            }
            JSONObject jSONObjectOptJSONObject = jSONObjectSpinSync.optJSONObject("data");
            final JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("prize") : null;
            JSONObject jSONObjectOptJSONObject3 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("ticket") : null;
            if (jSONObjectOptJSONObject3 != null) {
                iOptInt = jSONObjectOptJSONObject3.optInt("balance_after", this.remainingSpins - 1);
            } else {
                iOptInt = this.remainingSpins - 1;
            }
            JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("rewards") : null;
            final int i3 = -1;
            if (jSONArrayOptJSONArray != null) {
                int iOptInt2 = -1;
                int iOptInt3 = -1;
                for (int i4 = 0; i4 < jSONArrayOptJSONArray.length(); i4++) {
                    JSONObject jSONObjectOptJSONObject4 = jSONArrayOptJSONArray.optJSONObject(i4);
                    if (jSONObjectOptJSONObject4 != null) {
                        String strOptString = jSONObjectOptJSONObject4.optString("currency_code", "");
                        JSONObject jSONObjectOptJSONObject5 = jSONObjectOptJSONObject4.optJSONObject("balance");
                        if (jSONObjectOptJSONObject5 != null) {
                            if ("gem".equalsIgnoreCase(strOptString)) {
                                iOptInt2 = jSONObjectOptJSONObject5.optInt("balance_after", -1);
                            }
                            if ("heart".equalsIgnoreCase(strOptString)) {
                                iOptInt3 = jSONObjectOptJSONObject5.optInt("balance_after", -1);
                            }
                        }
                    }
                }
                i3 = iOptInt2;
                i = iOptInt3;
            } else {
                i = -1;
            }
            if (jSONObjectOptJSONObject2 != null) {
                String strOptString2 = jSONObjectOptJSONObject2.optString("id");
                i2 = 0;
                while (i2 < this.prizes.size()) {
                    if (strOptString2.equals(this.prizes.get(i2).optString("id"))) {
                        break;
                    } else {
                        i2++;
                    }
                }
                i2 = 0;
            } else {
                i2 = 0;
            }
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m105lambda$doSpin$6$comzenoappBeatZooSpinActivity(iOptInt, i3, i, i2, jSONObjectOptJSONObject2);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "doSpin", e);
            this.main.post(new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m106lambda$doSpin$7$comzenoappBeatZooSpinActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$6$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m105lambda$doSpin$6$comzenoappBeatZooSpinActivity(int i, int i2, int i3, int i4, final JSONObject jSONObject) {
        TextView textView;
        TextView textView2;
        this.remainingSpins = i;
        TextView textView3 = this.tvTicket;
        if (textView3 != null) {
            textView3.setText(String.valueOf(i));
        }
        if (i2 >= 0 && (textView2 = this.tvGem) != null) {
            textView2.setText(String.valueOf(i2));
        }
        if (i3 >= 0 && (textView = this.tvHeart) != null) {
            textView.setText(String.valueOf(i3));
        }
        SpinWheelView spinWheelView = this.spinWheelView;
        if (spinWheelView != null) {
            spinWheelView.spinToIndex(i4, 4500L, new Runnable() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m104lambda$doSpin$5$comzenoappBeatZooSpinActivity(jSONObject);
                }
            });
            return;
        }
        this.spinning = false;
        refreshSpinButton();
        showResultDialog(jSONObject);
    }

    /* JADX INFO: renamed from: lambda$doSpin$5$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m104lambda$doSpin$5$comzenoappBeatZooSpinActivity(JSONObject jSONObject) {
        this.spinning = false;
        refreshSpinButton();
        showResultDialog(jSONObject);
    }

    /* JADX INFO: renamed from: lambda$doSpin$7$com-zeno-app-BeatZooSpinActivity, reason: not valid java name */
    /* synthetic */ void m106lambda$doSpin$7$comzenoappBeatZooSpinActivity(Exception exc) {
        this.spinning = false;
        refreshSpinButton();
        toast(exc.getMessage() != null ? exc.getMessage() : "Spin error");
    }

    private JSONArray fetchPrizes() throws Exception {
        Response responseExecute = this.http.newCall(apiGet("/lucky-wheel/prizes").build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (jSONObject.optInt("status") != 1) {
                throw new Exception(jSONObject.optString("message", "prizes failed"));
            }
            JSONArray jSONArray = jSONObject.getJSONArray("data");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONArray;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONObject fetchBalances() throws Exception {
        JSONObject jSONObject = new JSONObject();
        String[] strArr = {"gem", "ticket", "heart"};
        for (int i = 0; i < 3; i++) {
            String str = strArr[i];
            try {
                Response responseExecute = this.http.newCall(apiGet("/currency/" + str + "/balance").build()).execute();
                try {
                    JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
                    if (jSONObject2.optInt("status") == 1) {
                        jSONObject.put(str, jSONObject2.getJSONObject("data").optInt("balance", 0));
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                } catch (Throwable th) {
                    if (responseExecute != null) {
                        try {
                            responseExecute.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } catch (Exception unused) {
                jSONObject.put(str, 0);
            }
        }
        return jSONObject;
    }

    private JSONObject spinSync() throws Exception {
        Response responseExecute = this.http.newCall(apiPost("/lucky-wheel/spin", "{}").build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "{}");
            if (responseExecute != null) {
                responseExecute.close();
            }
            return jSONObject;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private Request.Builder apiGet(String str) {
        Request.Builder builder = new Request.Builder().url(API + str).get();
        StringBuilder sb = new StringBuilder("Bearer ");
        String str2 = this.jwt;
        if (str2 == null) {
            str2 = "";
        }
        sb.append(str2);
        return builder.addHeader("Authorization", sb.toString()).addHeader("x-api-key", API_KEY).addHeader("Accept", "*/*");
    }

    private Request.Builder apiPost(String str, String str2) {
        Request.Builder builderPost = new Request.Builder().url(API + str).post(RequestBody.create(str2, JSON));
        StringBuilder sb = new StringBuilder("Bearer ");
        String str3 = this.jwt;
        if (str3 == null) {
            str3 = "";
        }
        sb.append(str3);
        return builderPost.addHeader("Authorization", sb.toString()).addHeader("x-api-key", API_KEY).addHeader("Content-Type", "application/json");
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showResultDialog(JSONObject jSONObject) {
        JSONObject jSONObjectOptJSONObject;
        if (isFinishing()) {
            return;
        }
        try {
            final Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(1);
            dialog.setContentView(R.layout.dialog_spin_result);
            dialog.setCancelable(true);
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(0));
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.88f), -2);
            }
            TextView textView = (TextView) dialog.findViewById(R.id.resultTitle);
            TextView textView2 = (TextView) dialog.findViewById(R.id.resultDetail);
            ImageView imageView = (ImageView) dialog.findViewById(R.id.resultIcon);
            TextView textView3 = (TextView) dialog.findViewById(R.id.resultEmoji);
            Button button = (Button) dialog.findViewById(R.id.btnResultClose);
            String strOptString = jSONObject != null ? jSONObject.optString("name", "Prize") : "Prize";
            String str = "";
            JSONArray jSONArrayOptJSONArray = jSONObject != null ? jSONObject.optJSONArray("rewards") : null;
            String strOptString2 = "gem";
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0 && (jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(0)) != null) {
                strOptString2 = jSONObjectOptJSONObject.optString("currency_code", "gem");
                str = "x" + jSONObjectOptJSONObject.optInt("amount", 0) + " " + strOptString2.toUpperCase(Locale.US);
            }
            if (textView != null) {
                textView.setText("Congratulations!");
            }
            if (textView2 != null) {
                if (!str.isEmpty()) {
                    strOptString = str;
                }
                textView2.setText(strOptString);
            }
            if (imageView != null) {
                if ("ticket".equalsIgnoreCase(strOptString2)) {
                    imageView.setImageResource(R.drawable.ic_spin_ticket);
                } else if ("heart".equalsIgnoreCase(strOptString2)) {
                    imageView.setImageResource(R.drawable.ic_spin_heart);
                } else {
                    imageView.setImageResource(R.drawable.ic_spin_gem);
                }
                imageView.setVisibility(0);
            }
            if (textView3 != null) {
                textView3.setVisibility(8);
            }
            if (button != null) {
                button.setText("ရယူမည်");
                button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.BeatZooSpinActivity$$ExternalSyntheticLambda8
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
            dialog.show();
        } catch (Exception unused) {
            toast(jSONObject != null ? jSONObject.optString("name", "Win!") : "Win!");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }
}
