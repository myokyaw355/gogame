package com.zeno.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.WindowCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class OtpActivity extends BaseActivity {
    private boolean addAccountMode;
    private MaterialButton btnVerify;
    private boolean isRegister;
    private String phoneNumber;
    private SessionManager sessionManager;
    private TextView tvOtpSubtitle;
    private TextView tvPhoneDisplay;
    private TextView tvResend;
    private final EditText[] otpBoxes = new EditText[6];
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(android.R.color.transparent, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_otp);
        this.sessionManager = new SessionManager(this);
        this.phoneNumber = getIntent().getStringExtra("phone");
        this.isRegister = getIntent().getBooleanExtra("isRegister", false);
        this.addAccountMode = getIntent().getBooleanExtra(LoginActivity.EXTRA_ADD_ACCOUNT, false);
        this.tvOtpSubtitle = (TextView) findViewById(R.id.tvOtpSubtitle);
        this.tvPhoneDisplay = (TextView) findViewById(R.id.tvPhoneDisplay);
        this.btnVerify = findViewById(R.id.btnVerify);
        this.tvResend = (TextView) findViewById(R.id.tvResend);
        this.tvPhoneDisplay.setText(this.phoneNumber);
        this.tvOtpSubtitle.setText("Enter the 6-digit code sent to");
        int[] iArr = {R.id.otp1, R.id.otp2, R.id.otp3, R.id.otp4, R.id.otp5, R.id.otp6};
        for (int i = 0; i < 6; i++) {
            this.otpBoxes[i] = (EditText) findViewById(iArr[i]);
            setupOtpBox(i);
        }
        this.otpBoxes[0].post(new Runnable() { // from class: com.zeno.app.OtpActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m633lambda$onCreate$0$comzenoappOtpActivity();
            }
        });
        this.btnVerify.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.OtpActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m634lambda$onCreate$1$comzenoappOtpActivity(view);
            }
        });
        this.tvResend.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.OtpActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m635lambda$onCreate$2$comzenoappOtpActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-OtpActivity, reason: not valid java name */
    /* synthetic */ void m633lambda$onCreate$0$comzenoappOtpActivity() {
        this.otpBoxes[0].requestFocus();
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.showSoftInput(this.otpBoxes[0], 1);
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-OtpActivity, reason: not valid java name */
    /* synthetic */ void m634lambda$onCreate$1$comzenoappOtpActivity(View view) {
        handleVerify();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-OtpActivity, reason: not valid java name */
    /* synthetic */ void m635lambda$onCreate$2$comzenoappOtpActivity(View view) {
        handleResend();
    }

    private void setupOtpBox(final int i) {
        final EditText editText = this.otpBoxes[i];
        editText.addTextChangedListener(new TextWatcher() { // from class: com.zeno.app.OtpActivity.1
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                OtpActivity.this.refreshBoxBg(i);
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
                if (charSequence.length() == 1 && i3 == 0 && i < 5) {
                    OtpActivity.this.otpBoxes[i + 1].requestFocus();
                }
            }
        });
        editText.setOnKeyListener(new View.OnKeyListener() { // from class: com.zeno.app.OtpActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnKeyListener
            public final boolean onKey(View view, int i2, KeyEvent keyEvent) {
                return this.f$0.m636lambda$setupOtpBox$3$comzenoappOtpActivity(editText, i, view, i2, keyEvent);
            }
        });
        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.zeno.app.OtpActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                this.f$0.m637lambda$setupOtpBox$4$comzenoappOtpActivity(i, view, z);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$setupOtpBox$3$com-zeno-app-OtpActivity, reason: not valid java name */
    /* synthetic */ boolean m636lambda$setupOtpBox$3$comzenoappOtpActivity(EditText editText, int i, View view, int i2, KeyEvent keyEvent) {
        if (i2 != 67 || keyEvent.getAction() != 0 || !editText.getText().toString().isEmpty() || i <= 0) {
            return false;
        }
        EditText editText2 = this.otpBoxes[i - 1];
        editText2.setText("");
        editText2.requestFocus();
        return true;
    }

    /* JADX INFO: renamed from: lambda$setupOtpBox$4$com-zeno-app-OtpActivity, reason: not valid java name */
    /* synthetic */ void m637lambda$setupOtpBox$4$comzenoappOtpActivity(int i, View view, boolean z) {
        refreshBoxBg(i);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshBoxBg(int i) {
        EditText editText = this.otpBoxes[i];
        boolean z = !editText.getText().toString().isEmpty();
        boolean zHasFocus = editText.hasFocus();
        if (z) {
            editText.setBackgroundResource(R.drawable.otp_box_filled);
        } else if (zHasFocus) {
            editText.setBackgroundResource(R.drawable.otp_box_focused);
        } else {
            editText.setBackgroundResource(R.drawable.otp_box_empty);
        }
    }

    private String getOtpCode() {
        StringBuilder sb = new StringBuilder();
        for (EditText editText : this.otpBoxes) {
            sb.append(editText.getText().toString().trim());
        }
        return sb.toString();
    }

    private void handleVerify() {
        String otpCode = getOtpCode();
        if (otpCode.length() != 6) {
            snack("Please enter all 6 digits");
            return;
        }
        this.btnVerify.setEnabled(false);
        this.btnVerify.setText("Verifying...");
        ApiClient.validateOtp(this.phoneNumber, otpCode, this.sessionManager.getDeviceId(), new AnonymousClass2());
    }

    /* JADX INFO: renamed from: com.zeno.app.OtpActivity$2, reason: invalid class name */
    class AnonymousClass2 implements Callback {
        AnonymousClass2() {
        }

        public void onFailure(Call call, final IOException iOException) {
            OtpActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m638lambda$onFailure$0$comzenoappOtpActivity$2(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-OtpActivity$2, reason: not valid java name */
        /* synthetic */ void m638lambda$onFailure$0$comzenoappOtpActivity$2(IOException iOException) {
            OtpActivity.this.resetVerifyBtn();
            OtpActivity.this.snack("Network error: " + iOException.getMessage());
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            OtpActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m639lambda$onResponse$1$comzenoappOtpActivity$2(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-OtpActivity$2, reason: not valid java name */
        /* synthetic */ void m639lambda$onResponse$1$comzenoappOtpActivity$2(String str) {
            String strReplace;
            String strReplace2;
            String strOptString;
            String str2;
            String[] strArrSplit;
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optInt("errorCode", -1) == 200) {
                    JSONObject jSONObject2 = jSONObject.getJSONObject("result");
                    String string = jSONObject2.getString("access_token");
                    String strOptString2 = jSONObject2.optString("refresh_token", "");
                    long jOptLong = jSONObject2.optLong("expires_in", 2678400L);
                    String strOptString3 = jSONObject2.optString("thirdPartyToken", "");
                    try {
                        strArrSplit = string.split("\\.");
                    } catch (Exception unused) {
                    }
                    if (strArrSplit.length == 3) {
                        int length = strArrSplit[1].length() % 4;
                        StringBuilder sb = new StringBuilder();
                        sb.append(strArrSplit[1]);
                        sb.append(length == 0 ? "" : "====".substring(length));
                        JSONObject jSONObject3 = new JSONObject(new String(Base64.decode(sb.toString(), 8)));
                        strReplace = jSONObject3.optString("sub", "").replace("-", "");
                        try {
                            strReplace2 = jSONObject3.optString("session_state", "").replace("-", "");
                            try {
                                if (strReplace2.isEmpty()) {
                                    strReplace2 = jSONObject3.optString("jti", "").replace("-", "");
                                }
                            } catch (Exception unused2) {
                            }
                        } catch (Exception unused3) {
                            strReplace2 = "";
                        }
                    } else {
                        strReplace = "";
                        strReplace2 = strReplace;
                    }
                    String str3 = strReplace2;
                    String str4 = strReplace;
                    if (strOptString3.isEmpty()) {
                        str2 = "";
                        OtpActivity.this.sessionManager.saveTokens(string, strOptString2, jOptLong);
                        OtpActivity.this.sessionManager.saveUserInfo(OtpActivity.this.phoneNumber, "", "");
                        OtpActivity.this.sessionManager.clearScSession();
                        OtpActivity.this.sessionManager.clearKongSession();
                        OtpActivity.this.sessionManager.saveGameSession(strOptString3, strOptString3, str4, str3, str2);
                        OtpActivity.this.fetchAndSaveProfileThenContinue(string, OtpActivity.this.phoneNumber, OtpActivity.this.addAccountMode);
                    } else {
                        try {
                            String[] strArrSplit2 = strOptString3.split("\\.");
                            if (strArrSplit2.length == 3) {
                                int length2 = strArrSplit2[1].length() % 4;
                                StringBuilder sb2 = new StringBuilder();
                                sb2.append(strArrSplit2[1]);
                                sb2.append(length2 == 0 ? "" : "====".substring(length2));
                                strOptString = new JSONObject(new String(Base64.decode(sb2.toString(), 8))).optString("sub", "");
                            } else {
                                strOptString = "";
                            }
                            str2 = strOptString;
                        } catch (Exception unused4) {
                            str2 = "";
                        }
                        OtpActivity.this.sessionManager.saveTokens(string, strOptString2, jOptLong);
                        OtpActivity.this.sessionManager.saveUserInfo(OtpActivity.this.phoneNumber, "", "");
                        try {
                            OtpActivity.this.sessionManager.clearScSession();
                            OtpActivity.this.sessionManager.clearKongSession();
                        } catch (Exception unused5) {
                        }
                        OtpActivity.this.sessionManager.saveGameSession(strOptString3, strOptString3, str4, str3, str2);
                        OtpActivity.this.fetchAndSaveProfileThenContinue(string, OtpActivity.this.phoneNumber, OtpActivity.this.addAccountMode);
                    }
                } else {
                    OtpActivity.this.resetVerifyBtn();
                    OtpActivity.this.snack(jSONObject.optString("message", "Verification failed"));
                }
            } catch (Exception e) {
                OtpActivity.this.resetVerifyBtn();
                OtpActivity.this.snack("Parse error: " + e.getMessage());
            }
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.OtpActivity$3, reason: invalid class name */
    class AnonymousClass3 implements Callback {
        final /* synthetic */ boolean val$addAccountMode;
        final /* synthetic */ String val$phone;

        AnonymousClass3(boolean z, String str) {
            this.val$addAccountMode = z;
            this.val$phone = str;
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-OtpActivity$3, reason: not valid java name */
        /* synthetic */ void m640lambda$onFailure$0$comzenoappOtpActivity$3(boolean z) {
            OtpActivity.this.finishLoginFlow(z);
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = OtpActivity.this.uiHandler;
            final boolean z = this.val$addAccountMode;
            handler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m640lambda$onFailure$0$comzenoappOtpActivity$3(z);
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            String strOptString;
            String strOptString2;
            JSONObject jSONObjectOptJSONObject;
            JSONArray jSONArrayOptJSONArray;
            try {
                jSONObjectOptJSONObject = new JSONObject(response.body() != null ? response.body().string() : "{}").optJSONObject("result");
            } catch (Exception unused) {
                strOptString = "";
            }
            if (jSONObjectOptJSONObject != null) {
                strOptString = jSONObjectOptJSONObject.optString("fullName", "");
                try {
                    jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("externalRefs");
                } catch (Exception unused2) {
                }
                if (jSONArrayOptJSONArray == null) {
                    strOptString2 = "";
                } else {
                    for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                        JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                        if ("avatar_img".equals(jSONObject.optString("type"))) {
                            strOptString2 = jSONObject.optString("href", "");
                            break;
                        }
                        strOptString2 = "";
                    }
                    strOptString2 = "";
                }
            } else {
                strOptString2 = "";
                strOptString = strOptString2;
            }
            final String str = strOptString != null ? strOptString : "";
            final String str2 = strOptString2 != null ? strOptString2 : "";
            Handler handler = OtpActivity.this.uiHandler;
            final String str3 = this.val$phone;
            final boolean z = this.val$addAccountMode;
            handler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m641lambda$onResponse$1$comzenoappOtpActivity$3(str3, str, str2, z);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-OtpActivity$3, reason: not valid java name */
        /* synthetic */ void m641lambda$onResponse$1$comzenoappOtpActivity$3(String str, String str2, String str3, boolean z) {
            OtpActivity.this.sessionManager.saveUserInfo(str, str2, str3);
            try {
                new AccountManager(OtpActivity.this).saveFromSession(OtpActivity.this.sessionManager);
            } catch (Exception unused) {
            }
            OtpActivity.this.finishLoginFlow(z);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchAndSaveProfileThenContinue(String str, String str2, boolean z) {
        ApiClient.getCustomer(str, new AnonymousClass3(z, str2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void finishLoginFlow(boolean z) {
        try {
            new AccountManager(this).saveFromSession(this.sessionManager);
        } catch (Exception unused) {
        }
        if (z) {
            setResult(-1);
            Intent intent = new Intent((Context) this, (Class<?>) AccountsActivity.class);
            intent.addFlags(603979776);
            startActivity(intent);
            finish();
            return;
        }
        startActivity(new Intent((Context) this, (Class<?>) DashboardActivity.class));
        finish();
    }

    private void handleResend() {
        this.tvResend.setEnabled(false);
        this.tvResend.setAlpha(0.5f);
        for (EditText editText : this.otpBoxes) {
            editText.setText("");
        }
        this.otpBoxes[0].requestFocus();
        refreshAllBoxBg();
        AnonymousClass4 anonymousClass4 = new AnonymousClass4();
        if (this.isRegister) {
            ApiClient.registerRequest(this.phoneNumber, anonymousClass4);
        } else {
            ApiClient.getOtp(this.phoneNumber, anonymousClass4);
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.OtpActivity$4, reason: invalid class name */
    class AnonymousClass4 implements Callback {
        AnonymousClass4() {
        }

        public void onFailure(Call call, final IOException iOException) {
            OtpActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$4$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m642lambda$onFailure$0$comzenoappOtpActivity$4(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-OtpActivity$4, reason: not valid java name */
        /* synthetic */ void m642lambda$onFailure$0$comzenoappOtpActivity$4(IOException iOException) {
            OtpActivity.this.tvResend.setEnabled(true);
            OtpActivity.this.tvResend.setAlpha(1.0f);
            OtpActivity.this.snack("Resend failed: " + iOException.getMessage());
        }

        public void onResponse(Call call, Response response) throws IOException {
            OtpActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.OtpActivity$4$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m643lambda$onResponse$1$comzenoappOtpActivity$4();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-OtpActivity$4, reason: not valid java name */
        /* synthetic */ void m643lambda$onResponse$1$comzenoappOtpActivity$4() {
            OtpActivity.this.tvResend.setEnabled(true);
            OtpActivity.this.tvResend.setAlpha(1.0f);
            OtpActivity.this.snack("OTP resent!");
        }
    }

    private void refreshAllBoxBg() {
        for (int i = 0; i < 6; i++) {
            refreshBoxBg(i);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void resetVerifyBtn() {
        this.btnVerify.setEnabled(true);
        this.btnVerify.setText(getString(R.string.verify_login));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void snack(String str) {
        Snackbar snackbarMake = Snackbar.make(findViewById(android.R.id.content), str, 0);
        View view = snackbarMake.getView();
        ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
        view.setLayoutParams(view.getLayoutParams());
        snackbarMake.show();
    }
}
