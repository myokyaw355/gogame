package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.snackbar.Snackbar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class GameStoreActivity extends BaseActivity {
    private static final String GAME_BASE = "https://pubapi-mygov2.mtgmm.co/v1/engine";
    private ExecutorService exec;
    private LinearLayout llStoreError;
    private LinearLayout llStoreLoading;
    private LinearLayout[] llTabs;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private ScrollView[] svTabs;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tabIngame;
    private TextView tabOneTime;
    private TextView tabSub;
    private TextView tvStoreError;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS).followRedirects(true).build();
    private int currentTab = 0;
    private final String[] categoryIds = {null, null, null};
    private final boolean[] tabLoaded = {false, false, false};
    private boolean purchaseDone = false;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_game_store);
        this.session = new SessionManager(this);
        this.exec = Executors.newCachedThreadPool();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Game Store");
        }
        if (toolbarFindViewById != null) {
            toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m447lambda$onCreate$0$comzenoappGameStoreActivity(view);
                }
            });
        }
        bindViews();
        loadCategories();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m447lambda$onCreate$0$comzenoappGameStoreActivity(View view) {
        finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void bindViews() {
        this.tabSub = (TextView) findViewById(R.id.tabSub);
        this.tabOneTime = (TextView) findViewById(R.id.tabOneTime);
        this.tabIngame = (TextView) findViewById(R.id.tabIngame);
        this.llStoreLoading = (LinearLayout) findViewById(R.id.llStoreLoading);
        this.llStoreError = (LinearLayout) findViewById(R.id.llStoreError);
        this.tvStoreError = (TextView) findViewById(R.id.tvStoreError);
        this.svTabs = new ScrollView[]{(ScrollView) findViewById(R.id.svTab0), (ScrollView) findViewById(R.id.svTab1), (ScrollView) findViewById(R.id.svTab2)};
        this.llTabs = new LinearLayout[]{(LinearLayout) findViewById(R.id.llTab0), (LinearLayout) findViewById(R.id.llTab1), (LinearLayout) findViewById(R.id.llTab2)};
        Button button = (Button) findViewById(R.id.btnStoreRetry);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda10
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m435lambda$bindViews$1$comzenoappGameStoreActivity(view);
                }
            });
        }
        View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m436lambda$bindViews$2$comzenoappGameStoreActivity(view);
            }
        };
        this.tabSub.setOnClickListener(onClickListener);
        this.tabOneTime.setOnClickListener(onClickListener);
        this.tabIngame.setOnClickListener(onClickListener);
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        if (swipeRefreshLayoutFindViewById != null) {
            swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda12
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return this.f$0.m437lambda$bindViews$3$comzenoappGameStoreActivity(swipeRefreshLayout, view);
                }
            });
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda13
                public final void onRefresh() {
                    this.f$0.m438lambda$bindViews$4$comzenoappGameStoreActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$bindViews$1$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m435lambda$bindViews$1$comzenoappGameStoreActivity(View view) {
        boolean[] zArr = this.tabLoaded;
        int i = this.currentTab;
        zArr[i] = false;
        String str = this.categoryIds[i];
        if (str != null) {
            loadTabItems(i, str);
        } else {
            loadCategories();
        }
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m436lambda$bindViews$2$comzenoappGameStoreActivity(View view) {
        if (view == this.tabSub) {
            switchTab(0);
        } else if (view == this.tabOneTime) {
            switchTab(1);
        } else if (view == this.tabIngame) {
            switchTab(2);
        }
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ boolean m437lambda$bindViews$3$comzenoappGameStoreActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        int i;
        ScrollView scrollView;
        ScrollView[] scrollViewArr = this.svTabs;
        if (scrollViewArr == null || (i = this.currentTab) < 0 || i >= scrollViewArr.length || (scrollView = scrollViewArr[i]) == null || scrollView.getVisibility() != 0) {
            return false;
        }
        return this.svTabs[this.currentTab].canScrollVertically(-1);
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m438lambda$bindViews$4$comzenoappGameStoreActivity() {
        boolean[] zArr = this.tabLoaded;
        int i = this.currentTab;
        zArr[i] = false;
        String str = this.categoryIds[i];
        if (str != null) {
            loadTabItems(i, str);
        } else {
            loadCategories();
        }
    }

    private void loadCategories() {
        final String gameToken = this.session.getGameToken();
        if (gameToken == null || gameToken.isEmpty()) {
            showError("Game ကို မ Login မရသေးပါ။\nAuto Play ကို အရင် ဖွင့်ပါ။");
            return;
        }
        startStoreSkeleton();
        this.llStoreError.setVisibility(8);
        for (ScrollView scrollView : this.svTabs) {
            scrollView.setVisibility(8);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m444lambda$loadCategories$6$comzenoappGameStoreActivity(gameToken);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadCategories$6$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m444lambda$loadCategories$6$comzenoappGameStoreActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://pubapi-mygov2.mtgmm.co/v1/engine/game/store/categories").addHeader("Authorization", "Bearer " + str).addHeader("Accept", "application/json").build()).execute();
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            int iCode = responseExecute.code();
            responseExecute.close();
            if (iCode != 200) {
                showError("Store load မရဘူး (HTTP " + iCode + ")");
                return;
            }
            JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                int i = 0;
                while (i < jSONArrayOptJSONArray.length()) {
                    JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                    i++;
                    int iOptInt = jSONObject.optInt("display_order", i);
                    String strOptString = jSONObject.optString("id", "");
                    int i2 = iOptInt - 1;
                    if (i2 >= 0 && i2 < 3 && !strOptString.isEmpty()) {
                        this.categoryIds[i2] = strOptString;
                    }
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m443lambda$loadCategories$5$comzenoappGameStoreActivity();
                    }
                });
                return;
            }
            showError("Store category မတွေ့ဘူး");
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$loadCategories$5$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m443lambda$loadCategories$5$comzenoappGameStoreActivity() {
        stopStoreSkeleton();
        switchTab(0);
    }

    private void switchTab(int i) {
        this.currentTab = i;
        this.tabSub.setTextColor(i == 0 ? -1 : -6381922);
        this.tabOneTime.setTextColor(i == 1 ? -1 : -6381922);
        this.tabIngame.setTextColor(i != 2 ? -6381922 : -1);
        this.tabSub.setBackgroundResource(i == 0 ? R.drawable.bg_beat_mode_selected : R.drawable.bg_beat_mode_normal);
        this.tabOneTime.setBackgroundResource(i == 1 ? R.drawable.bg_beat_mode_selected : R.drawable.bg_beat_mode_normal);
        this.tabIngame.setBackgroundResource(i == 2 ? R.drawable.bg_beat_mode_selected : R.drawable.bg_beat_mode_normal);
        if (this.tabLoaded[i]) {
            for (ScrollView scrollView : this.svTabs) {
                scrollView.setVisibility(8);
            }
            this.svTabs[i].setVisibility(0);
            stopStoreSkeleton();
            this.llStoreError.setVisibility(8);
            return;
        }
        String str = this.categoryIds[i];
        if (str == null || str.isEmpty()) {
            showEmptyTab(i, "Package မတွေ့ဘူး");
        } else {
            loadTabItems(i, str);
        }
    }

    private void loadTabItems(final int i, final String str) {
        final String gameToken = this.session.getGameToken();
        if (gameToken == null || gameToken.isEmpty()) {
            showError("Game token မတွေ့ဘူး");
            return;
        }
        startStoreSkeleton();
        this.llStoreError.setVisibility(8);
        for (ScrollView scrollView : this.svTabs) {
            scrollView.setVisibility(8);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m446lambda$loadTabItems$8$comzenoappGameStoreActivity(str, gameToken, i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadTabItems$8$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m446lambda$loadTabItems$8$comzenoappGameStoreActivity(String str, final String str2, final int i) {
        try {
            Request.Builder builderUrl = new Request.Builder().url("https://pubapi-mygov2.mtgmm.co/v1/engine/game/store/categories/" + str + "/items");
            StringBuilder sb = new StringBuilder("Bearer ");
            sb.append(str2);
            Response responseExecute = this.http.newCall(builderUrl.addHeader("Authorization", sb.toString()).addHeader("Accept", "application/json").build()).execute();
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            int iCode = responseExecute.code();
            responseExecute.close();
            if (iCode != 200) {
                showError("Package load မရဘူး (HTTP " + iCode + ")");
                return;
            }
            final JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = new JSONArray();
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m445lambda$loadTabItems$7$comzenoappGameStoreActivity(i, jSONArrayOptJSONArray, str2);
                }
            });
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$loadTabItems$7$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m445lambda$loadTabItems$7$comzenoappGameStoreActivity(int i, JSONArray jSONArray, String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        stopStoreSkeleton();
        this.llTabs[i].removeAllViews();
        if (jSONArray.length() == 0) {
            addEmptyView(this.llTabs[i], "Package မရှိသေးဘူး");
        } else {
            for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                try {
                    addStoreItem(this.llTabs[i], jSONArray.getJSONObject(i2), str);
                } catch (Exception unused) {
                }
            }
        }
        this.svTabs[i].setVisibility(0);
        this.tabLoaded[i] = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addStoreItem(LinearLayout linearLayout, JSONObject jSONObject, final String str) {
        String number;
        final View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_store_package, (ViewGroup) linearLayout, false);
        final String strOptString = jSONObject.optString("id", "");
        String strOptString2 = jSONObject.optString("name", "Package");
        int iOptInt = jSONObject.optInt("price", 0);
        String strOptString3 = jSONObject.optString("type", "KS");
        String strOptString4 = jSONObject.optString("reg_type", "CHARGE");
        boolean zOptBoolean = jSONObject.optBoolean("subscribed", false);
        final boolean zEqualsIgnoreCase = "SUB".equalsIgnoreCase(strOptString4);
        boolean zEqualsIgnoreCase2 = "DIAMOND".equalsIgnoreCase(strOptString3);
        if (zEqualsIgnoreCase2 && strOptString2.contains("Diamond")) {
            strOptString2 = strOptString2.replace("Diamond", "Energy");
        }
        final String str2 = strOptString2;
        ((TextView) viewInflate.findViewById(R.id.tvPackName)).setText(str2);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPackType);
        if (zEqualsIgnoreCase) {
            textView.setText("Subscription");
            textView.setTextColor(-3632086);
        } else if (zEqualsIgnoreCase2) {
            textView.setText("Ingame Purchase");
            textView.setTextColor(-11549705);
        } else {
            textView.setText("One Time");
            textView.setTextColor(-8271996);
        }
        textView.setVisibility(0);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvPackDuration);
        if (zEqualsIgnoreCase) {
            textView2.setText("Monthly");
            textView2.setVisibility(0);
        } else {
            textView2.setVisibility(8);
        }
        ((TextView) viewInflate.findViewById(R.id.tvActiveBadge)).setVisibility(8);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivPackIcon);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("items");
        if (zEqualsIgnoreCase) {
            imageView.setImageResource(R.drawable.ic_gift);
        } else {
            imageView.setImageResource(resolvePackIcon(str2, jSONArrayOptJSONArray));
        }
        LinearLayout linearLayout2 = (LinearLayout) viewInflate.findViewById(R.id.llItemChips);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvPackDesc);
        final JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray("items");
        if (jSONArrayOptJSONArray2 != null && jSONArrayOptJSONArray2.length() > 0) {
            linearLayout2.setVisibility(0);
            textView3.setVisibility(8);
            addItemChips(linearLayout2, jSONArrayOptJSONArray2);
        } else {
            linearLayout2.setVisibility(8);
            textView3.setVisibility(8);
        }
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvPackPrice);
        if (iOptInt <= 0) {
            number = "Free";
        } else if (zEqualsIgnoreCase2) {
            number = formatNumber(iOptInt);
        } else {
            number = formatNumber(iOptInt) + " Ks";
        }
        final String str3 = number;
        if (textView4 != null) {
            textView4.setText(str3);
            textView4.setVisibility(8);
        }
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.btnBuyPack);
        textView5.setCompoundDrawablesRelative(null, null, null, null);
        if (zEqualsIgnoreCase) {
            if (zOptBoolean) {
                textView5.setText("ဝယ်ယူပြီး");
                textView5.setTag("ဝယ်ယူပြီး");
            } else {
                textView5.setText(str3);
                textView5.setTag(str3);
            }
        } else if (zEqualsIgnoreCase2) {
            textView5.setTag(str3);
            Drawable drawable = ContextCompat.getDrawable(this, R.drawable.ic_stat_diamond);
            if (drawable != null) {
                int iDpToPx = dpToPx(14);
                Drawable drawableMutate = drawable.mutate();
                drawableMutate.setBounds(0, 0, iDpToPx, iDpToPx);
                SpannableString spannableString = new SpannableString("￼ " + str3);
                spannableString.setSpan(new ImageSpan(drawableMutate, 2), 0, 1, 33);
                textView5.setText(spannableString);
                textView5.setContentDescription(str3);
            } else {
                textView5.setText(str3);
            }
        } else {
            textView5.setText(str3);
            textView5.setTag(str3);
        }
        if (zOptBoolean) {
            textView5.setEnabled(false);
            textView5.setAlpha(0.65f);
            textView5.setBackgroundResource(R.drawable.bg_subscribed_btn);
            ViewCompat.setBackgroundTintList(textView5, (ColorStateList) null);
        } else {
            textView5.setEnabled(true);
            textView5.setAlpha(1.0f);
            textView5.setBackgroundResource(R.drawable.bg_buy_pill);
            ViewCompat.setBackgroundTintList(textView5, (ColorStateList) null);
            textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m434lambda$addStoreItem$9$comzenoappGameStoreActivity(strOptString, str2, str3, jSONArrayOptJSONArray2, str, zEqualsIgnoreCase, viewInflate, view);
                }
            });
        }
        linearLayout.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addStoreItem$9$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m434lambda$addStoreItem$9$comzenoappGameStoreActivity(String str, String str2, String str3, JSONArray jSONArray, String str4, boolean z, View view, View view2) {
        showConfirmAndBuy(str, str2, str3, buildItemsText(jSONArray), str4, z, view);
    }

    private void addItemChips(final LinearLayout linearLayout, final JSONArray jSONArray) {
        linearLayout.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() { // from class: com.zeno.app.GameStoreActivity.1
            @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
            public void onGlobalLayout() {
                if (linearLayout.getWidth() > 0) {
                    linearLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    GameStoreActivity.this.buildChipRows(linearLayout, jSONArray);
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void buildChipRows(LinearLayout linearLayout, JSONArray jSONArray) {
        linearLayout.removeAllViews();
        int iDpToPx = dpToPx(8);
        int width = linearLayout.getWidth();
        LinearLayout linearLayout2 = null;
        int i = 0;
        int i2 = 0;
        for (int i3 = 0; i3 < jSONArray.length(); i3++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i3);
                int iOptInt = jSONObject.optInt("quantity", 1);
                String upperCase = jSONObject.optString("type", "").toUpperCase();
                String str = iOptInt + " " + friendlyType(upperCase);
                View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_store_chip, (ViewGroup) linearLayout, false);
                ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivChipIcon);
                int iItemIconRes = itemIconRes(upperCase);
                if (iItemIconRes != 0) {
                    imageView.setImageResource(iItemIconRes);
                    imageView.setVisibility(0);
                } else {
                    imageView.setVisibility(8);
                }
                TextView textView = (TextView) viewInflate.findViewById(R.id.tvChipLabel);
                textView.setText(str);
                textView.setTextColor(chipTextColor(upperCase));
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                layoutParams.setMargins(0, 0, iDpToPx, 0);
                viewInflate.setLayoutParams(layoutParams);
                viewInflate.measure(View.MeasureSpec.makeMeasureSpec(width > 0 ? width : 536870911, Integer.MIN_VALUE), 0);
                int measuredWidth = viewInflate.getMeasuredWidth() + iDpToPx;
                if (linearLayout2 == null || (width > 0 && i + measuredWidth > width)) {
                    LinearLayout linearLayout3 = new LinearLayout(this);
                    try {
                        linearLayout3.setOrientation(0);
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
                        if (i2 > 0) {
                            layoutParams2.topMargin = dpToPx(6);
                        }
                        linearLayout3.setLayoutParams(layoutParams2);
                        linearLayout.addView(linearLayout3);
                        i2++;
                        linearLayout2 = linearLayout3;
                        i = 0;
                        linearLayout2.addView(viewInflate);
                        i += measuredWidth;
                    } catch (Exception unused) {
                        linearLayout2 = linearLayout3;
                    }
                } else {
                    linearLayout2.addView(viewInflate);
                    i += measuredWidth;
                }
            } catch (Exception unused2) {
            }
        }
    }

    private int itemIconRes(String str) {
        str.hashCode();
        switch (str) {
            case "DIAMOND":
                return R.drawable.ic_stat_diamond;
            case "JACKFRUIT":
                return R.drawable.ic_stat_jackfruit;
            case "TURN_FREE":
            case "TURN_PAID":
            case "TURN":
                return R.drawable.ic_stat_turn;
            case "MIX":
                return R.drawable.ic_stat_mix;
            case "HAMMER":
                return R.drawable.ic_stat_hammer;
            default:
                return 0;
        }
    }

    private int resolvePackIcon(String str, JSONArray jSONArray) {
        int iItemIconRes;
        String lowerCase = str == null ? "" : str.toLowerCase();
        if (lowerCase.contains("diamond")) {
            return R.drawable.ic_stat_diamond;
        }
        if (lowerCase.contains("mix")) {
            return R.drawable.ic_stat_mix;
        }
        if (lowerCase.contains("hammer")) {
            return R.drawable.ic_stat_hammer;
        }
        if (lowerCase.contains("energy") || lowerCase.contains("turn")) {
            return R.drawable.ic_stat_turn;
        }
        if (lowerCase.contains("jackfruit") || lowerCase.contains("jack")) {
            return R.drawable.ic_stat_jackfruit;
        }
        if (jSONArray != null) {
            for (int i = 0; i < jSONArray.length(); i++) {
                try {
                    iItemIconRes = itemIconRes(jSONArray.getJSONObject(i).optString("type", "").toUpperCase());
                } catch (Exception unused) {
                }
                if (iItemIconRes != 0) {
                    return iItemIconRes;
                }
            }
        }
        return R.drawable.ic_stat_diamond;
    }

    private int chipTextColor(String str) {
        str.hashCode();
        switch (str) {
            case "DIAMOND":
                return -11549705;
            case "JACKFRUIT":
                return -8271996;
            case "TURN_PAID":
                return -3722;
            case "MIX":
                return -4560696;
            case "HAMMER":
                return -30107;
            default:
                return -3355444;
        }
    }

    private String friendlyType(String str) {
        str.hashCode();
        if (str.equals("TURN_FREE")) {
            return "FREE TURN";
        }
        if (str.equals("TURN_PAID")) {
            return "PAID TURN";
        }
        return str.replace("_", " ");
    }

    private String buildItemsText(JSONArray jSONArray) {
        if (jSONArray == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < jSONArray.length(); i++) {
            try {
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                int iOptInt = jSONObject.optInt("quantity", 1);
                String upperCase = jSONObject.optString("type", "").toUpperCase();
                if (sb.length() > 0) {
                    sb.append("  +  ");
                }
                sb.append(iOptInt);
                sb.append(" ");
                sb.append(friendlyType(upperCase));
            } catch (Exception unused) {
            }
        }
        return sb.toString();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00b8 A[PHI: r5
      0x00b8: PHI (r5v3 java.lang.String) = (r5v1 java.lang.String), (r5v11 java.lang.String) binds: [B:33:0x00b6, B:28:0x00a2] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void showConfirmAndBuy(final java.lang.String r14, final java.lang.String r15, java.lang.String r16, java.lang.String r17, final java.lang.String r18, final boolean r19, final android.view.View r20) {
        /*
            Method dump skipped, instruction units count: 400
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.GameStoreActivity.showConfirmAndBuy(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, boolean, android.view.View):void");
    }

    /* JADX INFO: renamed from: lambda$showConfirmAndBuy$11$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m448lambda$showConfirmAndBuy$11$comzenoappGameStoreActivity(Dialog dialog, String str, String str2, String str3, boolean z, View view, View view2) {
        dialog.dismiss();
        doPurchase(str, str2, str3, z, view);
    }

    private void doPurchase(final String str, final String str2, final String str3, final boolean z, final View view) {
        final TextView textView = (TextView) view.findViewById(R.id.btnBuyPack);
        String string = "ဝယ်ယူပြီး";
        if (textView != null) {
            Object tag = textView.getTag();
            if (tag instanceof String) {
                string = (String) tag;
            } else if (!z) {
                string = textView.getText().toString();
            }
            textView.setEnabled(false);
            textView.setText("...");
        } else if (!z) {
            string = "ဝယ်မည်";
        }
        final String str4 = string;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m442lambda$doPurchase$15$comzenoappGameStoreActivity(str, str3, str2, textView, z, str4, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doPurchase$15$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m442lambda$doPurchase$15$comzenoappGameStoreActivity(String str, String str2, final String str3, final TextView textView, final boolean z, final String str4, final View view) {
        try {
            Request.Builder builder = new Request.Builder().url("https://pubapi-mygov2.mtgmm.co/v1/engine/game/store/" + str + "/subscribe").get();
            StringBuilder sb = new StringBuilder("Bearer ");
            sb.append(str2);
            Response responseExecute = this.http.newCall(builder.addHeader("Authorization", sb.toString()).addHeader("Content-Type", "application/json").addHeader("Accept", "application/json").build()).execute();
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            responseExecute.code();
            responseExecute.close();
            JSONObject jSONObject = new JSONObject(strString);
            String strOptString = jSONObject.optString("code", "-1");
            final String strOptString2 = jSONObject.optString("message", jSONObject.optString("error_desc", "Done"));
            final boolean zEquals = "0".equals(strOptString);
            final boolean zEquals2 = "CM_0053".equals(strOptString);
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m440lambda$doPurchase$13$comzenoappGameStoreActivity(zEquals, str3, strOptString2, textView, z, str4, view, zEquals2);
                }
            });
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda8
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m441lambda$doPurchase$14$comzenoappGameStoreActivity(e, textView, str4);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doPurchase$13$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m440lambda$doPurchase$13$comzenoappGameStoreActivity(boolean z, String str, String str2, TextView textView, boolean z2, String str3, View view, boolean z3) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        if (z) {
            this.purchaseDone = true;
            setResult(-1);
            showSnack("✓ " + str + " — " + str2);
            if (textView != null) {
                if (z2) {
                    str3 = "ဝယ်ယူပြီး";
                }
                textView.setText(str3);
                textView.setEnabled(false);
                textView.setAlpha(0.65f);
                textView.setBackgroundResource(R.drawable.bg_subscribed_btn);
            }
            View viewFindViewById = view.findViewById(R.id.tvActiveBadge);
            if (viewFindViewById != null) {
                viewFindViewById.setVisibility(8);
            }
            this.llStoreLoading.postDelayed(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m439lambda$doPurchase$12$comzenoappGameStoreActivity();
                }
            }, 1200L);
            return;
        }
        if (z3) {
            showSnack("ℹ️ Already subscribed: " + str);
            if (textView != null) {
                if (z2) {
                    str3 = "ဝယ်ယူပြီး";
                }
                textView.setText(str3);
                textView.setEnabled(false);
                textView.setAlpha(0.65f);
                textView.setBackgroundResource(R.drawable.bg_subscribed_btn);
                return;
            }
            return;
        }
        showSnack("✗ " + str2);
        if (textView != null) {
            textView.setEnabled(true);
            textView.setAlpha(1.0f);
            textView.setText(str3);
        }
    }

    /* JADX INFO: renamed from: lambda$doPurchase$12$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m439lambda$doPurchase$12$comzenoappGameStoreActivity() {
        boolean[] zArr = this.tabLoaded;
        int i = this.currentTab;
        zArr[i] = false;
        String str = this.categoryIds[i];
        if (str != null) {
            loadTabItems(i, str);
        }
    }

    /* JADX INFO: renamed from: lambda$doPurchase$14$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m441lambda$doPurchase$14$comzenoappGameStoreActivity(Exception exc, TextView textView, String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        showSnack("Error: " + exc.getMessage());
        if (textView != null) {
            textView.setEnabled(true);
            textView.setAlpha(1.0f);
            textView.setText(str);
        }
    }

    private void showSnack(String str) {
        View viewFindViewById = findViewById(android.R.id.content);
        if (viewFindViewById != null) {
            Snackbar snackbarMake = Snackbar.make(viewFindViewById, str, 0);
            View view = snackbarMake.getView();
            view.setBackgroundColor(-13487566);
            ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
            view.setLayoutParams(view.getLayoutParams());
            snackbarMake.show();
        }
    }

    private void showError(String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.GameStoreActivity$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m449lambda$showError$16$comzenoappGameStoreActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$16$com-zeno-app-GameStoreActivity, reason: not valid java name */
    /* synthetic */ void m449lambda$showError$16$comzenoappGameStoreActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        stopStoreSkeleton();
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
        for (ScrollView scrollView : this.svTabs) {
            scrollView.setVisibility(8);
        }
        TextView textView = this.tvStoreError;
        if (textView != null) {
            textView.setText("Package Failed");
        }
        this.llStoreError.setVisibility(0);
    }

    private void showEmptyTab(int i, String str) {
        stopStoreSkeleton();
        this.llStoreError.setVisibility(8);
        this.llTabs[i].removeAllViews();
        addEmptyView(this.llTabs[i], str);
        this.svTabs[i].setVisibility(0);
        this.tabLoaded[i] = true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addEmptyView(LinearLayout linearLayout, String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-8947849);
        textView.setTextSize(16.0f);
        textView.setGravity(17);
        textView.setPadding(24, 120, 24, 120);
        linearLayout.addView(textView);
    }

    private String formatNumber(int i) {
        return String.format("%,d", Integer.valueOf(i));
    }

    private int dpToPx(int i) {
        return (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private void startStoreSkeleton() {
        LinearLayout linearLayout = this.llStoreLoading;
        if (linearLayout == null) {
            return;
        }
        linearLayout.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llStoreLoading);
    }

    private void stopStoreSkeleton() {
        SkeletonPulse.stop(this.skeletonAnim, this.llStoreLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llStoreLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }
}
