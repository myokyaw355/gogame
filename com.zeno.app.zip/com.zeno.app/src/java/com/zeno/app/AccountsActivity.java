package com.zeno.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import com.bumptech.glide.Glide;
import com.zeno.app.AccountManager;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class AccountsActivity extends BaseActivity {
    private static final int REQ_ADD_ACCOUNT = 2101;
    private LinearLayout accountList;
    private AccountManager accounts;
    private String currentPhone;
    private View panelAccount;
    private View panelCustom;
    private SessionManager session;
    private SwitchCompat switchKeepScreenOn;
    private TextView tabAccount;
    private TextView tabCustom;
    private TextView tvEmpty;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        setContentView(R.layout.activity_accounts);
        this.session = new SessionManager(this);
        AccountManager accountManager = new AccountManager(this);
        this.accounts = accountManager;
        accountManager.saveFromSession(this.session);
        String phone = this.session.getPhone();
        this.currentPhone = phone;
        if (phone == null) {
            this.currentPhone = "";
        }
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }
        if (toolbarFindViewById != null) {
            toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda0
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m3lambda$onCreate$0$comzenoappAccountsActivity(view);
                }
            });
        }
        this.accountList = (LinearLayout) findViewById(R.id.accountList);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmptyAccounts);
        View viewFindViewById = findViewById(R.id.btnAddAccount);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m4lambda$onCreate$1$comzenoappAccountsActivity(view);
                }
            });
        }
        renderAccounts();
        setupTabs();
        setupKeepScreenSwitch();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m3lambda$onCreate$0$comzenoappAccountsActivity(View view) {
        finish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m4lambda$onCreate$1$comzenoappAccountsActivity(View view) {
        this.accounts.saveFromSession(this.session);
        Intent intent = new Intent((Context) this, (Class<?>) LoginActivity.class);
        intent.putExtra(LoginActivity.EXTRA_ADD_ACCOUNT, true);
        startActivityForResult(intent, REQ_ADD_ACCOUNT);
    }

    private void setupTabs() {
        this.tabAccount = (TextView) findViewById(R.id.tabAccount);
        this.tabCustom = (TextView) findViewById(R.id.tabCustom);
        this.panelAccount = findViewById(R.id.panelAccount);
        this.panelCustom = findViewById(R.id.panelCustom);
        TextView textView = this.tabAccount;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m6lambda$setupTabs$2$comzenoappAccountsActivity(view);
                }
            });
        }
        TextView textView2 = this.tabCustom;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m7lambda$setupTabs$3$comzenoappAccountsActivity(view);
                }
            });
        }
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$setupTabs$2$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m6lambda$setupTabs$2$comzenoappAccountsActivity(View view) {
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$setupTabs$3$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m7lambda$setupTabs$3$comzenoappAccountsActivity(View view) {
        selectTab(1);
    }

    private void selectTab(int i) {
        boolean z = i == 0;
        View view = this.panelAccount;
        if (view != null) {
            view.setVisibility(z ? 0 : 8);
        }
        View view2 = this.panelCustom;
        if (view2 != null) {
            view2.setVisibility(z ? 8 : 0);
        }
        TextView textView = this.tabAccount;
        if (textView != null) {
            if (z) {
                textView.setBackgroundResource(R.drawable.bg_game_count_selected);
                this.tabAccount.setTextColor(-3632086);
                this.tabAccount.setTypeface(null, 1);
            } else {
                textView.setBackgroundResource(R.drawable.bg_game_count_normal);
                this.tabAccount.setTextColor(-7829368);
                this.tabAccount.setTypeface(null, 0);
            }
        }
        TextView textView2 = this.tabCustom;
        if (textView2 != null) {
            if (!z) {
                textView2.setBackgroundResource(R.drawable.bg_game_count_selected);
                this.tabCustom.setTextColor(-3632086);
                this.tabCustom.setTypeface(null, 1);
            } else {
                textView2.setBackgroundResource(R.drawable.bg_game_count_normal);
                this.tabCustom.setTextColor(-7829368);
                this.tabCustom.setTypeface(null, 0);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void setupKeepScreenSwitch() {
        SwitchCompat switchCompatFindViewById = findViewById(R.id.switchKeepScreenOn);
        this.switchKeepScreenOn = switchCompatFindViewById;
        if (switchCompatFindViewById == null) {
            return;
        }
        boolean zIsKeepScreenOnEnabled = BaseActivity.isKeepScreenOnEnabled(this);
        this.switchKeepScreenOn.setOnCheckedChangeListener((CompoundButton.OnCheckedChangeListener) null);
        this.switchKeepScreenOn.setChecked(zIsKeepScreenOnEnabled);
        this.switchKeepScreenOn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda5
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.m5lambda$setupKeepScreenSwitch$4$comzenoappAccountsActivity(compoundButton, z);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$setupKeepScreenSwitch$4$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m5lambda$setupKeepScreenSwitch$4$comzenoappAccountsActivity(CompoundButton compoundButton, boolean z) {
        BaseActivity.setKeepScreenOnEnabled(this, z);
        applyKeepScreenOnFlag();
        Toast.makeText((Context) this, (CharSequence) (z ? "Screen ဖွင့်ထားမည် ဖွင့်ပြီး" : "Screen ဖွင့်ထားမည် ပိတ်ပြီး"), 0).show();
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        super.onResume();
        this.accounts.saveFromSession(this.session);
        this.currentPhone = this.session.getPhone() != null ? this.session.getPhone() : "";
        String fullName = this.session.getFullName();
        this.session.getAvatarUrl();
        if ((fullName == null || fullName.isEmpty()) && this.session.isLoggedIn()) {
            enrichCurrentProfile();
        } else {
            renderAccounts();
        }
    }

    private void enrichCurrentProfile() {
        String accessToken = this.session.getAccessToken();
        if (accessToken == null || accessToken.isEmpty()) {
            renderAccounts();
        } else {
            ApiClient.getCustomer(accessToken, new AnonymousClass1());
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.AccountsActivity$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass1 implements Callback {
        AnonymousClass1() {
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-AccountsActivity$1, reason: not valid java name */
        /* synthetic */ void m8lambda$onFailure$0$comzenoappAccountsActivity$1() {
            AccountsActivity.this.renderAccounts();
        }

        public void onFailure(Call call, IOException iOException) {
            AccountsActivity.this.runOnUiThread(new Runnable() { // from class: com.zeno.app.AccountsActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m8lambda$onFailure$0$comzenoappAccountsActivity$1();
                }
            });
        }

        /* JADX WARN: Code restructure failed: missing block: B:16:0x0048, code lost:
        
            r6 = r2.optString("href", "");
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void onResponse(okhttp3.Call r6, okhttp3.Response r7) throws java.io.IOException {
            /*
                r5 = this;
                java.lang.String r6 = ""
                okhttp3.ResponseBody r0 = r7.body()
                if (r0 == 0) goto L11
                okhttp3.ResponseBody r7 = r7.body()
                java.lang.String r7 = r7.string()
                goto L14
            L11:
                java.lang.String r7 = "{}"
            L14:
                org.json.JSONObject r0 = new org.json.JSONObject     // Catch: java.lang.Exception -> L54
                r0.<init>(r7)     // Catch: java.lang.Exception -> L54
                java.lang.String r7 = "result"
                org.json.JSONObject r7 = r0.optJSONObject(r7)     // Catch: java.lang.Exception -> L54
                if (r7 == 0) goto L52
                java.lang.String r0 = "fullName"
                java.lang.String r0 = r7.optString(r0, r6)     // Catch: java.lang.Exception -> L54
                java.lang.String r1 = "externalRefs"
                org.json.JSONArray r7 = r7.optJSONArray(r1)     // Catch: java.lang.Exception -> L55
                if (r7 == 0) goto L55
                r1 = 0
            L30:
                int r2 = r7.length()     // Catch: java.lang.Exception -> L55
                if (r1 >= r2) goto L55
                org.json.JSONObject r2 = r7.getJSONObject(r1)     // Catch: java.lang.Exception -> L55
                java.lang.String r3 = "avatar_img"
                java.lang.String r4 = "type"
                java.lang.String r4 = r2.optString(r4)     // Catch: java.lang.Exception -> L55
                boolean r3 = r3.equals(r4)     // Catch: java.lang.Exception -> L55
                if (r3 == 0) goto L4f
                java.lang.String r7 = "href"
                java.lang.String r6 = r2.optString(r7, r6)     // Catch: java.lang.Exception -> L55
                goto L55
            L4f:
                int r1 = r1 + 1
                goto L30
            L52:
                r7 = r6
                goto L57
            L54:
                r0 = r6
            L55:
                r7 = r6
                r6 = r0
            L57:
                com.zeno.app.AccountsActivity r0 = com.zeno.app.AccountsActivity.this
                com.zeno.app.AccountsActivity$1$$ExternalSyntheticLambda1 r1 = new com.zeno.app.AccountsActivity$1$$ExternalSyntheticLambda1
                r1.<init>()
                r0.runOnUiThread(r1)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.AccountsActivity.AnonymousClass1.onResponse(okhttp3.Call, okhttp3.Response):void");
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-AccountsActivity$1, reason: not valid java name */
        /* synthetic */ void m9lambda$onResponse$1$comzenoappAccountsActivity$1(String str, String str2) {
            AccountsActivity.this.session.saveUserInfo(AccountsActivity.this.session.getPhone(), str, str2);
            AccountsActivity.this.accounts.saveFromSession(AccountsActivity.this.session);
            AccountsActivity accountsActivity = AccountsActivity.this;
            accountsActivity.currentPhone = accountsActivity.session.getPhone() != null ? AccountsActivity.this.session.getPhone() : "";
            AccountsActivity.this.renderAccounts();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == REQ_ADD_ACCOUNT && i2 == -1) {
            this.accounts.saveFromSession(this.session);
            this.currentPhone = this.session.getPhone() != null ? this.session.getPhone() : "";
            renderAccounts();
            Toast.makeText((Context) this, (CharSequence) "Account added", 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renderAccounts() {
        LinearLayout linearLayout = this.accountList;
        if (linearLayout == null) {
            return;
        }
        linearLayout.removeAllViews();
        List<AccountManager.Account> accounts = this.accounts.getAccounts();
        TextView textView = this.tvEmpty;
        if (textView != null) {
            textView.setVisibility(accounts.isEmpty() ? 0 : 8);
        }
        Iterator<AccountManager.Account> it = accounts.iterator();
        while (it.hasNext()) {
            this.accountList.addView(buildCard(it.next()));
        }
    }

    private int dp(int i) {
        return Math.round(TypedValue.applyDimension(1, i, getResources().getDisplayMetrics()));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildCard(final AccountManager.Account account) {
        int i;
        boolean z = account.phone != null && account.phone.equals(this.currentPhone);
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.bottomMargin = dp(10);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setPadding(dp(14), dp(12), dp(10), dp(12));
        if (z) {
            i = R.drawable.bg_account_card_current;
        } else {
            i = R.drawable.bg_account_card;
        }
        linearLayout.setBackgroundResource(i);
        linearLayout.setClickable(true);
        linearLayout.setFocusable(true);
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(48), dp(48));
        layoutParams2.rightMargin = dp(12);
        imageView.setLayoutParams(layoutParams2);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.circle_bg);
        imageView.setClipToOutline(true);
        imageView.setImageResource(R.drawable.ic_default_avatar);
        if (account.avatarUrl != null && !account.avatarUrl.isEmpty()) {
            try {
                Glide.with(this).load(account.avatarUrl).circleCrop().placeholder(R.drawable.ic_default_avatar).into(imageView);
            } catch (Exception unused) {
            }
        }
        linearLayout.addView(imageView);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.setOrientation(1);
        TextView textView = new TextView(this);
        textView.setText((account.fullName == null || account.fullName.isEmpty()) ? "User" : account.fullName);
        textView.setTextColor(-1);
        textView.setTextSize(2, 15.0f);
        textView.setTypeface(null, 1);
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(account.phone != null ? account.phone : "—");
        textView2.setTextColor(-6381922);
        textView2.setTextSize(2, 13.0f);
        textView2.setPadding(0, dp(3), 0, 0);
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2);
        ImageView imageView2 = new ImageView(this);
        imageView2.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        imageView2.setPadding(dp(8), dp(8), dp(8), dp(8));
        imageView2.setImageResource(R.drawable.ic_delete);
        imageView2.setColorFilter(-1739917);
        imageView2.setClickable(true);
        imageView2.setFocusable(true);
        imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m0lambda$buildCard$5$comzenoappAccountsActivity(account, view);
            }
        });
        linearLayout.addView(imageView2);
        linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m1lambda$buildCard$6$comzenoappAccountsActivity(account, view);
            }
        });
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildCard$5$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m0lambda$buildCard$5$comzenoappAccountsActivity(AccountManager.Account account, View view) {
        confirmDelete(account);
    }

    /* JADX INFO: renamed from: lambda$buildCard$6$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m1lambda$buildCard$6$comzenoappAccountsActivity(AccountManager.Account account, View view) {
        switchTo(account);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void switchTo(AccountManager.Account account) {
        if (account == null || account.phone == null) {
            return;
        }
        if (account.phone.equals(this.currentPhone)) {
            Toast.makeText((Context) this, (CharSequence) "Already current account", 0).show();
            return;
        }
        this.accounts.saveFromSession(this.session);
        this.accounts.applyToSession(this.session, account);
        this.currentPhone = account.phone;
        Toast.makeText((Context) this, (CharSequence) ("Switched to " + account.phone), 0).show();
        Intent intent = new Intent((Context) this, (Class<?>) DashboardActivity.class);
        intent.addFlags(335544320);
        startActivity(intent);
        finish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmDelete(final AccountManager.Account account) {
        if (account == null) {
            return;
        }
        final boolean z = account.phone != null && account.phone.equals(this.currentPhone);
        StringBuilder sb = new StringBuilder("Remove ");
        sb.append(account.phone != null ? account.phone : "this account");
        sb.append(" from this device?");
        ZDialog.confirm(this, "Delete Account", sb.toString(), "Delete", new Runnable() { // from class: com.zeno.app.AccountsActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m2lambda$confirmDelete$7$comzenoappAccountsActivity(account, z);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$confirmDelete$7$com-zeno-app-AccountsActivity, reason: not valid java name */
    /* synthetic */ void m2lambda$confirmDelete$7$comzenoappAccountsActivity(AccountManager.Account account, boolean z) {
        this.accounts.delete(account.phone);
        if (z) {
            List<AccountManager.Account> accounts = this.accounts.getAccounts();
            if (accounts.isEmpty()) {
                this.session.clear();
                startActivity(new Intent((Context) this, (Class<?>) LoginActivity.class));
                finish();
                return;
            } else {
                this.accounts.applyToSession(this.session, accounts.get(0));
                this.currentPhone = accounts.get(0).phone;
                Intent intent = new Intent((Context) this, (Class<?>) DashboardActivity.class);
                intent.addFlags(335544320);
                startActivity(intent);
                finish();
                return;
            }
        }
        renderAccounts();
    }
}
