package com.zeno.app;

import android.animation.ValueAnimator;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.snackbar.Snackbar;
import com.zeno.app.DataPackagesActivity;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class DataPackagesActivity extends BaseActivity {
    private View layoutContent;
    private View layoutLoading;
    private LinearLayout listContainer;
    private String phone;
    private SessionManager sessionManager;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final List<JSONObject> allPackages = new ArrayList();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(R.color.yellow_primary, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_data_packages);
        this.sessionManager = new SessionManager(this);
        String stringExtra = getIntent().getStringExtra("phone");
        this.phone = stringExtra;
        if (stringExtra == null) {
            this.phone = this.sessionManager.getPhone();
        }
        findViewById(R.id.toolbar).setTitle("Data Packages");
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{getResources().getColor(R.color.green_active, getTheme())});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.bg_card, getTheme()));
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.DataPackagesActivity$$ExternalSyntheticLambda1
            public final void onRefresh() {
                this.f$0.loadPackages();
            }
        });
        this.layoutLoading = findViewById(R.id.layout_loading);
        this.layoutContent = findViewById(R.id.layout_content);
        this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.DataPackagesActivity$$ExternalSyntheticLambda2
            public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                return this.f$0.m310lambda$onCreate$0$comzenoappDataPackagesActivity(swipeRefreshLayout, view);
            }
        });
        this.listContainer = (LinearLayout) findViewById(R.id.listContainer);
        loadPackages();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-DataPackagesActivity, reason: not valid java name */
    /* synthetic */ boolean m310lambda$onCreate$0$comzenoappDataPackagesActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        View view2 = this.layoutContent;
        View view3 = (view2 == null || view2.getVisibility() != 0) ? this.layoutLoading : this.layoutContent;
        return view3 != null && view3.canScrollVertically(-1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadPackages() {
        showSkeletonLoading();
        LinearLayout linearLayout = this.listContainer;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        ApiClient.getVasPackages(this.phone, this.sessionManager.getAccessToken(), this.sessionManager.getDeviceId(), new AnonymousClass1());
    }

    /* JADX INFO: renamed from: com.zeno.app.DataPackagesActivity$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass1 implements Callback {
        AnonymousClass1() {
        }

        public void onFailure(Call call, IOException iOException) {
            DataPackagesActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$1$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m311lambda$onFailure$0$comzenoappDataPackagesActivity$1();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DataPackagesActivity$1, reason: not valid java name */
        /* synthetic */ void m311lambda$onFailure$0$comzenoappDataPackagesActivity$1() {
            DataPackagesActivity.this.hideSkeletonLoading();
            DataPackagesActivity.this.listContainer.removeAllViews();
            DataPackagesActivity.this.addStatusRow("Network error. Pull down to retry.");
            DataPackagesActivity.this.swipeRefresh.setRefreshing(false);
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            if (strString.trim().startsWith("<")) {
                DataPackagesActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m312lambda$onResponse$1$comzenoappDataPackagesActivity$1();
                    }
                });
            } else {
                DataPackagesActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$1$$ExternalSyntheticLambda1
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m313lambda$onResponse$2$comzenoappDataPackagesActivity$1(strString);
                    }
                });
            }
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DataPackagesActivity$1, reason: not valid java name */
        /* synthetic */ void m312lambda$onResponse$1$comzenoappDataPackagesActivity$1() {
            DataPackagesActivity.this.hideSkeletonLoading();
            DataPackagesActivity.this.listContainer.removeAllViews();
            DataPackagesActivity.this.addStatusRow("Session expired. Pull down to retry.");
            DataPackagesActivity.this.swipeRefresh.setRefreshing(false);
        }

        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-DataPackagesActivity$1, reason: not valid java name */
        /* synthetic */ void m313lambda$onResponse$2$comzenoappDataPackagesActivity$1(String str) {
            JSONArray jSONArrayOptJSONArray;
            try {
                try {
                    jSONArrayOptJSONArray = new JSONObject(str).optJSONArray("result");
                    DataPackagesActivity.this.listContainer.removeAllViews();
                    DataPackagesActivity.this.allPackages.clear();
                } catch (Exception unused) {
                    DataPackagesActivity.this.hideSkeletonLoading();
                    DataPackagesActivity.this.listContainer.removeAllViews();
                    DataPackagesActivity.this.addStatusRow("Failed to load. Pull down to retry.");
                }
                if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                    for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                        DataPackagesActivity.this.allPackages.add(jSONArrayOptJSONArray.getJSONObject(i));
                    }
                    DataPackagesActivity.this.renderList();
                    DataPackagesActivity.this.hideSkeletonLoading();
                    return;
                }
                DataPackagesActivity.this.hideSkeletonLoading();
                DataPackagesActivity.this.addStatusRow("No packages available");
            } finally {
                DataPackagesActivity.this.swipeRefresh.setRefreshing(false);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void renderList() {
        this.listContainer.removeAllViews();
        int iDp = dp(10);
        LinearLayout linearLayout = null;
        for (int i = 0; i < this.allPackages.size(); i++) {
            int i2 = i % 2;
            if (i2 == 0) {
                linearLayout = new LinearLayout(this);
                linearLayout.setOrientation(0);
                linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
                this.listContainer.addView(linearLayout);
            }
            LinearLayout linearLayoutBuildCard = buildCard(this.allPackages.get(i));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, -2, 1.0f);
            if (i2 == 0) {
                layoutParams.setMargins(0, 0, iDp / 2, iDp);
            } else {
                layoutParams.setMargins(iDp / 2, 0, 0, iDp);
            }
            linearLayoutBuildCard.setLayoutParams(layoutParams);
            if (linearLayout != null) {
                linearLayout.addView(linearLayoutBuildCard);
            }
        }
        if (this.allPackages.size() % 2 != 1 || linearLayout == null) {
            return;
        }
        View view = new View(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, -1, 1.0f);
        layoutParams2.setMargins(iDp / 2, 0, 0, iDp);
        view.setLayoutParams(layoutParams2);
        linearLayout.addView(view);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private LinearLayout buildCard(JSONObject jSONObject) {
        String str;
        String str2;
        JSONObject jSONObjectOptJSONObject;
        String strOptString = "";
        final String strOptString2 = jSONObject.optString("id", "");
        String strOptString3 = jSONObject.optString("name", strOptString2);
        double dOptDouble = jSONObject.optDouble("price", 0.0d);
        final int iOptInt = jSONObject.optInt("validity", 0);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("vasDescriptions");
        if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() > 0 && (jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(0)) != null) {
            strOptString = jSONObjectOptJSONObject.optString("shortDesCription", "");
        }
        if (strOptString.isEmpty()) {
            strOptString = strOptString3;
        }
        if (iOptInt == 1) {
            str = "24 နာရီ";
        } else {
            str = iOptInt + " ရက်";
        }
        final int iconBg = getIconBg(strOptString2, strOptString3);
        final int iconRes = getIconRes(strOptString2, strOptString3);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(14), dp(14), dp(14), dp(14));
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(dp(16));
        gradientDrawable.setColor(-14803426);
        gradientDrawable.setStroke(dp(1), -13750738);
        linearLayout.setBackground(gradientDrawable);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(iconRes);
        imageView.setColorFilter(-1, PorterDuff.Mode.SRC_IN);
        imageView.setPadding(dp(8), dp(8), dp(8), dp(8));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(0);
        gradientDrawable2.setCornerRadius(dp(10));
        gradientDrawable2.setColor(iconBg);
        imageView.setBackground(gradientDrawable2);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(32), dp(32));
        layoutParams.setMarginEnd(dp(8));
        linearLayout2.addView(imageView, layoutParams);
        TextView textView = new TextView(this);
        textView.setText(strOptString2);
        textView.setTextColor(-6381922);
        textView.setTextSize(12.0f);
        textView.setMaxLines(1);
        textView.setEllipsize(TextUtils.TruncateAt.END);
        linearLayout2.addView(textView);
        linearLayout.addView(linearLayout2);
        TextView textView2 = new TextView(this);
        textView2.setText(strOptString3);
        textView2.setTextColor(-1);
        textView2.setTextSize(14.0f);
        textView2.setTypeface(null, 1);
        textView2.setMaxLines(1);
        textView2.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.topMargin = dp(10);
        textView2.setLayoutParams(layoutParams2);
        linearLayout.addView(textView2);
        TextView textView3 = new TextView(this);
        textView3.setText(strOptString);
        textView3.setTextColor(-6381922);
        textView3.setTextSize(12.0f);
        textView3.setMaxLines(2);
        textView3.setEllipsize(TextUtils.TruncateAt.END);
        textView3.setMinLines(2);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams3.topMargin = dp(2);
        textView3.setLayoutParams(layoutParams3);
        linearLayout.addView(textView3);
        TextView textView4 = new TextView(this);
        int i = (int) dOptDouble;
        if (i == ((int) Math.floor(dOptDouble))) {
            str2 = String.format("%,d Ks", Integer.valueOf(i));
        } else {
            str2 = dOptDouble + " Ks";
        }
        textView4.setText(str2);
        textView4.setTextColor(-1);
        textView4.setTextSize(18.0f);
        textView4.setTypeface(null, 1);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = dp(10);
        textView4.setLayoutParams(layoutParams4);
        linearLayout.addView(textView4);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams5.topMargin = dp(12);
        linearLayout3.setLayoutParams(layoutParams5);
        LinearLayout linearLayout4 = new LinearLayout(this);
        linearLayout4.setOrientation(0);
        linearLayout4.setGravity(16);
        linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        ImageView imageView2 = new ImageView(this);
        imageView2.setImageResource(R.drawable.ic_clock);
        imageView2.setColorFilter(-6381922, PorterDuff.Mode.SRC_IN);
        imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
        linearLayout4.addView(imageView2, new LinearLayout.LayoutParams(dp(13), dp(13)));
        TextView textView5 = new TextView(this);
        textView5.setText("  " + str);
        textView5.setTextColor(-6381922);
        textView5.setTextSize(11.0f);
        linearLayout4.addView(textView5);
        linearLayout3.addView(linearLayout4);
        final TextView textView6 = new TextView(this);
        textView6.setText("ဝယ်မည်");
        textView6.setTextColor(-15066598);
        textView6.setTextSize(12.0f);
        textView6.setTypeface(null, 1);
        textView6.setGravity(17);
        textView6.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable gradientDrawable3 = new GradientDrawable();
        gradientDrawable3.setShape(0);
        gradientDrawable3.setCornerRadius(dp(20));
        gradientDrawable3.setColor(-1518424);
        textView6.setBackground(gradientDrawable3);
        textView6.setClickable(true);
        textView6.setFocusable(true);
        final String str3 = strOptString.isEmpty() ? strOptString3 : strOptString;
        final String str4 = i + " Ks";
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.DataPackagesActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m309lambda$buildCard$1$comzenoappDataPackagesActivity(textView6, strOptString2, str3, str4, iOptInt, iconRes, iconBg, view);
            }
        });
        linearLayout3.addView(textView6);
        linearLayout.addView(linearLayout3);
        return linearLayout;
    }

    /* JADX INFO: renamed from: lambda$buildCard$1$com-zeno-app-DataPackagesActivity, reason: not valid java name */
    /* synthetic */ void m309lambda$buildCard$1$comzenoappDataPackagesActivity(TextView textView, String str, String str2, String str3, int i, int i2, int i3, View view) {
        showBuyConfirm(textView, str, str2, str3, i, i2, i3);
    }

    private void showBuyConfirm(TextView textView, String str, String str2, String str3, int i, int i2, int i3) {
        textView.setEnabled(false);
        textView.setText("...");
        ApiClient.getVasPackageDetail(str, this.phone, this.sessionManager.getAccessToken(), this.sessionManager.getDeviceId(), new AnonymousClass2(textView, str2, str3, i, i2, i3, str));
    }

    /* JADX INFO: renamed from: com.zeno.app.DataPackagesActivity$2, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass2 implements Callback {
        final /* synthetic */ TextView val$btn;
        final /* synthetic */ int val$iconBg;
        final /* synthetic */ int val$iconRes;
        final /* synthetic */ String val$name;
        final /* synthetic */ String val$packId;
        final /* synthetic */ String val$price;
        final /* synthetic */ int val$validity;

        AnonymousClass2(TextView textView, String str, String str2, int i, int i2, int i3, String str3) {
            this.val$btn = textView;
            this.val$name = str;
            this.val$price = str2;
            this.val$validity = i;
            this.val$iconRes = i2;
            this.val$iconBg = i3;
            this.val$packId = str3;
        }

        static /* synthetic */ void lambda$onFailure$0(TextView textView) {
            textView.setEnabled(true);
            textView.setText("ဝယ်မည်");
        }

        public void onFailure(Call call, IOException iOException) {
            Handler handler = DataPackagesActivity.this.uiHandler;
            final TextView textView = this.val$btn;
            handler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$2$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    DataPackagesActivity.AnonymousClass2.lambda$onFailure$0(textView);
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DataPackagesActivity.this.uiHandler;
            final TextView textView = this.val$btn;
            final String str = this.val$name;
            final String str2 = this.val$price;
            final int i = this.val$validity;
            final int i2 = this.val$iconRes;
            final int i3 = this.val$iconBg;
            final String str3 = this.val$packId;
            handler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m315lambda$onResponse$2$comzenoappDataPackagesActivity$2(textView, str, strString, str2, i, i2, i3, str3);
                }
            });
        }

        /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.zeno.app.DataPackagesActivity] */
        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-DataPackagesActivity$2, reason: not valid java name */
        /* synthetic */ void m315lambda$onResponse$2$comzenoappDataPackagesActivity$2(TextView textView, final String str, String str2, String str3, int i, int i2, int i3, final String str4) {
            String strOptString;
            JSONArray jSONArrayOptJSONArray;
            JSONObject jSONObjectOptJSONObject;
            textView.setEnabled(true);
            textView.setText("ဝယ်မည်");
            try {
                JSONObject jSONObjectOptJSONObject2 = new JSONObject(str2).optJSONObject("result");
                strOptString = (jSONObjectOptJSONObject2 == null || (jSONArrayOptJSONArray = jSONObjectOptJSONObject2.optJSONArray("vasDescriptions")) == null || jSONArrayOptJSONArray.length() <= 0 || (jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(0)) == null) ? str : jSONObjectOptJSONObject.optString("description", str);
            } catch (Exception unused) {
                strOptString = str;
            }
            ?? r1 = DataPackagesActivity.this;
            ZDialog.purchase(r1, str, strOptString, str3, i, i2, i3, ((DataPackagesActivity) r1).phone, new Runnable() { // from class: com.zeno.app.DataPackagesActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m314lambda$onResponse$1$comzenoappDataPackagesActivity$2(str4, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DataPackagesActivity$2, reason: not valid java name */
        /* synthetic */ void m314lambda$onResponse$1$comzenoappDataPackagesActivity$2(String str, String str2) {
            DataPackagesActivity.this.doBuyPackage(str, str2);
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.DataPackagesActivity$3, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass3 implements Callback {
        final /* synthetic */ String val$name;

        AnonymousClass3(String str) {
            this.val$name = str;
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-DataPackagesActivity$3, reason: not valid java name */
        /* synthetic */ void m316lambda$onFailure$0$comzenoappDataPackagesActivity$3(IOException iOException) {
            DataPackagesActivity.this.snack("Network error: " + iOException.getMessage());
        }

        public void onFailure(Call call, final IOException iOException) {
            DataPackagesActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m316lambda$onFailure$0$comzenoappDataPackagesActivity$3(iOException);
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = DataPackagesActivity.this.uiHandler;
            final String str = this.val$name;
            handler.post(new Runnable() { // from class: com.zeno.app.DataPackagesActivity$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m317lambda$onResponse$1$comzenoappDataPackagesActivity$3(strString, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-DataPackagesActivity$3, reason: not valid java name */
        /* synthetic */ void m317lambda$onResponse$1$comzenoappDataPackagesActivity$3(String str, String str2) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                int iOptInt = jSONObject.optInt("errorCode", -1);
                String strOptString = jSONObject.optString("message", "");
                if (iOptInt == 0) {
                    DataPackagesActivity.this.snack("✓ " + str2 + " ဝယ်ယူပြီးပြီ!");
                    return;
                }
                AppCompatActivity appCompatActivity = DataPackagesActivity.this;
                if (strOptString.isEmpty()) {
                    strOptString = "errorCode: " + iOptInt;
                }
                ZDialog.alert(appCompatActivity, "ဝယ်ယူမရပါ", strOptString);
            } catch (Exception e) {
                DataPackagesActivity.this.snack("Error: " + e.getMessage());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doBuyPackage(String str, String str2) {
        ApiClient.registerVasPackage(str, this.phone, this.sessionManager.getAccessToken(), new AnonymousClass3(str2));
    }

    private int getIconRes(String str, String str2) {
        String upperCase = str.toUpperCase();
        String lowerCase = str2.toLowerCase();
        if (upperCase.startsWith("TT") || lowerCase.contains("tiktok")) {
            return R.drawable.ic_music;
        }
        if (upperCase.startsWith("TG") || lowerCase.contains("telegram")) {
            return R.drawable.ic_send_plane;
        }
        if (upperCase.startsWith("GG") || lowerCase.contains("youtube")) {
            return R.drawable.ic_play;
        }
        if (upperCase.startsWith("HL") || upperCase.startsWith("OTT")) {
            return R.drawable.ic_phone;
        }
        if (upperCase.startsWith("SH") || upperCase.startsWith("S9")) {
            return R.drawable.ic_star;
        }
        return R.drawable.ic_bar_chart;
    }

    private int getIconBg(String str, String str2) {
        String upperCase = str.toUpperCase();
        String lowerCase = str2.toLowerCase();
        if (upperCase.startsWith("TT") || lowerCase.contains("tiktok")) {
            return -9633735;
        }
        if (upperCase.startsWith("TG") || lowerCase.contains("telegram")) {
            return -16044693;
        }
        if (upperCase.startsWith("GG") || lowerCase.contains("youtube")) {
            return -8781824;
        }
        if (upperCase.startsWith("HL")) {
            return -15909608;
        }
        if (upperCase.startsWith("OTT")) {
            return -13759908;
        }
        return upperCase.startsWith("S9") ? -11914752 : -14018048;
    }

    private int getCardBg(String str, String str2) {
        return (str.toUpperCase().startsWith("GG") || str2.toLowerCase().contains("youtube")) ? -13758456 : -14213096;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addStatusRow(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(-9079435);
        textView.setTextSize(14.0f);
        textView.setGravity(17);
        textView.setPadding(0, dp(64), 0, 0);
        this.listContainer.addView(textView);
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void snack(String str) {
        Snackbar snackbarMake = Snackbar.make(findViewById(android.R.id.content), str, 0);
        View view = snackbarMake.getView();
        ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
        view.setLayoutParams(view.getLayoutParams());
        snackbarMake.show();
    }

    private void showSkeletonLoading() {
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(0);
            View view2 = this.layoutContent;
            if (view2 != null) {
                view2.setVisibility(8);
            }
            this.skeletonAnim = SkeletonPulse.start(this.layoutLoading);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideSkeletonLoading() {
        SkeletonPulse.stop(this.skeletonAnim, this.layoutLoading);
        this.skeletonAnim = null;
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.layoutContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }
}
