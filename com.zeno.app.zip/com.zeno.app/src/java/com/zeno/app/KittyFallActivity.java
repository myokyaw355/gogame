package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Layout;
import android.text.SpannableString;
import android.text.TextPaint;
import android.text.style.ImageSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.zeno.app.KittyFallService;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class KittyFallActivity extends BaseActivity implements KittyFallService.BotCallback {
    private ValueAnimator actionsSkeletonAnim;
    private ValueAnimator avatarSkeletonAnim;
    private View btnKittyBuyTurn;
    private View btnKittyHistory;
    private View btnStart;
    private View btnStop;
    private View cardKittyActionsContent;
    private View cardKittyActionsSkeleton;
    private View cardKittyResources;
    private View cardKittyResourcesSkeleton;
    private View cardModePicker;
    private View cardModePickerContainer;
    private View cardPlaying;
    private boolean checkingSubscription;
    private View contentPlay;
    private View contentRank;
    private int currentLevel;
    private long currentLevelStartedAt;
    private boolean hasSubscription;
    private ImageView ivKittyProfileAvatar;
    private View kittyAvatarSkeleton;
    private KittyFallService.UserInfo latestUserInfo;
    private boolean leaderboardLoading;
    private View modeEasy;
    private View modeHard;
    private View modeMedium;
    private View modePickerSkeleton;
    private ValueAnimator modePickerSkeletonAnim;
    private ValueAnimator packageLoadingAnimator;
    private BottomSheetDialog packageLoadingSheet;
    private View packageLoadingSkeleton;
    private boolean pageSkeletonsStopped;
    private View pbKittyProfileLoading;
    private View playBtnSkeleton;
    private ValueAnimator playBtnSkeletonAnim;
    private View playButtonContainer;
    private ValueAnimator profileSkeletonAnim;
    private ProgressBar progressLevel;
    private LinearLayout rankList;
    private View rankLoading;
    private ValueAnimator rankSkeletonAnim;
    private View rankUserFooter;
    private LinearLayout rankUserRow;
    private ValueAnimator resourcesSkeletonAnim;
    private View rowKittyProfileReal;
    private KittyFallService service;
    private boolean serviceBound;
    private boolean startWhenConnected;
    private SwipeRefreshLayout swipeRefresh;
    private SwipeRefreshLayout swipeRefreshRank;
    private View tabPlay;
    private View tabPlayUnderline;
    private View tabRank;
    private View tabRankUnderline;
    private TextView tvCurrentLevel;
    private TextView tvKittyPlayTurns;
    private TextView tvKittyPoints;
    private TextView tvKittyProfileName;
    private TextView tvKittyProfilePhone;
    private TextView tvLevelCaption;
    private TextView tvLevelProgress;
    private TextView tvLoyaltyPoint;
    private TextView tvMobileData;
    private TextView tvNextRun;
    private TextView tvPlayingLevels;
    private TextView tvPlayingMode;
    private TextView tvScore;
    private TextView tvSelectedMode;
    private TextView tvStartedTime;
    private String selectedMode = "Hard";
    private final Handler clockHandler = new Handler(Looper.getMainLooper());
    private final Runnable clockRunnable = new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda14
        @Override // java.lang.Runnable
        public final void run() {
            this.f$0.renderPlayingClock();
        }
    };
    private final ServiceConnection connection = new ServiceConnection() { // from class: com.zeno.app.KittyFallActivity.1
        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            KittyFallActivity.this.service = ((KittyFallService.ServiceBinder) iBinder).getService();
            KittyFallActivity.this.serviceBound = true;
            KittyFallActivity.this.service.setCallback(KittyFallActivity.this);
            KittyFallActivity.this.syncFromService();
            KittyFallActivity.this.fetchLiveUserInfo();
            if (KittyFallActivity.this.startWhenConnected) {
                KittyFallActivity.this.startWhenConnected = false;
                KittyFallActivity.this.service.startBot(KittyFallActivity.this.selectedMode);
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName componentName) {
            KittyFallActivity.this.serviceBound = false;
            KittyFallActivity.this.service = null;
        }
    };

    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        setContentView(R.layout.activity_kitty_fall);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Kitty Fall");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        bindViews();
        loadLocalProfileFallback();
        setupModeSelection();
        renderModeSelection();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent((Context) this, (Class<?>) KittyFallService.class);
        startService(intent);
        bindService(intent, this.connection, 1);
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        super.onResume();
        if (!this.serviceBound || this.service == null) {
            return;
        }
        fetchLiveUserInfo();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onStop() {
        KittyFallService kittyFallService;
        super.onStop();
        stopClock();
        if (this.serviceBound && (kittyFallService = this.service) != null) {
            kittyFallService.clearCallback();
            unbindService(this.connection);
            this.serviceBound = false;
        }
        KittyFallService kittyFallService2 = this.service;
        if (kittyFallService2 == null || !kittyFallService2.isRunning()) {
            stopService(new Intent((Context) this, (Class<?>) KittyFallService.class));
        }
    }

    protected void onDestroy() {
        KittyFallService kittyFallService;
        stopClock();
        ValueAnimator valueAnimator = this.rankSkeletonAnim;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        dismissPackageLoadingSkeleton();
        super.onDestroy();
        if (!this.serviceBound || (kittyFallService = this.service) == null) {
            return;
        }
        kittyFallService.clearCallback();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onSupportNavigateUp() {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService != null && kittyFallService.isRunning()) {
            this.service.stopBot();
            stopService(new Intent((Context) this, (Class<?>) KittyFallService.class));
        }
        finish();
        return true;
    }

    private void bindViews() {
        this.ivKittyProfileAvatar = (ImageView) findViewById(R.id.ivKittyProfileAvatar);
        this.tvKittyProfileName = (TextView) findViewById(R.id.tvKittyProfileName);
        this.tvKittyProfilePhone = (TextView) findViewById(R.id.tvKittyProfilePhone);
        this.tvKittyPoints = (TextView) findViewById(R.id.tvKittyPoints);
        this.tvKittyPlayTurns = (TextView) findViewById(R.id.tvKittyPlayTurns);
        this.tvSelectedMode = (TextView) findViewById(R.id.tvSelectedMode);
        this.tvPlayingMode = (TextView) findViewById(R.id.tvPlayingMode);
        this.tvCurrentLevel = (TextView) findViewById(R.id.tvCurrentLevel);
        this.tvPlayingLevels = (TextView) findViewById(R.id.tvPlayingLevels);
        this.tvStartedTime = (TextView) findViewById(R.id.tvStartedTime);
        this.tvScore = (TextView) findViewById(R.id.tvScore);
        this.tvLoyaltyPoint = (TextView) findViewById(R.id.tvLoyaltyPoint);
        this.tvMobileData = (TextView) findViewById(R.id.tvMobileData);
        this.tvLevelCaption = (TextView) findViewById(R.id.tvLevelCaption);
        this.tvLevelProgress = (TextView) findViewById(R.id.tvLevelProgress);
        this.tvNextRun = (TextView) findViewById(R.id.tvNextRun);
        this.tabPlay = findViewById(R.id.tabPlay);
        this.tabRank = findViewById(R.id.tabRank);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabRankUnderline = findViewById(R.id.tabRankUnderline);
        this.contentPlay = findViewById(R.id.contentPlay);
        this.contentRank = findViewById(R.id.contentRank);
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        if (swipeRefreshLayoutFindViewById != null) {
            swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefresh.setProgressBackgroundColorSchemeColor(-14803426);
            this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda24
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return this.f$0.m468lambda$bindViews$0$comzenoappKittyFallActivity(swipeRefreshLayout, view);
                }
            });
            this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda1
                public final void onRefresh() {
                    this.f$0.refreshPage();
                }
            });
        }
        SwipeRefreshLayout swipeRefreshLayoutFindViewById2 = findViewById(R.id.swipeRefreshRank);
        this.swipeRefreshRank = swipeRefreshLayoutFindViewById2;
        if (swipeRefreshLayoutFindViewById2 != null) {
            swipeRefreshLayoutFindViewById2.setColorSchemeColors(new int[]{-3632086});
            this.swipeRefreshRank.setProgressBackgroundColorSchemeColor(-14803426);
            final View viewFindViewById = findViewById(R.id.rankScroll);
            this.swipeRefreshRank.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda2
                public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                    return KittyFallActivity.lambda$bindViews$1(viewFindViewById, swipeRefreshLayout, view);
                }
            });
            this.swipeRefreshRank.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda3
                public final void onRefresh() {
                    this.f$0.fetchLeaderboard();
                }
            });
        }
        this.rankList = (LinearLayout) findViewById(R.id.rankList);
        this.rankLoading = findViewById(R.id.rankLoading);
        this.rankUserFooter = findViewById(R.id.rankUserFooter);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        this.tabPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m469lambda$bindViews$2$comzenoappKittyFallActivity(view);
            }
        });
        this.tabRank.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m470lambda$bindViews$3$comzenoappKittyFallActivity(view);
            }
        });
        this.cardModePickerContainer = findViewById(R.id.cardModePickerContainer);
        this.cardModePicker = findViewById(R.id.cardModePicker);
        this.cardPlaying = findViewById(R.id.cardPlaying);
        this.playButtonContainer = findViewById(R.id.playButtonContainer);
        this.btnStart = findViewById(R.id.btnStart);
        this.btnStop = findViewById(R.id.btnStop);
        this.progressLevel = (ProgressBar) findViewById(R.id.progressLevel);
        this.modeEasy = findViewById(R.id.modeEasy);
        this.modeMedium = findViewById(R.id.modeMedium);
        this.modeHard = findViewById(R.id.modeHard);
        this.kittyAvatarSkeleton = findViewById(R.id.kittyAvatarSkeleton);
        this.pbKittyProfileLoading = findViewById(R.id.pbKittyProfileLoading);
        this.rowKittyProfileReal = findViewById(R.id.rowKittyProfileReal);
        this.cardKittyResourcesSkeleton = findViewById(R.id.cardKittyResourcesSkeleton);
        this.cardKittyResources = findViewById(R.id.cardKittyResources);
        this.cardKittyActionsSkeleton = findViewById(R.id.cardKittyActionsSkeleton);
        this.cardKittyActionsContent = findViewById(R.id.cardKittyActionsContent);
        this.btnKittyBuyTurn = findViewById(R.id.btnKittyBuyTurn);
        this.btnKittyHistory = findViewById(R.id.btnKittyHistory);
        this.modePickerSkeleton = findViewById(R.id.modePickerSkeleton);
        this.playBtnSkeleton = findViewById(R.id.playBtnSkeleton);
        startPageSkeletons();
        this.btnStart.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m471lambda$bindViews$4$comzenoappKittyFallActivity(view);
            }
        });
        this.btnStop.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m472lambda$bindViews$5$comzenoappKittyFallActivity(view);
            }
        });
        findViewById(R.id.ivPlayingBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m473lambda$bindViews$6$comzenoappKittyFallActivity(view);
            }
        });
        this.btnKittyBuyTurn.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m474lambda$bindViews$7$comzenoappKittyFallActivity(view);
            }
        });
        this.btnKittyHistory.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda25
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m475lambda$bindViews$8$comzenoappKittyFallActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$bindViews$0$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ boolean m468lambda$bindViews$0$comzenoappKittyFallActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        View view2 = this.contentPlay;
        return view2 != null && view2.canScrollVertically(-1);
    }

    static /* synthetic */ boolean lambda$bindViews$1(View view, SwipeRefreshLayout swipeRefreshLayout, View view2) {
        return view != null && view.canScrollVertically(-1);
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m469lambda$bindViews$2$comzenoappKittyFallActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m470lambda$bindViews$3$comzenoappKittyFallActivity(View view) {
        showRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m471lambda$bindViews$4$comzenoappKittyFallActivity(View view) {
        startBot();
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m472lambda$bindViews$5$comzenoappKittyFallActivity(View view) {
        stopBot();
    }

    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m473lambda$bindViews$6$comzenoappKittyFallActivity(View view) {
        stopBot();
    }

    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m474lambda$bindViews$7$comzenoappKittyFallActivity(View view) {
        checkSubscriptionThenShowPackages();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m475lambda$bindViews$8$comzenoappKittyFallActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) KittyFallHistoryActivity.class));
    }

    @Override // com.zeno.app.KittyFallService.BotCallback
    public void onResourcesChanged(final int i, final int i2) {
        runOnUiThread(new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda17
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m480lambda$onResourcesChanged$9$comzenoappKittyFallActivity(i, i2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onResourcesChanged$9$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m480lambda$onResourcesChanged$9$comzenoappKittyFallActivity(int i, int i2) {
        TextView textView = this.tvKittyPoints;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
        TextView textView2 = this.tvKittyPlayTurns;
        if (textView2 != null) {
            textView2.setText(String.valueOf(i2));
        }
    }

    @Override // com.zeno.app.KittyFallService.BotCallback
    public void onGameInfoChanged(final int i, final String str, final String str2) {
        runOnUiThread(new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m478lambda$onGameInfoChanged$10$comzenoappKittyFallActivity(i, str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onGameInfoChanged$10$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m478lambda$onGameInfoChanged$10$comzenoappKittyFallActivity(int i, String str, String str2) {
        TextView textView = this.tvScore;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
        TextView textView2 = this.tvLoyaltyPoint;
        if (textView2 != null) {
            if (str == null || str.trim().isEmpty()) {
                str = "0";
            }
            textView2.setText(str);
        }
        TextView textView3 = this.tvMobileData;
        if (textView3 != null) {
            if (str2 == null || str2.trim().isEmpty()) {
                str2 = "0";
            }
            textView3.setText(str2);
        }
    }

    private void startPageSkeletons() {
        this.avatarSkeletonAnim = SkeletonPulse.start(this.kittyAvatarSkeleton);
        this.profileSkeletonAnim = SkeletonPulse.start(this.pbKittyProfileLoading);
        this.resourcesSkeletonAnim = SkeletonPulse.start(this.cardKittyResourcesSkeleton);
        this.actionsSkeletonAnim = SkeletonPulse.start(this.cardKittyActionsSkeleton);
        this.modePickerSkeletonAnim = SkeletonPulse.start(this.modePickerSkeleton);
        this.playBtnSkeletonAnim = SkeletonPulse.start(this.playBtnSkeleton);
    }

    private void restartPageSkeletons() {
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.kittyAvatarSkeleton);
        SkeletonPulse.stop(this.profileSkeletonAnim, this.pbKittyProfileLoading);
        SkeletonPulse.stop(this.resourcesSkeletonAnim, this.cardKittyResourcesSkeleton);
        SkeletonPulse.stop(this.actionsSkeletonAnim, this.cardKittyActionsSkeleton);
        SkeletonPulse.stop(this.modePickerSkeletonAnim, this.modePickerSkeleton);
        SkeletonPulse.stop(this.playBtnSkeletonAnim, this.playBtnSkeleton);
        this.pageSkeletonsStopped = false;
        this.kittyAvatarSkeleton.setVisibility(0);
        this.pbKittyProfileLoading.setVisibility(0);
        this.rowKittyProfileReal.setVisibility(8);
        this.cardKittyResourcesSkeleton.setVisibility(0);
        this.cardKittyResources.setVisibility(8);
        this.cardKittyActionsSkeleton.setVisibility(0);
        this.cardKittyActionsContent.setVisibility(8);
        KittyFallService kittyFallService = this.service;
        if (kittyFallService != null && kittyFallService.isRunning()) {
            this.cardModePickerContainer.setVisibility(8);
            this.cardPlaying.setVisibility(0);
            this.playButtonContainer.setVisibility(8);
            this.modePickerSkeleton.setVisibility(8);
            this.playBtnSkeleton.setVisibility(8);
            this.btnStart.setVisibility(8);
            this.btnStop.setVisibility(0);
        } else {
            this.cardPlaying.setVisibility(8);
            this.cardModePickerContainer.setVisibility(0);
            this.playButtonContainer.setVisibility(0);
            this.cardModePicker.setVisibility(8);
            this.modePickerSkeleton.setVisibility(0);
            this.playBtnSkeleton.setVisibility(0);
            this.btnStart.setVisibility(8);
            this.btnStop.setVisibility(8);
        }
        startPageSkeletons();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void refreshPage() {
        if (this.service == null) {
            SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
            if (swipeRefreshLayout != null) {
                swipeRefreshLayout.setRefreshing(false);
            }
            showSnack("ခဏစောင့်ပေးပါ, ပြန်ကြိုးစားပါ");
            return;
        }
        restartPageSkeletons();
        fetchLiveUserInfo();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopPageSkeletons() {
        if (this.pageSkeletonsStopped) {
            return;
        }
        this.pageSkeletonsStopped = true;
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.kittyAvatarSkeleton);
        View view = this.kittyAvatarSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        SkeletonPulse.stop(this.profileSkeletonAnim, this.pbKittyProfileLoading);
        View view2 = this.pbKittyProfileLoading;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.rowKittyProfileReal;
        if (view3 != null) {
            view3.setVisibility(0);
        }
        SkeletonPulse.stop(this.resourcesSkeletonAnim, this.cardKittyResourcesSkeleton);
        View view4 = this.cardKittyResourcesSkeleton;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        View view5 = this.cardKittyResources;
        if (view5 != null) {
            view5.setVisibility(0);
        }
        SkeletonPulse.stop(this.actionsSkeletonAnim, this.cardKittyActionsSkeleton);
        View view6 = this.cardKittyActionsSkeleton;
        if (view6 != null) {
            view6.setVisibility(8);
        }
        View view7 = this.cardKittyActionsContent;
        if (view7 != null) {
            view7.setVisibility(0);
        }
        SkeletonPulse.stop(this.modePickerSkeletonAnim, this.modePickerSkeleton);
        View view8 = this.modePickerSkeleton;
        if (view8 != null) {
            view8.setVisibility(8);
        }
        View view9 = this.cardPlaying;
        if (view9 == null || view9.getVisibility() != 0) {
            View view10 = this.cardModePickerContainer;
            if (view10 != null) {
                view10.setVisibility(0);
            }
            View view11 = this.cardModePicker;
            if (view11 != null) {
                view11.setVisibility(0);
            }
        }
        SkeletonPulse.stop(this.playBtnSkeletonAnim, this.playBtnSkeleton);
        View view12 = this.playBtnSkeleton;
        if (view12 != null) {
            view12.setVisibility(8);
        }
        View view13 = this.cardPlaying;
        boolean z = view13 != null && view13.getVisibility() == 0;
        View view14 = this.playButtonContainer;
        if (view14 != null) {
            view14.setVisibility(z ? 8 : 0);
        }
        View view15 = this.btnStart;
        if (view15 != null && !z) {
            view15.setVisibility(0);
        }
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void loadLocalProfileFallback() {
        if (this.ivKittyProfileAvatar == null) {
            return;
        }
        SessionManager sessionManager = new SessionManager(this);
        String fullName = sessionManager.getFullName();
        String phone = sessionManager.getPhone();
        String avatarUrl = sessionManager.getAvatarUrl();
        TextView textView = this.tvKittyProfileName;
        if (fullName == null || fullName.trim().isEmpty()) {
            fullName = "---";
        }
        textView.setText(fullName);
        TextView textView2 = this.tvKittyProfilePhone;
        if (phone == null) {
            phone = "";
        }
        textView2.setText(phone);
        loadDashboardProfileAvatar(avatarUrl);
    }

    private void loadDashboardProfileAvatar(String str) {
        if (this.ivKittyProfileAvatar == null) {
            return;
        }
        if (ok(str)) {
            Glide.with(this).load(str).transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar).into(this.ivKittyProfileAvatar);
        } else {
            this.ivKittyProfileAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchLiveUserInfo() {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService == null) {
            stopPageSkeletons();
        } else {
            kittyFallService.fetchUserInfo(new KittyFallService.UserInfoCallback() { // from class: com.zeno.app.KittyFallActivity.2
                @Override // com.zeno.app.KittyFallService.UserInfoCallback
                public void onUserInfo(KittyFallService.UserInfo userInfo) {
                    KittyFallActivity.this.latestUserInfo = userInfo;
                    KittyFallActivity.this.hasSubscription = userInfo.hasSubscription;
                    if (KittyFallActivity.this.tvKittyProfileName != null && KittyFallActivity.ok(userInfo.fullName)) {
                        KittyFallActivity.this.tvKittyProfileName.setText(userInfo.fullName);
                    }
                    if (KittyFallActivity.this.tvKittyProfilePhone != null && KittyFallActivity.ok(userInfo.phone)) {
                        KittyFallActivity.this.tvKittyProfilePhone.setText(userInfo.phone);
                    }
                    if (KittyFallActivity.this.tvKittyPoints != null && KittyFallActivity.ok(userInfo.points)) {
                        KittyFallActivity.this.tvKittyPoints.setText(String.valueOf(KittyFallActivity.digitsOnly(userInfo.points)));
                    }
                    if (KittyFallActivity.this.tvKittyPlayTurns != null && KittyFallActivity.ok(userInfo.playTurns)) {
                        KittyFallActivity.this.tvKittyPlayTurns.setText(String.valueOf(KittyFallActivity.digitsOnly(userInfo.playTurns)));
                    }
                    KittyFallActivity.this.stopPageSkeletons();
                }

                @Override // com.zeno.app.KittyFallService.UserInfoCallback
                public void onUserInfoError(String str) {
                    KittyFallActivity.this.stopPageSkeletons();
                }
            });
        }
    }

    private void checkSubscriptionThenShowPackages() {
        if (this.service == null) {
            showSnack("ခဏစောင့်ပေးပါ၊ ပြန်ကြိုးစားပါ");
            return;
        }
        if (this.checkingSubscription) {
            return;
        }
        this.checkingSubscription = true;
        View view = this.btnKittyBuyTurn;
        if (view != null) {
            view.setEnabled(false);
        }
        showPackageLoadingSkeleton();
        this.service.fetchUserInfo(new KittyFallService.UserInfoCallback() { // from class: com.zeno.app.KittyFallActivity.3
            @Override // com.zeno.app.KittyFallService.UserInfoCallback
            public void onUserInfo(KittyFallService.UserInfo userInfo) {
                KittyFallActivity.this.checkingSubscription = false;
                KittyFallActivity.this.latestUserInfo = userInfo;
                KittyFallActivity.this.dismissPackageLoadingSkeleton();
                if (KittyFallActivity.this.btnKittyBuyTurn != null) {
                    KittyFallActivity.this.btnKittyBuyTurn.setEnabled(true);
                }
                KittyFallActivity.this.hasSubscription = userInfo.hasSubscription;
                if (KittyFallActivity.this.hasSubscription) {
                    KittyFallActivity.this.showBuyTurnSheet(userInfo.buyTurnPackages);
                } else {
                    KittyFallActivity.this.showDailySubscriptionSheet(userInfo.dailySubscriptionPackage);
                }
            }

            @Override // com.zeno.app.KittyFallService.UserInfoCallback
            public void onUserInfoError(String str) {
                KittyFallActivity.this.checkingSubscription = false;
                KittyFallActivity.this.dismissPackageLoadingSkeleton();
                if (KittyFallActivity.this.btnKittyBuyTurn != null) {
                    KittyFallActivity.this.btnKittyBuyTurn.setEnabled(true);
                }
                KittyFallActivity.this.showSnack("စာရင်းသွင်းမှုကို စစ်ဆေးမရပါ။ ထပ်မံကြိုးစားပါ။");
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showPackageLoadingSkeleton() {
        dismissPackageLoadingSkeleton();
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.MyBottomSheet);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_kitty_package_loading);
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setCanceledOnTouchOutside(false);
        configurePackageSheet(bottomSheetDialog);
        this.packageLoadingSheet = bottomSheetDialog;
        this.packageLoadingSkeleton = bottomSheetDialog.findViewById(R.id.kittyPackageLoadingRoot);
        View viewFindViewById = bottomSheetDialog.findViewById(R.id.kittyTurnPackageLoadingSkeleton);
        View viewFindViewById2 = bottomSheetDialog.findViewById(R.id.kittySubscriptionPackageLoadingSkeleton);
        if (this.hasSubscription) {
            if (viewFindViewById != null) {
                viewFindViewById.setVisibility(0);
            }
            if (viewFindViewById2 != null) {
                viewFindViewById2.setVisibility(8);
            }
        } else {
            if (viewFindViewById != null) {
                viewFindViewById.setVisibility(8);
            }
            if (viewFindViewById2 != null) {
                viewFindViewById2.setVisibility(0);
            }
        }
        updatePackageSkeletonTextWidths(bottomSheetDialog);
        this.packageLoadingAnimator = SkeletonPulse.start(this.packageLoadingSkeleton);
        bottomSheetDialog.show();
    }

    private void updatePackageSkeletonTextWidths(BottomSheetDialog bottomSheetDialog) {
        KittyFallService.UserInfo userInfo = this.latestUserInfo;
        if (userInfo == null) {
            return;
        }
        if (this.hasSubscription) {
            List<KittyFallService.BuyTurnPackage> list = userInfo.buyTurnPackages;
            if (list == null) {
                return;
            }
            View viewFindViewById = bottomSheetDialog.findViewById(R.id.kittyTurnPackageLoadingItem1);
            View viewFindViewById2 = bottomSheetDialog.findViewById(R.id.kittyTurnPackageLoadingItem2);
            if (!list.isEmpty()) {
                KittyFallService.BuyTurnPackage buyTurnPackage = list.get(0);
                setSkeletonTextWidth(viewFindViewById == null ? null : viewFindViewById.findViewById(R.id.kittyTurnLoadingTitleLine), buyTurnPackage.title, 14.0f, true, 150);
                setSkeletonTextWidth(viewFindViewById == null ? null : viewFindViewById.findViewById(R.id.kittyTurnLoadingPriceLine), buyTurnPackage.priceLabel, 12.0f, false, 120);
            }
            if (list.size() > 1) {
                KittyFallService.BuyTurnPackage buyTurnPackage2 = list.get(1);
                setSkeletonTextWidth(viewFindViewById2 == null ? null : viewFindViewById2.findViewById(R.id.kittyTurnLoadingTitleLine), buyTurnPackage2.title, 14.0f, true, 150);
                setSkeletonTextWidth(viewFindViewById2 != null ? viewFindViewById2.findViewById(R.id.kittyTurnLoadingPriceLine) : null, buyTurnPackage2.priceLabel, 12.0f, false, 120);
                return;
            }
            return;
        }
        KittyFallService.DailySubscriptionPackage dailySubscriptionPackage = userInfo.dailySubscriptionPackage;
        if (dailySubscriptionPackage == null) {
            return;
        }
        setSkeletonTextWidth(bottomSheetDialog.findViewById(R.id.kittyDailyLoadingTitleLine), dailySubscriptionPackage.title, 14.0f, true, 150);
        setSkeletonTextWidth(bottomSheetDialog.findViewById(R.id.kittyDailyLoadingBenefitLine), dailySubscriptionPackage.benefitText, 12.0f, false, 150);
        setSkeletonTextWidth(bottomSheetDialog.findViewById(R.id.kittyDailyLoadingPriceLine), dailySubscriptionPackage.priceLabel, 12.0f, false, 120);
        setSkeletonTextWidth(bottomSheetDialog.findViewById(R.id.kittyDailyLoadingRenewalLine), dailySubscriptionPackage.renewalNote, 12.0f, false, 280);
    }

    private void setSkeletonTextWidth(View view, String str, float f, boolean z, int i) {
        if (view == null || !ok(str)) {
            return;
        }
        TextPaint textPaint = new TextPaint(1);
        textPaint.setTextSize(TypedValue.applyDimension(2, f, getResources().getDisplayMetrics()));
        textPaint.setTypeface(Typeface.create("sans-serif", z ? 1 : 0));
        int iMax = Math.max(dpToPx(24), Math.min(dpToPx(i), Math.round(Layout.getDesiredWidth(str, textPaint))));
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams != null) {
            layoutParams.width = iMax;
            view.setLayoutParams(layoutParams);
        }
    }

    private int dpToPx(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissPackageLoadingSkeleton() {
        BottomSheetDialog bottomSheetDialog = this.packageLoadingSheet;
        View view = this.packageLoadingSkeleton;
        ValueAnimator valueAnimator = this.packageLoadingAnimator;
        this.packageLoadingSheet = null;
        this.packageLoadingSkeleton = null;
        this.packageLoadingAnimator = null;
        SkeletonPulse.stop(valueAnimator, view);
        if (bottomSheetDialog == null || !bottomSheetDialog.isShowing()) {
            return;
        }
        bottomSheetDialog.dismiss();
    }

    private void configurePackageSheet(final BottomSheetDialog bottomSheetDialog) {
        bottomSheetDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda18
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                KittyFallActivity.lambda$configurePackageSheet$11(bottomSheetDialog, dialogInterface);
            }
        });
    }

    static /* synthetic */ void lambda$configurePackageSheet$11(BottomSheetDialog bottomSheetDialog, DialogInterface dialogInterface) {
        Window window = bottomSheetDialog.getWindow();
        if (window != null) {
            window.setDimAmount(0.55f);
            window.setNavigationBarColor(-14803426);
        }
        FrameLayout frameLayout = (FrameLayout) bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (frameLayout != null) {
            frameLayout.setBackground(null);
            frameLayout.setBackgroundColor(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showDailySubscriptionSheet(final KittyFallService.DailySubscriptionPackage dailySubscriptionPackage) {
        if (dailySubscriptionPackage == null) {
            showSnack("စာရင်းသွင်းမှုအထုပ် အချက်အလက်ကို ရယူမရပါ။");
            return;
        }
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.MyBottomSheet);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_kitty_subscription);
        bottomSheetDialog.setCancelable(true);
        configurePackageSheet(bottomSheetDialog);
        final View viewFindViewById = bottomSheetDialog.findViewById(R.id.btnKittyDailySubscription);
        TextView textView = (TextView) bottomSheetDialog.findViewById(R.id.tvKittyDailyPackageTitle);
        TextView textView2 = (TextView) bottomSheetDialog.findViewById(R.id.tvKittyDailyPackageBenefits);
        TextView textView3 = (TextView) bottomSheetDialog.findViewById(R.id.tvKittyDailyPackagePrice);
        TextView textView4 = (TextView) bottomSheetDialog.findViewById(R.id.tvKittyDailyPackageRenewal);
        final TextView textView5 = (TextView) bottomSheetDialog.findViewById(R.id.tvKittyDailySubscriptionState);
        View viewFindViewById2 = bottomSheetDialog.findViewById(R.id.btnKittySubscriptionCancel);
        if (textView != null) {
            textView.setText(dailySubscriptionPackage.title);
        }
        if (textView2 != null) {
            textView2.setText(dailySubscriptionPackage.benefitText);
        }
        if (textView3 != null) {
            textView3.setText(dailySubscriptionPackage.priceLabel);
        }
        if (textView4 != null) {
            if (ok(dailySubscriptionPackage.renewalNote)) {
                textView4.setText(dailySubscriptionPackage.renewalNote);
            } else {
                textView4.setVisibility(8);
            }
        }
        if (viewFindViewById != null) {
            viewFindViewById.setContentDescription(dailySubscriptionPackage.title + ", " + dailySubscriptionPackage.turnCount + ", " + dailySubscriptionPackage.priceLabel);
        }
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda22
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m486lambda$showDailySubscriptionSheet$12$comzenoappKittyFallActivity(bottomSheetDialog, dailySubscriptionPackage, viewFindViewById, textView5, view);
                }
            });
        }
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda23
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    bottomSheetDialog.dismiss();
                }
            });
        }
        bottomSheetDialog.show();
    }

    /* JADX INFO: renamed from: lambda$showDailySubscriptionSheet$12$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m486lambda$showDailySubscriptionSheet$12$comzenoappKittyFallActivity(BottomSheetDialog bottomSheetDialog, KittyFallService.DailySubscriptionPackage dailySubscriptionPackage, View view, TextView textView, View view2) {
        confirmDailySubscription(bottomSheetDialog, dailySubscriptionPackage, view, textView);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmDailySubscription(final BottomSheetDialog bottomSheetDialog, final KittyFallService.DailySubscriptionPackage dailySubscriptionPackage, final View view, final TextView textView) {
        String str = dailySubscriptionPackage.priceLabel + " — " + dailySubscriptionPackage.benefitText;
        if (ok(dailySubscriptionPackage.renewalNote)) {
            str = str + " " + dailySubscriptionPackage.renewalNote;
        }
        ZDialog.confirm(this, dailySubscriptionPackage.title, str, "စာရင်းသွင်းမည်", new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m477lambda$confirmDailySubscription$14$comzenoappKittyFallActivity(view, textView, dailySubscriptionPackage, bottomSheetDialog);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$confirmDailySubscription$14$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m477lambda$confirmDailySubscription$14$comzenoappKittyFallActivity(final View view, final TextView textView, KittyFallService.DailySubscriptionPackage dailySubscriptionPackage, final BottomSheetDialog bottomSheetDialog) {
        if (this.service == null) {
            showSnack("ခဏစောင့်ပေးပါ၊ ပြန်ကြိုးစားပါ");
            return;
        }
        if (view != null) {
            view.setEnabled(false);
        }
        if (textView != null) {
            textView.setText("...");
        }
        this.service.registerDailySubscription(dailySubscriptionPackage.productCode, new KittyFallService.SubscriptionCallback() { // from class: com.zeno.app.KittyFallActivity.4
            @Override // com.zeno.app.KittyFallService.SubscriptionCallback
            public void onSubscriptionSuccess(String str, int i, int i2) {
                if (bottomSheetDialog.isShowing()) {
                    bottomSheetDialog.dismiss();
                }
                if (KittyFallActivity.this.tvKittyPlayTurns != null && i >= 0) {
                    KittyFallActivity.this.tvKittyPlayTurns.setText(String.valueOf(i));
                }
                if (KittyFallActivity.this.tvKittyPoints != null && i2 >= 0) {
                    KittyFallActivity.this.tvKittyPoints.setText(String.valueOf(i2));
                }
                KittyFallActivity.this.verifySubscriptionAfterRegistration();
            }

            @Override // com.zeno.app.KittyFallService.SubscriptionCallback
            public void onSubscriptionError(String str) {
                View view2 = view;
                if (view2 != null) {
                    view2.setEnabled(true);
                }
                TextView textView2 = textView;
                if (textView2 != null) {
                    textView2.setText("စာရင်းသွင်းမည်");
                }
                AppCompatActivity appCompatActivity = KittyFallActivity.this;
                if (!KittyFallActivity.ok(str)) {
                    str = "စာရင်းသွင်းမှု မအောင်မြင်ပါ";
                }
                ZDialog.alert(appCompatActivity, "မအောင်မြင်ပါ", str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void verifySubscriptionAfterRegistration() {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService == null) {
            showSnack("စာရင်းသွင်းမှုကို အတည်ပြုမရပါ။ နောက်မှ ပြန်စစ်ဆေးပါ။");
        } else {
            kittyFallService.fetchUserInfo(new KittyFallService.UserInfoCallback() { // from class: com.zeno.app.KittyFallActivity.5
                @Override // com.zeno.app.KittyFallService.UserInfoCallback
                public void onUserInfo(KittyFallService.UserInfo userInfo) {
                    KittyFallActivity.this.latestUserInfo = userInfo;
                    KittyFallActivity.this.hasSubscription = userInfo.hasSubscription;
                    if (KittyFallActivity.this.tvKittyPoints != null && KittyFallActivity.ok(userInfo.points)) {
                        KittyFallActivity.this.tvKittyPoints.setText(String.valueOf(KittyFallActivity.digitsOnly(userInfo.points)));
                    }
                    if (KittyFallActivity.this.tvKittyPlayTurns != null && KittyFallActivity.ok(userInfo.playTurns)) {
                        KittyFallActivity.this.tvKittyPlayTurns.setText(String.valueOf(KittyFallActivity.digitsOnly(userInfo.playTurns)));
                    }
                    if (KittyFallActivity.this.hasSubscription) {
                        KittyFallActivity.this.showBuyTurnSheet(userInfo.buyTurnPackages);
                    } else {
                        KittyFallActivity.this.showSnack("စာရင်းသွင်းမှု အတည်မပြုရသေးပါ။ ခဏစောင့်ပြီး ပြန်စစ်ဆေးပါ။");
                    }
                }

                @Override // com.zeno.app.KittyFallService.UserInfoCallback
                public void onUserInfoError(String str) {
                    KittyFallActivity.this.showSnack("စာရင်းသွင်းမှုကို အတည်ပြုမရပါ။ ခဏစောင့်ပြီး ပြန်စစ်ဆေးပါ။");
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showBuyTurnSheet(List<KittyFallService.BuyTurnPackage> list) {
        if (this.service == null) {
            showSnack("ခဏစောင့်ပေးပါ, ပြန်ကြိုးစားပါ");
            return;
        }
        if (!this.hasSubscription) {
            showDailySubscriptionSheet(null);
            return;
        }
        if (list == null || list.isEmpty()) {
            showSnack("ကစားကြိမ် အထုပ်အချက်အလက်ကို ရယူမရပါ။");
            return;
        }
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this, R.style.MyBottomSheet);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_kitty_buy_turn);
        bottomSheetDialog.setCancelable(true);
        configurePackageSheet(bottomSheetDialog);
        LinearLayout linearLayout = (LinearLayout) bottomSheetDialog.findViewById(R.id.kittyBuyTurnPackageList);
        View viewFindViewById = bottomSheetDialog.findViewById(R.id.btnKittyBuyCancel);
        if (linearLayout == null) {
            showSnack("ကစားကြိမ် အထုပ်စာရင်းကို ဖတ်မရပါ။");
            return;
        }
        for (final KittyFallService.BuyTurnPackage buyTurnPackage : list) {
            final View viewInflate = getLayoutInflater().inflate(R.layout.item_kitty_buy_turn_package, (ViewGroup) linearLayout, false);
            TextView textView = (TextView) viewInflate.findViewById(R.id.tvKittyBuyTurnPackageName);
            TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvKittyBuyTurnPackagePrice);
            final TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvKittyBuyTurnPackageState);
            if (textView != null) {
                textView.setText(buyTurnPackage.title);
            }
            if (textView2 != null) {
                textView2.setText(buyTurnPackage.priceLabel);
            }
            viewInflate.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda19
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m485lambda$showBuyTurnSheet$15$comzenoappKittyFallActivity(bottomSheetDialog, buyTurnPackage, viewInflate, textView3, view);
                }
            });
            linearLayout.addView(viewInflate);
        }
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda20
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    bottomSheetDialog.dismiss();
                }
            });
        }
        bottomSheetDialog.show();
    }

    /* JADX INFO: renamed from: lambda$showBuyTurnSheet$15$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m485lambda$showBuyTurnSheet$15$comzenoappKittyFallActivity(BottomSheetDialog bottomSheetDialog, KittyFallService.BuyTurnPackage buyTurnPackage, View view, TextView textView, View view2) {
        confirmBuyTurn(bottomSheetDialog, buyTurnPackage, view, textView);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void confirmBuyTurn(final BottomSheetDialog bottomSheetDialog, final KittyFallService.BuyTurnPackage buyTurnPackage, final View view, final TextView textView) {
        ZDialog.confirm(this, "ဝယ်ယူမည်", buyTurnPackage.title + " ကို " + buyTurnPackage.priceLabel + " ဖြင့် ဝယ်ယူမည်လား?", "ဝယ်ယူမည်", new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda21
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m476lambda$confirmBuyTurn$17$comzenoappKittyFallActivity(bottomSheetDialog, buyTurnPackage, view, textView);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: doBuyTurn, reason: merged with bridge method [inline-methods] */
    public void m476lambda$confirmBuyTurn$17$comzenoappKittyFallActivity(final BottomSheetDialog bottomSheetDialog, final KittyFallService.BuyTurnPackage buyTurnPackage, final View view, final TextView textView) {
        if (this.service == null) {
            showSnack("ခဏစောင့်ပေးပါ, ပြန်ကြိုးစားပါ");
            return;
        }
        if (view != null) {
            view.setEnabled(false);
        }
        if (textView != null) {
            textView.setText("...");
        }
        this.service.buyTurn(buyTurnPackage.productCode, new KittyFallService.BuyTurnCallback() { // from class: com.zeno.app.KittyFallActivity.6
            @Override // com.zeno.app.KittyFallService.BuyTurnCallback
            public void onBuySuccess(String str, int i, int i2) {
                if (bottomSheetDialog.isShowing()) {
                    bottomSheetDialog.dismiss();
                }
                if (KittyFallActivity.this.tvKittyPlayTurns != null && i >= 0) {
                    KittyFallActivity.this.tvKittyPlayTurns.setText(String.valueOf(i));
                }
                if (KittyFallActivity.this.tvKittyPoints != null && i2 >= 0) {
                    KittyFallActivity.this.tvKittyPoints.setText(String.valueOf(i2));
                }
                AppCompatActivity appCompatActivity = KittyFallActivity.this;
                if (!KittyFallActivity.ok(str)) {
                    str = buyTurnPackage.title + " ဝယ်ယူပြီးပါပြီ";
                }
                ZDialog.alert(appCompatActivity, "အောင်မြင်ပါသည်", str);
            }

            @Override // com.zeno.app.KittyFallService.BuyTurnCallback
            public void onBuyError(String str) {
                View view2 = view;
                if (view2 != null) {
                    view2.setEnabled(true);
                }
                TextView textView2 = textView;
                if (textView2 != null) {
                    textView2.setText("ဝယ်ယူမည်");
                }
                AppCompatActivity appCompatActivity = KittyFallActivity.this;
                if (!KittyFallActivity.ok(str)) {
                    str = "ဝယ်ယူမှု မအောင်မြင်ပါ";
                }
                ZDialog.alert(appCompatActivity, "မအောင်မြင်ပါ", str);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean ok(String str) {
        return (str == null || str.trim().isEmpty()) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int digitsOnly(String str) {
        try {
            return Integer.parseInt(str.replaceAll("[^0-9]", ""));
        } catch (Exception unused) {
            return 0;
        }
    }

    private void setupModeSelection() {
        this.modeEasy.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda10
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m482lambda$setupModeSelection$18$comzenoappKittyFallActivity(view);
            }
        });
        this.modeMedium.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m483lambda$setupModeSelection$19$comzenoappKittyFallActivity(view);
            }
        });
        this.modeHard.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda13
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m484lambda$setupModeSelection$20$comzenoappKittyFallActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$setupModeSelection$18$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m482lambda$setupModeSelection$18$comzenoappKittyFallActivity(View view) {
        selectMode("Easy");
    }

    /* JADX INFO: renamed from: lambda$setupModeSelection$19$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m483lambda$setupModeSelection$19$comzenoappKittyFallActivity(View view) {
        selectMode("Medium");
    }

    /* JADX INFO: renamed from: lambda$setupModeSelection$20$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m484lambda$setupModeSelection$20$comzenoappKittyFallActivity(View view) {
        selectMode("Hard");
    }

    private void selectMode(String str) {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService == null || !kittyFallService.isRunning()) {
            this.selectedMode = str;
            renderModeSelection();
        }
    }

    private void renderModeSelection() {
        this.tvSelectedMode.setText(this.selectedMode + " mode selected");
        styleMode(this.modeEasy, "Easy".equals(this.selectedMode));
        styleMode(this.modeMedium, "Medium".equals(this.selectedMode));
        styleMode(this.modeHard, "Hard".equals(this.selectedMode));
    }

    private void styleMode(View view, boolean z) {
        int i;
        int i2;
        if (z) {
            i = R.drawable.bg_kitty_mode_selected;
        } else {
            i = R.drawable.bg_kitty_mode_normal;
        }
        view.setBackgroundResource(i);
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            Resources resources = getResources();
            if (z) {
                i2 = R.color.yellow_primary;
            } else {
                i2 = R.color.text_grey;
            }
            textView.setTextColor(resources.getColor(i2));
            textView.setTypeface(null, z ? 1 : 0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startBot() {
        KittyFallService kittyFallService;
        if (this.serviceBound && (kittyFallService = this.service) != null) {
            kittyFallService.startBot(this.selectedMode);
            return;
        }
        this.startWhenConnected = true;
        Intent intent = new Intent((Context) this, (Class<?>) KittyFallService.class);
        startService(intent);
        bindService(intent, this.connection, 1);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void stopBot() {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService != null) {
            kittyFallService.stopBot();
        }
        stopService(new Intent((Context) this, (Class<?>) KittyFallService.class));
        renderIdle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void syncFromService() {
        KittyFallService kittyFallService = this.service;
        if (kittyFallService == null) {
            return;
        }
        if (kittyFallService.isRunning()) {
            onResourcesChanged(this.service.getPoints(), this.service.getPlayTurns());
            onGameInfoChanged(this.service.getScore(), this.service.getLoyaltyPoint(), this.service.getMobileData());
            onStateChanged(true, this.service.getMode(), this.service.getCurrentLevel(), this.service.getMaxLevel(), this.service.getStartedAt(), this.service.getLevelStartedAt(), this.service.getLastSuccessAt());
            return;
        }
        renderIdle();
    }

    @Override // com.zeno.app.KittyFallService.BotCallback
    public void onStateChanged(final boolean z, final String str, final int i, int i2, final long j, final long j2, final long j3) {
        runOnUiThread(new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m481lambda$onStateChanged$21$comzenoappKittyFallActivity(z, str, i, j2, j, j3);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onStateChanged$21$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m481lambda$onStateChanged$21$comzenoappKittyFallActivity(boolean z, String str, int i, long j, long j2, long j3) {
        if (!z) {
            stopClock();
            renderIdle();
            return;
        }
        this.selectedMode = str;
        this.cardModePicker.setVisibility(8);
        View view = this.cardModePickerContainer;
        if (view != null) {
            view.setVisibility(8);
        }
        this.cardPlaying.setVisibility(0);
        View view2 = this.playButtonContainer;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        this.btnStart.setVisibility(8);
        this.btnStop.setVisibility(0);
        this.tvPlayingMode.setText(str);
        int iMax = Math.max(1, i);
        this.currentLevel = iMax;
        if (j <= 0) {
            j = j2;
        }
        this.currentLevelStartedAt = j;
        this.tvPlayingLevels.setText(String.valueOf(iMax));
        this.tvStartedTime.setText(formatDateTime(j2));
        renderPlayingClock();
        startClock();
        this.tvLevelCaption.setText(j3 > 0 ? "Auto play is running" : "စတင်နေသည်…");
    }

    @Override // com.zeno.app.KittyFallService.BotCallback
    public void onMessage(final String str) {
        runOnUiThread(new Runnable() { // from class: com.zeno.app.KittyFallActivity$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m479lambda$onMessage$22$comzenoappKittyFallActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onMessage$22$com-zeno-app-KittyFallActivity, reason: not valid java name */
    /* synthetic */ void m479lambda$onMessage$22$comzenoappKittyFallActivity(String str) {
        if (str == null) {
            return;
        }
        this.tvLevelCaption.setText(str);
        if (str.contains("ရပ်သွား")) {
            showSnack(str);
        }
    }

    private void renderIdle() {
        if (this.cardModePicker == null) {
            return;
        }
        this.cardPlaying.setVisibility(8);
        stopClock();
        this.btnStop.setVisibility(8);
        if (this.pageSkeletonsStopped) {
            this.cardModePickerContainer.setVisibility(0);
            this.cardModePicker.setVisibility(0);
            View view = this.playButtonContainer;
            if (view != null) {
                view.setVisibility(0);
            }
            this.btnStart.setVisibility(0);
        }
        renderModeSelection();
    }

    private void startClock() {
        this.clockHandler.removeCallbacks(this.clockRunnable);
        this.clockHandler.post(this.clockRunnable);
    }

    private void stopClock() {
        this.clockHandler.removeCallbacks(this.clockRunnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renderPlayingClock() {
        View view = this.cardPlaying;
        if (view == null || view.getVisibility() != 0) {
            return;
        }
        KittyFallService kittyFallService = this.service;
        long levelDelayMs = kittyFallService != null ? kittyFallService.getLevelDelayMs() : 0L;
        long jMin = levelDelayMs > 0 ? Math.min(this.currentLevelStartedAt > 0 ? Math.max(0L, System.currentTimeMillis() - this.currentLevelStartedAt) : 0L, levelDelayMs) : 0L;
        int iMin = levelDelayMs > 0 ? (int) Math.min(100L, (jMin * 100) / levelDelayMs) : 0;
        long jMax = levelDelayMs > 0 ? Math.max(0L, levelDelayMs - jMin) : 0L;
        this.tvCurrentLevel.setText(formatDuration(jMin));
        this.progressLevel.setMax(100);
        this.progressLevel.setProgress(iMin);
        this.tvLevelProgress.setText(formatDurationShort(jMin) + " / " + formatDurationShort(levelDelayMs));
        this.tvNextRun.setText(iMin + "% • " + formatDurationShort(jMax) + " left");
        this.clockHandler.postDelayed(this.clockRunnable, 1000L);
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void setTabStyle(boolean z) {
        this.tabPlayUnderline.setBackgroundColor(z ? -3632086 : 0);
        this.tabRankUnderline.setBackgroundColor(z ? 0 : -3632086);
        TextView textView = (TextView) findViewById(R.id.tvTabPlay);
        TextView textView2 = (TextView) findViewById(R.id.tvTabRank);
        textView.setTextColor(z ? -3632086 : -7829368);
        textView2.setTextColor(z ? -7829368 : -3632086);
        textView.setTypeface(null, z ? 1 : 0);
        textView2.setTypeface(null, !z ? 1 : 0);
        ((ImageView) findViewById(R.id.ivTabPlay)).setColorFilter(z ? -3632086 : -7829368);
        ((ImageView) findViewById(R.id.ivTabRank)).setColorFilter(z ? -7829368 : -3632086);
    }

    private void showPlayTab() {
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefreshRank;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setVisibility(8);
        }
        this.swipeRefresh.setVisibility(0);
        this.contentPlay.setVisibility(0);
        this.contentRank.setVisibility(8);
        setTabStyle(true);
    }

    private void showRankTab() {
        this.swipeRefresh.setVisibility(8);
        this.contentPlay.setVisibility(8);
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefreshRank;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setVisibility(0);
        }
        this.contentRank.setVisibility(0);
        setTabStyle(false);
        if (this.rankList.getChildCount() != 0 || this.leaderboardLoading) {
            return;
        }
        fetchLeaderboard();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopRankSkeleton() {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.rankLoading);
        this.rankSkeletonAnim = null;
        this.leaderboardLoading = false;
        this.rankLoading.setVisibility(8);
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefreshRank;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fetchLeaderboard() {
        if (this.service == null) {
            SwipeRefreshLayout swipeRefreshLayout = this.swipeRefreshRank;
            if (swipeRefreshLayout != null) {
                swipeRefreshLayout.setRefreshing(false);
            }
            showSnack("Leaderboard ဖွင့်၍ မရပါ");
            return;
        }
        if (this.leaderboardLoading) {
            return;
        }
        this.leaderboardLoading = true;
        this.rankList.removeAllViews();
        this.rankUserFooter.setVisibility(8);
        this.rankLoading.setVisibility(0);
        this.rankSkeletonAnim = SkeletonPulse.start(this.rankLoading);
        this.service.fetchLeaderboard(new KittyFallService.LeaderboardCallback() { // from class: com.zeno.app.KittyFallActivity.7
            @Override // com.zeno.app.KittyFallService.LeaderboardCallback
            public void onLeaderboard(KittyFallService.LeaderboardResult leaderboardResult) {
                KittyFallActivity.this.stopRankSkeleton();
                KittyFallActivity.this.renderLeaderboard(leaderboardResult);
            }

            @Override // com.zeno.app.KittyFallService.LeaderboardCallback
            public void onLeaderboardError(String str) {
                KittyFallActivity.this.stopRankSkeleton();
                KittyFallActivity kittyFallActivity = KittyFallActivity.this;
                if (!KittyFallActivity.ok(str)) {
                    str = "Leaderboard ဖွင့်၍ မရပါ";
                }
                kittyFallActivity.showSnack(str);
            }
        });
    }

    private CharSequence scoreSpan(String str) {
        try {
            Drawable drawable = getResources().getDrawable(R.drawable.kitty_coin, getTheme());
            int iDp = dp(14);
            drawable.setBounds(0, 0, iDp, iDp);
            SpannableString spannableString = new SpannableString("  " + str);
            spannableString.setSpan(new ImageSpan(drawable, 2), 0, 1, 33);
            return spannableString;
        } catch (Exception unused) {
            return str;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private ImageView defaultAvatar() {
        ImageView imageView = new ImageView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(36), dp(36));
        layoutParams.setMarginEnd(dp(10));
        imageView.setLayoutParams(layoutParams);
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView.setClipToOutline(true);
        imageView.setImageResource(R.drawable.ic_rank_default_avatar);
        return imageView;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void renderLeaderboard(KittyFallService.LeaderboardResult leaderboardResult) {
        int i;
        this.rankList.removeAllViews();
        for (KittyFallService.RankEntry rankEntry : leaderboardResult.entries) {
            int i2 = rankEntry.order;
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(0);
            linearLayout.setGravity(16);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(0, 0, 0, dp(6));
            linearLayout.setLayoutParams(layoutParams);
            linearLayout.setPadding(dp(8), dp(10), dp(8), dp(10));
            linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
            if (i2 <= 3) {
                ImageView imageView = new ImageView(this);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(40), dp(40));
                layoutParams2.setMarginEnd(dp(8));
                imageView.setLayoutParams(layoutParams2);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                if (i2 == 1) {
                    i = R.drawable.ic_medal_gold;
                } else {
                    i = i2 == 2 ? R.drawable.ic_medal_silver : R.drawable.ic_medal_bronze;
                }
                imageView.setImageResource(i);
                linearLayout.addView(imageView);
            } else {
                TextView textView = new TextView(this);
                LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(40), -2);
                layoutParams3.setMarginEnd(dp(8));
                textView.setLayoutParams(layoutParams3);
                textView.setText(String.valueOf(i2));
                textView.setTextColor(-7829368);
                textView.setTextSize(2, 13.0f);
                textView.setGravity(17);
                linearLayout.addView(textView);
            }
            linearLayout.addView(defaultAvatar());
            TextView textView2 = new TextView(this);
            textView2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
            textView2.setText(rankEntry.phone);
            textView2.setTextColor(i2 <= 3 ? -1 : -3355444);
            textView2.setTextSize(2, i2 <= 3 ? 14.0f : 13.0f);
            if (i2 <= 3) {
                textView2.setTypeface(null, 1);
            }
            linearLayout.addView(textView2);
            TextView textView3 = new TextView(this);
            textView3.setText(scoreSpan(rankEntry.score));
            textView3.setTextColor(i2 <= 3 ? -10752 : -5592406);
            textView3.setTextSize(2, 12.0f);
            if (i2 <= 3) {
                textView3.setTypeface(null, 1);
            }
            textView3.setGravity(8388613);
            linearLayout.addView(textView3);
            this.rankList.addView(linearLayout);
        }
        KittyFallService.RankEntry rankEntry2 = leaderboardResult.me;
        if (rankEntry2 == null) {
            this.rankUserFooter.setVisibility(8);
            return;
        }
        this.rankUserRow.removeAllViews();
        TextView textView4 = new TextView(this);
        textView4.setText("ကိုယ်တိုင်");
        textView4.setTextColor(-7829368);
        textView4.setTextSize(2, 11.0f);
        textView4.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.rankUserRow.addView(textView4);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView textView5 = new TextView(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(40), -2);
        layoutParams4.setMarginEnd(dp(8));
        textView5.setLayoutParams(layoutParams4);
        textView5.setText("#" + rankEntry2.order);
        textView5.setTextColor(-3632086);
        textView5.setTextSize(2, 13.0f);
        textView5.setTypeface(null, 1);
        textView5.setGravity(17);
        linearLayout2.addView(textView5);
        linearLayout2.addView(defaultAvatar());
        TextView textView6 = new TextView(this);
        textView6.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        textView6.setText(rankEntry2.phone);
        textView6.setTextColor(-1);
        textView6.setTextSize(2, 13.0f);
        textView6.setTypeface(null, 1);
        linearLayout2.addView(textView6);
        TextView textView7 = new TextView(this);
        textView7.setText(scoreSpan(rankEntry2.score));
        textView7.setTextColor(-10752);
        textView7.setTextSize(2, 12.0f);
        textView7.setTypeface(null, 1);
        textView7.setGravity(8388613);
        linearLayout2.addView(textView7);
        this.rankUserRow.addView(linearLayout2);
        this.rankUserFooter.setVisibility(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showSnack(String str) {
        ZSnack.make(findViewById(android.R.id.content), str, 0).show();
    }

    private static String formatTime(long j) {
        if (j <= 0) {
            return "--";
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Rangoon"));
        return simpleDateFormat.format(new Date(j));
    }

    private static String formatDateTime(long j) {
        if (j <= 0) {
            return "--";
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Rangoon"));
        return simpleDateFormat.format(new Date(j));
    }

    private static String formatDuration(long j) {
        long jMax = Math.max(0L, j / 1000);
        return String.format(Locale.ENGLISH, "%02d:%02d", Long.valueOf(jMax / 60), Long.valueOf(jMax % 60));
    }

    private static String formatDurationShort(long j) {
        long jMax = Math.max(0L, j / 1000);
        if (jMax < 60) {
            return jMax + "s";
        }
        return (jMax / 60) + "m " + (jMax % 60) + "s";
    }
}
