package com.zeno.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class ZenoMyIDFirebaseMessagingService extends FirebaseMessagingService {
    public static final String CHANNEL_ID = "zenomyid_default";
    public static final String KEY_FCM_TOKEN = "fcm_token";
    public static final String PREFS_NAME = "fcm_prefs";

    public void onNewToken(String str) {
        super.onNewToken(str);
        getSharedPreferences(PREFS_NAME, 0).edit().putString(KEY_FCM_TOKEN, str).apply();
    }

    public void onMessageReceived(RemoteMessage remoteMessage) throws Throwable {
        String string;
        String title;
        String body;
        String str;
        super.onMessageReceived(remoteMessage);
        RemoteMessage.Notification notification = remoteMessage.getNotification();
        Bitmap bitmapDownloadImage = null;
        if (notification != null) {
            title = notification.getTitle();
            body = notification.getBody();
            Uri imageUrl = notification.getImageUrl();
            string = imageUrl != null ? imageUrl.toString() : null;
        } else {
            string = null;
            title = null;
            body = null;
        }
        Map data = remoteMessage.getData();
        if (data == null || data.isEmpty()) {
            str = null;
        } else {
            if (title == null) {
                title = (String) data.get("title");
            }
            if (body == null) {
                body = (String) data.get("body");
            }
            str = (String) data.get("link");
            if (str == null) {
                str = (String) data.get("click_action");
            }
            if (string == null) {
                string = (String) data.get("image");
            }
            if (string == null) {
                string = (String) data.get("image_url");
            }
        }
        if (title == null && body == null) {
            return;
        }
        if (string != null && !string.trim().isEmpty()) {
            bitmapDownloadImage = downloadImage(string.trim());
        }
        if (title == null) {
            title = "ZenoMyID";
        }
        if (body == null) {
            body = "";
        }
        showNotification(title, body, str, bitmapDownloadImage);
    }

    private Bitmap downloadImage(String str) throws Throwable {
        Throwable th;
        HttpURLConnection httpURLConnection;
        try {
            httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            try {
                httpURLConnection.setConnectTimeout(8000);
                httpURLConnection.setReadTimeout(10000);
                httpURLConnection.setInstanceFollowRedirects(true);
                if (httpURLConnection.getResponseCode() != 200) {
                    if (httpURLConnection != null) {
                        httpURLConnection.disconnect();
                    }
                    return null;
                }
                InputStream inputStream = httpURLConnection.getInputStream();
                Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return bitmapDecodeStream;
            } catch (Exception unused) {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                return null;
            } catch (Throwable th2) {
                th = th2;
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
                throw th;
            }
        } catch (Exception unused2) {
            httpURLConnection = null;
        } catch (Throwable th3) {
            th = th3;
            httpURLConnection = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showNotification(String str, String str2, String str3, Bitmap bitmap) {
        ensureChannel();
        Intent intent = new Intent((Context) this, (Class<?>) SplashActivity.class);
        intent.setFlags(335544320);
        if (str3 != null && !str3.trim().isEmpty()) {
            intent.putExtra("notif_link", str3.trim());
        }
        NotificationCompat.Builder contentIntent = new NotificationCompat.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_stat_notify).setColor(-11751600).setContentTitle(str).setContentText(str2).setAutoCancel(true).setPriority(1).setContentIntent(PendingIntent.getActivity(this, (int) System.currentTimeMillis(), intent, Build.VERSION.SDK_INT >= 23 ? 201326592 : 134217728));
        if (bitmap != null) {
            contentIntent.setLargeIcon(bitmap).setStyle(new NotificationCompat.BigPictureStyle().bigPicture(bitmap).bigLargeIcon((Bitmap) null).setSummaryText(str2));
        } else {
            contentIntent.setStyle(new NotificationCompat.BigTextStyle().bigText(str2));
        }
        try {
            NotificationManagerCompat.from(this).notify((int) System.currentTimeMillis(), contentIntent.build());
        } catch (SecurityException unused) {
        }
    }

    private void ensureChannel() {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= 26 && (notificationManager = (NotificationManager) getSystemService("notification")) != null && notificationManager.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel notificationChannelM = SplashActivity$$ExternalSyntheticApiModelOutline0.m(CHANNEL_ID, "ZenoMyID Notifications", 4);
            notificationChannelM.setDescription("ZenoMyID app ကနေ ပို့တဲ့ notification များ");
            notificationManager.createNotificationChannel(notificationChannelM);
        }
    }
}
