package com.zeno.app;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatImageView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class AspectRatioImageView extends AppCompatImageView {
    private float ratio;

    public AspectRatioImageView(Context context) {
        super(context);
        this.ratio = 2.1745563f;
    }

    public AspectRatioImageView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.ratio = 2.1745563f;
    }

    public void setRatio(float f) {
        this.ratio = f;
        requestLayout();
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int measuredWidth = getMeasuredWidth();
        setMeasuredDimension(measuredWidth, Math.round(measuredWidth / this.ratio));
    }
}
