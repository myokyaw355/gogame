package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class KongIslandExchangeActivity extends BaseActivity {
    private static final String BASE = "https://kong.mascom.vn";
    private ExecutorService exec;
    private LinearLayout llItems;
    private LinearLayout llLoading;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svItems;
    private TextView tvBananaBalance;
    private TextView tvEmpty;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_kong_island_exchange);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m555lambda$onCreate$0$comzenoappKongIslandExchangeActivity(view);
            }
        });
        this.tvBananaBalance = (TextView) findViewById(R.id.tvBananaBalance);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svItems = findViewById(R.id.svItems);
        this.llItems = (LinearLayout) findViewById(R.id.llItems);
        loadAll();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m555lambda$onCreate$0$comzenoappKongIslandExchangeActivity(View view) {
        finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void loadAll() {
        showLoading();
        final String kongToken = this.session.getKongToken();
        if (!ok(kongToken)) {
            showEmpty("Kong Runner ကို အရင်ဖွင့်ပြီး login ဝင်ပါ။");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m552lambda$loadAll$4$comzenoappKongIslandExchangeActivity(kongToken);
                }
            });
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda19
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m554lambda$loadAll$6$comzenoappKongIslandExchangeActivity(kongToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$4$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m552lambda$loadAll$4$comzenoappKongIslandExchangeActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/user/info").get().addHeader("Accept", "*/*").addHeader("Authorization", "Bearer " + str).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                if (jSONObject.optBoolean("success", false)) {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("gameData") : null;
                    final long jOptLong = jSONObjectOptJSONObject2 != null ? jSONObjectOptJSONObject2.optLong("totalBanana", 0L) : 0L;
                    this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda2
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m549lambda$loadAll$1$comzenoappKongIslandExchangeActivity(jOptLong);
                        }
                    });
                } else {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda3
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m550lambda$loadAll$2$comzenoappKongIslandExchangeActivity();
                        }
                    });
                }
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception unused) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m551lambda$loadAll$3$comzenoappKongIslandExchangeActivity();
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAll$1$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m549lambda$loadAll$1$comzenoappKongIslandExchangeActivity(long j) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.tvBananaBalance.setText(String.format("%,d", Long.valueOf(j)));
    }

    /* JADX INFO: renamed from: lambda$loadAll$2$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m550lambda$loadAll$2$comzenoappKongIslandExchangeActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.tvBananaBalance.setText("---");
    }

    /* JADX INFO: renamed from: lambda$loadAll$3$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m551lambda$loadAll$3$comzenoappKongIslandExchangeActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.tvBananaBalance.setText("---");
    }

    /* JADX INFO: renamed from: lambda$loadAll$6$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m554lambda$loadAll$6$comzenoappKongIslandExchangeActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/shop/item").get().addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda11
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m553lambda$loadAll$5$comzenoappKongIslandExchangeActivity(strString);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code());
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parseItems, reason: merged with bridge method [inline-methods] */
    public void m553lambda$loadAll$5$comzenoappKongIslandExchangeActivity(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Item list ယူ၍ မရပါ။"));
                return;
            }
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("data");
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
                this.skeletonAnim = null;
                LinearLayout linearLayout = this.llLoading;
                if (linearLayout != null) {
                    linearLayout.setVisibility(8);
                }
                this.llItems.removeAllViews();
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject != null) {
                        addItemRow(jSONObjectOptJSONObject);
                    }
                }
                this.svItems.setVisibility(0);
                return;
            }
            showEmpty("Item မရှိသေးပါ။");
        } catch (Exception e) {
            showEmpty("Parse error: " + e.getMessage());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addItemRow(JSONObject jSONObject) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_kong_exchange, (ViewGroup) this.llItems, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivItemIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvItemName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvItemDesc);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvItemPrice);
        final EditText editText = (EditText) viewInflate.findViewById(R.id.etQty);
        final TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvTotalCost);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.btnMinus);
        TextView textView6 = (TextView) viewInflate.findViewById(R.id.btnPlus);
        final Button button = (Button) viewInflate.findViewById(R.id.btnExchange);
        final int iOptInt = jSONObject.optInt("id", -1);
        final String strOptString = jSONObject.optString("name", "Item");
        String strOptString2 = jSONObject.optString("typeItem", "");
        final long jOptLong = jSONObject.optLong("price", 0L);
        String strOptString3 = jSONObject.optString("description", "");
        textView.setText(strOptString);
        textView2.setText(strOptString3);
        textView3.setText(String.format("%,d", Long.valueOf(jOptLong)));
        imageView.setImageResource(iconFor(strOptString2));
        imageView.setImageTintList(null);
        imageView.clearColorFilter();
        final int[] iArr = {1};
        editText.setText("1");
        textView4.setText(String.format("%,d", Long.valueOf(jOptLong)));
        final Runnable runnable = new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                textView4.setText(String.format("%,d", Long.valueOf(jOptLong * ((long) Math.max(1, iArr[0])))));
            }
        };
        editText.addTextChangedListener(new TextWatcher() { // from class: com.zeno.app.KongIslandExchangeActivity.1
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                String strTrim = editable.toString().trim();
                if (strTrim.isEmpty()) {
                    iArr[0] = 1;
                    runnable.run();
                    return;
                }
                try {
                    int i = Integer.parseInt(strTrim);
                    if (i < 1) {
                        i = 1;
                    }
                    if (i > 9999) {
                        i = 9999;
                    }
                    iArr[0] = i;
                    if (i != Integer.parseInt(strTrim)) {
                        editText.removeTextChangedListener(this);
                        editText.setText(String.valueOf(i));
                        EditText editText2 = editText;
                        editText2.setSelection(editText2.getText().length());
                        editText.addTextChangedListener(this);
                    }
                } catch (NumberFormatException unused) {
                    iArr[0] = 1;
                }
                runnable.run();
            }
        });
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda13
            @Override // android.widget.TextView.OnEditorActionListener
            public final boolean onEditorAction(TextView textView7, int i, KeyEvent keyEvent) {
                return this.f$0.m545lambda$addItemRow$8$comzenoappKongIslandExchangeActivity(editText, iArr, textView7, i, keyEvent);
            }
        });
        editText.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda14
            @Override // android.view.View.OnFocusChangeListener
            public final void onFocusChange(View view, boolean z) {
                KongIslandExchangeActivity.lambda$addItemRow$9(editText, iArr, runnable, view, z);
            }
        });
        textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda15
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                KongIslandExchangeActivity.lambda$addItemRow$10(iArr, editText, view);
            }
        });
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                KongIslandExchangeActivity.lambda$addItemRow$11(iArr, editText, view);
            }
        });
        button.setBackgroundTintList(null);
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda17
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m544lambda$addItemRow$12$comzenoappKongIslandExchangeActivity(editText, iArr, iOptInt, strOptString, jOptLong, button, view);
            }
        });
        this.llItems.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addItemRow$8$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ boolean m545lambda$addItemRow$8$comzenoappKongIslandExchangeActivity(EditText editText, int[] iArr, TextView textView, int i, KeyEvent keyEvent) {
        if (i != 6) {
            return false;
        }
        if (editText.getText().toString().trim().isEmpty() || iArr[0] < 1) {
            iArr[0] = 1;
            editText.setText("1");
        }
        editText.clearFocus();
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService("input_method");
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
        return true;
    }

    static /* synthetic */ void lambda$addItemRow$9(EditText editText, int[] iArr, Runnable runnable, View view, boolean z) {
        if (!z) {
            if (editText.getText().toString().trim().isEmpty() || iArr[0] < 1) {
                iArr[0] = 1;
                editText.setText("1");
                runnable.run();
                return;
            }
            return;
        }
        editText.selectAll();
    }

    static /* synthetic */ void lambda$addItemRow$10(int[] iArr, EditText editText, View view) {
        int i = iArr[0];
        if (i > 1) {
            int i2 = i - 1;
            iArr[0] = i2;
            editText.setText(String.valueOf(i2));
            editText.setSelection(editText.getText().length());
        }
    }

    static /* synthetic */ void lambda$addItemRow$11(int[] iArr, EditText editText, View view) {
        int i = iArr[0];
        if (i < 9999) {
            int i2 = i + 1;
            iArr[0] = i2;
            editText.setText(String.valueOf(i2));
            editText.setSelection(editText.getText().length());
        }
    }

    /* JADX INFO: renamed from: lambda$addItemRow$12$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m544lambda$addItemRow$12$comzenoappKongIslandExchangeActivity(EditText editText, int[] iArr, int i, String str, long j, Button button, View view) {
        String strTrim = editText.getText().toString().trim();
        int i2 = !strTrim.isEmpty() ? Integer.parseInt(strTrim) : 1;
        int i3 = i2 >= 1 ? i2 : 1;
        if (i3 > 9999) {
            i3 = 9999;
        }
        iArr[0] = i3;
        editText.setText(String.valueOf(i3));
        doExchange(i, str, iArr[0], j, button);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void doExchange(final int i, final String str, final int i2, final long j, final Button button) {
        if (i < 0) {
            return;
        }
        final String kongToken = this.session.getKongToken();
        if (!ok(kongToken)) {
            Toast.makeText((Context) this, (CharSequence) "Kong Runner ကို အရင်ဖွင့်ပြီး login ဝင်ပါ။", 0).show();
            return;
        }
        button.setEnabled(false);
        button.setText("...");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() throws Throwable {
                this.f$0.m548lambda$doExchange$15$comzenoappKongIslandExchangeActivity(i, i2, kongToken, j, str, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doExchange$15$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m548lambda$doExchange$15$comzenoappKongIslandExchangeActivity(int i, int i2, String str, long j, String str2, final Button button) throws Throwable {
        final String strOptString;
        Response responseExecute;
        final boolean z = false;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("id", i);
            jSONObject.put("value", i2);
            responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/shop/item").post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str).addHeader("Origin", BASE).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
        } catch (Exception e) {
            strOptString = "Network error: " + e.getMessage();
        }
        try {
            JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
            if (jSONObject2.optBoolean("success", false)) {
                try {
                    strOptString = str2 + " × " + i2 + " ရပါပြီ! 🎉 (🍌 " + String.format("%,d", Long.valueOf(j * ((long) i2))) + " သုံးသည်)";
                    z = true;
                } catch (Throwable th) {
                    th = th;
                    z = true;
                    if (responseExecute != null) {
                        try {
                            responseExecute.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } else {
                strOptString = jSONObject2.optString("message", "လဲလှည်၍ မရပါ။");
            }
            if (responseExecute != null) {
                responseExecute.close();
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m547lambda$doExchange$14$comzenoappKongIslandExchangeActivity(strOptString, z, button);
                }
            });
        } catch (Throwable th3) {
            th = th3;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$doExchange$14$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m547lambda$doExchange$14$comzenoappKongIslandExchangeActivity(String str, boolean z, final Button button) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        if (z) {
            button.setText("ရပြီ ✓");
            refreshBalance();
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m546lambda$doExchange$13$comzenoappKongIslandExchangeActivity(button);
                }
            }, 1200L);
        } else {
            button.setEnabled(true);
            button.setText("လဲမည်");
        }
    }

    /* JADX INFO: renamed from: lambda$doExchange$13$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m546lambda$doExchange$13$comzenoappKongIslandExchangeActivity(Button button) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        button.setEnabled(true);
        button.setText("လဲမည်");
    }

    private void refreshBalance() {
        final String kongToken = this.session.getKongToken();
        if (ok(kongToken)) {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m557lambda$refreshBalance$17$comzenoappKongIslandExchangeActivity(kongToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$refreshBalance$17$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m557lambda$refreshBalance$17$comzenoappKongIslandExchangeActivity(String str) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://kong.mascom.vn/api/user/info").get().addHeader("Accept", "*/*").addHeader("Authorization", "Bearer " + str).addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                final int iOptInt = 0;
                final long jOptLong = 0;
                if (jSONObject.optBoolean("success", false)) {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                    JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("gameData") : null;
                    if (jSONObjectOptJSONObject2 != null) {
                        jOptLong = jSONObjectOptJSONObject2.optLong("totalBanana", 0L);
                        iOptInt = jSONObjectOptJSONObject2.optInt("total2xBanana", 0);
                    }
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m556lambda$refreshBalance$16$comzenoappKongIslandExchangeActivity(jOptLong, iOptInt);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: renamed from: lambda$refreshBalance$16$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m556lambda$refreshBalance$16$comzenoappKongIslandExchangeActivity(long j, int i) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.tvBananaBalance.setText(String.format("%,d", Long.valueOf(j)));
        KongIslandService kongIslandService = KongIslandService.instance;
        if (kongIslandService != null) {
            kongIslandService.setTotal2xBanana(i);
        }
    }

    private int iconFor(String str) {
        String upperCase = str.toUpperCase();
        upperCase.hashCode();
        switch (upperCase) {
            case "MAGNET":
                return R.drawable.ic_magnet;
            case "REBORN":
                return R.drawable.ic_reborn;
            case "PROTECT":
                return R.drawable.ic_protect;
            case "BANANA":
                return R.drawable.ic_banana;
            case "X2BANANA":
                return R.drawable.ic_x2banana;
            default:
                return R.drawable.ic_gift;
        }
    }

    private void showLoading() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m559lambda$showLoading$18$comzenoappKongIslandExchangeActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showLoading$18$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m559lambda$showLoading$18$comzenoappKongIslandExchangeActivity() {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.llLoading.setVisibility(0);
        this.tvEmpty.setVisibility(8);
        this.svItems.setVisibility(8);
        this.llItems.removeAllViews();
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KongIslandExchangeActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m558lambda$showEmpty$19$comzenoappKongIslandExchangeActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$19$com-zeno-app-KongIslandExchangeActivity, reason: not valid java name */
    /* synthetic */ void m558lambda$showEmpty$19$comzenoappKongIslandExchangeActivity(String str) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svItems.setVisibility(8);
        this.tvEmpty.setText(str);
        this.tvEmpty.setVisibility(0);
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
