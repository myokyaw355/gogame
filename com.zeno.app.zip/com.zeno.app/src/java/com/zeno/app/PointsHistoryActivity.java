package com.zeno.app;

import android.animation.ValueAnimator;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class PointsHistoryActivity extends BaseActivity {
    private ImageView iconBurn;
    private ImageView iconEarn;
    private View layoutContent;
    private View layoutLoading;
    private LinearLayout listContainer;
    private String phone;
    private SessionManager sessionManager;
    private ValueAnimator skeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout tabBurn;
    private LinearLayout tabEarn;
    private TextView textBurn;
    private TextView textEarn;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private int selectedTab = 0;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(R.color.yellow_primary, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_points_history);
        this.sessionManager = new SessionManager(this);
        String stringExtra = getIntent().getStringExtra("phone");
        this.phone = stringExtra;
        if (stringExtra == null) {
            this.phone = this.sessionManager.getPhone();
        }
        findViewById(R.id.toolbar).setTitle("Points History");
        SwipeRefreshLayout swipeRefreshLayoutFindViewById = findViewById(R.id.swipeRefresh);
        this.swipeRefresh = swipeRefreshLayoutFindViewById;
        swipeRefreshLayoutFindViewById.setColorSchemeColors(new int[]{getResources().getColor(R.color.yellow_primary, getTheme())});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(getResources().getColor(R.color.bg_card, getTheme()));
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.PointsHistoryActivity$$ExternalSyntheticLambda0
            public final void onRefresh() {
                this.f$0.m660lambda$onCreate$0$comzenoappPointsHistoryActivity();
            }
        });
        this.tabBurn = (LinearLayout) findViewById(R.id.tabBurn);
        this.tabEarn = (LinearLayout) findViewById(R.id.tabEarn);
        this.iconBurn = (ImageView) findViewById(R.id.iconBurn);
        this.iconEarn = (ImageView) findViewById(R.id.iconEarn);
        this.textBurn = (TextView) findViewById(R.id.textBurn);
        this.textEarn = (TextView) findViewById(R.id.textEarn);
        this.layoutLoading = findViewById(R.id.layout_loading);
        this.layoutContent = findViewById(R.id.layout_content);
        this.swipeRefresh.setOnChildScrollUpCallback(new SwipeRefreshLayout.OnChildScrollUpCallback() { // from class: com.zeno.app.PointsHistoryActivity$$ExternalSyntheticLambda1
            public final boolean canChildScrollUp(SwipeRefreshLayout swipeRefreshLayout, View view) {
                return this.f$0.m661lambda$onCreate$1$comzenoappPointsHistoryActivity(swipeRefreshLayout, view);
            }
        });
        this.listContainer = (LinearLayout) findViewById(R.id.listContainer);
        this.tabBurn.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsHistoryActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m662lambda$onCreate$2$comzenoappPointsHistoryActivity(view);
            }
        });
        this.tabEarn.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.PointsHistoryActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m663lambda$onCreate$3$comzenoappPointsHistoryActivity(view);
            }
        });
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-PointsHistoryActivity, reason: not valid java name */
    /* synthetic */ void m660lambda$onCreate$0$comzenoappPointsHistoryActivity() {
        loadHistory(this.selectedTab == 0 ? "BURN" : "EARN");
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-PointsHistoryActivity, reason: not valid java name */
    /* synthetic */ boolean m661lambda$onCreate$1$comzenoappPointsHistoryActivity(SwipeRefreshLayout swipeRefreshLayout, View view) {
        View view2 = this.layoutContent;
        View view3 = (view2 == null || view2.getVisibility() != 0) ? this.layoutLoading : this.layoutContent;
        return view3 != null && view3.canScrollVertically(-1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-PointsHistoryActivity, reason: not valid java name */
    /* synthetic */ void m662lambda$onCreate$2$comzenoappPointsHistoryActivity(View view) {
        selectTab(0);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$com-zeno-app-PointsHistoryActivity, reason: not valid java name */
    /* synthetic */ void m663lambda$onCreate$3$comzenoappPointsHistoryActivity(View view) {
        selectTab(1);
    }

    private void selectTab(int i) {
        this.selectedTab = i;
        applyTabStyle(this.tabBurn, this.textBurn, this.iconBurn, i == 0);
        applyTabStyle(this.tabEarn, this.textEarn, this.iconEarn, i == 1);
        loadHistory(i == 0 ? "BURN" : "EARN");
    }

    private void applyTabStyle(LinearLayout linearLayout, TextView textView, ImageView imageView, boolean z) {
        int i;
        int color = getResources().getColor(z ? R.color.text_white : R.color.text_grey, getTheme());
        if (z) {
            i = R.drawable.bg_beat_mode_selected;
        } else {
            i = R.drawable.bg_beat_mode_normal;
        }
        linearLayout.setBackgroundResource(i);
        textView.setTextColor(color);
        if (imageView != null) {
            int i2 = imageView.getId() == R.id.iconBurn ? -1092784 : -11751600;
            imageView.clearColorFilter();
            imageView.setColorFilter(i2, PorterDuff.Mode.SRC_IN);
            imageView.setAlpha(z ? 1.0f : 0.7f);
        }
    }

    private void loadHistory(String str) {
        showSkeletonLoading();
        LinearLayout linearLayout = this.listContainer;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        ApiClient.getPointsHistory(this.phone, str, this.sessionManager.getAccessToken(), this.sessionManager.getDeviceId(), new AnonymousClass1(str));
    }

    /* JADX INFO: renamed from: com.zeno.app.PointsHistoryActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Callback {
        final /* synthetic */ String val$type;

        AnonymousClass1(String str) {
            this.val$type = str;
        }

        public void onFailure(Call call, final IOException iOException) {
            PointsHistoryActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsHistoryActivity$1$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m664lambda$onFailure$0$comzenoappPointsHistoryActivity$1(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-PointsHistoryActivity$1, reason: not valid java name */
        /* synthetic */ void m664lambda$onFailure$0$comzenoappPointsHistoryActivity$1(IOException iOException) {
            PointsHistoryActivity.this.hideSkeletonLoading();
            PointsHistoryActivity.this.listContainer.removeAllViews();
            PointsHistoryActivity.this.showEmptyState("Network error: " + iOException.getMessage());
            PointsHistoryActivity.this.swipeRefresh.setRefreshing(false);
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            if (strString.trim().startsWith("<")) {
                PointsHistoryActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.PointsHistoryActivity$1$$ExternalSyntheticLambda0
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m665lambda$onResponse$1$comzenoappPointsHistoryActivity$1();
                    }
                });
                return;
            }
            Handler handler = PointsHistoryActivity.this.uiHandler;
            final String str = this.val$type;
            handler.post(new Runnable() { // from class: com.zeno.app.PointsHistoryActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m666lambda$onResponse$2$comzenoappPointsHistoryActivity$1(strString, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-PointsHistoryActivity$1, reason: not valid java name */
        /* synthetic */ void m665lambda$onResponse$1$comzenoappPointsHistoryActivity$1() {
            PointsHistoryActivity.this.hideSkeletonLoading();
            PointsHistoryActivity.this.listContainer.removeAllViews();
            PointsHistoryActivity.this.showEmptyState("Session expired or server error.\nPull down to retry or re-login.");
            PointsHistoryActivity.this.swipeRefresh.setRefreshing(false);
        }

        /* JADX INFO: renamed from: lambda$onResponse$2$com-zeno-app-PointsHistoryActivity$1, reason: not valid java name */
        /* synthetic */ void m666lambda$onResponse$2$comzenoappPointsHistoryActivity$1(String str, String str2) {
            JSONObject jSONObjectOptJSONObject;
            try {
                try {
                    jSONObjectOptJSONObject = new JSONObject(str).optJSONObject("result");
                    PointsHistoryActivity.this.listContainer.removeAllViews();
                } catch (Exception e) {
                    PointsHistoryActivity.this.listContainer.removeAllViews();
                    PointsHistoryActivity.this.showEmptyState("Parse error: " + e.getMessage());
                }
                if (jSONObjectOptJSONObject == null) {
                    PointsHistoryActivity.this.showEmptyState("No data");
                } else {
                    JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("content");
                    if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                        for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                            JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                            PointsHistoryActivity.this.addHistoryRow(jSONObject.optString("reason", "--"), jSONObject.optString("updateTime", "--"), jSONObject.optInt("amount", 0), jSONObject.optString("type", str2));
                        }
                        return;
                    }
                    PointsHistoryActivity.this.showEmptyState("No " + str2 + " history");
                }
            } finally {
                PointsHistoryActivity.this.hideSkeletonLoading();
                PointsHistoryActivity.this.swipeRefresh.setRefreshing(false);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void addHistoryRow(String str, String str2, int i, String str3) {
        int color;
        boolean zEquals = "BURN".equals(str3);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        linearLayout.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.setMargins(0, 0, 0, dp(8));
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setPadding(dp(14), dp(14), dp(14), dp(14));
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundResource(zEquals ? R.drawable.bg_icon_burn : R.drawable.bg_icon_earn);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(42), dp(42));
        layoutParams2.setMargins(0, 0, dp(14), 0);
        frameLayout.setLayoutParams(layoutParams2);
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.ic_loyal_point);
        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageView.setPadding(0, 0, 0, 0);
        frameLayout.addView(imageView, new FrameLayout.LayoutParams(dp(27), dp(27), 17));
        linearLayout.addView(frameLayout);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(getResources().getColor(R.color.text_white, getTheme()));
        textView.setTextSize(14.0f);
        textView.setTypeface(null, 1);
        linearLayout2.addView(textView);
        TextView textView2 = new TextView(this);
        textView2.setText(str2);
        textView2.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
        textView2.setTextSize(12.0f);
        linearLayout2.addView(textView2);
        linearLayout.addView(linearLayout2);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(1);
        linearLayout3.setGravity(8388629);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.setMargins(dp(8), 0, 0, 0);
        linearLayout3.setLayoutParams(layoutParams3);
        TextView textView3 = new TextView(this);
        StringBuilder sb = zEquals ? new StringBuilder("-") : new StringBuilder("+");
        sb.append(i);
        textView3.setText(sb.toString());
        textView3.setTextSize(15.0f);
        textView3.setTypeface(null, 1);
        textView3.setGravity(8388613);
        if (zEquals) {
            color = getResources().getColor(R.color.color_burn, getTheme());
        } else {
            color = getResources().getColor(R.color.color_earn, getTheme());
        }
        textView3.setTextColor(color);
        linearLayout3.addView(textView3);
        TextView textView4 = new TextView(this);
        textView4.setText("pts");
        textView4.setTextSize(12.0f);
        textView4.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
        textView4.setGravity(8388613);
        linearLayout3.addView(textView4);
        linearLayout.addView(linearLayout3);
        this.listContainer.addView(linearLayout);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void showEmptyState(String str) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
        textView.setGravity(17);
        textView.setPadding(0, dp(48), 0, dp(16));
        this.listContainer.addView(textView);
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private void showSkeletonLoading() {
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(0);
            View view2 = this.layoutContent;
            if (view2 != null) {
                view2.setVisibility(8);
            }
            this.skeletonAnim = SkeletonPulse.start(this.layoutLoading);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hideSkeletonLoading() {
        SkeletonPulse.stop(this.skeletonAnim, this.layoutLoading);
        this.skeletonAnim = null;
        View view = this.layoutLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.layoutContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }
}
