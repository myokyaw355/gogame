package com.zeno.app;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ScrollView;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SongAwareScrollView extends ScrollView {
    private View blockedRegion;
    private final int[] loc;
    private final Rect regionRect;
    private boolean touchingBlockedRegion;

    public SongAwareScrollView(Context context) {
        super(context);
        this.regionRect = new Rect();
        this.loc = new int[2];
        this.touchingBlockedRegion = false;
    }

    public SongAwareScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.regionRect = new Rect();
        this.loc = new int[2];
        this.touchingBlockedRegion = false;
    }

    public SongAwareScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.regionRect = new Rect();
        this.loc = new int[2];
        this.touchingBlockedRegion = false;
    }

    public void setBlockedRegion(View view) {
        this.blockedRegion = view;
    }

    private boolean isInBlockedRegion(MotionEvent motionEvent) {
        View view = this.blockedRegion;
        if (view == null || view.getVisibility() != 0 || this.blockedRegion.getWidth() <= 0 || this.blockedRegion.getHeight() <= 0) {
            return false;
        }
        this.blockedRegion.getLocationOnScreen(this.loc);
        Rect rect = this.regionRect;
        int[] iArr = this.loc;
        int i = iArr[0];
        rect.set(i, iArr[1], this.blockedRegion.getWidth() + i, this.loc[1] + this.blockedRegion.getHeight());
        return this.regionRect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY());
    }

    @Override // android.widget.ScrollView, android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.touchingBlockedRegion = isInBlockedRegion(motionEvent);
        } else if (actionMasked == 1 || actionMasked == 3) {
            this.touchingBlockedRegion = false;
        }
        if (this.touchingBlockedRegion) {
            return false;
        }
        try {
            return super.onInterceptTouchEvent(motionEvent);
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // android.widget.ScrollView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.touchingBlockedRegion) {
            return false;
        }
        try {
            return super.onTouchEvent(motionEvent);
        } catch (Exception unused) {
            return false;
        }
    }
}
