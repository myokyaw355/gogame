package com.zeno.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.widget.LinearLayout;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class SongCardLayout extends LinearLayout {
    private float downX;
    private float downY;
    private boolean dragging;
    private float lastY;
    private SongScrollView songScroll;
    private final int touchSlop;

    public SongCardLayout(Context context) {
        super(context);
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public SongCardLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public SongCardLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
    }

    public void setSongScroll(SongScrollView songScrollView) {
        this.songScroll = songScrollView;
    }

    private void lockParents(boolean z) {
        for (ViewParent parent = getParent(); parent != null; parent = parent.getParent()) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        if (this.songScroll == null) {
            return super.onInterceptTouchEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.downX = motionEvent.getX();
            this.downY = motionEvent.getY();
            this.lastY = motionEvent.getY();
            this.dragging = false;
            lockParents(true);
            return false;
        }
        if (actionMasked != 1) {
            if (actionMasked == 2) {
                float fAbs = Math.abs(motionEvent.getX() - this.downX);
                float fAbs2 = Math.abs(motionEvent.getY() - this.downY);
                if (fAbs2 <= this.touchSlop || fAbs2 < fAbs) {
                    return false;
                }
                this.dragging = true;
                this.lastY = motionEvent.getY();
                lockParents(true);
                return true;
            }
            if (actionMasked != 3) {
                return false;
            }
        }
        this.dragging = false;
        lockParents(false);
        return false;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.songScroll == null) {
            return super.onTouchEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.downX = motionEvent.getX();
            this.downY = motionEvent.getY();
            this.lastY = motionEvent.getY();
            this.dragging = false;
            lockParents(true);
            return true;
        }
        if (actionMasked != 1) {
            if (actionMasked == 2) {
                lockParents(true);
                float y = motionEvent.getY();
                float fAbs = Math.abs(motionEvent.getX() - this.downX);
                float fAbs2 = Math.abs(y - this.downY);
                if (!this.dragging && fAbs2 > this.touchSlop && fAbs2 >= fAbs) {
                    this.dragging = true;
                    this.lastY = y;
                }
                if (this.dragging) {
                    float f = this.lastY - y;
                    if (f != 0.0f) {
                        this.songScroll.scrollBy(0, Math.round(f));
                    }
                    this.lastY = y;
                }
                return true;
            }
            if (actionMasked != 3) {
                return true;
            }
        }
        lockParents(false);
        this.dragging = false;
        return true;
    }
}
