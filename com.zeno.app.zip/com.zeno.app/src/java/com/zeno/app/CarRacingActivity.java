package com.zeno.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import android.util.Property;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.RequestOptions;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CarRacingActivity extends BaseActivity {
    private static final long DELAY_BETWEEN_GAMES = 5000;
    private static final String GAME_BASE = "https://car-racing.mascom.vn";
    private static final String GAME_CODE = "CAR_ONLINE";
    private static final String MC_APP = "myid";
    private static final String ORIGIN = "https://car-racing.mascom.vn";
    private static final String PAYLOAD_END = "dCkgKGd8D0MwZJQfL5HjV47U64XTwmaO50vBxRyAS2mSi1qUjUltpjpus5cC/782";
    private static final String PAYLOAD_JOIN = "IJsBm8s6uMgYmXqXk06m7RD4EFkvG5rwQP+o6yfl7uHF2Kl/4m8kk/XwwEAdz9FI7CVEG5v6dfc52IgVLHvofYSQyAWQVhjzGf0k5R1mTd6LCohT70WWbO0ScdCT+33zfs5n+VehrRY1YdR+N1HfXA==";
    private static final String PAYLOAD_START = "s4XbEyqBZKUcMSxCNZdD2J5XkXfvW1u50AiY/wyNvA8=";
    private static final long RACE_DURATION_MS = 75000;
    private static final String TAG = "CarRacing";
    private static final String TELCO_GW = "https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login";
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12; Redmi K30 5G Build/SKQ1.211006.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/150.0.7871.181 Mobile Safari/537.36";
    private static final String WS_URL = "wss://car-racing.mascom.vn/api/ws";
    private static final String X_REQ_WITH = "com.myentertainment.oneid";
    private WebSocket activeWs;
    private View autoPlaySkeleton;
    private ValueAnimator autoPlaySkeletonAnim;
    private View avatarSkeleton;
    private ValueAnimator avatarSkeletonAnim;
    private View balanceContent;
    private View balanceSkeleton;
    private ValueAnimator balanceSkeletonAnim;
    private Button btnAutoPlay;
    private TextView btnCount1;
    private TextView btnCount10;
    private TextView btnCount20;
    private TextView btnCount3;
    private TextView btnCount30;
    private TextView btnCount5;
    private View btnPlayingBack;
    private TextView btnRankBronze;
    private TextView btnRankGold;
    private TextView btnRankMonthly;
    private TextView btnRankSilver;
    private TextView btnStop;
    private TextView btnTierBronze;
    private TextView btnTierGold;
    private TextView btnTierSilver;
    private View contentPicker;
    private View contentPlay;
    private View contentPlaying;
    private View contentRank;
    private View gamePickerSkeleton;
    private ValueAnimator gamePickerSkeletonAnim;
    private ImageView ivAvatar;
    private ImageView ivEditName;
    private ImageView ivInfoCar;
    private ImageView ivProgressCar;
    private View pbProfileLoading;
    private ValueAnimator profileSkeletonAnim;
    private ProgressBar progressRace;
    private View progressRaceContainer;
    private LinearLayout rankList;
    private View rankLoading;
    private ValueAnimator rankSkeletonAnim;
    private View rankUserFooter;
    private LinearLayout rankUserRow;
    private View rowProfileContent;
    private SessionManager session;
    private View shopCardsContent;
    private View shopCardsSkeleton;
    private ValueAnimator shopSkeletonAnim;
    private View spinSkeleton;
    private ValueAnimator spinSkeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private SwitchCompat switchAlwaysLoopCarRacing;
    private View tabPlayUnderline;
    private View tabRankUnderline;
    private boolean tierBronzeOk;
    private boolean tierGoldOk;
    private boolean tierSilverOk;
    private Runnable timerRunnable;
    private TextView tvBigCoin;
    private TextView tvCoin;
    private TextView tvCurrentRaceLabel;
    private TextView tvGem;
    private TextView tvInfoCar;
    private TextView tvInfoCoin;
    private TextView tvInfoLicense;
    private TextView tvInfoMap;
    private TextView tvInfoRankCoin;
    private TextView tvInfoStartTime;
    private TextView tvInfoStats;
    private TextView tvInfoStatus;
    private TextView tvLicense;
    private TextView tvProfileName;
    private TextView tvProfilePhone;
    private TextView tvProgressLeft;
    private TextView tvRankExpire;
    private TextView tvTabPlay;
    private TextView tvTabRank;
    private TextView tvTicket;
    private TextView tvTimeLeft;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).followRedirects(false).build();
    private final OkHttpClient wsClient = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build();
    private String gameAccessToken = null;
    private boolean alwaysLoopCarRacingEnabled = false;
    private String cachedCarIcon = null;
    private String selectedTier = "BRONZE";
    private int selectedCount = 1;
    private final AtomicBoolean isPlaying = new AtomicBoolean(false);
    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private int sessionRaces = 0;
    private int sessionWins = 0;
    private int sessionCoins = 0;
    private int raceAccumCoins = 0;
    private int raceAccumRankCoins = 0;
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private long raceEndAtMs = 0;
    private long raceDurationMs = RACE_DURATION_MS;
    private String cachedCarName = "—";
    private long cachedCoins = 0;
    private long cachedGems = 0;
    private String cachedLicense = "—";
    private int rankTab = 0;
    private String cachedStats = "—";

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_car_racing);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        this.session = new SessionManager(this);
        bindViews();
        setupToolbar();
        setupListeners();
        loginAndLoad();
    }

    private void bindViews() {
        this.swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeRefresh);
        this.contentPicker = findViewById(R.id.contentPicker);
        this.contentPlaying = findViewById(R.id.contentPlaying);
        this.btnPlayingBack = findViewById(R.id.btnPlayingBack);
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        ImageView imageView = (ImageView) findViewById(R.id.ivEditName);
        this.ivEditName = imageView;
        if (imageView != null) {
            imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda15
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m113lambda$bindViews$0$comzenoappCarRacingActivity(view);
                }
            });
        }
        View viewFindViewById = findViewById(R.id.btnSpin);
        if (viewFindViewById != null) {
            viewFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda18
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m114lambda$bindViews$1$comzenoappCarRacingActivity(view);
                }
            });
        }
        View viewFindViewById2 = findViewById(R.id.cardGemExchange);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda19
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m117lambda$bindViews$2$comzenoappCarRacingActivity(view);
                }
            });
        }
        View viewFindViewById3 = findViewById(R.id.cardPackageShop);
        if (viewFindViewById3 != null) {
            viewFindViewById3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda20
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m118lambda$bindViews$3$comzenoappCarRacingActivity(view);
                }
            });
        }
        ImageView imageView2 = (ImageView) findViewById(R.id.btnGiftRewards);
        if (imageView2 != null) {
            imageView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda21
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m119lambda$bindViews$4$comzenoappCarRacingActivity(view);
                }
            });
            startGiftPulse(imageView2);
        }
        this.contentPlay = findViewById(R.id.swipeRefresh);
        this.contentRank = findViewById(R.id.contentRank);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabRankUnderline = findViewById(R.id.tabRankUnderline);
        this.tvTabPlay = (TextView) findViewById(R.id.tvTabPlay);
        this.tvTabRank = (TextView) findViewById(R.id.tvTabRank);
        View viewFindViewById4 = findViewById(R.id.tabPlay);
        View viewFindViewById5 = findViewById(R.id.tabRank);
        if (viewFindViewById4 != null) {
            viewFindViewById4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda23
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m120lambda$bindViews$5$comzenoappCarRacingActivity(view);
                }
            });
        }
        if (viewFindViewById5 != null) {
            viewFindViewById5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda24
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m121lambda$bindViews$6$comzenoappCarRacingActivity(view);
                }
            });
        }
        this.btnRankBronze = (TextView) findViewById(R.id.btnRankBronze);
        this.btnRankSilver = (TextView) findViewById(R.id.btnRankSilver);
        this.btnRankGold = (TextView) findViewById(R.id.btnRankGold);
        this.btnRankMonthly = (TextView) findViewById(R.id.btnRankMonthly);
        TextView textView = this.btnRankBronze;
        if (textView != null) {
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda25
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m122lambda$bindViews$7$comzenoappCarRacingActivity(view);
                }
            });
        }
        TextView textView2 = this.btnRankSilver;
        if (textView2 != null) {
            textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda26
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m123lambda$bindViews$8$comzenoappCarRacingActivity(view);
                }
            });
        }
        TextView textView3 = this.btnRankGold;
        if (textView3 != null) {
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda27
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m124lambda$bindViews$9$comzenoappCarRacingActivity(view);
                }
            });
        }
        TextView textView4 = this.btnRankMonthly;
        if (textView4 != null) {
            textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda16
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m115lambda$bindViews$10$comzenoappCarRacingActivity(view);
                }
            });
        }
        this.rankList = (LinearLayout) findViewById(R.id.rankList);
        this.rankUserRow = (LinearLayout) findViewById(R.id.rankUserRow);
        this.rankUserFooter = findViewById(R.id.rankUserFooter);
        this.rankLoading = findViewById(R.id.rankLoading);
        this.tvRankExpire = (TextView) findViewById(R.id.tvRankExpire);
        this.tvProfileName = (TextView) findViewById(R.id.tvProfileName);
        this.tvProfilePhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.tvLicense = (TextView) findViewById(R.id.tvLicense);
        this.tvCoin = (TextView) findViewById(R.id.tvCoin);
        this.tvGem = (TextView) findViewById(R.id.tvGem);
        this.tvTicket = (TextView) findViewById(R.id.tvTicket);
        this.btnTierBronze = (TextView) findViewById(R.id.btnTierBronze);
        this.btnTierSilver = (TextView) findViewById(R.id.btnTierSilver);
        this.btnTierGold = (TextView) findViewById(R.id.btnTierGold);
        SwitchCompat switchCompat = (SwitchCompat) findViewById(R.id.switchAlwaysLoopCarRacing);
        this.switchAlwaysLoopCarRacing = switchCompat;
        if (switchCompat != null) {
            boolean alwaysLoop = this.session.getAlwaysLoop("car_racing");
            this.alwaysLoopCarRacingEnabled = alwaysLoop;
            this.switchAlwaysLoopCarRacing.setChecked(alwaysLoop);
            this.switchAlwaysLoopCarRacing.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda17
                @Override // android.widget.CompoundButton.OnCheckedChangeListener
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    this.f$0.m116lambda$bindViews$11$comzenoappCarRacingActivity(compoundButton, z);
                }
            });
        }
        this.btnCount1 = (TextView) findViewById(R.id.btnCount1);
        this.btnCount3 = (TextView) findViewById(R.id.btnCount3);
        this.btnCount5 = (TextView) findViewById(R.id.btnCount5);
        this.btnCount10 = (TextView) findViewById(R.id.btnCount10);
        this.btnCount20 = (TextView) findViewById(R.id.btnCount20);
        this.btnCount30 = (TextView) findViewById(R.id.btnCount30);
        setCountButtonsEnabled(!this.alwaysLoopCarRacingEnabled);
        this.btnAutoPlay = (Button) findViewById(R.id.btnAutoPlay);
        this.spinSkeleton = findViewById(R.id.spinSkeleton);
        this.autoPlaySkeleton = findViewById(R.id.autoPlaySkeleton);
        this.pbProfileLoading = findViewById(R.id.pbProfileLoading);
        this.avatarSkeleton = findViewById(R.id.avatarSkeleton);
        this.shopCardsSkeleton = findViewById(R.id.shopCardsSkeleton);
        this.shopCardsContent = findViewById(R.id.shopCardsContent);
        this.balanceSkeleton = findViewById(R.id.balanceSkeleton);
        this.balanceContent = findViewById(R.id.balanceContent);
        this.gamePickerSkeleton = findViewById(R.id.gamePickerSkeleton);
        this.rowProfileContent = findViewById(R.id.rowProfileContent);
        this.tvBigCoin = (TextView) findViewById(R.id.tvBigCoin);
        this.tvCurrentRaceLabel = (TextView) findViewById(R.id.tvCurrentRaceLabel);
        this.tvProgressLeft = (TextView) findViewById(R.id.tvProgressLeft);
        this.tvTimeLeft = (TextView) findViewById(R.id.tvTimeLeft);
        this.progressRace = (ProgressBar) findViewById(R.id.progressRace);
        this.ivProgressCar = (ImageView) findViewById(R.id.ivProgressCar);
        this.progressRaceContainer = findViewById(R.id.progressRaceContainer);
        this.tvInfoCoin = (TextView) findViewById(R.id.tvInfoCoin);
        this.tvInfoRankCoin = (TextView) findViewById(R.id.tvInfoRankCoin);
        this.tvInfoStartTime = (TextView) findViewById(R.id.tvInfoStartTime);
        this.tvInfoMap = (TextView) findViewById(R.id.tvInfoMap);
        this.tvInfoCar = (TextView) findViewById(R.id.tvInfoCar);
        this.ivInfoCar = (ImageView) findViewById(R.id.ivInfoCar);
        this.tvInfoStatus = (TextView) findViewById(R.id.tvInfoStatus);
        this.tvInfoLicense = (TextView) findViewById(R.id.tvInfoLicense);
        this.tvInfoStats = (TextView) findViewById(R.id.tvInfoStats);
        TextView textView5 = (TextView) findViewById(R.id.btnStop);
        this.btnStop = textView5;
        if (textView5 != null) {
            textView5.setBackgroundResource(R.drawable.bg_btn_stop);
            this.btnStop.setBackgroundTintList(null);
        }
        this.tvProfilePhone.setText(this.session.getPhone());
        String fullName = this.session.getFullName();
        TextView textView6 = this.tvProfileName;
        if (fullName == null || fullName.isEmpty()) {
            fullName = "Player";
        }
        textView6.setText(fullName);
    }

    /* JADX INFO: renamed from: lambda$bindViews$0$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m113lambda$bindViews$0$comzenoappCarRacingActivity(View view) {
        showEditNameDialog();
    }

    /* JADX INFO: renamed from: lambda$bindViews$1$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m114lambda$bindViews$1$comzenoappCarRacingActivity(View view) {
        openLuckySpin();
    }

    /* JADX INFO: renamed from: lambda$bindViews$2$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m117lambda$bindViews$2$comzenoappCarRacingActivity(View view) {
        openGemShop();
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m118lambda$bindViews$3$comzenoappCarRacingActivity(View view) {
        openPackageShop();
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m119lambda$bindViews$4$comzenoappCarRacingActivity(View view) {
        openRewards();
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m120lambda$bindViews$5$comzenoappCarRacingActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m121lambda$bindViews$6$comzenoappCarRacingActivity(View view) {
        showRankTab();
    }

    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m122lambda$bindViews$7$comzenoappCarRacingActivity(View view) {
        switchRankTab(0);
    }

    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m123lambda$bindViews$8$comzenoappCarRacingActivity(View view) {
        switchRankTab(1);
    }

    /* JADX INFO: renamed from: lambda$bindViews$9$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m124lambda$bindViews$9$comzenoappCarRacingActivity(View view) {
        switchRankTab(2);
    }

    /* JADX INFO: renamed from: lambda$bindViews$10$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m115lambda$bindViews$10$comzenoappCarRacingActivity(View view) {
        switchRankTab(3);
    }

    /* JADX INFO: renamed from: lambda$bindViews$11$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m116lambda$bindViews$11$comzenoappCarRacingActivity(CompoundButton compoundButton, boolean z) {
        if (this.isPlaying.get()) {
            compoundButton.setChecked(this.alwaysLoopCarRacingEnabled);
            return;
        }
        this.alwaysLoopCarRacingEnabled = z;
        this.session.saveAlwaysLoop("car_racing", z);
        setCountButtonsEnabled(!z);
        updatePlayButtonLabel();
    }

    private void setupToolbar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda29
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m168lambda$setupToolbar$12$comzenoappCarRacingActivity(view);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$setupToolbar$12$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m168lambda$setupToolbar$12$comzenoappCarRacingActivity(View view) {
        if (this.isPlaying.get()) {
            Toast.makeText((Context) this, (CharSequence) "Stop playing first", 0).show();
        } else {
            finish();
        }
    }

    private void setupListeners() {
        this.swipeRefresh.setColorSchemeColors(new int[]{-3632086});
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda53
            public final void onRefresh() {
                this.f$0.m155lambda$setupListeners$13$comzenoappCarRacingActivity();
            }
        });
        this.btnTierBronze.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda58
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m156lambda$setupListeners$14$comzenoappCarRacingActivity(view);
            }
        });
        this.btnTierSilver.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda59
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m157lambda$setupListeners$15$comzenoappCarRacingActivity(view);
            }
        });
        this.btnTierGold.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda60
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m158lambda$setupListeners$16$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount1.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda61
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m159lambda$setupListeners$17$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda62
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m160lambda$setupListeners$18$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda63
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m161lambda$setupListeners$19$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount10.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda64
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m162lambda$setupListeners$20$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount20.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda65
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m163lambda$setupListeners$21$comzenoappCarRacingActivity(view);
            }
        });
        this.btnCount30.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda67
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m164lambda$setupListeners$22$comzenoappCarRacingActivity(view);
            }
        });
        this.btnAutoPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda54
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m165lambda$setupListeners$23$comzenoappCarRacingActivity(view);
            }
        });
        updatePlayButtonLabel();
        this.btnStop.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda56
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m166lambda$setupListeners$24$comzenoappCarRacingActivity(view);
            }
        });
        View view = this.btnPlayingBack;
        if (view != null) {
            view.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda57
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m167lambda$setupListeners$25$comzenoappCarRacingActivity(view2);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$setupListeners$13$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m155lambda$setupListeners$13$comzenoappCarRacingActivity() {
        if (this.isPlaying.get()) {
            this.swipeRefresh.setRefreshing(false);
            Toast.makeText((Context) this, (CharSequence) "Playing... cannot refresh", 0).show();
        } else {
            loginAndLoad();
        }
    }

    /* JADX INFO: renamed from: lambda$setupListeners$14$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m156lambda$setupListeners$14$comzenoappCarRacingActivity(View view) {
        selectTier("BRONZE");
    }

    /* JADX INFO: renamed from: lambda$setupListeners$15$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m157lambda$setupListeners$15$comzenoappCarRacingActivity(View view) {
        selectTier("SILVER");
    }

    /* JADX INFO: renamed from: lambda$setupListeners$16$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m158lambda$setupListeners$16$comzenoappCarRacingActivity(View view) {
        selectTier("GOLD");
    }

    /* JADX INFO: renamed from: lambda$setupListeners$17$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m159lambda$setupListeners$17$comzenoappCarRacingActivity(View view) {
        selectCount(1, this.btnCount1);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$18$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m160lambda$setupListeners$18$comzenoappCarRacingActivity(View view) {
        selectCount(3, this.btnCount3);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$19$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m161lambda$setupListeners$19$comzenoappCarRacingActivity(View view) {
        selectCount(5, this.btnCount5);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$20$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m162lambda$setupListeners$20$comzenoappCarRacingActivity(View view) {
        selectCount(10, this.btnCount10);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$21$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m163lambda$setupListeners$21$comzenoappCarRacingActivity(View view) {
        selectCount(20, this.btnCount20);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$22$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m164lambda$setupListeners$22$comzenoappCarRacingActivity(View view) {
        selectCount(30, this.btnCount30);
    }

    /* JADX INFO: renamed from: lambda$setupListeners$23$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m165lambda$setupListeners$23$comzenoappCarRacingActivity(View view) {
        startAutoPlay();
    }

    /* JADX INFO: renamed from: lambda$setupListeners$24$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m166lambda$setupListeners$24$comzenoappCarRacingActivity(View view) {
        requestStop();
    }

    /* JADX INFO: renamed from: lambda$setupListeners$25$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m167lambda$setupListeners$25$comzenoappCarRacingActivity(View view) {
        requestStop();
        showPickerUi();
    }

    private void selectTier(String str) {
        if (this.isPlaying.get()) {
            return;
        }
        this.selectedTier = str;
        applyTierBg(this.btnTierBronze, "BRONZE".equals(str), this.tierBronzeOk, "🥉 BRONZE");
        applyTierBg(this.btnTierSilver, "SILVER".equals(str), this.tierSilverOk, "🥈 SILVER");
        applyTierBg(this.btnTierGold, "GOLD".equals(str), this.tierGoldOk, "🥇 GOLD");
    }

    private void applyTierBg(TextView textView, boolean z, boolean z2, String str) {
        if (textView == null) {
            return;
        }
        textView.setText(str);
        if (!z) {
            textView.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView.setTextColor(z2 ? -8271996 : -6381922);
        } else if (z2) {
            textView.setBackgroundResource(R.drawable.bg_tier_eligible);
            textView.setTextColor(-11751600);
        } else {
            textView.setBackgroundResource(R.drawable.bg_tier_locked);
            textView.setTextColor(-1092784);
        }
    }

    private void selectCount(int i, TextView textView) {
        if (this.isPlaying.get()) {
            return;
        }
        SwitchCompat switchCompat = this.switchAlwaysLoopCarRacing;
        if (switchCompat == null || !switchCompat.isChecked()) {
            this.selectedCount = i;
            TextView[] textViewArr = {this.btnCount1, this.btnCount3, this.btnCount5, this.btnCount10, this.btnCount20, this.btnCount30};
            for (int i2 = 0; i2 < 6; i2++) {
                TextView textView2 = textViewArr[i2];
                textView2.setBackgroundResource(R.drawable.bg_game_count_normal);
                textView2.setTextColor(-6381922);
            }
            textView.setBackgroundResource(R.drawable.bg_game_count_selected);
            textView.setTextColor(-3632086);
        }
    }

    private void setCountButtonsEnabled(boolean z) {
        TextView[] textViewArr = {this.btnCount1, this.btnCount3, this.btnCount5, this.btnCount10, this.btnCount20, this.btnCount30};
        for (int i = 0; i < 6; i++) {
            TextView textView = textViewArr[i];
            if (textView != null) {
                textView.setEnabled(z);
                textView.setClickable(z);
                textView.setAlpha(z ? 1.0f : 0.4f);
            }
        }
    }

    @Override // com.zeno.app.BaseActivity
    protected void onResume() {
        String str;
        super.onResume();
        if (this.isPlaying.get() || (str = this.gameAccessToken) == null || str.isEmpty()) {
            return;
        }
        final String str2 = this.gameAccessToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda40
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m152lambda$onResume$27$comzenoappCarRacingActivity(str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onResume$27$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m152lambda$onResume$27$comzenoappCarRacingActivity(String str) {
        try {
            final JSONObject jSONObjectFetchPlayerInfo = fetchPlayerInfo(str);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda69
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m151lambda$onResume$26$comzenoappCarRacingActivity(jSONObjectFetchPlayerInfo);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "onResume refresh", e);
        }
    }

    private void loginAndLoad() {
        this.pbProfileLoading.setVisibility(0);
        View view = this.spinSkeleton;
        if (view != null) {
            view.setVisibility(0);
        }
        View view2 = this.autoPlaySkeleton;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        View viewFindViewById = findViewById(R.id.btnSpin);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(4);
        }
        Button button = this.btnAutoPlay;
        if (button != null) {
            button.setVisibility(4);
            this.btnAutoPlay.setEnabled(false);
        }
        View view3 = this.rowProfileContent;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        View view4 = this.avatarSkeleton;
        if (view4 != null) {
            view4.setVisibility(0);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(4);
        }
        this.profileSkeletonAnim = SkeletonPulse.start(this.pbProfileLoading);
        View view5 = this.spinSkeleton;
        if (view5 != null) {
            this.spinSkeletonAnim = SkeletonPulse.start(view5);
        }
        View view6 = this.autoPlaySkeleton;
        if (view6 != null) {
            this.autoPlaySkeletonAnim = SkeletonPulse.start(view6);
        }
        View view7 = this.avatarSkeleton;
        if (view7 != null) {
            this.avatarSkeletonAnim = SkeletonPulse.start(view7);
        }
        View view8 = this.shopCardsSkeleton;
        if (view8 != null) {
            view8.setVisibility(0);
            View view9 = this.shopCardsContent;
            if (view9 != null) {
                view9.setVisibility(8);
            }
            this.shopSkeletonAnim = SkeletonPulse.start(this.shopCardsSkeleton);
        }
        View view10 = this.balanceSkeleton;
        if (view10 != null) {
            view10.setVisibility(0);
            View view11 = this.balanceContent;
            if (view11 != null) {
                view11.setVisibility(8);
            }
            this.balanceSkeletonAnim = SkeletonPulse.start(this.balanceSkeleton);
        }
        View view12 = this.gamePickerSkeleton;
        if (view12 != null) {
            view12.setVisibility(0);
            View viewFindViewById2 = findViewById(R.id.cardGamePicker);
            if (viewFindViewById2 != null) {
                viewFindViewById2.setVisibility(8);
            }
            this.gamePickerSkeletonAnim = SkeletonPulse.start(this.gamePickerSkeleton);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m150lambda$loginAndLoad$30$comzenoappCarRacingActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loginAndLoad$30$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m150lambda$loginAndLoad$30$comzenoappCarRacingActivity() {
        try {
            String strDoTelcoLogin = doTelcoLogin();
            this.gameAccessToken = strDoTelcoLogin;
            final JSONObject jSONObjectFetchPlayerInfo = fetchPlayerInfo(strDoTelcoLogin);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda38
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m148lambda$loginAndLoad$28$comzenoappCarRacingActivity(jSONObjectFetchPlayerInfo);
                }
            });
            checkTiers(strDoTelcoLogin);
        } catch (Exception e) {
            Log.e(TAG, "loginAndLoad", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda39
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m149lambda$loginAndLoad$29$comzenoappCarRacingActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loginAndLoad$28$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m148lambda$loginAndLoad$28$comzenoappCarRacingActivity(JSONObject jSONObject) {
        m179lambda$startAutoPlay$37$comzenoappCarRacingActivity(jSONObject);
        stopProfileSkeleton();
        this.swipeRefresh.setRefreshing(false);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loginAndLoad$29$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m149lambda$loginAndLoad$29$comzenoappCarRacingActivity(Exception exc) {
        stopProfileSkeleton();
        this.swipeRefresh.setRefreshing(false);
        Toast.makeText((Context) this, (CharSequence) ("Login failed: " + exc.getMessage()), 1).show();
    }

    private String doTelcoLogin() throws Exception {
        String strSubstring;
        String phone = this.session.getPhone();
        String accessToken = this.session.getAccessToken();
        if (phone == null || phone.isEmpty() || accessToken == null || accessToken.isEmpty()) {
            throw new Exception("No session token. Please re-login to MyID.");
        }
        Response responseExecute = this.http.newCall(new Request.Builder().url("https://telco-gw.mascom.vn/gateway-service/v1/game/super-app/login?game-code=CAR_ONLINE&uuid=" + UUID.randomUUID().toString() + "&mcuid=" + UUID.randomUUID().toString().replace("-", "").substring(0, 32) + "&mcapp=myid").header("User-Agent", USER_AGENT).header("phone-number", phone).header("access-token", accessToken).header("avatar", "").header("lang", "my").header("username", phone).get().build()).execute();
        try {
            String strHeader = responseExecute.header("Location");
            if (strHeader == null || strHeader.isEmpty()) {
                throw new Exception("No redirect from telco gateway (HTTP " + responseExecute.code() + ")");
            }
            String[] strArrSplit = strHeader.split("[?&]");
            int length = strArrSplit.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    strSubstring = null;
                    break;
                }
                String str = strArrSplit[i];
                if (str.startsWith("token=")) {
                    strSubstring = str.substring(6);
                    break;
                }
                i++;
            }
            if (strSubstring == null || strSubstring.isEmpty()) {
                throw new Exception("No token in redirect");
            }
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("token", strSubstring);
            Response responseExecute2 = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/auth/login").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("Accept-Language", "en").header("X-Requested-With", X_REQ_WITH).post(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).build()).execute();
            try {
                JSONObject jSONObject2 = new JSONObject(responseExecute2.body() != null ? responseExecute2.body().string() : "");
                if (jSONObject2.optBoolean("success", false)) {
                    String string = jSONObject2.getJSONObject("data").getString("accessToken");
                    if (responseExecute2 != null) {
                        responseExecute2.close();
                    }
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return string;
                }
                throw new Exception("Game auth fail: " + jSONObject2.optString("error") + " " + jSONObject2.optString("message"));
            } finally {
            }
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONObject fetchPlayerInfo(String str) throws Exception {
        Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/user/info").header("Authorization", "Bearer " + str).header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ_WITH).get().build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
            if (jSONObject.optBoolean("success", false)) {
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return jSONObject;
            }
            throw new Exception("Player info fail: " + jSONObject.optString("error"));
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: applyPlayerInfo, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public void m179lambda$startAutoPlay$37$comzenoappCarRacingActivity(JSONObject jSONObject) {
        try {
            JSONObject jSONObject2 = jSONObject.getJSONObject("data");
            JSONObject jSONObject3 = jSONObject2.getJSONObject("gameData");
            this.tvProfileName.setText(jSONObject2.optString("playerName", "Player"));
            loadAvatar(jSONObject2.optString("avatar", null));
            this.cachedLicense = jSONObject3.optString("licenseName", "—");
            this.tvLicense.setText("License: " + this.cachedLicense + " (" + jSONObject3.optInt("expLicenseCurrent") + "/" + jSONObject3.optInt("expLicenseNext") + " EXP)");
            this.cachedCoins = jSONObject3.optLong("totalCoin", (long) jSONObject3.optInt("totalCoin", 0));
            this.cachedGems = jSONObject3.optLong("totalGem", (long) jSONObject3.optInt("totalGem", 0));
            this.tvCoin.setText(String.valueOf(this.cachedCoins));
            this.tvGem.setText(String.valueOf(this.cachedGems));
            this.tvTicket.setText(String.valueOf(jSONObject3.optInt("totalTicket")));
            if (!jSONObject3.has("carUsing") || jSONObject3.isNull("carUsing")) {
                return;
            }
            JSONObject jSONObject4 = jSONObject3.getJSONObject("carUsing");
            if (!jSONObject4.has("car") || jSONObject4.isNull("car")) {
                return;
            }
            JSONObject jSONObject5 = jSONObject4.getJSONObject("car");
            String strOptString = jSONObject5.optString("code", "");
            String strOptString2 = jSONObject5.optString("name", "—");
            if (strOptString.isEmpty()) {
                strOptString = strOptString2;
            }
            this.cachedCarName = strOptString;
            String strOptString3 = jSONObject5.optString("icon", null);
            this.cachedCarIcon = strOptString3;
            if (strOptString3 != null && (strOptString3.isEmpty() || "null".equals(this.cachedCarIcon))) {
                this.cachedCarIcon = null;
            }
            this.cachedStats = jSONObject5.optInt("baseTopSpeed") + " / " + jSONObject5.optInt("baseAcc") + " / " + jSONObject5.optInt("baseNosSpeed");
        } catch (Exception e) {
            Log.e(TAG, "applyPlayerInfo", e);
        }
    }

    private void checkTiers(final String str) {
        Runnable runnable = new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m131lambda$checkTiers$32$comzenoappCarRacingActivity(str);
            }
        };
        if (Looper.myLooper() == Looper.getMainLooper()) {
            this.exec.execute(runnable);
        } else {
            runnable.run();
        }
    }

    /* JADX INFO: renamed from: lambda$checkTiers$32$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m131lambda$checkTiers$32$comzenoappCarRacingActivity(String str) {
        try {
            Log.d(TAG, "Validating tiers (config → suggest → activate → check)...");
            this.tierBronzeOk = validateTierBeforeMenu(str, "BRONZE");
            this.tierSilverOk = validateTierBeforeMenu(str, "SILVER");
            this.tierGoldOk = validateTierBeforeMenu(str, "GOLD");
            Log.d(TAG, "Tier status BRONZE=" + this.tierBronzeOk + " SILVER=" + this.tierSilverOk + " GOLD=" + this.tierGoldOk);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda30
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m130lambda$checkTiers$31$comzenoappCarRacingActivity();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "checkTiers", e);
        }
    }

    /* JADX INFO: renamed from: lambda$checkTiers$31$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m130lambda$checkTiers$31$comzenoappCarRacingActivity() {
        selectTier(this.selectedTier);
    }

    private boolean validateTierBeforeMenu(String str, String str2) {
        try {
            if (!configurePvpMode(str, str2)) {
                Log.w(TAG, str2 + " config-pvp failed");
                return false;
            }
            JSONArray jSONArraySuggestCars = suggestCars(str, str2);
            if (jSONArraySuggestCars != null && jSONArraySuggestCars.length() != 0) {
                if (!useSuggestedCar(str, jSONArraySuggestCars.getJSONObject(0))) {
                    Log.w(TAG, str2 + " suggested car activation/verification failed");
                    return false;
                }
                return checkTier(str, str2);
            }
            Log.w(TAG, str2 + " no suggested cars");
            return false;
        } catch (Exception e) {
            Log.e(TAG, "validateTierBeforeMenu " + str2, e);
            return false;
        }
    }

    private boolean prepareTierForRace(String str, String str2) {
        try {
            if (!configurePvpMode(str, str2)) {
                Log.w(TAG, str2 + " config-pvp failed before race");
                return false;
            }
            JSONArray jSONArraySuggestCars = suggestCars(str, str2);
            if (jSONArraySuggestCars != null && jSONArraySuggestCars.length() != 0) {
                if (!useSuggestedCar(str, jSONArraySuggestCars.getJSONObject(0))) {
                    Log.w(TAG, str2 + " car activation failed before race");
                    return false;
                }
                if (!checkTier(str, str2)) {
                    Log.w(TAG, str2 + " check failed or locked before race");
                    return false;
                }
                try {
                    JSONObject jSONObject = fetchPlayerInfo(str).getJSONObject("data").getJSONObject("gameData");
                    if (!jSONObject.has("carUsing") || jSONObject.isNull("carUsing")) {
                        return true;
                    }
                    JSONObject jSONObject2 = jSONObject.getJSONObject("carUsing");
                    if (!jSONObject2.has("car") || jSONObject2.isNull("car")) {
                        return true;
                    }
                    JSONObject jSONObject3 = jSONObject2.getJSONObject("car");
                    String strOptString = jSONObject3.optString("code", "");
                    String strOptString2 = jSONObject3.optString("name", "—");
                    if (strOptString.isEmpty()) {
                        strOptString = strOptString2;
                    }
                    this.cachedCarName = strOptString;
                    String strOptString3 = jSONObject3.optString("icon", null);
                    this.cachedCarIcon = strOptString3;
                    if (strOptString3 != null && (strOptString3.isEmpty() || "null".equals(this.cachedCarIcon))) {
                        this.cachedCarIcon = null;
                    }
                    this.cachedStats = jSONObject3.optInt("baseTopSpeed") + " / " + jSONObject3.optInt("baseAcc") + " / " + jSONObject3.optInt("baseNosSpeed");
                    return true;
                } catch (Exception unused) {
                    return true;
                }
            }
            Log.w(TAG, str2 + " no suggested cars before race");
            return false;
        } catch (Exception e) {
            Log.e(TAG, "prepareTierForRace " + str2, e);
            return false;
        }
    }

    private boolean configurePvpMode(String str, String str2) {
        String str3 = "RANK_" + str2;
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/leaderboard/config-pvp?typeItem=" + str3).header("Authorization", "Bearer " + str).header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ_WITH).get().build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                JSONObject jSONObject = strString.isEmpty() ? new JSONObject() : new JSONObject(strString);
                if (responseExecute.isSuccessful() && jSONObject.optBoolean("success", true)) {
                    Log.d(TAG, "PVP mode configured: " + str3);
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return true;
                }
                StringBuilder sb = new StringBuilder();
                sb.append(str3);
                sb.append(" config failed: ");
                sb.append(jSONObject.optString("message", jSONObject.optString("error", "HTTP " + responseExecute.code())));
                Log.w(TAG, sb.toString());
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return false;
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "configurePvpMode " + str3, e);
            return false;
        }
    }

    private JSONArray suggestCars(String str, String str2) {
        Response responseExecute;
        JSONObject jSONObject;
        try {
            responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/game-pvp/suggest-cars/" + str2).header("Authorization", "Bearer " + str).header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ_WITH).get().build()).execute();
            try {
                jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "suggestCars " + str2, e);
        }
        if (!jSONObject.optBoolean("success", false) || jSONObject.optJSONArray("data") == null) {
            if (responseExecute != null) {
                responseExecute.close();
            }
            return new JSONArray();
        }
        JSONArray jSONArray = jSONObject.getJSONArray("data");
        if (responseExecute != null) {
            responseExecute.close();
        }
        return jSONArray;
        Log.e(TAG, "suggestCars " + str2, e);
        return new JSONArray();
    }

    /* JADX WARN: Removed duplicated region for block: B:111:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00ee A[Catch: all -> 0x0235, TryCatch #0 {all -> 0x0235, blocks: (B:22:0x00e8, B:24:0x00ee, B:26:0x00f8, B:28:0x00fe, B:30:0x010a, B:32:0x0110, B:78:0x01f7, B:29:0x0104), top: B:100:0x00e8, outer: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00fe A[Catch: all -> 0x0235, TryCatch #0 {all -> 0x0235, blocks: (B:22:0x00e8, B:24:0x00ee, B:26:0x00f8, B:28:0x00fe, B:30:0x010a, B:32:0x0110, B:78:0x01f7, B:29:0x0104), top: B:100:0x00e8, outer: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0104 A[Catch: all -> 0x0235, TryCatch #0 {all -> 0x0235, blocks: (B:22:0x00e8, B:24:0x00ee, B:26:0x00f8, B:28:0x00fe, B:30:0x010a, B:32:0x0110, B:78:0x01f7, B:29:0x0104), top: B:100:0x00e8, outer: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0152  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x0230 A[Catch: Exception -> 0x0243, TRY_ENTER, TRY_LEAVE, TryCatch #2 {Exception -> 0x0243, blocks: (B:21:0x00de, B:36:0x011d, B:37:0x0120, B:51:0x0155, B:53:0x015c, B:55:0x0166, B:57:0x016c, B:59:0x0172, B:60:0x017a, B:62:0x0180, B:63:0x0186, B:65:0x01a0, B:67:0x01a6, B:69:0x01ac, B:71:0x01b2, B:74:0x01bd, B:76:0x01d6, B:80:0x0230, B:91:0x0242, B:90:0x023f, B:22:0x00e8, B:24:0x00ee, B:26:0x00f8, B:28:0x00fe, B:30:0x010a, B:32:0x0110, B:78:0x01f7, B:29:0x0104, B:86:0x0239), top: B:104:0x00de, inners: #0, #3 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private boolean useSuggestedCar(java.lang.String r23, org.json.JSONObject r24) {
        /*
            Method dump skipped, instruction units count: 600
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CarRacingActivity.useSuggestedCar(java.lang.String, org.json.JSONObject):boolean");
    }

    private boolean checkTier(String str, String str2) throws Exception {
        Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/game-pvp/check/" + str2).header("Authorization", "Bearer " + str).header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ_WITH).get().build()).execute();
        try {
            JSONObject jSONObject = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
            boolean z = false;
            if (jSONObject.optBoolean("success", false)) {
                if (jSONObject.isNull("data")) {
                    z = true;
                }
            }
            if (responseExecute != null) {
                responseExecute.close();
            }
            return z;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private void requestStop() {
        this.stopRequested.set(true);
        stopRaceTimer();
        WebSocket webSocket = this.activeWs;
        if (webSocket != null) {
            try {
                webSocket.close(1000, "stop");
            } catch (Exception unused) {
            }
        }
    }

    private void showPlayingUi() {
        this.contentPicker.setVisibility(8);
        this.contentPlaying.setVisibility(0);
        this.btnAutoPlay.setVisibility(8);
        TextView textView = this.btnStop;
        if (textView != null) {
            textView.setVisibility(0);
        }
        this.tvBigCoin.setText("Waiting...");
        this.tvBigCoin.setTextColor(-1527744);
        SwitchCompat switchCompat = this.switchAlwaysLoopCarRacing;
        if (switchCompat != null) {
            switchCompat.setEnabled(false);
        }
    }

    private void showPickerUi() {
        this.contentPlaying.setVisibility(8);
        this.contentPicker.setVisibility(0);
        this.btnAutoPlay.setVisibility(0);
        this.btnAutoPlay.setEnabled(true);
        this.btnAutoPlay.setAlpha(1.0f);
        TextView textView = this.btnStop;
        if (textView != null) {
            textView.setVisibility(8);
        }
        SwitchCompat switchCompat = this.switchAlwaysLoopCarRacing;
        if (switchCompat != null) {
            switchCompat.setEnabled(true);
        }
        updatePlayButtonLabel();
    }

    private void updatePlayButtonLabel() {
        if (this.btnAutoPlay == null || this.isPlaying.get()) {
            return;
        }
        if (this.alwaysLoopCarRacingEnabled) {
            this.btnAutoPlay.setText("Auto Play Loop");
        } else {
            this.btnAutoPlay.setText("ကစားမည်");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startAutoPlay() {
        boolean z;
        if (this.gameAccessToken == null) {
            Toast.makeText((Context) this, (CharSequence) "Not logged in yet", 0).show();
            return;
        }
        if ("BRONZE".equals(this.selectedTier)) {
            z = this.tierBronzeOk;
        } else {
            z = "SILVER".equals(this.selectedTier) ? this.tierSilverOk : this.tierGoldOk;
        }
        if (!z) {
            Toast.makeText((Context) this, (CharSequence) (this.selectedTier + " is locked"), 0).show();
            return;
        }
        if (this.isPlaying.get()) {
            return;
        }
        this.isPlaying.set(true);
        this.stopRequested.set(false);
        this.raceAccumCoins = 0;
        this.raceAccumRankCoins = 0;
        showPlayingUi();
        this.tvInfoLicense.setText(this.cachedLicense);
        setInfoCar(this.cachedCarName, this.cachedCarIcon);
        this.tvInfoStats.setText(this.cachedStats);
        final String str = this.selectedTier;
        final boolean z2 = this.alwaysLoopCarRacingEnabled;
        final int i = z2 ? Integer.MAX_VALUE : this.selectedCount;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda37
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m181lambda$startAutoPlay$39$comzenoappCarRacingActivity(i, z2, str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$startAutoPlay$39$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m181lambda$startAutoPlay$39$comzenoappCarRacingActivity(final int i, final boolean z, final String str) {
        for (int i2 = 1; i2 <= i && !this.stopRequested.get(); i2++) {
            final int i3 = i2;
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m175lambda$startAutoPlay$33$comzenoappCarRacingActivity(i3, i, z, str);
                }
            });
            if (prepareTierForRace(this.gameAccessToken, str)) {
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda7
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m177lambda$startAutoPlay$35$comzenoappCarRacingActivity();
                    }
                });
                try {
                    playOneRace(this.gameAccessToken, str, i2, i);
                } catch (Exception e) {
                    Log.e(TAG, "playOneRace", e);
                }
                if (i2 < i && !this.stopRequested.get()) {
                    Thread.sleep(DELAY_BETWEEN_GAMES);
                }
            } else {
                Log.w(TAG, "Skip race " + i2 + ": tier setup failed for " + str);
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda6
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m176lambda$startAutoPlay$34$comzenoappCarRacingActivity(str);
                    }
                });
                if (i2 < i && !this.stopRequested.get()) {
                    try {
                        Thread.sleep(DELAY_BETWEEN_GAMES);
                    } catch (InterruptedException unused) {
                    }
                }
            }
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m178lambda$startAutoPlay$36$comzenoappCarRacingActivity();
            }
        });
        String str2 = this.gameAccessToken;
        if (str2 != null) {
            try {
                final JSONObject jSONObjectFetchPlayerInfo = fetchPlayerInfo(str2);
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda9
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m179lambda$startAutoPlay$37$comzenoappCarRacingActivity(jSONObjectFetchPlayerInfo);
                    }
                });
                this.tierBronzeOk = validateTierBeforeMenu(this.gameAccessToken, "BRONZE");
                this.tierSilverOk = validateTierBeforeMenu(this.gameAccessToken, "SILVER");
                this.tierGoldOk = validateTierBeforeMenu(this.gameAccessToken, "GOLD");
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda10
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m180lambda$startAutoPlay$38$comzenoappCarRacingActivity();
                    }
                });
            } catch (Exception e2) {
                Log.e(TAG, "post-session refresh", e2);
            }
        }
    }

    /* JADX INFO: renamed from: lambda$startAutoPlay$33$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m175lambda$startAutoPlay$33$comzenoappCarRacingActivity(int i, int i2, boolean z, String str) {
        prepareRaceUi(i, i2, z);
        this.tvInfoStatus.setText("Preparing " + str + "...");
        setInfoCar(this.cachedCarName, this.cachedCarIcon);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$startAutoPlay$34$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m176lambda$startAutoPlay$34$comzenoappCarRacingActivity(String str) {
        this.tvInfoStatus.setText(str + " setup failed — skipped");
        Toast.makeText((Context) this, (CharSequence) (str + " setup failed, race skipped"), 0).show();
    }

    /* JADX INFO: renamed from: lambda$startAutoPlay$35$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m177lambda$startAutoPlay$35$comzenoappCarRacingActivity() {
        setInfoCar(this.cachedCarName, this.cachedCarIcon);
        this.tvInfoStats.setText(this.cachedStats);
        this.tvInfoLicense.setText(this.cachedLicense);
        this.tvInfoStatus.setText("Joining room...");
    }

    /* JADX INFO: renamed from: lambda$startAutoPlay$36$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m178lambda$startAutoPlay$36$comzenoappCarRacingActivity() {
        stopRaceTimer();
        this.isPlaying.set(false);
        showPickerUi();
    }

    /* JADX INFO: renamed from: lambda$startAutoPlay$38$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m180lambda$startAutoPlay$38$comzenoappCarRacingActivity() {
        selectTier(this.selectedTier);
    }

    private void prepareRaceUi(int i, int i2, boolean z) {
        String str;
        if (z) {
            str = "Current race · " + i + " (Loop)";
        } else {
            str = "Current race · " + i + "/" + i2;
        }
        this.tvCurrentRaceLabel.setText(str);
        this.tvProgressLeft.setText(str);
        this.progressRace.setProgress(0);
        loadProgressCarIcon(this.cachedCarIcon);
        updateProgressCarPosition(0);
        this.tvTimeLeft.setText("Waiting");
        this.tvInfoCoin.setText(iconCoinAmount(this.raceAccumCoins, 14));
        this.tvInfoRankCoin.setText(iconRankAmount(this.raceAccumRankCoins, 16));
        this.tvInfoMap.setText("—");
        this.tvInfoStatus.setText("Connecting...");
        this.tvInfoStartTime.setText("—");
        int i3 = this.raceAccumCoins;
        if (i3 > 0) {
            this.tvBigCoin.setText(iconCoinAmount(i3, 28));
        } else {
            this.tvBigCoin.setText("Waiting...");
        }
    }

    private void startRaceTimer(long j) {
        stopRaceTimer();
        this.raceDurationMs = j;
        this.raceEndAtMs = System.currentTimeMillis() + j;
        Runnable runnable = new Runnable() { // from class: com.zeno.app.CarRacingActivity.1
            @Override // java.lang.Runnable
            public void run() {
                long jCurrentTimeMillis = CarRacingActivity.this.raceEndAtMs - System.currentTimeMillis();
                if (jCurrentTimeMillis < 0) {
                    jCurrentTimeMillis = 0;
                }
                int iMin = (int) Math.min(100L, ((CarRacingActivity.this.raceDurationMs - jCurrentTimeMillis) * 100) / Math.max(1L, CarRacingActivity.this.raceDurationMs));
                CarRacingActivity.this.progressRace.setProgress(iMin);
                CarRacingActivity.this.updateProgressCarPosition(iMin);
                CarRacingActivity.this.tvTimeLeft.setText(CarRacingActivity.formatTimeLeft(jCurrentTimeMillis) + " left");
                if (jCurrentTimeMillis <= 0 || !CarRacingActivity.this.isPlaying.get() || CarRacingActivity.this.stopRequested.get()) {
                    return;
                }
                CarRacingActivity.this.timerHandler.postDelayed(this, 500L);
            }
        };
        this.timerRunnable = runnable;
        this.timerHandler.post(runnable);
    }

    private void stopRaceTimer() {
        Runnable runnable = this.timerRunnable;
        if (runnable != null) {
            this.timerHandler.removeCallbacks(runnable);
            this.timerRunnable = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String formatTimeLeft(long j) {
        long j2 = j / 1000;
        long j3 = j2 / 60;
        long j4 = j2 % 60;
        if (j3 > 0) {
            return j3 + "m " + j4 + "s";
        }
        return j4 + "s";
    }

    private static String formatNumber(int i) {
        return String.format(Locale.US, "%,d", Integer.valueOf(i));
    }

    private CharSequence iconCoinAmount(int i, int i2) {
        int i3 = (int) (i2 * getResources().getDisplayMetrics().density);
        Drawable drawable = getResources().getDrawable(R.drawable.ic_coin, getTheme());
        drawable.setBounds(0, 0, i3, i3);
        SpannableString spannableString = new SpannableString("  " + formatNumber(i));
        spannableString.setSpan(new ImageSpan(drawable, 2), 0, 1, 33);
        return spannableString;
    }

    private CharSequence iconRankAmount(int i, int i2) {
        int i3 = R.drawable.ic_rank_bronze;
        if ("SILVER".equalsIgnoreCase(this.selectedTier)) {
            i3 = R.drawable.ic_rank_silver;
        } else if ("GOLD".equalsIgnoreCase(this.selectedTier)) {
            i3 = R.drawable.ic_rank_gold;
        }
        int i4 = (int) (i2 * getResources().getDisplayMetrics().density);
        Drawable drawable = getResources().getDrawable(i3, getTheme());
        drawable.setBounds(0, 0, i4, i4);
        SpannableString spannableString = new SpannableString("  " + formatNumber(i));
        spannableString.setSpan(new ImageSpan(drawable, 2), 0, 1, 33);
        return spannableString;
    }

    private void playOneRace(final String str, String str2, final int i, final int i2) throws Exception {
        final Object obj = new Object();
        final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
        final AtomicBoolean atomicBoolean2 = new AtomicBoolean(false);
        final AtomicBoolean atomicBoolean3 = new AtomicBoolean(false);
        final int[] iArr = {0};
        final int[] iArr2 = {0};
        final int[] iArr3 = {0};
        final long[] jArr = {0};
        final long[] jArr2 = {0};
        WebSocket webSocketNewWebSocket = this.wsClient.newWebSocket(new Request.Builder().url(WS_URL).header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").build(), new WebSocketListener() { // from class: com.zeno.app.CarRacingActivity.2
            public void onOpen(WebSocket webSocket, Response response) {
                CarRacingActivity.this.activeWs = webSocket;
                webSocket.send(CarRacingActivity.stompFrame("CONNECT", "accept-version:1.1,1.2\nhost:car-racing.mascom.vn\nheart-beat:10000,10000"));
            }

            public void onMessage(WebSocket webSocket, String str3) {
                CarRacingActivity.this.handleStomp(webSocket, str3, str, atomicBoolean, atomicBoolean2, atomicBoolean3, iArr, iArr2, iArr3, jArr, jArr2, obj, i, i2);
            }

            public void onMessage(WebSocket webSocket, ByteString byteString) {
                CarRacingActivity.this.handleStomp(webSocket, byteString.utf8(), str, atomicBoolean, atomicBoolean2, atomicBoolean3, iArr, iArr2, iArr3, jArr, jArr2, obj, i, i2);
            }

            public void onClosing(WebSocket webSocket, int i3, String str3) {
                webSocket.close(1000, (String) null);
            }

            public void onClosed(WebSocket webSocket, int i3, String str3) {
                if (atomicBoolean.get()) {
                    return;
                }
                synchronized (obj) {
                    obj.notifyAll();
                }
            }

            public void onFailure(WebSocket webSocket, Throwable th, Response response) {
                Log.e(CarRacingActivity.TAG, "WS fail", th);
                synchronized (obj) {
                    obj.notifyAll();
                }
            }
        });
        this.activeWs = webSocketNewWebSocket;
        synchronized (obj) {
            long jCurrentTimeMillis = System.currentTimeMillis() + 120000;
            while (!atomicBoolean.get() && System.currentTimeMillis() < jCurrentTimeMillis && !this.stopRequested.get()) {
                obj.wait(2000L);
            }
        }
        stopRaceTimer();
        if (!atomicBoolean.get()) {
            try {
                webSocketNewWebSocket.close(1000, "timeout");
            } catch (Exception unused) {
            }
        } else {
            this.sessionRaces++;
            final int i3 = iArr3[0];
            if (i3 == 1) {
                this.sessionWins++;
            }
            int i4 = this.sessionCoins;
            int i5 = iArr[0];
            this.sessionCoins = i4 + i5;
            final int i6 = this.raceAccumCoins + i5;
            this.raceAccumCoins = i6;
            final int i7 = this.raceAccumRankCoins + iArr2[0];
            this.raceAccumRankCoins = i7;
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m153lambda$playOneRace$40$comzenoappCarRacingActivity(i6, i7, i3);
                }
            });
        }
        this.activeWs = null;
    }

    /* JADX INFO: renamed from: lambda$playOneRace$40$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m153lambda$playOneRace$40$comzenoappCarRacingActivity(int i, int i2, int i3) {
        this.progressRace.setProgress(100);
        updateProgressCarPosition(100);
        this.tvTimeLeft.setText("0s left");
        this.tvInfoCoin.setText(iconCoinAmount(i, 14));
        this.tvInfoRankCoin.setText(iconRankAmount(i2, 16));
        this.tvInfoStatus.setText("Finished · Rank " + i3);
        this.tvBigCoin.setText(iconCoinAmount(i, 28));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:127:0x034d  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x019b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void handleStomp(final okhttp3.WebSocket r18, java.lang.String r19, final java.lang.String r20, final java.util.concurrent.atomic.AtomicBoolean r21, java.util.concurrent.atomic.AtomicBoolean r22, java.util.concurrent.atomic.AtomicBoolean r23, int[] r24, int[] r25, int[] r26, final long[] r27, long[] r28, java.lang.Object r29, int r30, int r31) {
        /*
            Method dump skipped, instruction units count: 1050
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CarRacingActivity.handleStomp(okhttp3.WebSocket, java.lang.String, java.lang.String, java.util.concurrent.atomic.AtomicBoolean, java.util.concurrent.atomic.AtomicBoolean, java.util.concurrent.atomic.AtomicBoolean, int[], int[], int[], long[], long[], java.lang.Object, int, int):void");
    }

    /* JADX INFO: renamed from: lambda$handleStomp$42$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m137lambda$handleStomp$42$comzenoappCarRacingActivity(String str, long[] jArr, WebSocket webSocket) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("accessToken", str);
            jSONObject.put("data", PAYLOAD_JOIN);
            jArr[0] = System.currentTimeMillis();
            webSocket.send(stompFrame("SEND", "destination:/app/room/join\nAccept-Language:en", jSONObject.toString()));
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m136lambda$handleStomp$41$comzenoappCarRacingActivity();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "join send", e);
        }
    }

    /* JADX INFO: renamed from: lambda$handleStomp$41$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m136lambda$handleStomp$41$comzenoappCarRacingActivity() {
        this.tvInfoStatus.setText("Joining room...");
    }

    /* JADX INFO: renamed from: lambda$handleStomp$43$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m138lambda$handleStomp$43$comzenoappCarRacingActivity() {
        this.tvInfoStatus.setText("Waiting for server start...");
    }

    /* JADX INFO: renamed from: lambda$handleStomp$44$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m139lambda$handleStomp$44$comzenoappCarRacingActivity(String str) {
        this.tvInfoStatus.setText("Error: " + str);
    }

    /* JADX INFO: renamed from: lambda$handleStomp$45$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m140lambda$handleStomp$45$comzenoappCarRacingActivity(String str, String str2, String str3, String str4, int i) {
        this.tvInfoMap.setText(str);
        setInfoCar(str2, str3);
        loadProgressCarIcon(str3);
        updateProgressCarPosition(0);
        this.tvInfoStartTime.setText(str4);
        this.tvInfoStatus.setText("Active · HP " + i + "%");
        this.progressRace.setProgress(0);
        this.tvTimeLeft.setText("Waiting");
    }

    /* JADX INFO: renamed from: lambda$handleStomp$46$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m141lambda$handleStomp$46$comzenoappCarRacingActivity(long j) {
        this.tvInfoStatus.setText("Racing...");
        startRaceTimer(j);
    }

    /* JADX INFO: renamed from: lambda$handleStomp$47$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m142lambda$handleStomp$47$comzenoappCarRacingActivity(long j, AtomicBoolean atomicBoolean, String str, WebSocket webSocket) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
        if (this.stopRequested.get() || atomicBoolean.get()) {
            return;
        }
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("accessToken", str);
            jSONObject.put("data", PAYLOAD_END);
            webSocket.send(stompFrame("SEND", "destination:/app/room/end", jSONObject.toString()));
        } catch (Exception e) {
            Log.e(TAG, "end send", e);
        }
    }

    /* JADX INFO: renamed from: lambda$handleStomp$48$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m143lambda$handleStomp$48$comzenoappCarRacingActivity(int i, int i2) {
        this.tvInfoCoin.setText(iconCoinAmount(this.raceAccumCoins + i, 14));
        this.tvInfoRankCoin.setText(iconRankAmount(this.raceAccumRankCoins + i2, 16));
        if (i > 0) {
            this.tvBigCoin.setText(iconCoinAmount(this.raceAccumCoins + i, 28));
        }
    }

    /* JADX INFO: renamed from: lambda$handleStomp$49$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m144lambda$handleStomp$49$comzenoappCarRacingActivity(int i, int i2, int i3) {
        this.tvInfoCoin.setText(iconCoinAmount(i, 14));
        this.tvInfoRankCoin.setText(iconRankAmount(i2, 16));
        this.tvBigCoin.setText(iconCoinAmount(i, 28));
        this.tvInfoStatus.setText("Finished · Rank " + i3);
        this.progressRace.setProgress(100);
        updateProgressCarPosition(100);
        this.tvTimeLeft.setText("0s left");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static String stompFrame(String str, String str2) {
        return str + "\n" + str2 + "\n\n\u0000";
    }

    private static String stompFrame(String str, String str2, String str3) {
        return str + "\n" + str2 + "\n\n" + str3 + "\u0000";
    }

    private String normalizeMediaUrl(String str) {
        if (str == null) {
            return null;
        }
        String strTrim = str.trim();
        if (strTrim.isEmpty() || "null".equalsIgnoreCase(strTrim)) {
            return null;
        }
        if (strTrim.startsWith("//")) {
            return "https:" + strTrim;
        }
        if (strTrim.startsWith("/")) {
            return "https://minio.mascom.vn" + strTrim;
        }
        if (strTrim.startsWith("http://") || strTrim.startsWith("https://")) {
            return strTrim;
        }
        return "https://minio.mascom.vn/" + strTrim;
    }

    private Object glideLoadModel(String str) {
        String strNormalizeMediaUrl = normalizeMediaUrl(str);
        if (strNormalizeMediaUrl == null) {
            return null;
        }
        return new GlideUrl(strNormalizeMediaUrl, new LazyHeaders.Builder().addHeader("User-Agent", USER_AGENT).addHeader("Accept", "image/*,*/*").addHeader("Referer", "https://car-racing.mascom.vn/").build());
    }

    private void loadAvatar(String str) {
        if (this.ivAvatar == null) {
            return;
        }
        Object objGlideLoadModel = glideLoadModel(str);
        if (objGlideLoadModel == null) {
            this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
            return;
        }
        try {
            Glide.with(getApplicationContext()).load(objGlideLoadModel).apply(new RequestOptions().circleCrop().placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(this.ivAvatar);
        } catch (Exception e) {
            Log.e(TAG, "loadAvatar", e);
            this.ivAvatar.setImageResource(R.drawable.ic_default_avatar);
        }
    }

    private void setInfoCar(String str, String str2) {
        TextView textView = this.tvInfoCar;
        if (textView != null) {
            if (str == null || str.isEmpty()) {
                str = "—";
            }
            textView.setText(str);
        }
        if (this.ivInfoCar == null) {
            return;
        }
        if (str2 == null) {
            str2 = this.cachedCarIcon;
        }
        Object objGlideLoadModel = glideLoadModel(str2);
        if (objGlideLoadModel == null) {
            this.ivInfoCar.setVisibility(8);
            return;
        }
        this.ivInfoCar.setVisibility(0);
        try {
            Glide.with(getApplicationContext()).load(objGlideLoadModel).placeholder(android.R.color.transparent).error(android.R.color.transparent).into(this.ivInfoCar);
        } catch (Exception e) {
            Log.e(TAG, "setInfoCar", e);
            this.ivInfoCar.setVisibility(8);
        }
    }

    private void loadProgressCarIcon(String str) {
        if (this.ivProgressCar == null) {
            return;
        }
        if (str == null || str.isEmpty() || "null".equalsIgnoreCase(str)) {
            str = this.cachedCarIcon;
        }
        Object objGlideLoadModel = glideLoadModel(str);
        if (objGlideLoadModel == null) {
            this.ivProgressCar.setVisibility(8);
            return;
        }
        this.ivProgressCar.setVisibility(0);
        this.ivProgressCar.setScaleX(-1.0f);
        try {
            Glide.with(getApplicationContext()).load(objGlideLoadModel).placeholder(android.R.color.transparent).error(android.R.color.transparent).into(this.ivProgressCar);
        } catch (Exception e) {
            Log.e(TAG, "loadProgressCarIcon", e);
            this.ivProgressCar.setVisibility(8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateProgressCarPosition(final int i) {
        ImageView imageView = this.ivProgressCar;
        if (imageView == null || this.progressRaceContainer == null) {
            return;
        }
        if (imageView.getVisibility() != 0) {
            String str = this.cachedCarIcon;
            if (str != null) {
                loadProgressCarIcon(str);
            }
            if (this.ivProgressCar.getVisibility() != 0) {
                return;
            }
        }
        this.progressRaceContainer.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda28
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m182lambda$updateProgressCarPosition$50$comzenoappCarRacingActivity(i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$updateProgressCarPosition$50$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m182lambda$updateProgressCarPosition$50$comzenoappCarRacingActivity(int i) {
        int width = this.progressRaceContainer.getWidth();
        int width2 = this.ivProgressCar.getWidth();
        if (width <= 0) {
            return;
        }
        if (width2 <= 0) {
            width2 = (int) (getResources().getDisplayMetrics().density * 36.0f);
        }
        this.ivProgressCar.setTranslationX(Math.max(0, width - width2) * (Math.max(0, Math.min(100, i)) / 100.0f));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openLuckySpin() {
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ၊ ခဏစောင့်ပြီး ထပ်နှိပ်ပါ", 0).show();
            loginAndLoad();
            return;
        }
        try {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.zeno.app.CarRacingSpinActivity");
            intent.putExtra("gameToken", this.gameAccessToken);
            intent.putExtra("coins", this.cachedCoins);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "openLuckySpin", e);
            Toast.makeText((Context) this, (CharSequence) ("Spin page ဖွင့်မရပါ: " + e.getMessage()), 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openGemShop() {
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ၊ ခဏစောင့်ပြီး ထပ်နှိပ်ပါ", 0).show();
            loginAndLoad();
            return;
        }
        try {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.zeno.app.CarRacingGemShopActivity");
            intent.putExtra("gameToken", this.gameAccessToken);
            intent.putExtra("gems", this.cachedGems);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "openGemShop", e);
            Toast.makeText((Context) this, (CharSequence) ("Gem Shop ဖွင့်မရပါ: " + e.getMessage()), 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openPackageShop() {
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ၊ ခဏစောင့်ပြီး ထပ်နှိပ်ပါ", 0).show();
            loginAndLoad();
            return;
        }
        try {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.zeno.app.CarRacingPackageShopActivity");
            intent.putExtra("gameToken", this.gameAccessToken);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "openPackageShop", e);
            Toast.makeText((Context) this, (CharSequence) ("Shop ဖွင့်မရပါ: " + e.getMessage()), 0).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void openRewards() {
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ၊ ခဏစောင့်ပြီး ထပ်နှိပ်ပါ", 0).show();
            loginAndLoad();
            return;
        }
        try {
            Intent intent = new Intent();
            intent.setClassName(getPackageName(), "com.zeno.app.CarRacingRewardsActivity");
            intent.putExtra("gameToken", this.gameAccessToken);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "openRewards", e);
            Toast.makeText((Context) this, (CharSequence) ("Rewards ဖွင့်မရပါ: " + e.getMessage()), 0).show();
        }
    }

    private void startGiftPulse(View view) {
        try {
            ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_X, 1.0f, 1.18f, 1.0f);
            ObjectAnimator objectAnimatorOfFloat2 = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.SCALE_Y, 1.0f, 1.18f, 1.0f);
            objectAnimatorOfFloat.setDuration(900L);
            objectAnimatorOfFloat2.setDuration(900L);
            objectAnimatorOfFloat.setRepeatCount(-1);
            objectAnimatorOfFloat2.setRepeatCount(-1);
            objectAnimatorOfFloat.setInterpolator(new AccelerateDecelerateInterpolator());
            objectAnimatorOfFloat2.setInterpolator(new AccelerateDecelerateInterpolator());
            objectAnimatorOfFloat.start();
            objectAnimatorOfFloat2.start();
        } catch (Exception e) {
            Log.w(TAG, "gift pulse", e);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r18v0, types: [android.content.Context, com.zeno.app.CarRacingActivity] */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v2, types: [android.content.Context] */
    /* JADX WARN: Type inference failed for: r2v24 */
    /* JADX WARN: Type inference failed for: r2v25 */
    /* JADX WARN: Type inference failed for: r2v4 */
    /* JADX WARN: Type inference failed for: r2v7 */
    private void showEditNameDialog() {
        ?? r2;
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, "Login မပြီးသေးပါ၊ ခဏစောင့်ပြီး ထပ်နှိပ်ပါ", 0).show();
            loginAndLoad();
            return;
        }
        try {
            final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog.requestWindowFeature(1);
            int i = R.layout.dialog_edit_name;
            dialog.setContentView(i);
            dialog.setCancelable(true);
            dialog.setCanceledOnTouchOutside(true);
            Window window = dialog.getWindow();
            r2 = i;
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.9f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
                r2 = attributes;
            }
            final EditText editText = (EditText) dialog.findViewById(R.id.etName);
            ImageView imageView = (ImageView) dialog.findViewById(R.id.btnCloseDialog);
            final Button button = (Button) dialog.findViewById(R.id.btnChangeName);
            final TextView textView = (TextView) dialog.findViewById(R.id.tabName);
            final TextView textView2 = (TextView) dialog.findViewById(R.id.tabPicture);
            final View viewFindViewById = dialog.findViewById(R.id.panelName);
            final View viewFindViewById2 = dialog.findViewById(R.id.panelPicture);
            final ProgressBar progressBar = (ProgressBar) dialog.findViewById(R.id.pbAvatarLoading);
            final GridLayout gridLayout = (GridLayout) dialog.findViewById(R.id.gridAvatars);
            try {
                if (editText != null && imageView != null && button != null && textView != null && textView2 != null && viewFindViewById != null && viewFindViewById2 != null && gridLayout != null) {
                    TextView textView3 = this.tvProfileName;
                    String string = textView3 != null ? textView3.getText().toString() : "";
                    if (string != null && !string.equals("—") && !string.equals("---") && !string.isEmpty()) {
                        editText.setText(string);
                        editText.setSelection(string.length());
                    }
                    final Runnable runnable = new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda0
                        @Override // java.lang.Runnable
                        public final void run() {
                            CarRacingActivity.lambda$showEditNameDialog$51(viewFindViewById, viewFindViewById2, textView, textView2);
                        }
                    };
                    try {
                        final Runnable runnable2 = new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda11
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.m170lambda$showEditNameDialog$52$comzenoappCarRacingActivity(viewFindViewById, viewFindViewById2, textView2, textView, gridLayout, dialog, progressBar);
                            }
                        };
                        textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda22
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                runnable.run();
                            }
                        });
                        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda33
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                runnable2.run();
                            }
                        });
                        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda44
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                dialog.dismiss();
                            }
                        });
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda55
                            @Override // android.view.View.OnClickListener
                            public final void onClick(View view) {
                                this.f$0.m174lambda$showEditNameDialog$59$comzenoappCarRacingActivity(editText, button, dialog, view);
                            }
                        });
                        runnable.run();
                        dialog.show();
                        return;
                    } catch (Exception e) {
                        e = e;
                        r2 = this;
                        Log.e(TAG, "showEditNameDialog", e);
                        Toast.makeText((Context) r2, "Dialog ဖွင့်မရပါ: " + e.getMessage(), 0).show();
                        return;
                    }
                }
                Toast.makeText((Context) this, "Dialog layout error", 0).show();
            } catch (Exception e2) {
                e = e2;
            }
        } catch (Exception e3) {
            e = e3;
            r2 = this;
        }
    }

    static /* synthetic */ void lambda$showEditNameDialog$51(View view, View view2, TextView textView, TextView textView2) {
        view.setVisibility(0);
        view2.setVisibility(8);
        textView.setBackgroundResource(R.drawable.bg_tab_active);
        textView.setTextColor(-16777216);
        textView.setTypeface(null, 1);
        textView2.setBackgroundResource(android.R.color.transparent);
        textView2.setTextColor(-5592406);
        textView2.setTypeface(null, 0);
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$52$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m170lambda$showEditNameDialog$52$comzenoappCarRacingActivity(View view, View view2, TextView textView, TextView textView2, GridLayout gridLayout, Dialog dialog, ProgressBar progressBar) {
        view.setVisibility(8);
        view2.setVisibility(0);
        textView.setBackgroundResource(R.drawable.bg_tab_active);
        textView.setTextColor(-16777216);
        textView.setTypeface(null, 1);
        textView2.setBackgroundResource(android.R.color.transparent);
        textView2.setTextColor(-5592406);
        textView2.setTypeface(null, 0);
        if (gridLayout.getChildCount() == 0) {
            loadAvatarsIntoGrid(dialog, gridLayout, progressBar);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showEditNameDialog$59$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m174lambda$showEditNameDialog$59$comzenoappCarRacingActivity(EditText editText, final Button button, final Dialog dialog, View view) {
        final String strTrim = editText.getText().toString().trim();
        if (strTrim.isEmpty()) {
            editText.setError("Name ထည့်ပါ");
            return;
        }
        String str = this.gameAccessToken;
        if (str == null || str.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ", 0).show();
            return;
        }
        button.setEnabled(false);
        final String str2 = this.gameAccessToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda43
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m173lambda$showEditNameDialog$58$comzenoappCarRacingActivity(strTrim, str2, dialog, button);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEditNameDialog$58$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m173lambda$showEditNameDialog$58$comzenoappCarRacingActivity(final String str, String str2, final Dialog dialog, final Button button) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("playerName", str);
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/user/player-name").header("Authorization", "Bearer " + str2).header("Content-Type", "application/json").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ_WITH).put(RequestBody.create(jSONObject.toString(), MediaType.parse("application/json"))).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                final boolean z = responseExecute.isSuccessful() && new JSONObject(strString).optBoolean("success", true);
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m171lambda$showEditNameDialog$56$comzenoappCarRacingActivity(z, str, dialog, button);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda4
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m172lambda$showEditNameDialog$57$comzenoappCarRacingActivity(button, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showEditNameDialog$56$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m171lambda$showEditNameDialog$56$comzenoappCarRacingActivity(boolean z, String str, Dialog dialog, Button button) {
        if (!z) {
            button.setEnabled(true);
            Toast.makeText((Context) this, (CharSequence) "ပြောင်းမရပါ၊ ထပ်ကြိုးစားပါ", 0).show();
            return;
        }
        TextView textView = this.tvProfileName;
        if (textView != null) {
            textView.setText(str);
        }
        dialog.dismiss();
        Toast.makeText((Context) this, (CharSequence) "Name ပြောင်းပြီးပါပြီ", 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showEditNameDialog$57$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m172lambda$showEditNameDialog$57$comzenoappCarRacingActivity(Button button, Exception exc) {
        button.setEnabled(true);
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void loadAvatarsIntoGrid(final Dialog dialog, final GridLayout gridLayout, final ProgressBar progressBar) {
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
        gridLayout.removeAllViews();
        final String str = this.gameAccessToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda66
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m147lambda$loadAvatarsIntoGrid$62$comzenoappCarRacingActivity(str, progressBar, dialog, gridLayout);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loadAvatarsIntoGrid$62$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m147lambda$loadAvatarsIntoGrid$62$comzenoappCarRacingActivity(String str, final ProgressBar progressBar, final Dialog dialog, final GridLayout gridLayout) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/avatar/list").header("Authorization", "Bearer " + str).header("Accept", "*/*").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ_WITH).get().build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONArray jSONArrayOptJSONArray = new JSONObject(strString).optJSONArray("data");
                if (jSONArrayOptJSONArray == null) {
                    jSONArrayOptJSONArray = new JSONArray();
                }
                final JSONArray jSONArray = jSONArrayOptJSONArray;
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda41
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m145lambda$loadAvatarsIntoGrid$60$comzenoappCarRacingActivity(progressBar, dialog, gridLayout, jSONArray);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "loadAvatars", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda42
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m146lambda$loadAvatarsIntoGrid$61$comzenoappCarRacingActivity(progressBar);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loadAvatarsIntoGrid$60$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m145lambda$loadAvatarsIntoGrid$60$comzenoappCarRacingActivity(ProgressBar progressBar, Dialog dialog, GridLayout gridLayout, JSONArray jSONArray) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        if (dialog.isShowing()) {
            populateAvatarGrid(dialog, gridLayout, jSONArray);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$loadAvatarsIntoGrid$61$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m146lambda$loadAvatarsIntoGrid$61$comzenoappCarRacingActivity(ProgressBar progressBar) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        Toast.makeText((Context) this, (CharSequence) "Avatar list မရပါ", 0).show();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0195 A[Catch: Exception -> 0x01b8, TRY_LEAVE, TryCatch #2 {Exception -> 0x01b8, blocks: (B:22:0x00b6, B:25:0x00be, B:29:0x00f1, B:31:0x00f7, B:33:0x00fe, B:61:0x0195, B:37:0x0111, B:39:0x0116, B:41:0x0124, B:45:0x0131, B:51:0x014f, B:56:0x0182), top: B:81:0x00b6 }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x01ae  */
    /* JADX WARN: Type inference failed for: r14v0 */
    /* JADX WARN: Type inference failed for: r14v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r14v2 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void populateAvatarGrid(final android.app.Dialog r23, final android.widget.GridLayout r24, org.json.JSONArray r25) {
        /*
            Method dump skipped, instruction units count: 474
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.CarRacingActivity.populateAvatarGrid(android.app.Dialog, android.widget.GridLayout, org.json.JSONArray):void");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$populateAvatarGrid$63$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m154lambda$populateAvatarGrid$63$comzenoappCarRacingActivity(boolean z, boolean z2, String str, int i, Dialog dialog, GridLayout gridLayout, int i2, String str2, View view) {
        CharSequence charSequence;
        if (z) {
            Toast.makeText((Context) this, (CharSequence) "အခုသုံးနေတဲ့ avatar ပါ", 0).show();
            return;
        }
        if (z2) {
            charSequence = "ဒီ avatar ကို သုံးမလား?";
        } else {
            Drawable drawable = getResources().getDrawable("GEM".equalsIgnoreCase(str) ? R.drawable.ic_gem : R.drawable.ic_coin, getTheme());
            int i3 = (int) (getResources().getDisplayMetrics().density * 14.0f);
            drawable.setBounds(0, 0, i3, i3);
            String str3 = i + " ";
            SpannableString spannableString = new SpannableString(str3 + "  နဲ့ ဝယ်ပြီး သုံးမလား?");
            ImageSpan imageSpan = new ImageSpan(drawable, 2);
            int length = str3.length();
            spannableString.setSpan(imageSpan, length, length + 1, 33);
            charSequence = spannableString;
        }
        showAvatarConfirmDialog(dialog, gridLayout, i2, str2, charSequence);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showAvatarConfirmDialog(final Dialog dialog, final GridLayout gridLayout, final int i, final String str, CharSequence charSequence) {
        Object objGlideLoadModel;
        try {
            final Dialog dialog2 = new Dialog(this, R.style.Theme_ZenoMyID);
            dialog2.requestWindowFeature(1);
            dialog2.setContentView(R.layout.dialog_avatar_confirm);
            dialog2.setCancelable(true);
            dialog2.setCanceledOnTouchOutside(true);
            Window window = dialog2.getWindow();
            if (window != null) {
                window.setBackgroundDrawableResource(android.R.color.transparent);
                window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.82f), -2);
                window.setGravity(17);
                window.addFlags(2);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.65f;
                window.setAttributes(attributes);
            }
            ImageView imageView = (ImageView) dialog2.findViewById(R.id.ivConfirmAvatar);
            TextView textView = (TextView) dialog2.findViewById(R.id.tvConfirmMessage);
            ImageView imageView2 = (ImageView) dialog2.findViewById(R.id.btnCloseAvatarConfirm);
            TextView textView2 = (TextView) dialog2.findViewById(R.id.btnConfirmCancel);
            TextView textView3 = (TextView) dialog2.findViewById(R.id.btnConfirmOk);
            if (textView != null) {
                textView.setText(charSequence);
            }
            if (imageView != null && (objGlideLoadModel = glideLoadModel(str)) != null) {
                Glide.with(getApplicationContext()).load(objGlideLoadModel).apply(RequestOptions.bitmapTransform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(imageView);
            }
            View.OnClickListener onClickListener = new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda74
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog2.dismiss();
                }
            };
            if (imageView2 != null) {
                imageView2.setOnClickListener(onClickListener);
            }
            if (textView2 != null) {
                textView2.setOnClickListener(onClickListener);
            }
            if (textView3 != null) {
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m169lambda$showAvatarConfirmDialog$65$comzenoappCarRacingActivity(dialog2, dialog, gridLayout, i, str, view);
                    }
                });
            }
            dialog2.show();
        } catch (Exception e) {
            Log.e(TAG, "showAvatarConfirmDialog", e);
            buyOrUseAvatar(dialog, gridLayout, (ProgressBar) dialog.findViewById(R.id.pbAvatarLoading), i, str);
        }
    }

    /* JADX INFO: renamed from: lambda$showAvatarConfirmDialog$65$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m169lambda$showAvatarConfirmDialog$65$comzenoappCarRacingActivity(Dialog dialog, Dialog dialog2, GridLayout gridLayout, int i, String str, View view) {
        dialog.dismiss();
        buyOrUseAvatar(dialog2, gridLayout, (ProgressBar) dialog2.findViewById(R.id.pbAvatarLoading), i, str);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buyOrUseAvatar(final Dialog dialog, final GridLayout gridLayout, final ProgressBar progressBar, final int i, final String str) {
        String str2 = this.gameAccessToken;
        if (str2 == null || str2.isEmpty()) {
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ", 0).show();
            return;
        }
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
        final String str3 = this.gameAccessToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda73
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m129lambda$buyOrUseAvatar$70$comzenoappCarRacingActivity(i, str3, progressBar, str, dialog, gridLayout);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyOrUseAvatar$70$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m129lambda$buyOrUseAvatar$70$comzenoappCarRacingActivity(int i, String str, final ProgressBar progressBar, final String str2, final Dialog dialog, final GridLayout gridLayout) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/avatar/buy/" + i).header("Authorization", "Bearer " + str).header("Accept", "*/*").header("Content-Type", "application/json").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ_WITH).get().build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (strString.isEmpty()) {
                    strString = "{}";
                }
                JSONObject jSONObject = new JSONObject(strString);
                final boolean z = responseExecute.isSuccessful() && jSONObject.optBoolean("success", false);
                final String strOptString = jSONObject.optString("error", "");
                final String strOptString2 = jSONObject.optString("message", "");
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda70
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m127lambda$buyOrUseAvatar$68$comzenoappCarRacingActivity(progressBar, z, strOptString, str2, dialog, gridLayout, strOptString2);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            Log.e(TAG, "buyOrUseAvatar", e);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda71
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m128lambda$buyOrUseAvatar$69$comzenoappCarRacingActivity(progressBar, e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyOrUseAvatar$68$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m127lambda$buyOrUseAvatar$68$comzenoappCarRacingActivity(ProgressBar progressBar, boolean z, String str, String str2, Dialog dialog, GridLayout gridLayout, String str3) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        if (!z && !"00000".equals(str)) {
            if (str3 == null || str3.isEmpty()) {
                str3 = "Avatar ပြောင်းမရပါ";
            }
            Toast.makeText((Context) this, (CharSequence) str3, 0).show();
            return;
        }
        loadAvatar(str2);
        Toast.makeText((Context) this, (CharSequence) "Avatar ပြောင်းပြီးပါပြီ", 0).show();
        loadAvatarsIntoGrid(dialog, gridLayout, progressBar);
        final String str4 = this.gameAccessToken;
        if (str4 != null) {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda68
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m126lambda$buyOrUseAvatar$67$comzenoappCarRacingActivity(str4);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$buyOrUseAvatar$67$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m126lambda$buyOrUseAvatar$67$comzenoappCarRacingActivity(String str) {
        try {
            final JSONObject jSONObjectFetchPlayerInfo = fetchPlayerInfo(str);
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda72
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m125lambda$buyOrUseAvatar$66$comzenoappCarRacingActivity(jSONObjectFetchPlayerInfo);
                }
            });
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyOrUseAvatar$69$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m128lambda$buyOrUseAvatar$69$comzenoappCarRacingActivity(ProgressBar progressBar, Exception exc) {
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void showPlayTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(0);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(-3632086);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(0);
        }
        TextView textView = this.tvTabPlay;
        if (textView != null) {
            textView.setTextColor(-3632086);
            this.tvTabPlay.setTypeface(null, 1);
        }
        TextView textView2 = this.tvTabRank;
        if (textView2 != null) {
            textView2.setTextColor(-7829368);
            this.tvTabRank.setTypeface(null, 0);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-3632086);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-7829368);
        }
    }

    private void showRankTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(0);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(-3632086);
        }
        TextView textView = this.tvTabPlay;
        if (textView != null) {
            textView.setTextColor(-7829368);
            this.tvTabPlay.setTypeface(null, 0);
        }
        TextView textView2 = this.tvTabRank;
        if (textView2 != null) {
            textView2.setTextColor(-3632086);
            this.tvTabRank.setTypeface(null, 1);
        }
        ImageView imageView = (ImageView) findViewById(R.id.ivTabPlay);
        ImageView imageView2 = (ImageView) findViewById(R.id.ivTabRank);
        if (imageView != null) {
            imageView.setColorFilter(-7829368);
        }
        if (imageView2 != null) {
            imageView2.setColorFilter(-3632086);
        }
        LinearLayout linearLayout = this.rankList;
        if (linearLayout == null || linearLayout.getChildCount() != 0) {
            return;
        }
        fetchCarLeaderboard(this.rankTab);
    }

    private void switchRankTab(int i) {
        LinearLayout linearLayout;
        if (this.rankTab != i || (linearLayout = this.rankList) == null || linearLayout.getChildCount() <= 0) {
            this.rankTab = i;
            styleRankSubTabs();
            fetchCarLeaderboard(i);
        }
    }

    private void styleRankSubTabs() {
        styleRankChip(this.btnRankBronze, this.rankTab == 0);
        styleRankChip(this.btnRankSilver, this.rankTab == 1);
        styleRankChip(this.btnRankGold, this.rankTab == 2);
        styleRankChip(this.btnRankMonthly, this.rankTab == 3);
    }

    private void styleRankChip(TextView textView, boolean z) {
        if (textView == null) {
            return;
        }
        if (z) {
            textView.setBackgroundResource(R.drawable.bg_game_count_selected);
            textView.setTextColor(-3632086);
            textView.setTypeface(null, 1);
        } else {
            textView.setBackgroundResource(R.drawable.bg_game_count_normal);
            textView.setTextColor(-7829368);
            textView.setTypeface(null, 0);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void fetchCarLeaderboard(int i) {
        String str;
        final String strConcat;
        LinearLayout linearLayout = this.rankList;
        if (linearLayout != null) {
            linearLayout.removeAllViews();
        }
        View view = this.rankUserFooter;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.rankLoading;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        this.rankSkeletonAnim = SkeletonPulse.start(this.rankLoading);
        TextView textView = this.tvRankExpire;
        if (textView != null) {
            textView.setVisibility(8);
        }
        String str2 = this.gameAccessToken;
        if (str2 == null || str2.isEmpty()) {
            if (this.rankLoading != null) {
                stopRankSkeleton();
            }
            Toast.makeText((Context) this, (CharSequence) "Login မပြီးသေးပါ", 0).show();
            return;
        }
        if (i == 3) {
            strConcat = "https://car-racing.mascom.vn/api/leaderboard/type?typeConfigRank=RANK_MONTH";
        } else {
            if (i == 0) {
                str = "RANK_BRONZE";
            } else {
                str = i == 1 ? "RANK_SILVER" : "RANK_GOLD";
            }
            strConcat = "https://car-racing.mascom.vn/api/leaderboard/type?typeConfigRank=RANK_WEEK&typeRank=".concat(str);
        }
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda32
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m135lambda$fetchCarLeaderboard$74$comzenoappCarRacingActivity(strConcat);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchCarLeaderboard$74$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m135lambda$fetchCarLeaderboard$74$comzenoappCarRacingActivity(String str) {
        try {
            final Response responseExecute = this.http.newCall(new Request.Builder().url(str).get().header("Authorization", "Bearer " + this.gameAccessToken).header("Accept", "*/*").header("Content-Type", "application/json").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ_WITH).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (!responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda34
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m132lambda$fetchCarLeaderboard$71$comzenoappCarRacingActivity(responseExecute);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                JSONObject jSONObjectOptJSONObject = new JSONObject(strString).optJSONObject("data");
                final JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("listUserRank") : null;
                final JSONObject jSONObjectOptJSONObject2 = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONObject("userRank") : null;
                final String strOptString = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("timeExpire", "") : "";
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda35
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m133lambda$fetchCarLeaderboard$72$comzenoappCarRacingActivity(strOptString, jSONArrayOptJSONArray, jSONObjectOptJSONObject2);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingActivity$$ExternalSyntheticLambda36
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m134lambda$fetchCarLeaderboard$73$comzenoappCarRacingActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$fetchCarLeaderboard$71$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m132lambda$fetchCarLeaderboard$71$comzenoappCarRacingActivity(Response response) {
        if (this.rankLoading != null) {
            stopRankSkeleton();
        }
        Toast.makeText((Context) this, (CharSequence) ("Leaderboard error " + response.code()), 0).show();
    }

    /* JADX INFO: renamed from: lambda$fetchCarLeaderboard$72$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m133lambda$fetchCarLeaderboard$72$comzenoappCarRacingActivity(String str, JSONArray jSONArray, JSONObject jSONObject) {
        if (isFinishing()) {
            return;
        }
        if (this.rankLoading != null) {
            stopRankSkeleton();
        }
        if (this.tvRankExpire != null && str != null && !str.isEmpty()) {
            this.tvRankExpire.setText("⏳ Expire: " + str.replace("T", " ").replace(".000", ""));
            this.tvRankExpire.setVisibility(0);
        }
        renderCarLeaderboard(jSONArray, jSONObject);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$fetchCarLeaderboard$73$com-zeno-app-CarRacingActivity, reason: not valid java name */
    /* synthetic */ void m134lambda$fetchCarLeaderboard$73$comzenoappCarRacingActivity(Exception exc) {
        if (this.rankLoading != null) {
            stopRankSkeleton();
        }
        Toast.makeText((Context) this, (CharSequence) ("Network: " + exc.getMessage()), 0).show();
    }

    private void renderCarLeaderboard(JSONArray jSONArray, JSONObject jSONObject) {
        LinearLayout linearLayout;
        LinearLayout linearLayout2 = this.rankList;
        if (linearLayout2 == null) {
            return;
        }
        linearLayout2.removeAllViews();
        if (jSONArray != null) {
            for (int i = 0; i < jSONArray.length(); i++) {
                JSONObject jSONObjectOptJSONObject = jSONArray.optJSONObject(i);
                if (jSONObjectOptJSONObject != null) {
                    this.rankList.addView(buildRankRow(jSONObjectOptJSONObject, false));
                }
            }
        }
        if (jSONObject == null || (linearLayout = this.rankUserRow) == null || this.rankUserFooter == null) {
            return;
        }
        linearLayout.removeAllViews();
        this.rankUserRow.addView(buildRankRow(jSONObject, true));
        this.rankUserFooter.setVisibility(0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private View buildRankRow(JSONObject jSONObject, boolean z) {
        long j;
        long j2;
        JSONArray jSONArray;
        int i;
        int iOptInt = jSONObject.optInt("rank", 0);
        long jOptLong = jSONObject.optLong("score", 0L);
        String strOptString = jSONObject.optString("username", "---");
        String strOptString2 = jSONObject.optString("avatar", null);
        if ("null".equals(strOptString2) || (strOptString2 != null && strOptString2.isEmpty())) {
            strOptString2 = null;
        }
        int i2 = (int) getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(0);
        linearLayout.setGravity(16);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        if (!z) {
            layoutParams.setMargins(0, 0, 0, i2 * 6);
        }
        linearLayout.setLayoutParams(layoutParams);
        int i3 = i2 * 8;
        int i4 = i2 * 10;
        linearLayout.setPadding(i3, i4, i3, i4);
        linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
        if (iOptInt >= 1 && iOptInt <= 3) {
            ImageView imageView = new ImageView(this);
            int i5 = i2 * 40;
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i5, i5);
            layoutParams2.setMarginEnd(i3);
            imageView.setLayoutParams(layoutParams2);
            imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            if (iOptInt == 1) {
                imageView.setImageResource(R.drawable.ic_medal_gold);
            } else if (iOptInt == 2) {
                imageView.setImageResource(R.drawable.ic_medal_silver);
            } else {
                imageView.setImageResource(R.drawable.ic_medal_bronze);
            }
            linearLayout.addView(imageView);
        } else {
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(i2 * 40, -2);
            layoutParams3.setMarginEnd(i3);
            textView.setLayoutParams(layoutParams3);
            textView.setText(iOptInt > 0 ? String.valueOf(iOptInt) : "—");
            textView.setTextColor(-7829368);
            textView.setTextSize(2, 13.0f);
            textView.setGravity(17);
            linearLayout.addView(textView);
        }
        ImageView imageView2 = new ImageView(this);
        int i6 = i2 * 36;
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(i6, i6);
        layoutParams4.setMarginEnd(i4);
        imageView2.setLayoutParams(layoutParams4);
        imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView2.setBackgroundResource(R.drawable.bg_avatar_circle);
        imageView2.setClipToOutline(true);
        if (strOptString2 != null) {
            Glide.with(this).load(strOptString2).apply(new RequestOptions().transform(new CircleCrop()).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar)).into(imageView2);
        } else {
            imageView2.setImageResource(R.drawable.ic_default_avatar);
        }
        linearLayout.addView(imageView2);
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        TextView textView2 = new TextView(this);
        textView2.setText(strOptString);
        textView2.setTextColor(-1);
        textView2.setTextSize(2, 13.0f);
        textView2.setTypeface(null, 1);
        textView2.setSingleLine(true);
        linearLayout2.addView(textView2);
        JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("rewards");
        if (jSONArrayOptJSONArray == null || jSONArrayOptJSONArray.length() <= 0) {
            j = jOptLong;
        } else {
            LinearLayout linearLayout3 = new LinearLayout(this);
            linearLayout3.setOrientation(0);
            linearLayout3.setGravity(16);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-1, -2);
            int i7 = i2 * 3;
            layoutParams5.topMargin = i7;
            linearLayout3.setLayoutParams(layoutParams5);
            int i8 = 0;
            while (i8 < jSONArrayOptJSONArray.length()) {
                JSONObject jSONObjectOptJSONObject = jSONArrayOptJSONArray.optJSONObject(i8);
                if (jSONObjectOptJSONObject == null) {
                    jSONArray = jSONArrayOptJSONArray;
                    j2 = jOptLong;
                    i = i4;
                } else {
                    String strOptString3 = jSONObjectOptJSONObject.optString("icon", "");
                    j2 = jOptLong;
                    long jOptDouble = (long) jSONObjectOptJSONObject.optDouble("value", 0.0d);
                    LinearLayout linearLayout4 = new LinearLayout(this);
                    linearLayout4.setOrientation(0);
                    linearLayout4.setGravity(16);
                    jSONArray = jSONArrayOptJSONArray;
                    LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
                    if (i8 > 0) {
                        layoutParams6.setMarginStart(i4);
                    }
                    linearLayout4.setLayoutParams(layoutParams6);
                    ImageView imageView3 = new ImageView(this);
                    i = i4;
                    int i9 = i2 * 16;
                    LinearLayout.LayoutParams layoutParams7 = new LinearLayout.LayoutParams(i9, i9);
                    layoutParams7.setMarginEnd(i7);
                    imageView3.setLayoutParams(layoutParams7);
                    imageView3.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    if (strOptString3 != null && !strOptString3.isEmpty() && !"null".equalsIgnoreCase(strOptString3)) {
                        Glide.with(this).load(strOptString3).apply(new RequestOptions().placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift)).into(imageView3);
                    } else {
                        imageView3.setImageResource(R.drawable.ic_gift);
                    }
                    linearLayout4.addView(imageView3);
                    TextView textView3 = new TextView(this);
                    textView3.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(jOptDouble)));
                    textView3.setTextColor(-3355444);
                    textView3.setTextSize(2, 11.0f);
                    linearLayout4.addView(textView3);
                    linearLayout3.addView(linearLayout4);
                }
                i8++;
                jSONArrayOptJSONArray = jSONArray;
                i4 = i;
                jOptLong = j2;
            }
            j = jOptLong;
            linearLayout2.addView(linearLayout3);
        }
        linearLayout.addView(linearLayout2);
        TextView textView4 = new TextView(this);
        textView4.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
        textView4.setTextColor(-3632086);
        textView4.setTextSize(2, 13.0f);
        textView4.setTypeface(null, 1);
        textView4.setGravity(8388613);
        linearLayout.addView(textView4);
        return linearLayout;
    }

    protected void onDestroy() {
        this.stopRequested.set(true);
        stopRaceTimer();
        WebSocket webSocket = this.activeWs;
        if (webSocket != null) {
            try {
                webSocket.close(1000, "destroy");
            } catch (Exception unused) {
            }
        }
        this.exec.shutdownNow();
        super.onDestroy();
    }

    private void stopProfileSkeleton() {
        SkeletonPulse.stop(this.profileSkeletonAnim, this.pbProfileLoading);
        this.profileSkeletonAnim = null;
        View view = this.pbProfileLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.rowProfileContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        SkeletonPulse.stop(this.spinSkeletonAnim, this.spinSkeleton);
        this.spinSkeletonAnim = null;
        View view3 = this.spinSkeleton;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        View viewFindViewById = findViewById(R.id.btnSpin);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(0);
        }
        SkeletonPulse.stop(this.autoPlaySkeletonAnim, this.autoPlaySkeleton);
        this.autoPlaySkeletonAnim = null;
        View view4 = this.autoPlaySkeleton;
        if (view4 != null) {
            view4.setVisibility(8);
        }
        Button button = this.btnAutoPlay;
        if (button != null) {
            button.setVisibility(0);
            this.btnAutoPlay.setEnabled(true);
        }
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.avatarSkeleton);
        this.avatarSkeletonAnim = null;
        View view5 = this.avatarSkeleton;
        if (view5 != null) {
            view5.setVisibility(8);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(0);
        }
        SkeletonPulse.stop(this.shopSkeletonAnim, this.shopCardsSkeleton);
        this.shopSkeletonAnim = null;
        View view6 = this.shopCardsSkeleton;
        if (view6 != null) {
            view6.setVisibility(8);
        }
        View view7 = this.shopCardsContent;
        if (view7 != null) {
            view7.setVisibility(0);
        }
        SkeletonPulse.stop(this.balanceSkeletonAnim, this.balanceSkeleton);
        this.balanceSkeletonAnim = null;
        View view8 = this.balanceSkeleton;
        if (view8 != null) {
            view8.setVisibility(8);
        }
        View view9 = this.balanceContent;
        if (view9 != null) {
            view9.setVisibility(0);
        }
        SkeletonPulse.stop(this.gamePickerSkeletonAnim, this.gamePickerSkeleton);
        this.gamePickerSkeletonAnim = null;
        View view10 = this.gamePickerSkeleton;
        if (view10 != null) {
            view10.setVisibility(8);
        }
        View viewFindViewById2 = findViewById(R.id.cardGamePicker);
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(0);
        }
    }

    private void stopRankSkeleton() {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.rankLoading);
        this.rankSkeletonAnim = null;
        View view = this.rankLoading;
        if (view != null) {
            view.setVisibility(8);
        }
    }
}
