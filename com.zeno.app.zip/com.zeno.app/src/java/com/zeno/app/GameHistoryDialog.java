package com.zeno.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
public class GameHistoryDialog {
    private static final String GAME_BASE = "https://pubapi-mygov2.mtgmm.co/v1/engine";
    private final Context ctx;
    private Dialog dialog;
    private LinearLayout llHistoryError;
    private LinearLayout llHistoryLoading;
    private LinearLayout llPrizes;
    private final SessionManager session;
    private ScrollView svPrizes;
    private TextView tvHistoryError;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    public GameHistoryDialog(Context context, SessionManager sessionManager) {
        this.ctx = context;
        this.session = sessionManager;
    }

    public void show() {
        Dialog dialog = new Dialog(this.ctx, android.R.style.Theme.Black.NoTitleBar.Fullscreen);
        this.dialog = dialog;
        dialog.requestWindowFeature(1);
        this.dialog.setCancelable(false);
        this.dialog.setCanceledOnTouchOutside(false);
        this.dialog.setContentView(R.layout.dialog_game_history);
        Window window = this.dialog.getWindow();
        if (window != null) {
            window.setLayout(-1, -1);
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(2);
            window.setDimAmount(0.75f);
        }
        this.llHistoryLoading = (LinearLayout) this.dialog.findViewById(R.id.llHistoryLoading);
        this.llHistoryError = (LinearLayout) this.dialog.findViewById(R.id.llHistoryError);
        this.tvHistoryError = (TextView) this.dialog.findViewById(R.id.tvHistoryError);
        this.llPrizes = (LinearLayout) this.dialog.findViewById(R.id.llPrizes);
        this.svPrizes = (ScrollView) this.dialog.findViewById(R.id.svPrizes);
        this.dialog.findViewById(R.id.btnHistoryRetry).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.GameHistoryDialog$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m432lambda$show$0$comzenoappGameHistoryDialog(view);
            }
        });
        this.dialog.show();
        fetchPrizes();
    }

    /* JADX INFO: renamed from: lambda$show$0$com-zeno-app-GameHistoryDialog, reason: not valid java name */
    /* synthetic */ void m432lambda$show$0$comzenoappGameHistoryDialog(View view) {
        fetchPrizes();
    }

    private void fetchPrizes() {
        this.llHistoryLoading.setVisibility(0);
        this.llHistoryError.setVisibility(8);
        this.svPrizes.setVisibility(8);
        final String gameToken = this.session.getGameToken();
        if (gameToken == null || gameToken.isEmpty()) {
            showError("Not logged in to game.\nPlease open Auto Play first.");
        } else {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.GameHistoryDialog$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m431lambda$fetchPrizes$2$comzenoappGameHistoryDialog(gameToken);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPrizes$2$com-zeno-app-GameHistoryDialog, reason: not valid java name */
    /* synthetic */ void m431lambda$fetchPrizes$2$comzenoappGameHistoryDialog(String str) {
        final JSONArray jSONArray;
        String strString;
        try {
            int i = 0;
            String[] strArr = {"https://pubapi-mygov2.mtgmm.co/v1/engine/game/reward/history", "https://pubapi-mygov2.mtgmm.co/v1/engine/game/history", "https://pubapi-mygov2.mtgmm.co/v1/engine/user/reward/history"};
            while (true) {
                jSONArray = null;
                if (i >= 3) {
                    strString = null;
                    break;
                }
                Response responseExecute = this.http.newCall(new Request.Builder().url(strArr[i]).addHeader("Authorization", "Bearer " + str).addHeader("Accept", "application/json").build()).execute();
                strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
                int iCode = responseExecute.code();
                responseExecute.close();
                if (iCode == 200 && strString != null && !strString.isEmpty()) {
                    break;
                } else {
                    i++;
                }
            }
            if (strString != null && !strString.isEmpty()) {
                JSONObject jSONObject = new JSONObject(strString);
                JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                if (jSONObjectOptJSONObject != null) {
                    jSONArray = jSONObjectOptJSONObject.optJSONArray("data");
                    if (jSONArray == null) {
                        jSONArray = jSONObjectOptJSONObject.optJSONArray("items");
                    }
                    if (jSONArray == null) {
                        jSONArray = jSONObjectOptJSONObject.optJSONArray("rewards");
                    }
                }
                if (jSONArray == null) {
                    jSONArray = jSONObject.optJSONArray("data");
                }
                if (jSONArray == null) {
                    jSONArray = jSONObject.optJSONArray("items");
                }
                if (jSONArray == null) {
                    jSONArray = new JSONArray();
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.GameHistoryDialog$$ExternalSyntheticLambda3
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m430lambda$fetchPrizes$1$comzenoappGameHistoryDialog(jSONArray);
                    }
                });
                return;
            }
            showError("Game history not available.");
        } catch (Exception e) {
            showError("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: renamed from: lambda$fetchPrizes$1$com-zeno-app-GameHistoryDialog, reason: not valid java name */
    /* synthetic */ void m430lambda$fetchPrizes$1$comzenoappGameHistoryDialog(JSONArray jSONArray) {
        if (this.dialog.isShowing()) {
            this.llHistoryLoading.setVisibility(8);
            this.llPrizes.removeAllViews();
            if (jSONArray.length() == 0) {
                addEmptyView("No prize history yet.\nStart playing to win rewards! 🎮");
            } else {
                for (int i = 0; i < jSONArray.length(); i++) {
                    try {
                        addPrizeRow(jSONArray.getJSONObject(i));
                    } catch (Exception unused) {
                    }
                }
            }
            this.svPrizes.setVisibility(0);
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:8:0x008d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void addPrizeRow(org.json.JSONObject r12) {
        /*
            Method dump skipped, instruction units count: 430
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.GameHistoryDialog.addPrizeRow(org.json.JSONObject):void");
    }

    private void showError(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.GameHistoryDialog$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m433lambda$showError$3$comzenoappGameHistoryDialog(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showError$3$com-zeno-app-GameHistoryDialog, reason: not valid java name */
    /* synthetic */ void m433lambda$showError$3$comzenoappGameHistoryDialog(String str) {
        if (this.dialog.isShowing()) {
            this.llHistoryLoading.setVisibility(8);
            this.svPrizes.setVisibility(8);
            this.tvHistoryError.setText(str);
            this.llHistoryError.setVisibility(0);
        }
    }

    private void addEmptyView(String str) {
        TextView textView = new TextView(this.ctx);
        textView.setText(str);
        textView.setTextColor(-6381922);
        textView.setGravity(17);
        textView.setPadding(24, 100, 24, 100);
        this.llPrizes.addView(textView);
    }
}
