package com.zeno.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.core.widget.NestedScrollView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class FightingFishShopActivity extends BaseActivity {
    private static final String BASE = "https://fishio.mascom.vn";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private ExecutorService exec;
    private String gameToken;
    private LinearLayout llLoading;
    private LinearLayout llPackages;
    private SessionManager session;
    private ValueAnimator skeletonAnim;
    private NestedScrollView svPackages;
    private LinearLayout tabRetail;
    private View tabRetailUnderline;
    private LinearLayout tabSubscription;
    private View tabSubscriptionUnderline;
    private TextView tvEmpty;
    private TextView tvTabHint;
    private TextView tvTabRetail;
    private TextView tvTabSubscription;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).build();
    private boolean isSubscriptionTab = true;

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_kong_island_shop);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        String stringExtra = getIntent().getStringExtra("gameToken");
        this.gameToken = stringExtra;
        if (stringExtra == null) {
            this.gameToken = "";
        }
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Shop");
        }
        toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m420lambda$onCreate$0$comzenoappFightingFishShopActivity(view);
            }
        });
        this.tabSubscription = (LinearLayout) findViewById(R.id.tabSubscription);
        this.tabRetail = (LinearLayout) findViewById(R.id.tabRetail);
        this.tvTabSubscription = (TextView) findViewById(R.id.tvTabSubscription);
        this.tvTabRetail = (TextView) findViewById(R.id.tvTabRetail);
        this.tabSubscriptionUnderline = findViewById(R.id.tabSubscriptionUnderline);
        this.tabRetailUnderline = findViewById(R.id.tabRetailUnderline);
        this.llLoading = (LinearLayout) findViewById(R.id.llLoading);
        this.tvEmpty = (TextView) findViewById(R.id.tvEmpty);
        this.svPackages = findViewById(R.id.svPackages);
        this.llPackages = (LinearLayout) findViewById(R.id.llPackages);
        this.tvTabHint = (TextView) findViewById(R.id.tvTabHint);
        TextView textView = this.tvTabSubscription;
        if (textView != null) {
            textView.setText("Subscription");
        }
        TextView textView2 = this.tvTabRetail;
        if (textView2 != null) {
            textView2.setText("Retail");
        }
        this.tabSubscription.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m421lambda$onCreate$1$comzenoappFightingFishShopActivity(view);
            }
        });
        this.tabRetail.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m422lambda$onCreate$2$comzenoappFightingFishShopActivity(view);
            }
        });
        fetchPackages("RENEW");
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m420lambda$onCreate$0$comzenoappFightingFishShopActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m421lambda$onCreate$1$comzenoappFightingFishShopActivity(View view) {
        switchTab(true);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m422lambda$onCreate$2$comzenoappFightingFishShopActivity(View view) {
        switchTab(false);
    }

    protected void onDestroy() {
        super.onDestroy();
        this.exec.shutdownNow();
    }

    private void switchTab(boolean z) {
        if (this.isSubscriptionTab == z) {
            return;
        }
        this.isSubscriptionTab = z;
        updateTabBar();
        fetchPackages(z ? "RENEW" : "RETAIL");
    }

    private void updateTabBar() {
        if (this.isSubscriptionTab) {
            this.tvTabSubscription.setTextColor(-3632086);
            this.tvTabSubscription.setTypeface(null, 1);
            this.tabSubscriptionUnderline.setBackgroundColor(-3632086);
            this.tvTabRetail.setTextColor(-7829368);
            this.tvTabRetail.setTypeface(null, 0);
            this.tabRetailUnderline.setBackgroundColor(0);
            return;
        }
        this.tvTabRetail.setTextColor(-3632086);
        this.tvTabRetail.setTypeface(null, 1);
        this.tabRetailUnderline.setBackgroundColor(-3632086);
        this.tvTabSubscription.setTextColor(-7829368);
        this.tvTabSubscription.setTypeface(null, 0);
        this.tabSubscriptionUnderline.setBackgroundColor(0);
    }

    private void fetchPackages(final String str) {
        String str2;
        this.llLoading.setVisibility(0);
        this.skeletonAnim = SkeletonPulse.start(this.llLoading);
        this.svPackages.setVisibility(8);
        this.tvEmpty.setVisibility(8);
        TextView textView = this.tvTabHint;
        if (textView != null) {
            if (this.isSubscriptionTab) {
                str2 = "Subscription packages (auto-renew)";
            } else {
                str2 = "One-time retail packages";
            }
            textView.setText(str2);
        }
        final String str3 = this.gameToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m419lambda$fetchPackages$4$comzenoappFightingFishShopActivity(str, str3);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchPackages$4$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m419lambda$fetchPackages$4$comzenoappFightingFishShopActivity(String str, String str2) {
        try {
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://fishio.mascom.vn/api/package/list?type=" + str).get().addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str2).addHeader("Origin", BASE).addHeader("Referer", "https://fishio.mascom.vn/").addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                final String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda7
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m418lambda$fetchPackages$3$comzenoappFightingFishShopActivity(strString);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                showEmpty("Error " + responseExecute.code());
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            showEmpty("Network error: " + e.getMessage());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: parsePackages, reason: merged with bridge method [inline-methods] */
    public void m418lambda$fetchPackages$3$comzenoappFightingFishShopActivity(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            if (!jSONObject.optBoolean("success", false)) {
                showEmpty(jSONObject.optString("message", "Package list မရပါ"));
                return;
            }
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("listPackage") : null;
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                this.llPackages.removeAllViews();
                for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject2 != null && !jSONObjectOptJSONObject2.optBoolean("hide", false)) {
                        addPackageRow(jSONObjectOptJSONObject2);
                    }
                }
                SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
                this.skeletonAnim = null;
                LinearLayout linearLayout = this.llLoading;
                if (linearLayout != null) {
                    linearLayout.setVisibility(8);
                }
                this.tvEmpty.setVisibility(8);
                this.svPackages.setVisibility(0);
                return;
            }
            showEmpty("Package မရှိပါ");
        } catch (Exception unused) {
            showEmpty("Parse error");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addPackageRow(JSONObject jSONObject) {
        int i;
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_fighting_fish_package, (ViewGroup) this.llPackages, false);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivPackIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvPackName);
        TextView textView2 = (TextView) viewInflate.findViewById(R.id.tvPackPrice);
        Button button = (Button) viewInflate.findViewById(R.id.btnPackBuy);
        TextView textView3 = (TextView) viewInflate.findViewById(R.id.tvStatTicket);
        TextView textView4 = (TextView) viewInflate.findViewById(R.id.tvStatCoin);
        TextView textView5 = (TextView) viewInflate.findViewById(R.id.tvStatGem);
        View viewFindViewById = viewInflate.findViewById(R.id.rowAbilities);
        final String strOptString = jSONObject.optString("code", "");
        final String strOptString2 = jSONObject.optString("name", "Package");
        String strOptString3 = jSONObject.optString("icon", "");
        double dOptDouble = jSONObject.optDouble("price", 0.0d);
        String strOptString4 = jSONObject.optString("typePrice", "MMK");
        int iOptInt = jSONObject.optInt("ticket", 0);
        int iOptInt2 = jSONObject.optInt("coin", 0);
        int iOptInt3 = jSONObject.optInt("gem", 0);
        int iOptInt4 = jSONObject.optInt("magnetism", 0);
        int iOptInt5 = jSONObject.optInt("viewPort", 0);
        int iOptInt6 = jSONObject.optInt("speedUp", 0);
        int iOptInt7 = jSONObject.optInt("multiFood", 0);
        int iOptInt8 = jSONObject.optInt("treasure", 0);
        int iOptInt9 = jSONObject.optInt("shield", 0);
        int iOptInt10 = jSONObject.optInt("revive", 0);
        textView.setText(strOptString2);
        if (textView2 != null) {
            textView2.setText(String.format(Locale.getDefault(), "%,.0f %s", Double.valueOf(dOptDouble), strOptString4));
        }
        if (textView3 != null) {
            textView3.setText(String.valueOf(iOptInt));
        }
        if (textView4 != null) {
            textView4.setText(String.valueOf(iOptInt2));
        }
        if (textView5 != null) {
            textView5.setText(String.valueOf(iOptInt3));
        }
        View viewFindViewById2 = viewInflate.findViewById(R.id.rowStats);
        TextView textView6 = (TextView) viewInflate.findViewById(R.id.tvPackDesc);
        String strOptString5 = jSONObject.optString("description", "");
        if (strOptString5.startsWith("{")) {
            try {
                JSONObject jSONObject2 = new JSONObject(strOptString5);
                strOptString5 = jSONObject2.optString("en", jSONObject2.optString("my", strOptString5));
            } catch (Exception unused) {
            }
        }
        boolean z = iOptInt > 0 || iOptInt2 > 0 || iOptInt3 > 0;
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(z ? 0 : 8);
        }
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        if (iOptInt4 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_magnetism));
            arrayList2.add(Integer.valueOf(iOptInt4));
        }
        if (iOptInt5 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_viewport));
            arrayList2.add(Integer.valueOf(iOptInt5));
        }
        if (iOptInt6 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_speedup));
            arrayList2.add(Integer.valueOf(iOptInt6));
        }
        if (iOptInt7 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_multifood));
            arrayList2.add(Integer.valueOf(iOptInt7));
        }
        if (iOptInt8 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_treasure));
            arrayList2.add(Integer.valueOf(iOptInt8));
        }
        if (iOptInt9 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_shield));
            arrayList2.add(Integer.valueOf(iOptInt9));
        }
        if (iOptInt10 > 0) {
            arrayList.add(Integer.valueOf(R.drawable.ic_ff_revive));
            arrayList2.add(Integer.valueOf(iOptInt10));
        }
        View[] viewArr = {viewInflate.findViewById(R.id.colAbility1), viewInflate.findViewById(R.id.colAbility2), viewInflate.findViewById(R.id.colAbility3), viewInflate.findViewById(R.id.colAbility4)};
        ImageView[] imageViewArr = {(ImageView) viewInflate.findViewById(R.id.ivAbility1), (ImageView) viewInflate.findViewById(R.id.ivAbility2), (ImageView) viewInflate.findViewById(R.id.ivAbility3), (ImageView) viewInflate.findViewById(R.id.ivAbility4)};
        int i2 = 0;
        TextView[] textViewArr = {(TextView) viewInflate.findViewById(R.id.tvAbility1), (TextView) viewInflate.findViewById(R.id.tvAbility2), (TextView) viewInflate.findViewById(R.id.tvAbility3), (TextView) viewInflate.findViewById(R.id.tvAbility4)};
        if (viewFindViewById != null) {
            if (!arrayList.isEmpty()) {
                viewFindViewById.setVisibility(0);
                int i3 = 0;
                while (i3 < 4) {
                    if (i3 < arrayList.size()) {
                        View view = viewArr[i3];
                        if (view != null) {
                            view.setVisibility(i2);
                        }
                        ImageView imageView2 = imageViewArr[i3];
                        if (imageView2 != null) {
                            imageView2.setImageResource(((Integer) arrayList.get(i3)).intValue());
                            int iIntValue = ((Integer) arrayList.get(i3)).intValue();
                            if (iIntValue == R.drawable.ic_ff_treasure) {
                                i = 38;
                            } else {
                                i = iIntValue == R.drawable.ic_ff_shield ? 40 : 32;
                            }
                            int i4 = (int) ((i * getResources().getDisplayMetrics().density) + 0.5f);
                            ViewGroup.LayoutParams layoutParams = imageViewArr[i3].getLayoutParams();
                            if (layoutParams != null) {
                                layoutParams.width = i4;
                                layoutParams.height = i4;
                                imageViewArr[i3].setLayoutParams(layoutParams);
                            }
                        }
                        TextView textView7 = textViewArr[i3];
                        if (textView7 != null) {
                            textView7.setText(String.valueOf(arrayList2.get(i3)));
                        }
                    } else {
                        View view2 = viewArr[i3];
                        if (view2 != null) {
                            view2.setVisibility(8);
                        }
                        i3++;
                        i2 = 0;
                    }
                    i3++;
                    i2 = 0;
                }
            } else {
                viewFindViewById.setVisibility(8);
            }
        }
        if (textView6 != null) {
            if (!z && ok(strOptString5)) {
                textView6.setText(strOptString5);
                textView6.setVisibility(0);
            } else {
                textView6.setVisibility(8);
            }
        }
        if (ok(strOptString3)) {
            Glide.with(this).load(strOptString3).apply(new RequestOptions().placeholder(R.drawable.ic_gift).error(R.drawable.ic_gift)).into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_gift);
        }
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view3) {
                this.f$0.m414lambda$addPackageRow$5$comzenoappFightingFishShopActivity(strOptString, strOptString2, view3);
            }
        });
        this.llPackages.addView(viewInflate);
    }

    /* JADX INFO: renamed from: lambda$addPackageRow$5$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m414lambda$addPackageRow$5$comzenoappFightingFishShopActivity(String str, String str2, View view) {
        buyPackage(str, str2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void buyPackage(final String str, final String str2) {
        if (!ok(this.gameToken)) {
            Toast.makeText((Context) this, (CharSequence) "Login token မရှိပါ", 0).show();
            return;
        }
        Toast.makeText((Context) this, (CharSequence) "ဝယ်ယူနေသည်...", 0).show();
        final String str3 = this.gameToken;
        this.exec.execute(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda8
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m417lambda$buyPackage$8$comzenoappFightingFishShopActivity(str, str3, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$buyPackage$8$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m417lambda$buyPackage$8$comzenoappFightingFishShopActivity(String str, String str2, String str3) {
        String str4;
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("code", str);
            Response responseExecute = this.http.newCall(new Request.Builder().url("https://fishio.mascom.vn/api/package/buy-package").post(RequestBody.create(jSONObject.toString(), JSON)).addHeader("Accept", "*/*").addHeader("Content-Type", "application/json").addHeader("Authorization", "Bearer " + str2).addHeader("Origin", BASE).addHeader("Referer", "https://fishio.mascom.vn/").addHeader("User-Agent", "Mozilla/5.0").build()).execute();
            try {
                JSONObject jSONObject2 = new JSONObject(responseExecute.body() != null ? responseExecute.body().string() : "");
                final boolean zOptBoolean = jSONObject2.optBoolean("success", false);
                final String strOptString = jSONObject2.optString("message", zOptBoolean ? "အောင်မြင်ပါသည်" : "မအောင်မြင်ပါ");
                if (strOptString == null || strOptString.equals("null") || strOptString.isEmpty()) {
                    if (zOptBoolean) {
                        str4 = str3 + " ဝယ်ပြီးပါပြီ";
                    } else {
                        str4 = "Error " + jSONObject2.optString("error", "");
                    }
                    strOptString = str4;
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m415lambda$buyPackage$6$comzenoappFightingFishShopActivity(strOptString, zOptBoolean);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m416lambda$buyPackage$7$comzenoappFightingFishShopActivity(e);
                }
            });
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyPackage$6$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m415lambda$buyPackage$6$comzenoappFightingFishShopActivity(String str, boolean z) {
        Toast.makeText((Context) this, (CharSequence) str, 1).show();
        if (z) {
            fetchPackages(this.isSubscriptionTab ? "RENEW" : "RETAIL");
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$buyPackage$7$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m416lambda$buyPackage$7$comzenoappFightingFishShopActivity(Exception exc) {
        Toast.makeText((Context) this, (CharSequence) ("Error: " + exc.getMessage()), 0).show();
    }

    private void showEmpty(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.FightingFishShopActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m423lambda$showEmpty$9$comzenoappFightingFishShopActivity(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEmpty$9$com-zeno-app-FightingFishShopActivity, reason: not valid java name */
    /* synthetic */ void m423lambda$showEmpty$9$comzenoappFightingFishShopActivity(String str) {
        SkeletonPulse.stop(this.skeletonAnim, this.llLoading);
        this.skeletonAnim = null;
        LinearLayout linearLayout = this.llLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.svPackages.setVisibility(8);
        this.tvEmpty.setVisibility(0);
        this.tvEmpty.setText(str);
    }

    private static boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }
}
