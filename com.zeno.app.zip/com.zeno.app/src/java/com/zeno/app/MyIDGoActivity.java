package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.WindowCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation;
import com.bumptech.glide.request.RequestOptions;
import java.io.IOException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class MyIDGoActivity extends BaseActivity {
    private static final int COL_GREEN = -11751600;
    private static final int COL_GREY = -6381922;
    private static final int COL_RED = -1092784;
    private static final int COL_WHITE = -1;
    private static final int COL_YELLOW = -3632086;
    private static final String GAME_BASE = "https://pubapi-mygov2.mtgmm.co/v1/engine";
    private static final int REQ_STORE = 1001;
    private View autoPlayContent;
    private View autoPlaySkeleton;
    private ValueAnimator autoPlaySkeletonAnim;
    private View avatarSkeleton;
    private ValueAnimator avatarSkeletonAnim;
    private LinearLayout btnAutoPlay;
    private TextView btnMatchCount1;
    private TextView btnMatchCount10;
    private TextView btnMatchCount3;
    private TextView btnMatchCount5;
    private TextView btnMatchCount7;
    private TextView btnMatchCount8;
    private View btnOpenHistory;
    private View btnOpenStore;
    private View cardGamePicker;
    private View cardPlaying;
    private View contentPlay;
    private View contentRank;
    private ExecutorService exec;
    private View gamePickerContent;
    private View gamePickerSkeleton;
    private ValueAnimator gamePickerSkeletonAnim;
    private ImageView ivAutoPlayIcon;
    private ImageView ivAvatar;
    private ImageView ivTabPlay;
    private ImageView ivTabRank;
    private LinearLayout llLeaderboardLoading;
    private LinearLayout llLeaderboardRows;
    private LinearLayout llStats;
    private LinearLayout llStatsLoading;
    private View profileTextContent;
    private View profileTextSkeleton;
    private ValueAnimator profileTextSkeletonAnim;
    private ProgressBar progressGame;
    private ValueAnimator rankSkeletonAnim;
    private SessionManager session;
    private View shopCardsContent;
    private View shopCardsSkeleton;
    private ValueAnimator shopSkeletonAnim;
    private ValueAnimator statsSkeletonAnim;
    private SwipeRefreshLayout swipeRefresh;
    private View tabPlay;
    private View tabPlayUnderline;
    private View tabRank;
    private View tabRankUnderline;
    private Runnable timerRunnable;
    private TextView tvAutoPlayLabel;
    private TextView tvAutoPlayStatus;
    private TextView tvDiamond;
    private TextView tvGameProgress;
    private TextView tvHammer;
    private TextView tvInfoEnd;
    private TextView tvInfoStarted;
    private TextView tvInfoTotalTime;
    private TextView tvJackfruit;
    private TextView tvLeaderboardWeek;
    private TextView tvMix;
    private TextView tvMyRank;
    private TextView tvPlayingBig;
    private TextView tvPlayingStatus;
    private TextView tvProfileName;
    private TextView tvProfilePhone;
    private TextView tvProgressLeft;
    private TextView tvProgressRight;
    private TextView tvTabPlay;
    private TextView tvTabRank;
    private TextView tvTurn;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private volatile boolean stopping = false;
    private volatile int currentTurns = COL_WHITE;
    private String activeGameToken = null;
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).followRedirects(true).build();
    private final OkHttpClient httpNoRedir = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).followRedirects(false).followSslRedirects(false).build();
    private volatile int selectedMatchCount = 1;

    static /* synthetic */ boolean lambda$showRewardsDialog$26(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
        return i == 4;
    }

    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    private static class HttpResult {
        final String body;
        final String location;
        final int status;

        HttpResult(int i, String str, String str2) {
            this.status = i;
            this.body = str;
            this.location = str2;
        }
    }

    private static class CircleCrop extends BitmapTransformation {
        private CircleCrop() {
        }

        /* synthetic */ CircleCrop(AnonymousClass1 anonymousClass1) {
            this();
        }

        protected Bitmap transform(BitmapPool bitmapPool, Bitmap bitmap, int i, int i2) {
            int iMin = Math.min(bitmap.getWidth(), bitmap.getHeight());
            Bitmap bitmapCreateBitmap = Bitmap.createBitmap(bitmap, (bitmap.getWidth() - iMin) / 2, (bitmap.getHeight() - iMin) / 2, iMin, iMin);
            Bitmap bitmap2 = bitmapPool.get(iMin, iMin, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap2);
            Paint paint = new Paint(1);
            paint.setShader(new BitmapShader(bitmapCreateBitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            float f = iMin / 2.0f;
            canvas.drawCircle(f, f, f, paint);
            bitmapCreateBitmap.recycle();
            return bitmap2;
        }

        public void updateDiskCacheKey(MessageDigest messageDigest) {
            messageDigest.update("CircleCrop".getBytes());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(COL_YELLOW);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_myid_go);
        this.session = new SessionManager(this);
        this.exec = Executors.newSingleThreadExecutor();
        Toolbar toolbarFindViewById = findViewById(R.id.toolbar);
        setSupportActionBar(toolbarFindViewById);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("MyID GO");
        }
        if (toolbarFindViewById != null) {
            toolbarFindViewById.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda24
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m620lambda$onCreate$0$comzenoappMyIDGoActivity(view);
                }
            });
        }
        bindViews();
        setupPlayRankTabs();
        startProfileSkeleton();
        startShopSkeleton();
        startAutoPlaySkeleton();
        startGamePickerSkeleton();
        populateProfileFromSession();
        initLoad();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m620lambda$onCreate$0$comzenoappMyIDGoActivity(View view) {
        finish();
    }

    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    protected void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == REQ_STORE && i2 == COL_WHITE) {
            if (ok(this.activeGameToken)) {
                this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda9
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m618lambda$onActivityResult$1$comzenoappMyIDGoActivity();
                    }
                });
            } else {
                this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda11
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m619lambda$onActivityResult$2$comzenoappMyIDGoActivity();
                    }
                });
            }
        }
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$1$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m618lambda$onActivityResult$1$comzenoappMyIDGoActivity() {
        fetchProfile(this.activeGameToken);
        fetchLeaderboard(this.activeGameToken);
    }

    /* JADX INFO: renamed from: lambda$onActivityResult$2$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m619lambda$onActivityResult$2$comzenoappMyIDGoActivity() {
        String strResolveGameToken = resolveGameToken();
        if (ok(strResolveGameToken)) {
            this.activeGameToken = strResolveGameToken;
            fetchProfile(strResolveGameToken);
            fetchLeaderboard(strResolveGameToken);
        }
    }

    private void bindViews() {
        this.ivAvatar = (ImageView) findViewById(R.id.ivAvatar);
        this.tvProfileName = (TextView) findViewById(R.id.tvProfileName);
        this.tvProfilePhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.swipeRefresh = findViewById(R.id.swipeRefresh);
        this.btnOpenStore = findViewById(R.id.btnOpenStore);
        this.btnOpenHistory = findViewById(R.id.btnOpenHistory);
        this.tvDiamond = (TextView) findViewById(R.id.tvDiamonds);
        this.tvHammer = (TextView) findViewById(R.id.tvTools);
        this.tvJackfruit = (TextView) findViewById(R.id.tvAvocados);
        this.tvMix = (TextView) findViewById(R.id.tvUploads);
        this.tvTurn = (TextView) findViewById(R.id.tvLightning);
        this.tvAutoPlayStatus = (TextView) findViewById(R.id.tvAutoPlayStatus);
        this.btnAutoPlay = (LinearLayout) findViewById(R.id.btnAutoPlay);
        this.ivAutoPlayIcon = (ImageView) findViewById(R.id.ivAutoPlayIcon);
        this.tvAutoPlayLabel = (TextView) findViewById(R.id.tvAutoPlayLabel);
        this.llLeaderboardRows = (LinearLayout) findViewById(R.id.llLeaderboardRows);
        this.tvLeaderboardWeek = (TextView) findViewById(R.id.tvLeaderboardWeek);
        this.tvMyRank = (TextView) findViewById(R.id.tvMyRank);
        this.llStatsLoading = (LinearLayout) findViewById(R.id.llStatsLoading);
        this.llStats = (LinearLayout) findViewById(R.id.llStats);
        this.llLeaderboardLoading = (LinearLayout) findViewById(R.id.llLeaderboardLoading);
        this.cardGamePicker = findViewById(R.id.cardGamePicker);
        this.cardPlaying = findViewById(R.id.cardPlaying);
        this.btnMatchCount1 = (TextView) findViewById(R.id.btnMatchCount1);
        this.btnMatchCount3 = (TextView) findViewById(R.id.btnMatchCount3);
        this.btnMatchCount5 = (TextView) findViewById(R.id.btnMatchCount5);
        this.btnMatchCount7 = (TextView) findViewById(R.id.btnMatchCount7);
        this.btnMatchCount8 = (TextView) findViewById(R.id.btnMatchCount8);
        this.btnMatchCount10 = (TextView) findViewById(R.id.btnMatchCount10);
        this.tvPlayingBig = (TextView) findViewById(R.id.tvPlayingBig);
        this.tvGameProgress = (TextView) findViewById(R.id.tvGameProgress);
        this.progressGame = (ProgressBar) findViewById(R.id.progressGame);
        this.tvInfoTotalTime = (TextView) findViewById(R.id.tvInfoTotalTime);
        this.tvInfoStarted = (TextView) findViewById(R.id.tvInfoStarted);
        this.tvInfoEnd = (TextView) findViewById(R.id.tvInfoEnd);
        this.tvPlayingStatus = (TextView) findViewById(R.id.tvPlayingStatus);
        this.tvProgressLeft = (TextView) findViewById(R.id.tvProgressLeft);
        this.tvProgressRight = (TextView) findViewById(R.id.tvProgressRight);
        this.btnMatchCount1.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda35
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m605lambda$bindViews$3$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnMatchCount3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m606lambda$bindViews$4$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnMatchCount5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m607lambda$bindViews$5$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnMatchCount7.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m608lambda$bindViews$6$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnMatchCount8.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m609lambda$bindViews$7$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnMatchCount10.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m610lambda$bindViews$8$comzenoappMyIDGoActivity(view);
            }
        });
        this.avatarSkeleton = findViewById(R.id.avatarSkeleton);
        this.profileTextSkeleton = findViewById(R.id.profileTextSkeleton);
        this.profileTextContent = findViewById(R.id.profileTextContent);
        this.shopCardsSkeleton = findViewById(R.id.shopCardsSkeleton);
        this.shopCardsContent = findViewById(R.id.shopCardsContent);
        this.autoPlaySkeleton = findViewById(R.id.autoPlaySkeleton);
        this.autoPlayContent = findViewById(R.id.autoPlayContent);
        this.gamePickerSkeleton = findViewById(R.id.gamePickerSkeleton);
        this.gamePickerContent = findViewById(R.id.gamePickerContent);
        this.contentPlay = findViewById(R.id.contentPlay);
        this.contentRank = findViewById(R.id.contentRank);
        this.tabPlay = findViewById(R.id.tabPlay);
        this.tabRank = findViewById(R.id.tabRank);
        this.tabPlayUnderline = findViewById(R.id.tabPlayUnderline);
        this.tabRankUnderline = findViewById(R.id.tabRankUnderline);
        this.tvTabPlay = (TextView) findViewById(R.id.tvTabPlay);
        this.tvTabRank = (TextView) findViewById(R.id.tvTabRank);
        this.ivTabPlay = (ImageView) findViewById(R.id.ivTabPlay);
        this.ivTabRank = (ImageView) findViewById(R.id.ivTabRank);
        this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_autoplay);
        this.btnAutoPlay.setBackgroundTintList(null);
        setAutoPlayButtonState(false);
        this.btnAutoPlay.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m611lambda$bindViews$9$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnOpenStore.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m600lambda$bindViews$10$comzenoappMyIDGoActivity(view);
            }
        });
        this.btnOpenHistory.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m601lambda$bindViews$11$comzenoappMyIDGoActivity(view);
            }
        });
        this.swipeRefresh.setColorSchemeColors(new int[]{COL_YELLOW});
        this.swipeRefresh.setProgressBackgroundColorSchemeColor(-14803426);
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda8
            public final void onRefresh() {
                this.f$0.m604lambda$bindViews$14$comzenoappMyIDGoActivity();
            }
        });
        log("Waiting for command...", COL_GREY);
    }

    /* JADX INFO: renamed from: lambda$bindViews$3$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m605lambda$bindViews$3$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(1);
    }

    /* JADX INFO: renamed from: lambda$bindViews$4$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m606lambda$bindViews$4$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(3);
    }

    /* JADX INFO: renamed from: lambda$bindViews$5$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m607lambda$bindViews$5$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(5);
    }

    /* JADX INFO: renamed from: lambda$bindViews$6$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m608lambda$bindViews$6$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(7);
    }

    /* JADX INFO: renamed from: lambda$bindViews$7$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m609lambda$bindViews$7$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(8);
    }

    /* JADX INFO: renamed from: lambda$bindViews$8$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m610lambda$bindViews$8$comzenoappMyIDGoActivity(View view) {
        selectMatchCount(10);
    }

    /* JADX INFO: renamed from: lambda$bindViews$9$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m611lambda$bindViews$9$comzenoappMyIDGoActivity(View view) {
        if (this.running) {
            stopPlay();
        } else {
            startPlay();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$10$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m600lambda$bindViews$10$comzenoappMyIDGoActivity(View view) {
        startActivityForResult(new Intent((Context) this, (Class<?>) GameStoreActivity.class), REQ_STORE);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$bindViews$11$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m601lambda$bindViews$11$comzenoappMyIDGoActivity(View view) {
        startActivity(new Intent((Context) this, (Class<?>) GameHistoryActivity.class));
    }

    /* JADX INFO: renamed from: lambda$bindViews$14$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m604lambda$bindViews$14$comzenoappMyIDGoActivity() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda26
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m603lambda$bindViews$13$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$bindViews$13$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m603lambda$bindViews$13$comzenoappMyIDGoActivity() {
        if (ok(this.activeGameToken)) {
            fetchProfile(this.activeGameToken);
            fetchLeaderboard(this.activeGameToken);
        } else {
            String strResolveGameToken = resolveGameToken();
            if (ok(strResolveGameToken)) {
                this.activeGameToken = strResolveGameToken;
                fetchProfile(strResolveGameToken);
                fetchLeaderboard(strResolveGameToken);
            }
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda23
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m602lambda$bindViews$12$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$bindViews$12$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m602lambda$bindViews$12$comzenoappMyIDGoActivity() {
        this.swipeRefresh.setRefreshing(false);
    }

    private void populateProfileFromSession() {
        String fullName = this.session.getFullName();
        String phone = this.session.getPhone();
        String avatarUrl = this.session.getAvatarUrl();
        if (ok(fullName)) {
            this.tvProfileName.setText(fullName);
        }
        if (ok(phone)) {
            this.tvProfilePhone.setText(phone);
        }
        loadAvatar(avatarUrl);
    }

    private void loadAvatar(String str) {
        if (!ok(str)) {
            this.ivAvatar.setImageResource(R.drawable.ic_user_placeholder);
        } else {
            Glide.with(this).load(str).apply(new RequestOptions().transform(new CircleCrop(null)).placeholder(R.drawable.ic_user_placeholder).error(R.drawable.ic_user_placeholder)).into(this.ivAvatar);
        }
    }

    private void initLoad() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda25
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m616lambda$initLoad$15$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$initLoad$15$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m616lambda$initLoad$15$comzenoappMyIDGoActivity() {
        String strResolveGameToken = resolveGameToken();
        if (ok(strResolveGameToken)) {
            this.activeGameToken = strResolveGameToken;
            fetchProfile(strResolveGameToken);
            fetchLeaderboard(strResolveGameToken);
            return;
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda27
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.showStatsEmpty();
            }
        });
    }

    private void doRefresh() {
        this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m614lambda$doRefresh$17$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doRefresh$17$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m614lambda$doRefresh$17$comzenoappMyIDGoActivity() {
        if (!ok(this.activeGameToken)) {
            String strResolveGameToken = resolveGameToken();
            if (ok(strResolveGameToken)) {
                this.activeGameToken = strResolveGameToken;
            }
        }
        if (ok(this.activeGameToken)) {
            fetchProfile(this.activeGameToken);
            fetchLeaderboard(this.activeGameToken);
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m613lambda$doRefresh$16$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doRefresh$16$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m613lambda$doRefresh$16$comzenoappMyIDGoActivity() {
        SwipeRefreshLayout swipeRefreshLayout = this.swipeRefresh;
        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setRefreshing(false);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showStatsEmpty() {
        stopStatsSkeleton();
        LinearLayout linearLayout = this.llStats;
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
        }
        stopRankSkeleton();
        stopProfileSkeleton();
        stopShopSkeleton();
        stopAutoPlaySkeleton();
        stopGamePickerSkeleton();
    }

    private String resolveGameToken() {
        String strReplace;
        String strReplace2;
        String strReplace3;
        JSONObject jSONObjectJwtPayload;
        String accessToken = this.session.getAccessToken();
        String phone = this.session.getPhone();
        String rawTptToken = this.session.getRawTptToken();
        String gameToken = this.session.getGameToken();
        if (ok(gameToken) && probeToken(gameToken)) {
            return gameToken;
        }
        if (ok(rawTptToken) && !rawTptToken.equals(gameToken) && probeToken(rawTptToken)) {
            return rawTptToken;
        }
        if (!ok(accessToken)) {
            if (ok(gameToken)) {
                return gameToken;
            }
            return null;
        }
        try {
            jSONObjectJwtPayload = jwtPayload(accessToken);
            strReplace = jSONObjectJwtPayload.optString("sub", "").replace("-", "");
            try {
                strReplace2 = jSONObjectJwtPayload.optString("session_state", "").replace("-", "");
            } catch (Exception unused) {
                strReplace2 = "";
            }
        } catch (Exception unused2) {
            strReplace = "";
            strReplace2 = strReplace;
        }
        try {
            strReplace3 = jSONObjectJwtPayload.optString("jti", "").replace("-", "");
        } catch (Exception unused3) {
            strReplace3 = "";
        }
        String str = strReplace2;
        String uuid = ok(this.session.getUuid()) ? this.session.getUuid() : "";
        String mcuid = ok(this.session.getMcuid()) ? this.session.getMcuid() : "";
        String strReplace4 = ok(this.session.getTptSub()) ? this.session.getTptSub().replace("-", "") : "";
        String str2 = ok(strReplace) ? strReplace : uuid;
        String[] strArrUniqueNonEmpty = uniqueNonEmpty(mcuid, str, strReplace3, strReplace4, phone.replaceFirst("^0", ""), phone);
        String[] strArrUniqueNonEmpty2 = uniqueNonEmpty(accessToken, rawTptToken);
        String str3 = ok(phone) ? phone : "Player";
        if (ok(str2)) {
            int length = strArrUniqueNonEmpty.length;
            int i = 0;
            while (true) {
                String str4 = "&mcapp=myid";
                String str5 = "https://pubapi-mygov2.mtgmm.co/v1/engine/web/bootstrap.html?uuid=";
                if (i < length) {
                    String str6 = strArrUniqueNonEmpty[i];
                    if (!str6.equals(str2)) {
                        int length2 = strArrUniqueNonEmpty2.length;
                        int i2 = 0;
                        while (i2 < length2) {
                            String str7 = strArrUniqueNonEmpty2[i2];
                            StringBuilder sb = new StringBuilder(str5);
                            int i3 = i2;
                            sb.append(enc(str2));
                            sb.append("&mcuid=");
                            sb.append(enc(str6));
                            sb.append(str4);
                            String string = sb.toString();
                            int i4 = length2;
                            String str8 = str6;
                            String[] strArr = strArrUniqueNonEmpty;
                            String str9 = str5;
                            int i5 = length;
                            String str10 = str4;
                            String str11 = str2;
                            String strTryBootstrap = tryBootstrap(string, str7, phone, "https://pubapi-mygov2.mtgmm.co/v1/engine/user/avatar/default", str3);
                            if (ok(strTryBootstrap)) {
                                this.session.saveGameSession(strTryBootstrap, rawTptToken, str11, str8, strReplace4);
                                return strTryBootstrap;
                            }
                            i2 = i3 + 1;
                            str5 = str9;
                            str4 = str10;
                            str6 = str8;
                            strArrUniqueNonEmpty = strArr;
                            str2 = str11;
                            length2 = i4;
                            length = i5;
                        }
                    }
                    i++;
                    strArrUniqueNonEmpty = strArrUniqueNonEmpty;
                    str2 = str2;
                    length = length;
                } else {
                    String str12 = str2;
                    int length3 = strArrUniqueNonEmpty2.length;
                    int i6 = 0;
                    while (i6 < length3) {
                        String str13 = strArrUniqueNonEmpty2[i6];
                        StringBuilder sb2 = new StringBuilder("https://pubapi-mygov2.mtgmm.co/v1/engine/web/bootstrap.html?uuid=");
                        String str14 = str12;
                        sb2.append(enc(str14));
                        sb2.append("&mcapp=myid");
                        String strTryBootstrap2 = tryBootstrap(sb2.toString(), str13, phone, "https://pubapi-mygov2.mtgmm.co/v1/engine/user/avatar/default", str3);
                        if (ok(strTryBootstrap2)) {
                            this.session.saveGameSession(strTryBootstrap2, rawTptToken, str14, "", strReplace4);
                            return strTryBootstrap2;
                        }
                        i6++;
                        str12 = str14;
                    }
                }
            }
        }
        if (ok(gameToken)) {
            return gameToken;
        }
        return null;
    }

    private boolean probeToken(String str) {
        try {
            HttpResult withStatus = getWithStatus("https://pubapi-mygov2.mtgmm.co/v1/engine/user/profile", str);
            if (withStatus != null) {
                return withStatus.status == 200;
            }
            return false;
        } catch (Exception unused) {
            return false;
        }
    }

    private String tryBootstrap(String str, String str2, String str3, String str4, String str5) {
        try {
            Response responseExecute = this.httpNoRedir.newCall(new Request.Builder().url(str).addHeader("access-token", str2).addHeader("phone-number", str3).addHeader("avatar", str4).addHeader("fullname", str5).addHeader("Accept", "text/html,application/json").addHeader("User-Agent", "MyID/1.0.300 (Android)").build()).execute();
            int iCode = responseExecute.code();
            String strHeader = responseExecute.header("Location", "");
            responseExecute.close();
            if ((iCode == 301 || iCode == 302) && ok(strHeader)) {
                return uriParam(strHeader, "token");
            }
            return null;
        } catch (Exception unused) {
            return null;
        }
    }

    private void fetchProfile(String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m615lambda$fetchProfile$18$comzenoappMyIDGoActivity();
            }
        });
        this.http.newCall(gameReq("https://pubapi-mygov2.mtgmm.co/v1/engine/user/profile", str)).enqueue(new AnonymousClass1());
    }

    /* JADX INFO: renamed from: lambda$fetchProfile$18$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m615lambda$fetchProfile$18$comzenoappMyIDGoActivity() {
        startStatsSkeleton();
        startProfileSkeleton();
        startShopSkeleton();
        if (!this.running) {
            startAutoPlaySkeleton();
        }
        if (this.running) {
            return;
        }
        startGamePickerSkeleton();
    }

    /* JADX INFO: renamed from: com.zeno.app.MyIDGoActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Callback {
        AnonymousClass1() {
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-MyIDGoActivity$1, reason: not valid java name */
        /* synthetic */ void m629lambda$onFailure$0$comzenoappMyIDGoActivity$1() {
            MyIDGoActivity.this.stopStatsSkeleton();
            MyIDGoActivity.this.showStatsEmpty();
        }

        public void onFailure(Call call, IOException iOException) {
            MyIDGoActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m629lambda$onFailure$0$comzenoappMyIDGoActivity$1();
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strConsumeBody = MyIDGoActivity.this.consumeBody(response);
            MyIDGoActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m630lambda$onResponse$1$comzenoappMyIDGoActivity$1(strConsumeBody);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-MyIDGoActivity$1, reason: not valid java name */
        /* synthetic */ void m630lambda$onResponse$1$comzenoappMyIDGoActivity$1(String str) {
            MyIDGoActivity.this.parseProfile(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void parseProfile(String str) {
        try {
            JSONObject jSONObject = new JSONObject(str);
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            String strOptString = jSONObject.optString("display_name", jSONObject.optString("displayName", jSONObject.optString("username", "")));
            String phone = this.session.getPhone();
            if (!ok(strOptString)) {
                strOptString = ok(phone) ? phone : "Player";
            }
            this.tvProfileName.setText(strOptString);
            if (ok(phone)) {
                this.tvProfilePhone.setText(phone);
            }
            SessionManager sessionManager = this.session;
            sessionManager.saveUserInfo(phone, strOptString, sessionManager.getAvatarUrl());
            loadAvatar(this.session.getAvatarUrl());
            stopProfileSkeleton();
            stopShopSkeleton();
            stopAutoPlaySkeleton();
            stopGamePickerSkeleton();
            JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("wallet");
            if (jSONObjectOptJSONObject2 == null) {
                showStatsEmpty();
                return;
            }
            int iWalletBalance = walletBalance(jSONObjectOptJSONObject2, "DIAMOND");
            int iWalletBalance2 = walletBalance(jSONObjectOptJSONObject2, "HAMMER");
            int iWalletBalance3 = walletBalance(jSONObjectOptJSONObject2, "JACKFRUIT");
            int iWalletBalance4 = walletBalance(jSONObjectOptJSONObject2, "MIX");
            int iWalletBalance5 = walletBalance(jSONObjectOptJSONObject2, "TURN_FREE") + walletBalance(jSONObjectOptJSONObject2, "TURN_PAID") + walletBalance(jSONObjectOptJSONObject2, "TURN");
            this.currentTurns = iWalletBalance5;
            this.tvDiamond.setText(String.valueOf(iWalletBalance));
            this.tvHammer.setText(String.valueOf(iWalletBalance2));
            this.tvJackfruit.setText(String.valueOf(iWalletBalance3));
            this.tvMix.setText(String.valueOf(iWalletBalance4));
            this.tvTurn.setText(String.valueOf(iWalletBalance5));
            stopStatsSkeleton();
        } catch (Exception unused) {
            showStatsEmpty();
        }
    }

    private int walletBalance(JSONObject jSONObject, String str) {
        try {
            Object obj = jSONObject.get(str);
            if (obj instanceof JSONObject) {
                JSONObject jSONObject2 = (JSONObject) obj;
                return jSONObject2.optInt("balance", jSONObject2.optInt("amount", jSONObject2.optInt("value", 0)));
            }
            return jSONObject.optInt(str, 0);
        } catch (Exception unused) {
            return 0;
        }
    }

    private void setupPlayRankTabs() {
        View view = this.tabPlay;
        if (view != null) {
            view.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda32
                @Override // android.view.View.OnClickListener
                public final void onClick(View view2) {
                    this.f$0.m626lambda$setupPlayRankTabs$19$comzenoappMyIDGoActivity(view2);
                }
            });
        }
        View view2 = this.tabRank;
        if (view2 != null) {
            view2.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda33
                @Override // android.view.View.OnClickListener
                public final void onClick(View view3) {
                    this.f$0.m627lambda$setupPlayRankTabs$20$comzenoappMyIDGoActivity(view3);
                }
            });
        }
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$setupPlayRankTabs$19$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m626lambda$setupPlayRankTabs$19$comzenoappMyIDGoActivity(View view) {
        showPlayTab();
    }

    /* JADX INFO: renamed from: lambda$setupPlayRankTabs$20$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m627lambda$setupPlayRankTabs$20$comzenoappMyIDGoActivity(View view) {
        showRankTab();
    }

    private void showPlayTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(0);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(COL_YELLOW);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(0);
        }
        TextView textView = this.tvTabPlay;
        if (textView != null) {
            textView.setTextColor(COL_YELLOW);
            this.tvTabPlay.setTypeface(null, 1);
        }
        TextView textView2 = this.tvTabRank;
        if (textView2 != null) {
            textView2.setTextColor(COL_GREY);
            this.tvTabRank.setTypeface(null, 0);
        }
        ImageView imageView = this.ivTabPlay;
        if (imageView != null) {
            imageView.setColorFilter(COL_YELLOW);
        }
        ImageView imageView2 = this.ivTabRank;
        if (imageView2 != null) {
            imageView2.setColorFilter(COL_GREY);
        }
    }

    private void showRankTab() {
        View view = this.contentPlay;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.contentRank;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        View view3 = this.tabPlayUnderline;
        if (view3 != null) {
            view3.setBackgroundColor(0);
        }
        View view4 = this.tabRankUnderline;
        if (view4 != null) {
            view4.setBackgroundColor(COL_YELLOW);
        }
        TextView textView = this.tvTabPlay;
        if (textView != null) {
            textView.setTextColor(COL_GREY);
            this.tvTabPlay.setTypeface(null, 0);
        }
        TextView textView2 = this.tvTabRank;
        if (textView2 != null) {
            textView2.setTextColor(COL_YELLOW);
            this.tvTabRank.setTypeface(null, 1);
        }
        ImageView imageView = this.ivTabPlay;
        if (imageView != null) {
            imageView.setColorFilter(COL_GREY);
        }
        ImageView imageView2 = this.ivTabRank;
        if (imageView2 != null) {
            imageView2.setColorFilter(COL_YELLOW);
        }
        if (ok(this.activeGameToken)) {
            fetchLeaderboard(this.activeGameToken);
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.MyIDGoActivity$2, reason: invalid class name */
    class AnonymousClass2 implements Callback {
        AnonymousClass2() {
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-MyIDGoActivity$2, reason: not valid java name */
        /* synthetic */ void m631lambda$onFailure$0$comzenoappMyIDGoActivity$2() {
            MyIDGoActivity.this.stopRankSkeleton();
        }

        public void onFailure(Call call, IOException iOException) {
            MyIDGoActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m631lambda$onFailure$0$comzenoappMyIDGoActivity$2();
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strConsumeBody = MyIDGoActivity.this.consumeBody(response);
            MyIDGoActivity.this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m632lambda$onResponse$1$comzenoappMyIDGoActivity$2(strConsumeBody);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-MyIDGoActivity$2, reason: not valid java name */
        /* synthetic */ void m632lambda$onResponse$1$comzenoappMyIDGoActivity$2(String str) {
            MyIDGoActivity.this.parseLeaderboard(str);
        }
    }

    private void fetchLeaderboard(String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda20
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.startRankSkeleton();
            }
        });
        this.http.newCall(gameReq("https://pubapi-mygov2.mtgmm.co/v1/engine/game/leaderboard/current", str)).enqueue(new AnonymousClass2());
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void parseLeaderboard(String str) {
        String str2;
        String str3;
        stopRankSkeleton();
        try {
            JSONObject jSONObject = new JSONObject(str);
            JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
            if (jSONObjectOptJSONObject != null) {
                jSONObject = jSONObjectOptJSONObject;
            }
            int i = 0;
            int iOptInt = jSONObject.optInt("week_number", jSONObject.optInt("weekNumber", 0));
            int iOptInt2 = jSONObject.optInt("year", 0);
            if (iOptInt > 0) {
                TextView textView = this.tvLeaderboardWeek;
                StringBuilder sb = new StringBuilder("Week ");
                sb.append(iOptInt);
                if (iOptInt2 > 0) {
                    str3 = ", " + iOptInt2;
                } else {
                    str3 = "";
                }
                sb.append(str3);
                textView.setText(sb.toString());
            }
            JSONObject jSONObjectOptJSONObject2 = jSONObject.optJSONObject("current_player_rank");
            if (jSONObjectOptJSONObject2 == null) {
                jSONObjectOptJSONObject2 = jSONObject.optJSONObject("currentPlayerRank");
            }
            if (jSONObjectOptJSONObject2 != null) {
                int iOptInt3 = jSONObjectOptJSONObject2.optInt("rank", 0);
                TextView textView2 = this.tvMyRank;
                if (iOptInt3 > 0) {
                    str2 = "#" + iOptInt3;
                } else {
                    str2 = "#-";
                }
                textView2.setText(str2);
            }
            JSONArray jSONArrayOptJSONArray = jSONObject.optJSONArray("top_players");
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = jSONObject.optJSONArray("topPlayers");
            }
            if (jSONArrayOptJSONArray == null) {
                jSONArrayOptJSONArray = jSONObject.optJSONArray("players");
            }
            if (jSONArrayOptJSONArray != null && jSONArrayOptJSONArray.length() != 0) {
                this.llLeaderboardRows.removeAllViews();
                int i2 = 0;
                while (i2 < Math.min(jSONArrayOptJSONArray.length(), 20)) {
                    JSONObject jSONObject2 = jSONArrayOptJSONArray.getJSONObject(i2);
                    i2++;
                    int iOptInt4 = jSONObject2.optInt("rank", i2);
                    String strOptString = jSONObject2.optString("user_name", jSONObject2.optString("userName", jSONObject2.optString("username", "---")));
                    int iOptInt5 = jSONObject2.optInt("total_jackfruits", jSONObject2.optInt("totalJackfruits", jSONObject2.optInt("jackfruits", i)));
                    int iOptInt6 = jSONObject2.optInt("reward_amount", jSONObject2.optInt("rewardAmount", jSONObject2.optInt("prizeMb", jSONObject2.optInt("prizeMB", i))));
                    String strOptString2 = jSONObject2.optString("avatar", jSONObject2.optString("avatar_url", null));
                    if ("null".equals(strOptString2) || (strOptString2 != null && strOptString2.isEmpty())) {
                        strOptString2 = null;
                    }
                    LinearLayout linearLayout = new LinearLayout(this);
                    linearLayout.setOrientation(i);
                    linearLayout.setGravity(16);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(COL_WHITE, -2);
                    layoutParams.setMargins(i, i, i, dp(6));
                    linearLayout.setLayoutParams(layoutParams);
                    linearLayout.setPadding(dp(8), dp(10), dp(8), dp(10));
                    linearLayout.setBackgroundResource(R.drawable.bg_beat_song_normal);
                    if (iOptInt4 <= 3) {
                        ImageView imageView = new ImageView(this);
                        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(dp(40), dp(40));
                        layoutParams2.setMarginEnd(dp(8));
                        imageView.setLayoutParams(layoutParams2);
                        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                        if (iOptInt4 == 1) {
                            imageView.setImageResource(R.drawable.ic_medal_gold);
                        } else if (iOptInt4 == 2) {
                            imageView.setImageResource(R.drawable.ic_medal_silver);
                        } else {
                            imageView.setImageResource(R.drawable.ic_medal_bronze);
                        }
                        linearLayout.addView(imageView);
                    } else {
                        TextView textView3 = new TextView(this);
                        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(dp(40), dp(40));
                        layoutParams3.setMarginEnd(dp(8));
                        textView3.setLayoutParams(layoutParams3);
                        textView3.setGravity(17);
                        textView3.setText(String.valueOf(iOptInt4));
                        textView3.setTextColor(-5592406);
                        textView3.setTextSize(2, 14.0f);
                        textView3.setTypeface(null, 1);
                        linearLayout.addView(textView3);
                    }
                    ImageView imageView2 = new ImageView(this);
                    LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dp(36), dp(36));
                    layoutParams4.setMarginEnd(dp(10));
                    imageView2.setLayoutParams(layoutParams4);
                    imageView2.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    try {
                        imageView2.setBackgroundResource(R.drawable.bg_avatar_circle);
                        imageView2.setClipToOutline(true);
                    } catch (Exception unused) {
                    }
                    if (ok(strOptString2)) {
                        try {
                            Glide.with(this).load(strOptString2).placeholder(R.drawable.ic_default_avatar).error(R.drawable.ic_default_avatar).into(imageView2);
                        } catch (Exception unused2) {
                            imageView2.setImageResource(R.drawable.ic_default_avatar);
                        }
                    } else {
                        imageView2.setImageResource(R.drawable.ic_default_avatar);
                    }
                    linearLayout.addView(imageView2);
                    LinearLayout linearLayout2 = new LinearLayout(this);
                    linearLayout2.setOrientation(1);
                    linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                    TextView textView4 = new TextView(this);
                    textView4.setText(maskPhone(strOptString));
                    textView4.setTextColor(COL_WHITE);
                    textView4.setTextSize(2, 13.0f);
                    if (iOptInt4 <= 3) {
                        textView4.setTypeface(null, 1);
                    }
                    linearLayout2.addView(textView4);
                    if (iOptInt6 > 0) {
                        TextView textView5 = new TextView(this);
                        String str4 = String.format(Locale.getDefault(), "%,d MB", Integer.valueOf(iOptInt6));
                        try {
                            Drawable drawable = getResources().getDrawable(R.drawable.ic_prize_mb, getTheme());
                            int iDp = dp(18);
                            int iDp2 = dp(2);
                            drawable.setBounds(0, iDp2, iDp, iDp + iDp2);
                            SpannableString spannableString = new SpannableString("  " + str4);
                            spannableString.setSpan(new ImageSpan(drawable, 0), 0, 1, 33);
                            textView5.setText(spannableString);
                        } catch (Exception unused3) {
                            textView5.setText(str4);
                        }
                        textView5.setTextColor(COL_YELLOW);
                        textView5.setTextSize(2, 11.0f);
                        linearLayout2.addView(textView5);
                    }
                    linearLayout.addView(linearLayout2);
                    TextView textView6 = new TextView(this);
                    String str5 = String.format(Locale.getDefault(), "%,d", Integer.valueOf(iOptInt5));
                    try {
                        Drawable drawable2 = getResources().getDrawable(R.drawable.ic_stat_jackfruit, getTheme());
                        int iDp3 = dp(20);
                        drawable2.setBounds(0, 0, iDp3, iDp3);
                        SpannableString spannableString2 = new SpannableString("  " + str5);
                        try {
                            spannableString2.setSpan(new ImageSpan(drawable2, 2), 0, 1, 33);
                            textView6.setText(spannableString2);
                        } catch (Exception unused4) {
                            textView6.setText(str5);
                        }
                    } catch (Exception unused5) {
                    }
                    textView6.setTextColor(iOptInt4 <= 3 ? -10752 : COL_YELLOW);
                    textView6.setTextSize(2, 13.0f);
                    if (iOptInt4 <= 3) {
                        textView6.setTypeface(null, 1);
                    }
                    textView6.setGravity(8388613);
                    linearLayout.addView(textView6);
                    this.llLeaderboardRows.addView(linearLayout);
                    i = 0;
                }
            }
        } catch (Exception unused6) {
        }
    }

    private int dp(int i) {
        return Math.round(i * getResources().getDisplayMetrics().density);
    }

    private String maskPhone(String str) {
        if (str == null || str.length() < 8) {
            return str == null ? "" : str;
        }
        if (str.contains("*")) {
            return str;
        }
        return str.substring(0, 4) + "****" + str.substring(str.length() - 3);
    }

    private void startPlay() {
        if (this.running) {
            return;
        }
        if (this.currentTurns == 0) {
            ZSnack.make(this.btnAutoPlay, "ကစားကြိမ်မရှိပဲ မကစားနိုင်ပါ", 0).show();
            return;
        }
        this.running = true;
        this.stopping = false;
        setAutoPlayButtonState(true);
        this.btnAutoPlay.setBackgroundTintList(null);
        this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_stop);
        this.tvAutoPlayStatus.setVisibility(0);
        this.tvAutoPlayStatus.setText("● RUNNING");
        this.tvAutoPlayStatus.setTextColor(COL_GREEN);
        setGamePickerVisible(false);
        View view = this.cardPlaying;
        if (view != null) {
            view.setVisibility(0);
        }
        clearTerminal();
        this.exec.execute(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda28
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.runAutoPlay();
            }
        });
    }

    private void setAutoPlayButtonState(boolean z) {
        TextView textView;
        if (this.btnAutoPlay == null || (textView = this.tvAutoPlayLabel) == null) {
            return;
        }
        if (z) {
            textView.setText("ရပ်မည်");
            ImageView imageView = this.ivAutoPlayIcon;
            if (imageView != null) {
                imageView.setImageResource(R.drawable.ic_stop_notif);
                this.ivAutoPlayIcon.setVisibility(0);
                return;
            }
            return;
        }
        textView.setText("ကစားမည်");
        ImageView imageView2 = this.ivAutoPlayIcon;
        if (imageView2 != null) {
            imageView2.setVisibility(8);
        }
    }

    private void selectMatchCount(int i) {
        if (this.running) {
            return;
        }
        this.selectedMatchCount = i;
        int[] iArr = {1, 3, 5, 7, 8, 10};
        TextView[] textViewArr = {this.btnMatchCount1, this.btnMatchCount3, this.btnMatchCount5, this.btnMatchCount7, this.btnMatchCount8, this.btnMatchCount10};
        for (int i2 = 0; i2 < 6; i2++) {
            TextView textView = textViewArr[i2];
            if (textView != null) {
                if (iArr[i2] == i) {
                    textView.setBackgroundResource(R.drawable.bg_game_count_selected);
                    textViewArr[i2].setTextColor(getResources().getColor(R.color.yellow_primary, getTheme()));
                } else {
                    textView.setBackgroundResource(R.drawable.bg_game_count_normal);
                    textViewArr[i2].setTextColor(getResources().getColor(R.color.text_grey, getTheme()));
                }
            }
        }
    }

    private void setGamePickerVisible(boolean z) {
        View view = this.cardGamePicker;
        if (view != null) {
            view.setVisibility(z ? 0 : 8);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: startTimerUi, reason: merged with bridge method [inline-methods] */
    public void m624lambda$runAutoPlay$23$comzenoappMyIDGoActivity(final long j, final long j2) {
        stopTimerUi();
        Runnable runnable = new Runnable() { // from class: com.zeno.app.MyIDGoActivity.3
            @Override // java.lang.Runnable
            public void run() {
                long jCurrentTimeMillis = System.currentTimeMillis() - j;
                long jMax = Math.max(0L, j2 - jCurrentTimeMillis);
                int i = (int) (jCurrentTimeMillis / 1000);
                long j3 = j2;
                int iMin = j3 > 0 ? (int) Math.min(100L, (jCurrentTimeMillis * 100) / j3) : 100;
                long jMax2 = Math.max(0L, jMax / 1000);
                String str = String.format(Locale.getDefault(), "%02d:%02d", Long.valueOf(jMax2 / 60), Long.valueOf(jMax2 % 60));
                if (MyIDGoActivity.this.tvPlayingBig != null) {
                    MyIDGoActivity.this.tvPlayingBig.setText(str);
                }
                if (MyIDGoActivity.this.progressGame != null) {
                    MyIDGoActivity.this.progressGame.setProgress(iMin);
                }
                if (MyIDGoActivity.this.tvProgressLeft != null) {
                    MyIDGoActivity.this.tvProgressLeft.setText(MyIDGoActivity.this.fmtSec(i) + " / " + MyIDGoActivity.this.fmtMs(j2));
                }
                if (MyIDGoActivity.this.tvProgressRight != null) {
                    MyIDGoActivity.this.tvProgressRight.setText(iMin + "% • " + MyIDGoActivity.this.fmtMs(jMax) + " left");
                }
                if (jMax > 0) {
                    MyIDGoActivity.this.ui.postDelayed(this, 1000L);
                }
            }
        };
        this.timerRunnable = runnable;
        this.ui.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopTimerUi() {
        Runnable runnable = this.timerRunnable;
        if (runnable != null) {
            this.ui.removeCallbacks(runnable);
            this.timerRunnable = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    public java.lang.String fmtSec(
    /*  JADX ERROR: IndexOutOfBoundsException in pass: c
        java.lang.IndexOutOfBoundsException: Index 8 out of bounds for length 8
        	at jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:100)
        	at jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:106)
        	at jdk.internal.util.Preconditions.checkIndex(Preconditions.java:302)
        	at java.util.Objects.checkIndex(Objects.java:371)
        	at java.util.ArrayList.get(ArrayList.java:435)
        	at a9.c.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1507)
        */
    /*  JADX ERROR: Method generation error
        jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r7v0 ??
        	at g9.s.h(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:18)
        	at v8.f.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:547)
        	at v8.a.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:67)
        	at v8.a.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:209)
        	at aa.e.accept(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:16)
        	at j$.util.stream.o0.accept(SourceFile:183)
        	at j$.desugar.sun.nio.fs.g.accept(SourceFile:0)
        	at j$.util.Collection$-EL.a(SourceFile:665)
        	at j$.util.stream.n6.end(SourceFile:403)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.n.end(SourceFile:5)
        	at j$.util.stream.m5.end(SourceFile:258)
        	at j$.util.stream.m.end(SourceFile:5)
        	at j$.util.stream.a.c0(SourceFile:485)
        	at j$.util.stream.a.u0(SourceFile:474)
        	at j$.util.stream.o0.f(SourceFile:150)
        	at j$.util.stream.a.x0(SourceFile:234)
        	at j$.util.stream.i5.forEach(SourceFile:497)
        	at v8.a.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:359)
        	at com.google.firebase.remoteconfig.internal.b.call(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:78)
        	at qg.d.D(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:1)
        	at qg.d.l(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:71)
        	at u8.b.c(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:134)
        	at u8.b.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:89)
        	at k9.c.o0(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:48)
        	at a2.x.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:149)
        	at sa.b.e(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:10)
        	at androidx.activity.d.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:143)
        	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1100)
        	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:624)
        	at java.lang.Thread.run(Thread.java:1571)
        */

    /* JADX INFO: Access modifiers changed from: private */
    public String fmtMs(long j) {
        long j2 = j / 1000;
        if (j2 < 60) {
            return j2 + "s";
        }
        long j3 = j2 / 60;
        long j4 = j2 % 60;
        if (j4 == 0) {
            return j3 + "m";
        }
        return j3 + "m " + j4 + "s";
    }

    private void stopPlay() {
        this.stopping = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code restructure failed: missing block: B:153:0x03e0, code lost:
    
        r1 = "start failed";
     */
    /* JADX WARN: Code restructure failed: missing block: B:154:0x03e3, code lost:
    
        if (r0 == null) goto L158;
     */
    /* JADX WARN: Code restructure failed: missing block: B:156:0x03eb, code lost:
    
        if (ok(r0.body) == false) goto L158;
     */
    /* JADX WARN: Code restructure failed: missing block: B:157:0x03ed, code lost:
    
        r3 = new org.json.JSONObject(r0.body);
        r1 = r3.optString("message", r3.optString("error_desc", "start failed"));
     */
    /* JADX WARN: Removed duplicated region for block: B:139:0x0397  */
    /* JADX WARN: Removed duplicated region for block: B:161:0x0417  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x041e  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0154 A[PHI: r18
      0x0154: PHI (r18v2 java.lang.String) = (r18v0 java.lang.String), (r18v0 java.lang.String), (r18v1 java.lang.String) binds: [B:3:0x0026, B:29:0x00aa, B:52:0x0147] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:65:0x017b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void runAutoPlay() {
        /*
            Method dump skipped, instruction units count: 1080
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.zeno.app.MyIDGoActivity.runAutoPlay():void");
    }

    /* JADX INFO: renamed from: lambda$runAutoPlay$21$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m622lambda$runAutoPlay$21$comzenoappMyIDGoActivity(long j, SimpleDateFormat simpleDateFormat, long j2, long j3) {
        TextView textView = this.tvInfoTotalTime;
        if (textView != null) {
            textView.setText(fmtMs(j));
        }
        TextView textView2 = this.tvInfoStarted;
        if (textView2 != null) {
            textView2.setText(simpleDateFormat.format(new Date(j2)));
        }
        TextView textView3 = this.tvInfoEnd;
        if (textView3 != null) {
            textView3.setText(simpleDateFormat.format(new Date(j3)));
        }
    }

    /* JADX INFO: renamed from: lambda$runAutoPlay$22$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m623lambda$runAutoPlay$22$comzenoappMyIDGoActivity(int i, int i2) {
        this.tvGameProgress.setText("Round " + i + "/" + i2);
    }

    /* JADX INFO: renamed from: lambda$runAutoPlay$24$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m625lambda$runAutoPlay$24$comzenoappMyIDGoActivity() {
        if (ok(this.activeGameToken)) {
            fetchProfile(this.activeGameToken);
            fetchLeaderboard(this.activeGameToken);
        }
    }

    private void onDone() {
        this.running = false;
        this.stopping = false;
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m621lambda$onDone$25$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onDone$25$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m621lambda$onDone$25$comzenoappMyIDGoActivity() {
        stopTimerUi();
        setAutoPlayButtonState(false);
        this.btnAutoPlay.setBackgroundTintList(null);
        this.btnAutoPlay.setBackgroundResource(R.drawable.bg_btn_autoplay);
        this.tvAutoPlayStatus.setVisibility(8);
        setGamePickerVisible(true);
        View view = this.cardPlaying;
        if (view != null) {
            view.setVisibility(8);
        }
    }

    private void showRewardsDialog(final List<JSONObject> list) {
        if (list == null) {
            list = new ArrayList<>();
        }
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda34
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m628lambda$showRewardsDialog$29$comzenoappMyIDGoActivity(list);
            }
        });
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX INFO: renamed from: lambda$showRewardsDialog$29$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m628lambda$showRewardsDialog$29$comzenoappMyIDGoActivity(List list) {
        final Dialog dialog = new Dialog(this, R.style.Theme_ZenoMyID);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setContentView(R.layout.dialog_rewards);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda15
            @Override // android.content.DialogInterface.OnKeyListener
            public final boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                return MyIDGoActivity.lambda$showRewardsDialog$26(dialogInterface, i, keyEvent);
            }
        });
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.llRewardsTop);
        LinearLayout linearLayout2 = (LinearLayout) dialog.findViewById(R.id.llRewardsBottom);
        Button button = (Button) dialog.findViewById(R.id.btnRewardsOk);
        if (list.isEmpty()) {
            TextView textView = new TextView(this);
            textView.setText("ဒီ round အတွက် reward မရှိပါ");
            textView.setTextColor(COL_GREY);
            textView.setTextSize(14.0f);
            textView.setGravity(17);
            textView.setPadding(0, 0, 0, (int) (getResources().getDisplayMetrics().density * 8.0f));
            linearLayout.addView(textView);
            linearLayout2.setVisibility(8);
        } else {
            int iMin = Math.min(list.size(), 5);
            int iMin2 = Math.min(iMin, 3);
            int i = iMin - iMin2;
            for (int i2 = 0; i2 < iMin2; i2++) {
                addRewardItem(linearLayout, (JSONObject) list.get(i2));
            }
            for (int i3 = 0; i3 < i; i3++) {
                addRewardItem(linearLayout2, (JSONObject) list.get(iMin2 + i3));
            }
            linearLayout2.setVisibility(i <= 0 ? 8 : 0);
        }
        button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialog.dismiss();
            }
        });
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawableResource(android.R.color.transparent);
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            window.setLayout(displayMetrics.widthPixels - (((int) (displayMetrics.density * 20.0f)) * 2), -2);
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = 17;
            attributes.dimAmount = 0.7f;
            window.setAttributes(attributes);
            window.addFlags(2);
        }
        dialog.show();
        this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda17
            @Override // java.lang.Runnable
            public final void run() {
                MyIDGoActivity.lambda$showRewardsDialog$28(dialog);
            }
        }, 60000L);
    }

    static /* synthetic */ void lambda$showRewardsDialog$28(Dialog dialog) {
        if (dialog.isShowing()) {
            dialog.dismiss();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void addRewardItem(LinearLayout linearLayout, JSONObject jSONObject) {
        View viewInflate = LayoutInflater.from(this).inflate(R.layout.item_reward_dialog, (ViewGroup) linearLayout, false);
        String strFmtReward = fmtReward(jSONObject);
        int iLastIndexOf = strFmtReward.lastIndexOf(124);
        String strSubstring = iLastIndexOf >= 0 ? strFmtReward.substring(0, iLastIndexOf) : strFmtReward;
        String strSubstring2 = iLastIndexOf >= 0 ? strFmtReward.substring(iLastIndexOf + 1) : "1";
        int iRewardIconRes = rewardIconRes(strSubstring);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.ivRewardIcon);
        TextView textView = (TextView) viewInflate.findViewById(R.id.tvRewardAmt);
        if (iRewardIconRes == 0) {
            iRewardIconRes = R.drawable.ic_stat_mix;
        }
        imageView.setImageResource(iRewardIconRes);
        textView.setText(strSubstring2 + " " + strSubstring);
        linearLayout.addView(viewInflate);
    }

    private Request gameReq(String str, String str2) {
        return new Request.Builder().url(str).addHeader("Authorization", "Bearer " + str2).addHeader("Accept", "application/json").build();
    }

    private List<JSONObject> fetchLatestRewardsFromHistory(String str, long j) {
        ArrayList arrayList = new ArrayList();
        try {
            HttpResult withStatus = getWithStatus("https://pubapi-mygov2.mtgmm.co/v1/engine/game/reward/history?limit=30", str);
            if (withStatus != null && withStatus.status == 200 && ok(withStatus.body)) {
                JSONObject jSONObjectOptJSONObject = new JSONObject(withStatus.body).optJSONObject("data");
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optJSONArray("data") : null;
                if (jSONArrayOptJSONArray == null) {
                    return arrayList;
                }
                for (int i = 0; i < jSONArrayOptJSONArray.length() && arrayList.size() < 5; i++) {
                    JSONObject jSONObjectOptJSONObject2 = jSONArrayOptJSONArray.optJSONObject(i);
                    if (jSONObjectOptJSONObject2 != null) {
                        long jOptLong = jSONObjectOptJSONObject2.optLong("created_at", 0L);
                        if (jOptLong > 0 && jOptLong >= j) {
                            arrayList.add(jSONObjectOptJSONObject2);
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
        return arrayList;
    }

    private HttpResult getWithStatus(String str, String str2) {
        String strString = "";
        try {
            Response responseExecute = this.http.newCall(gameReq(str, str2)).execute();
            int iCode = responseExecute.code();
            String strHeader = responseExecute.header("Location", "");
            ResponseBody responseBodyBody = responseExecute.body();
            if (responseBodyBody != null) {
                strString = responseBodyBody.string();
                responseBodyBody.close();
            }
            responseExecute.close();
            return new HttpResult(iCode, strString, strHeader);
        } catch (Exception unused) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String consumeBody(Response response) throws IOException {
        String strString;
        ResponseBody responseBodyBody = response.body();
        if (responseBodyBody != null) {
            strString = responseBodyBody.string();
            responseBodyBody.close();
        } else {
            strString = "";
        }
        response.close();
        return strString;
    }

    private String fmtReward(JSONObject jSONObject) {
        String strOptString = jSONObject.optString("reward_name", jSONObject.optString("rewardName", jSONObject.optString("name", jSONObject.optString("type", jSONObject.optString("reward_type", "")))));
        int iOptInt = jSONObject.optInt("value", jSONObject.optInt("amount", jSONObject.optInt("Amount", jSONObject.optInt("quantity", 1))));
        return strOptString.replaceAll("^\\d+\\s*", "").trim() + "|" + iOptInt;
    }

    private void logReward(JSONObject jSONObject) {
        String strFmtReward = fmtReward(jSONObject);
        int iLastIndexOf = strFmtReward.lastIndexOf(124);
        String strSubstring = iLastIndexOf >= 0 ? strFmtReward.substring(0, iLastIndexOf) : strFmtReward;
        String strSubstring2 = iLastIndexOf >= 0 ? strFmtReward.substring(iLastIndexOf + 1) : "1";
        logWithIcon(rewardIconRes(strSubstring), "  " + strSubstring2 + " " + strSubstring, COL_YELLOW);
    }

    private int rewardIconRes(String str) {
        if (str == null) {
            return 0;
        }
        String strTrim = str.toUpperCase(Locale.US).trim();
        strTrim.hashCode();
        switch (strTrim) {
        }
        return 0;
    }

    private void logWithIcon(int i, String str, int i2) {
        log(str.trim(), i2);
    }

    private String ts() {
        return "[" + new SimpleDateFormat("hh:mm:ss a", Locale.US).format(new Date()) + "]";
    }

    private void clearTerminal() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda22
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m612lambda$clearTerminal$30$comzenoappMyIDGoActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$clearTerminal$30$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m612lambda$clearTerminal$30$comzenoappMyIDGoActivity() {
        stopTimerUi();
        TextView textView = this.tvPlayingBig;
        if (textView != null) {
            textView.setText("00:00");
        }
        ProgressBar progressBar = this.progressGame;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        TextView textView2 = this.tvProgressLeft;
        if (textView2 != null) {
            textView2.setText("0s / 0m");
        }
        TextView textView3 = this.tvProgressRight;
        if (textView3 != null) {
            textView3.setText("0% • -- left");
        }
        TextView textView4 = this.tvGameProgress;
        if (textView4 != null) {
            textView4.setText("Round 0/" + this.selectedMatchCount);
        }
        TextView textView5 = this.tvInfoTotalTime;
        if (textView5 != null) {
            textView5.setText("--");
        }
        TextView textView6 = this.tvInfoStarted;
        if (textView6 != null) {
            textView6.setText("--");
        }
        TextView textView7 = this.tvInfoEnd;
        if (textView7 != null) {
            textView7.setText("--");
        }
    }

    private int iconForMessage(String str) {
        if (str == null) {
            return 0;
        }
        String strTrim = str.toLowerCase(Locale.US).trim();
        if (strTrim.startsWith("waiting for command")) {
            return R.drawable.ic_clock;
        }
        if (strTrim.startsWith("starting automation")) {
            return R.drawable.ic_play;
        }
        if (strTrim.equals("login success")) {
            return R.drawable.ic_phone;
        }
        if (strTrim.equals("start success")) {
            return R.drawable.ic_play;
        }
        if (strTrim.startsWith("level") && strTrim.contains("success")) {
            return R.drawable.ic_star;
        }
        if (strTrim.equals("stop success")) {
            return R.drawable.ic_sync;
        }
        if (strTrim.startsWith("stopped by user")) {
            return R.drawable.ic_close_circle;
        }
        if (strTrim.startsWith("error")) {
            return R.drawable.ic_trending_down;
        }
        if (strTrim.equals("rewards:")) {
            return R.drawable.ic_gift;
        }
        if (strTrim.startsWith("automation complete")) {
            return R.drawable.ic_trophy;
        }
        return 0;
    }

    private void log(final String str, final int i) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.MyIDGoActivity$$ExternalSyntheticLambda14
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m617lambda$log$31$comzenoappMyIDGoActivity(str, i);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$log$31$com-zeno-app-MyIDGoActivity, reason: not valid java name */
    /* synthetic */ void m617lambda$log$31$comzenoappMyIDGoActivity(String str, int i) {
        TextView textView = this.tvPlayingStatus;
        if (textView == null) {
            return;
        }
        textView.setText(str);
        this.tvPlayingStatus.setTextColor(i);
    }

    private JSONObject jwtPayload(String str) throws Exception {
        String[] strArrSplit = str.split("\\.");
        if (strArrSplit.length < 2) {
            return new JSONObject();
        }
        int length = strArrSplit[1].length() % 4;
        StringBuilder sb = new StringBuilder();
        sb.append(strArrSplit[1]);
        sb.append(length == 0 ? "" : "====".substring(length));
        return new JSONObject(new String(Base64.decode(sb.toString(), 8), "UTF-8"));
    }

    private String uriParam(String str, String str2) {
        try {
            return Uri.parse(str).getQueryParameter(str2);
        } catch (Exception unused) {
            return null;
        }
    }

    private String enc(String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        } catch (Exception unused) {
            return str;
        }
    }

    private boolean ok(String str) {
        return (str == null || str.isEmpty()) ? false : true;
    }

    private void sleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException unused) {
        }
    }

    private String[] uniqueNonEmpty(String... strArr) {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        for (String str : strArr) {
            if (ok(str)) {
                linkedHashSet.add(str);
            }
        }
        return (String[]) linkedHashSet.toArray(new String[0]);
    }

    protected void onDestroy() {
        super.onDestroy();
        this.stopping = true;
        ExecutorService executorService = this.exec;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    private void startStatsSkeleton() {
        if (this.llStatsLoading == null) {
            return;
        }
        LinearLayout linearLayout = this.llStats;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.llStatsLoading.setVisibility(0);
        this.statsSkeletonAnim = SkeletonPulse.start(this.llStatsLoading);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopStatsSkeleton() {
        SkeletonPulse.stop(this.statsSkeletonAnim, this.llStatsLoading);
        this.statsSkeletonAnim = null;
        LinearLayout linearLayout = this.llStatsLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.llStats;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(0);
        }
    }

    private void startProfileSkeleton() {
        View view = this.avatarSkeleton;
        if (view != null) {
            view.setVisibility(0);
            this.avatarSkeletonAnim = SkeletonPulse.start(this.avatarSkeleton);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(4);
        }
        View view2 = this.profileTextSkeleton;
        if (view2 != null) {
            view2.setVisibility(0);
            this.profileTextSkeletonAnim = SkeletonPulse.start(this.profileTextSkeleton);
        }
        View view3 = this.profileTextContent;
        if (view3 != null) {
            view3.setVisibility(4);
        }
    }

    private void stopProfileSkeleton() {
        SkeletonPulse.stop(this.avatarSkeletonAnim, this.avatarSkeleton);
        this.avatarSkeletonAnim = null;
        SkeletonPulse.stop(this.profileTextSkeletonAnim, this.profileTextSkeleton);
        this.profileTextSkeletonAnim = null;
        View view = this.avatarSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        ImageView imageView = this.ivAvatar;
        if (imageView != null) {
            imageView.setVisibility(0);
        }
        View view2 = this.profileTextSkeleton;
        if (view2 != null) {
            view2.setVisibility(8);
        }
        View view3 = this.profileTextContent;
        if (view3 != null) {
            view3.setVisibility(0);
        }
    }

    private void startShopSkeleton() {
        if (this.shopCardsSkeleton == null) {
            return;
        }
        View view = this.shopCardsContent;
        if (view != null) {
            view.setVisibility(8);
        }
        this.shopCardsSkeleton.setVisibility(0);
        this.shopSkeletonAnim = SkeletonPulse.start(this.shopCardsSkeleton);
    }

    private void stopShopSkeleton() {
        SkeletonPulse.stop(this.shopSkeletonAnim, this.shopCardsSkeleton);
        this.shopSkeletonAnim = null;
        View view = this.shopCardsSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.shopCardsContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    private void startAutoPlaySkeleton() {
        if (this.autoPlaySkeleton == null) {
            return;
        }
        View view = this.autoPlayContent;
        if (view != null) {
            view.setVisibility(8);
        }
        LinearLayout linearLayout = this.btnAutoPlay;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.autoPlaySkeleton.setVisibility(0);
        this.autoPlaySkeletonAnim = SkeletonPulse.start(this.autoPlaySkeleton);
    }

    private void stopAutoPlaySkeleton() {
        SkeletonPulse.stop(this.autoPlaySkeletonAnim, this.autoPlaySkeleton);
        this.autoPlaySkeletonAnim = null;
        View view = this.autoPlaySkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.autoPlayContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        LinearLayout linearLayout = this.btnAutoPlay;
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
        }
    }

    private void startGamePickerSkeleton() {
        if (this.gamePickerSkeleton == null) {
            return;
        }
        View view = this.gamePickerContent;
        if (view != null) {
            view.setVisibility(8);
        }
        this.gamePickerSkeleton.setVisibility(0);
        this.gamePickerSkeletonAnim = SkeletonPulse.start(this.gamePickerSkeleton);
    }

    private void stopGamePickerSkeleton() {
        SkeletonPulse.stop(this.gamePickerSkeletonAnim, this.gamePickerSkeleton);
        this.gamePickerSkeletonAnim = null;
        View view = this.gamePickerSkeleton;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.gamePickerContent;
        if (view2 != null) {
            view2.setVisibility(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startRankSkeleton() {
        if (this.llLeaderboardLoading == null) {
            return;
        }
        LinearLayout linearLayout = this.llLeaderboardRows;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        this.llLeaderboardLoading.setVisibility(0);
        this.rankSkeletonAnim = SkeletonPulse.start(this.llLeaderboardLoading);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stopRankSkeleton() {
        SkeletonPulse.stop(this.rankSkeletonAnim, this.llLeaderboardLoading);
        this.rankSkeletonAnim = null;
        LinearLayout linearLayout = this.llLeaderboardLoading;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.llLeaderboardRows;
        if (linearLayout2 != null) {
            linearLayout2.setVisibility(0);
        }
    }
}
