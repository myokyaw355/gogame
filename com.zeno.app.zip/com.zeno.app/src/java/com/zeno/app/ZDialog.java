package com.zeno.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final class ZDialog {
    private ZDialog() {
    }

    public static void confirm(Context context, String str, String str2, String str3, Runnable runnable) {
        confirm(context, str, str2, str3, runnable, "Cancel", null, null, false);
    }

    public static void confirm(Context context, String str, String str2, String str3, final Runnable runnable, String str4, final Runnable runnable2, Integer num, boolean z) {
        final Dialog dialogBuildDialog = buildDialog(context);
        dialogBuildDialog.setContentView(R.layout.dialog_zeno);
        TextView textView = (TextView) dialogBuildDialog.findViewById(R.id.tvZTitle);
        TextView textView2 = (TextView) dialogBuildDialog.findViewById(R.id.tvZMessage);
        TextView textView3 = (TextView) dialogBuildDialog.findViewById(R.id.btnZPositive);
        TextView textView4 = (TextView) dialogBuildDialog.findViewById(R.id.btnZNegative);
        ImageView imageView = (ImageView) dialogBuildDialog.findViewById(R.id.ivZIcon);
        textView.setText(str);
        if (z) {
            textView.setGravity(17);
        }
        textView2.setText(str2);
        textView3.setText(str3);
        if (str4 == null) {
            str4 = "Cancel";
        }
        textView4.setText(str4);
        if (num != null) {
            imageView.setImageResource(num.intValue());
            imageView.setVisibility(0);
        }
        textView4.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda16
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ZDialog.lambda$confirm$0(dialogBuildDialog, runnable2, view);
            }
        });
        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                ZDialog.lambda$confirm$1(dialogBuildDialog, runnable, view);
            }
        });
        applyWindow(context, dialogBuildDialog);
        dialogBuildDialog.show();
    }

    static /* synthetic */ void lambda$confirm$0(Dialog dialog, Runnable runnable, View view) {
        dialog.dismiss();
        if (runnable != null) {
            runnable.run();
        }
    }

    static /* synthetic */ void lambda$confirm$1(Dialog dialog, Runnable runnable, View view) {
        dialog.dismiss();
        if (runnable != null) {
            runnable.run();
        }
    }

    public static void alert(Context context, String str, String str2) {
        final Dialog dialogBuildDialog = buildDialog(context);
        dialogBuildDialog.setContentView(R.layout.dialog_zeno);
        TextView textView = (TextView) dialogBuildDialog.findViewById(R.id.tvZTitle);
        TextView textView2 = (TextView) dialogBuildDialog.findViewById(R.id.tvZMessage);
        TextView textView3 = (TextView) dialogBuildDialog.findViewById(R.id.btnZPositive);
        TextView textView4 = (TextView) dialogBuildDialog.findViewById(R.id.btnZNegative);
        textView.setText(str);
        textView2.setText(str2);
        textView4.setVisibility(8);
        textView3.setText("OK");
        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                dialogBuildDialog.dismiss();
            }
        });
        applyWindow(context, dialogBuildDialog);
        dialogBuildDialog.show();
    }

    public static void showGameLocked(Context context, String str, String str2, String str3) {
        final Dialog dialogBuildDialog = buildDialog(context);
        dialogBuildDialog.setContentView(R.layout.dialog_game_locked);
        TextView textView = (TextView) dialogBuildDialog.findViewById(R.id.tvLockedTitle);
        TextView textView2 = (TextView) dialogBuildDialog.findViewById(R.id.tvLockedMessage);
        TextView textView3 = (TextView) dialogBuildDialog.findViewById(R.id.btnLockedOk);
        if (textView != null && str != null && !str.isEmpty()) {
            textView.setText(str);
        }
        if (textView2 != null) {
            textView2.setText(str2);
        }
        if (textView3 != null) {
            if (str3 != null && !str3.isEmpty()) {
                textView3.setText(str3);
            }
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda13
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialogBuildDialog.dismiss();
                }
            });
        }
        applyWindow(context, dialogBuildDialog);
        dialogBuildDialog.show();
    }

    public static void showCloseApp(Context context, String str, String str2) {
        Dialog dialogBuildLockDialog = buildLockDialog(context);
        dialogBuildLockDialog.setContentView(R.layout.dialog_close_app);
        TextView textView = (TextView) dialogBuildLockDialog.findViewById(R.id.tvCloseTitle);
        TextView textView2 = (TextView) dialogBuildLockDialog.findViewById(R.id.tvCloseMessage);
        TextView textView3 = (TextView) dialogBuildLockDialog.findViewById(R.id.btnCloseApp);
        if (textView != null && str != null && !str.isEmpty()) {
            textView.setText(str);
        }
        if (textView2 != null) {
            textView2.setText(str2);
        }
        if (textView3 != null) {
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda7
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    System.exit(0);
                }
            });
        }
        applyWindow(context, dialogBuildLockDialog);
        dialogBuildLockDialog.show();
    }

    public static void showUpdateRequired(final Context context, String str, String str2, final String str3, String str4, String str5) {
        Dialog dialogBuildLockDialog = buildLockDialog(context);
        dialogBuildLockDialog.setContentView(R.layout.dialog_update_app);
        TextView textView = (TextView) dialogBuildLockDialog.findViewById(R.id.tvUpdateTitle);
        TextView textView2 = (TextView) dialogBuildLockDialog.findViewById(R.id.tvUpdateMessage);
        TextView textView3 = (TextView) dialogBuildLockDialog.findViewById(R.id.btnUpdateNow);
        if (textView != null && str4 != null && !str4.isEmpty()) {
            textView.setText(str4);
        }
        if (textView2 != null && str5 != null && !str5.isEmpty()) {
            textView2.setText(str5);
        }
        if (textView3 != null) {
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda6
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ZDialog.lambda$showUpdateRequired$5(str3, context, view);
                }
            });
        }
        applyWindow(context, dialogBuildLockDialog);
        dialogBuildLockDialog.show();
    }

    static /* synthetic */ void lambda$showUpdateRequired$5(String str, Context context, View view) {
        if (str.isEmpty()) {
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
            intent.addFlags(268435456);
            context.startActivity(intent);
        } catch (Exception unused) {
        }
    }

    public static void showChangeApk(Context context, String str, String str2) {
        Dialog dialogBuildLockDialog = buildLockDialog(context);
        dialogBuildLockDialog.setContentView(R.layout.dialog_change_apk);
        TextView textView = (TextView) dialogBuildLockDialog.findViewById(R.id.tvChangeApkTitle);
        TextView textView2 = (TextView) dialogBuildLockDialog.findViewById(R.id.tvChangeApkMessage);
        if (textView != null && str != null && !str.isEmpty()) {
            textView.setText(str);
        }
        if (textView2 != null) {
            if (str2 == null) {
                str2 = "";
            }
            textView2.setText(str2);
        }
        applyWindow(context, dialogBuildLockDialog);
        dialogBuildLockDialog.show();
    }

    public static void showNotification(final Context context, String str, String str2, final String str3, String str4, String str5, final Runnable runnable) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_notification);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        TextView textView = (TextView) dialog.findViewById(R.id.tvNotifTitle);
        TextView textView2 = (TextView) dialog.findViewById(R.id.tvNotifMessage);
        TextView textView3 = (TextView) dialog.findViewById(R.id.btnNotifAction);
        ImageView imageView = (ImageView) dialog.findViewById(R.id.ivNotifImage);
        if (textView != null) {
            textView.setText(str);
        }
        if (textView2 != null) {
            if (str2 != null && !str2.isEmpty()) {
                textView2.setText(str2);
                textView2.setVisibility(0);
            } else {
                textView2.setVisibility(8);
            }
        }
        if (imageView != null) {
            if (str5 != null && !str5.isEmpty()) {
                imageView.setVisibility(0);
                final int i = (int) (context.getResources().getDisplayMetrics().density * 12.0f);
                imageView.setOutlineProvider(new ViewOutlineProvider() { // from class: com.zeno.app.ZDialog.1
                    @Override // android.view.ViewOutlineProvider
                    public void getOutline(View view, Outline outline) {
                        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), i);
                    }
                });
                imageView.setClipToOutline(true);
                loadNotificationImage(context, str5, imageView);
            } else {
                imageView.setVisibility(8);
            }
        }
        if (textView3 != null) {
            if (str4.isEmpty()) {
                str4 = "Open";
            }
            textView3.setText(str4);
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda14
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ZDialog.lambda$showNotification$6(str3, context, dialog, view);
                }
            });
        }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda15
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                ZDialog.lambda$showNotification$7(runnable, dialogInterface);
            }
        });
        applyWindow(context, dialog);
        dialog.show();
    }

    static /* synthetic */ void lambda$showNotification$6(String str, Context context, Dialog dialog, View view) {
        if (!str.isEmpty()) {
            try {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                intent.addFlags(268435456);
                context.startActivity(intent);
            } catch (Exception unused) {
            }
        }
        dialog.dismiss();
    }

    static /* synthetic */ void lambda$showNotification$7(Runnable runnable, DialogInterface dialogInterface) {
        if (runnable != null) {
            runnable.run();
        }
    }

    public static void confirmSheet(Context context, String str, String str2, String str3, Runnable runnable) {
        confirmSheet(context, str, str2, str3, runnable, null, null);
    }

    public static void confirmSheet(Context context, String str, String str2, String str3, final Runnable runnable, String str4, String str5) {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.MyBottomSheet);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_exchange_confirm);
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda3
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                ZDialog.lambda$confirmSheet$8(bottomSheetDialog, dialogInterface);
            }
        });
        TextView textView = (TextView) bottomSheetDialog.findViewById(R.id.tvExchangeTitle);
        if (textView != null) {
            textView.setText(str);
        }
        TextView textView2 = (TextView) bottomSheetDialog.findViewById(R.id.tvExchangePoints);
        TextView textView3 = (TextView) bottomSheetDialog.findViewById(R.id.tvExchangeReward);
        if (str4 != null && str5 != null) {
            if (textView2 != null) {
                textView2.setText(str4);
            }
            if (textView3 != null) {
                textView3.setText(str5);
            }
        } else if (str2 != null) {
            if (textView2 != null) {
                textView2.setText("—");
            }
            if (textView3 != null) {
                textView3.setText(str2.replace("\n", " ").trim());
            }
        }
        TextView textView4 = (TextView) bottomSheetDialog.findViewById(R.id.tvExchangeMessage);
        if (textView4 != null) {
            if (str2 == null) {
                str2 = "";
            }
            textView4.setText(str2);
        }
        TextView textView5 = (TextView) bottomSheetDialog.findViewById(R.id.btnExchangeCancel);
        if (textView5 != null) {
            textView5.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    bottomSheetDialog.dismiss();
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) bottomSheetDialog.findViewById(R.id.btnExchangeConfirm);
        if (linearLayout != null) {
            if (linearLayout.getChildCount() > 0 && (linearLayout.getChildAt(0) instanceof TextView)) {
                ((TextView) linearLayout.getChildAt(0)).setText(str3);
            }
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda5
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ZDialog.lambda$confirmSheet$10(bottomSheetDialog, runnable, view);
                }
            });
        }
        bottomSheetDialog.show();
    }

    static /* synthetic */ void lambda$confirmSheet$8(BottomSheetDialog bottomSheetDialog, DialogInterface dialogInterface) {
        Window window = bottomSheetDialog.getWindow();
        if (window != null) {
            window.setDimAmount(0.55f);
            window.setNavigationBarColor(-14803426);
        }
        FrameLayout frameLayout = (FrameLayout) bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (frameLayout != null) {
            frameLayout.setBackground(null);
            frameLayout.setBackgroundColor(0);
        }
    }

    static /* synthetic */ void lambda$confirmSheet$10(BottomSheetDialog bottomSheetDialog, Runnable runnable, View view) {
        bottomSheetDialog.dismiss();
        if (runnable != null) {
            runnable.run();
        }
    }

    public static void purchase(Context context, String str, String str2, String str3, int i, int i2, int i3, String str4, final Runnable runnable) {
        String str5;
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context, R.style.MyBottomSheet);
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_purchase);
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.setOnShowListener(new DialogInterface.OnShowListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda10
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                ZDialog.lambda$purchase$11(bottomSheetDialog, dialogInterface);
            }
        });
        ImageView imageView = (ImageView) bottomSheetDialog.findViewById(R.id.ivPurchaseIcon);
        if (imageView != null) {
            imageView.setImageResource(i2);
            imageView.setColorFilter(-1, PorterDuff.Mode.SRC_IN);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(0);
            gradientDrawable.setCornerRadius(context.getResources().getDisplayMetrics().density * 14.0f);
            gradientDrawable.setColor(i3);
            imageView.setBackground(gradientDrawable);
        }
        TextView textView = (TextView) bottomSheetDialog.findViewById(R.id.tvPurchaseName);
        if (textView != null) {
            textView.setText(str);
        }
        TextView textView2 = (TextView) bottomSheetDialog.findViewById(R.id.tvPurchaseDesc);
        if (textView2 != null) {
            if (!str2.isEmpty() && !str2.equals(str)) {
                textView2.setText(str2);
                textView2.setVisibility(0);
            } else {
                textView2.setVisibility(8);
            }
        }
        TextView textView3 = (TextView) bottomSheetDialog.findViewById(R.id.tvPurchasePrice);
        if (textView3 != null) {
            textView3.setText(str3);
        }
        TextView textView4 = (TextView) bottomSheetDialog.findViewById(R.id.tvPurchaseValidity);
        if (textView4 != null) {
            if (i == 1) {
                str5 = "24 နာရီ";
            } else {
                str5 = i + " ရက်";
            }
            textView4.setText(str5);
        }
        TextView textView5 = (TextView) bottomSheetDialog.findViewById(R.id.tvPurchasePhone);
        if (textView5 != null) {
            textView5.setText(str4 + " နံပါတ်အတွက် ဝယ်ယူမည်");
        }
        TextView textView6 = (TextView) bottomSheetDialog.findViewById(R.id.btnPurchaseCancel);
        if (textView6 != null) {
            textView6.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda11
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    bottomSheetDialog.dismiss();
                }
            });
        }
        LinearLayout linearLayout = (LinearLayout) bottomSheetDialog.findViewById(R.id.btnPurchaseConfirm);
        if (linearLayout != null) {
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda12
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    ZDialog.lambda$purchase$13(bottomSheetDialog, runnable, view);
                }
            });
        }
        bottomSheetDialog.show();
    }

    static /* synthetic */ void lambda$purchase$11(BottomSheetDialog bottomSheetDialog, DialogInterface dialogInterface) {
        Window window = bottomSheetDialog.getWindow();
        if (window != null) {
            window.setDimAmount(0.55f);
            window.setNavigationBarColor(-14803426);
        }
        FrameLayout frameLayout = (FrameLayout) bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (frameLayout != null) {
            frameLayout.setBackground(null);
            frameLayout.setBackgroundColor(0);
        }
    }

    static /* synthetic */ void lambda$purchase$13(BottomSheetDialog bottomSheetDialog, Runnable runnable, View view) {
        bottomSheetDialog.dismiss();
        if (runnable != null) {
            runnable.run();
        }
    }

    public static void purchase(Context context, String str, String str2, String str3, Runnable runnable) {
        purchase(context, str, str2, str3, 0, R.drawable.ic_bar_chart, -14018048, "", runnable);
    }

    private static void loadNotificationImage(Context context, final String str, final ImageView imageView) {
        if (str == null || str.isEmpty() || imageView == null) {
            return;
        }
        final Context applicationContext = context.getApplicationContext();
        final Handler handler = new Handler(Looper.getMainLooper());
        new Thread(new Runnable() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                ZDialog.lambda$loadNotificationImage$16(applicationContext, str, handler, imageView);
            }
        }).start();
    }

    static /* synthetic */ void lambda$loadNotificationImage$16(Context context, String str, Handler handler, final ImageView imageView) {
        final Bitmap bitmapDecodeFile;
        try {
            File fileNotifImageCacheFile = notifImageCacheFile(context, str);
            if (fileNotifImageCacheFile.exists() && fileNotifImageCacheFile.length() > 0 && (bitmapDecodeFile = BitmapFactory.decodeFile(fileNotifImageCacheFile.getAbsolutePath())) != null) {
                handler.post(new Runnable() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        imageView.setImageBitmap(bitmapDecodeFile);
                    }
                });
                return;
            }
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36");
            httpURLConnection.connect();
            if (httpURLConnection.getResponseCode() != 200) {
                httpURLConnection.disconnect();
                return;
            }
            InputStream inputStream = httpURLConnection.getInputStream();
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bArr = new byte[8192];
            while (true) {
                int i = inputStream.read(bArr);
                if (i == -1) {
                    break;
                } else {
                    byteArrayOutputStream.write(bArr, 0, i);
                }
            }
            inputStream.close();
            httpURLConnection.disconnect();
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            final Bitmap bitmapDecodeByteArray = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
            if (bitmapDecodeByteArray == null) {
                return;
            }
            clearNotifImageCache(context);
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(fileNotifImageCacheFile);
                try {
                    fileOutputStream.write(byteArray);
                    fileOutputStream.close();
                } finally {
                }
            } catch (Exception unused) {
            }
            handler.post(new Runnable() { // from class: com.zeno.app.ZDialog$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    imageView.setImageBitmap(bitmapDecodeByteArray);
                }
            });
        } catch (Exception unused2) {
        }
    }

    private static File notifImageCacheDir(Context context) {
        File file = new File(context.getFilesDir(), "notif_banner");
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    private static File notifImageCacheFile(Context context, String str) {
        String strValueOf = String.valueOf(str.hashCode());
        return new File(notifImageCacheDir(context), strValueOf + ".img");
    }

    private static void clearNotifImageCache(Context context) {
        File[] fileArrListFiles = notifImageCacheDir(context).listFiles();
        if (fileArrListFiles != null) {
            for (File file : fileArrListFiles) {
                file.delete();
            }
        }
    }

    private static Dialog buildDialog(Context context) {
        Dialog dialog = new Dialog(context, R.style.Theme_ZenoMyID);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        return dialog;
    }

    private static Dialog buildLockDialog(Context context) {
        Dialog dialog = new Dialog(context, R.style.Theme_ZenoMyID) { // from class: com.zeno.app.ZDialog.2
            @Override // android.app.Dialog
            public void onBackPressed() {
            }
        };
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    private static void applyWindow(Context context, Dialog dialog) {
        Window window = dialog.getWindow();
        if (window == null) {
            return;
        }
        window.setBackgroundDrawableResource(android.R.color.transparent);
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        window.setLayout(displayMetrics.widthPixels - (((int) (displayMetrics.density * 20.0f)) * 2), -2);
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = 17;
        attributes.dimAmount = 0.65f;
        window.setAttributes(attributes);
        window.addFlags(2);
    }
}
