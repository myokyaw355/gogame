package com.zeno.app;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.zeno.app.SpinWheelView;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class CarRacingSpinActivity extends AppCompatActivity {
    private static final String GAME_BASE = "https://car-racing.mascom.vn";
    private static final String ORIGIN = "https://car-racing.mascom.vn";
    private static final int[] SEG_BG = {-15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440, -15066598, -13885440};
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 12; Redmi K30 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36";
    private static final String X_REQ = "com.myentertainment.oneid";
    private TextView btnAutoSpin;
    private Button btnSpin;
    private View cardLoading;
    private ValueAnimator cardSkeletonAnim;
    private View chipRow;
    private View controlsLoading;
    private ValueAnimator controlsSkeletonAnim;
    private TextView[] countChips;
    private String gameToken;
    private SpinWheelView spinWheelView;
    private TextView tvBananaBalance;
    private TextView tvFreeSpins;
    private TextView tvSpinPrice;
    private View wheelLoading;
    private ValueAnimator wheelSkeletonAnim;
    private int turnFree = 0;
    private int turnNumber = 0;
    private int spinPrice = 0;
    private long coins = 0;
    private final List<JSONObject> spinItems = new ArrayList();
    private int autoSpinCount = 1;
    private int autoRemaining = 0;
    private boolean isAutoSpinning = false;
    private final List<JSONObject> autoResults = new ArrayList();
    private final ConcurrentHashMap<String, Bitmap> iconCache = new ConcurrentHashMap<>();
    private final ExecutorService exec = Executors.newFixedThreadPool(3);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build();

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(-3632086);
        WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            insetsController.setAppearanceLightStatusBars(false);
        }
        setContentView(R.layout.activity_spin_wheel);
        this.gameToken = getIntent().getStringExtra("gameToken");
        this.coins = getIntent().getLongExtra("coins", 0L);
        this.spinWheelView = (SpinWheelView) findViewById(R.id.spinWheelView);
        this.wheelLoading = findViewById(R.id.wheelLoading);
        this.cardLoading = findViewById(R.id.cardLoading);
        this.btnSpin = (Button) findViewById(R.id.btnSpin);
        this.tvFreeSpins = (TextView) findViewById(R.id.tvFreeSpins);
        this.tvSpinPrice = (TextView) findViewById(R.id.tvSpinPrice);
        this.tvBananaBalance = (TextView) findViewById(R.id.tvBananaBalance);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda19
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m247lambda$onCreate$0$comzenoappCarRacingSpinActivity(view);
            }
        });
        this.btnSpin.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda20
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m248lambda$onCreate$1$comzenoappCarRacingSpinActivity(view);
            }
        });
        replaceBananaWithCoin();
        setupAutoSpinUi();
        TextView textView = this.tvBananaBalance;
        if (textView != null) {
            textView.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(this.coins)));
        }
        fetchSpinList();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m247lambda$onCreate$0$comzenoappCarRacingSpinActivity(View view) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m248lambda$onCreate$1$comzenoappCarRacingSpinActivity(View view) {
        if (this.isAutoSpinning) {
            stopAutoSpin();
        } else {
            doSpin();
        }
    }

    private void replaceBananaWithCoin() {
        TextView textView = this.tvBananaBalance;
        if (textView != null) {
            ViewParent parent = textView.getParent();
            if (parent instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) parent;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    View childAt = viewGroup.getChildAt(i);
                    if (childAt instanceof ImageView) {
                        ImageView imageView = (ImageView) childAt;
                        imageView.setImageResource(R.drawable.ic_coin);
                        imageView.setContentDescription("Coin");
                    }
                }
            }
        }
        View viewFindViewById = findViewById(android.R.id.content);
        if (viewFindViewById != null) {
            replaceBananaEmojiInViews(viewFindViewById);
        }
    }

    private void replaceBananaEmojiInViews(View view) {
        Drawable drawable;
        if (view instanceof TextView) {
            TextView textView = (TextView) view;
            CharSequence text = textView.getText();
            if (text != null) {
                String string = text.toString();
                if (string.contains("🍌") || string.contains("Cost / Spin")) {
                    textView.setText(string.replace("🍌", "").trim());
                    if (!string.contains("Cost") || (drawable = getResources().getDrawable(R.drawable.ic_coin, getTheme())) == null) {
                        return;
                    }
                    int i = (int) (getResources().getDisplayMetrics().density * 14.0f);
                    drawable.setBounds(0, 0, i, i);
                    textView.setCompoundDrawables(drawable, null, null, null);
                    textView.setCompoundDrawablePadding((int) (getResources().getDisplayMetrics().density * 4.0f));
                    textView.setGravity(17);
                    return;
                }
                return;
            }
            return;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i2 = 0; i2 < viewGroup.getChildCount(); i2++) {
                replaceBananaEmojiInViews(viewGroup.getChildAt(i2));
            }
        }
    }

    private void fetchSpinList() {
        String str = this.gameToken;
        if (str == null || str.isEmpty()) {
            toast("Not logged in");
            return;
        }
        this.wheelLoading.setVisibility(0);
        this.spinWheelView.setVisibility(8);
        this.wheelSkeletonAnim = SkeletonPulse.start(this.wheelLoading);
        this.cardLoading.setVisibility(0);
        this.cardSkeletonAnim = SkeletonPulse.start(this.cardLoading);
        View view = this.controlsLoading;
        if (view != null) {
            view.setVisibility(0);
            this.controlsSkeletonAnim = SkeletonPulse.start(this.controlsLoading);
        }
        this.btnSpin.setEnabled(false);
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m246lambda$fetchSpinList$6$comzenoappCarRacingSpinActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$6$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m246lambda$fetchSpinList$6$comzenoappCarRacingSpinActivity() {
        final int iIntValue;
        try {
            final Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/lucky-spin/LUCKY_SPIN").header("Authorization", "Bearer " + this.gameToken).header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("X-Requested-With", X_REQ).get().build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (!responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda13
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m242lambda$fetchSpinList$2$comzenoappCarRacingSpinActivity(responseExecute);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                JSONObject jSONObjectOptJSONObject = new JSONObject(strString).optJSONObject("data");
                if (jSONObjectOptJSONObject == null) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda14
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m243lambda$fetchSpinList$3$comzenoappCarRacingSpinActivity();
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                Object objOpt = jSONObjectOptJSONObject.opt("turnFree");
                if (objOpt instanceof Boolean) {
                    int iOptInt = ((Boolean) objOpt).booleanValue() ? jSONObjectOptJSONObject.optInt("turnNumber", 1) : 0;
                    iIntValue = (!((Boolean) objOpt).booleanValue() || iOptInt > 0) ? iOptInt : 1;
                } else {
                    iIntValue = objOpt instanceof Number ? ((Number) objOpt).intValue() : jSONObjectOptJSONObject.optInt("turnNumber", jSONObjectOptJSONObject.optInt("turnFree", 0));
                }
                final int iOptInt2 = jSONObjectOptJSONObject.optInt("turnBuy", jSONObjectOptJSONObject.optInt("price", 500));
                JSONArray jSONArrayOptJSONArray = jSONObjectOptJSONObject.optJSONArray("rewards");
                final ArrayList arrayList = new ArrayList();
                final ArrayList arrayList2 = new ArrayList();
                if (jSONArrayOptJSONArray != null) {
                    for (int i = 0; i < jSONArrayOptJSONArray.length(); i++) {
                        JSONObject jSONObject = jSONArrayOptJSONArray.getJSONObject(i);
                        arrayList.add(jSONObject);
                        arrayList2.add(buildSegment(jSONObject, i, loadIconUrl(jSONObject.optString("icon", ""))));
                    }
                }
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda15
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m244lambda$fetchSpinList$4$comzenoappCarRacingSpinActivity(iIntValue, iOptInt2, arrayList, arrayList2);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda16
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m245lambda$fetchSpinList$5$comzenoappCarRacingSpinActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$2$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m242lambda$fetchSpinList$2$comzenoappCarRacingSpinActivity(Response response) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        toast("Spin list failed (" + response.code() + ")");
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$3$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m243lambda$fetchSpinList$3$comzenoappCarRacingSpinActivity() {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        toast("No spin data");
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$4$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m244lambda$fetchSpinList$4$comzenoappCarRacingSpinActivity(int i, int i2, List list, List list2) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        this.spinWheelView.setVisibility(0);
        this.turnFree = i;
        this.turnNumber = i;
        this.spinPrice = i2;
        TextView textView = this.tvFreeSpins;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
        TextView textView2 = this.tvSpinPrice;
        if (textView2 != null) {
            textView2.setText(String.format(Locale.getDefault(), "%,d", Integer.valueOf(i2)));
        }
        this.spinItems.clear();
        this.spinItems.addAll(list);
        this.spinWheelView.setSegments(list2);
        refreshSpinButton();
    }

    /* JADX INFO: renamed from: lambda$fetchSpinList$5$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m245lambda$fetchSpinList$5$comzenoappCarRacingSpinActivity(Exception exc) {
        SkeletonPulse.stop(this.wheelSkeletonAnim, this.wheelLoading);
        this.wheelSkeletonAnim = null;
        View view = this.wheelLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        hideCardLoading();
        hideControlsLoading();
        toast("Error: " + exc.getMessage());
    }

    private void hideCardLoading() {
        SkeletonPulse.stop(this.cardSkeletonAnim, this.cardLoading);
        this.cardSkeletonAnim = null;
        View viewFindViewById = findViewById(R.id.freeSpinsSkeleton);
        View viewFindViewById2 = findViewById(R.id.spinPriceSkeleton);
        if (viewFindViewById != null) {
            viewFindViewById.setVisibility(8);
        }
        if (viewFindViewById2 != null) {
            viewFindViewById2.setVisibility(8);
        }
        TextView textView = this.tvFreeSpins;
        if (textView != null) {
            textView.setVisibility(0);
        }
        TextView textView2 = this.tvSpinPrice;
        if (textView2 != null) {
            textView2.setVisibility(0);
        }
    }

    private void hideControlsLoading() {
        SkeletonPulse.stop(this.controlsSkeletonAnim, this.controlsLoading);
        this.controlsSkeletonAnim = null;
        View view = this.controlsLoading;
        if (view != null) {
            view.setVisibility(8);
        }
        View view2 = this.chipRow;
        if (view2 != null) {
            view2.setVisibility(0);
        }
        TextView[] textViewArr = this.countChips;
        if (textViewArr != null) {
            for (TextView textView : textViewArr) {
                if (textView != null) {
                    textView.setVisibility(0);
                }
            }
        }
        TextView textView2 = this.btnAutoSpin;
        if (textView2 != null) {
            textView2.setVisibility(0);
        }
    }

    private SpinWheelView.Segment buildSegment(JSONObject jSONObject, int i, Bitmap bitmap) {
        String str;
        String strOptString = jSONObject.optString("name", "?");
        int iOptInt = jSONObject.optInt("value", 0);
        if (strOptString.length() > 10) {
            strOptString = strOptString.substring(0, 9) + "…";
        }
        String str2 = strOptString;
        if (iOptInt > 0) {
            str = "×" + iOptInt;
        } else {
            str = "";
        }
        String str3 = str;
        int[] iArr = SEG_BG;
        return new SpinWheelView.Segment(str2, str3, iArr[i % iArr.length], i % 2 == 0 ? -3632086 : -1, bitmap);
    }

    private Bitmap loadIconUrl(String str) {
        if (str != null && !str.isEmpty()) {
            Bitmap bitmap = this.iconCache.get(str);
            if (bitmap != null) {
                return bitmap;
            }
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
                httpURLConnection.setConnectTimeout(8000);
                httpURLConnection.setReadTimeout(8000);
                httpURLConnection.setRequestProperty("User-Agent", USER_AGENT);
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStream);
                    if (bitmapDecodeStream != null) {
                        Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapDecodeStream, 96, 96, true);
                        this.iconCache.put(str, bitmapCreateScaledBitmap);
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        return bitmapCreateScaledBitmap;
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } finally {
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doSpin() {
        if (this.spinWheelView.isSpinning()) {
            return;
        }
        if (this.turnFree <= 0 && this.coins < this.spinPrice) {
            toast("Coin မလောက်ပါ");
            if (this.isAutoSpinning) {
                finishAutoSpin();
                return;
            }
            return;
        }
        this.btnSpin.setEnabled(false);
        this.btnSpin.setText("Spinning…");
        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda11
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m238lambda$doSpin$15$comzenoappCarRacingSpinActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doSpin$15$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m238lambda$doSpin$15$comzenoappCarRacingSpinActivity() {
        try {
            final Response responseExecute = this.http.newCall(new Request.Builder().url("https://car-racing.mascom.vn/api/lucky-spin/spin").header("Authorization", "Bearer " + this.gameToken).header("Content-Type", "application/json").header("Accept-Language", "my").header("User-Agent", USER_AGENT).header("Origin", "https://car-racing.mascom.vn").header("X-Requested-With", X_REQ).post(RequestBody.create("{}", MediaType.parse("application/json"))).build()).execute();
            try {
                String strString = responseExecute.body() != null ? responseExecute.body().string() : "";
                if (!responseExecute.isSuccessful()) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda4
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m239lambda$doSpin$7$comzenoappCarRacingSpinActivity(responseExecute);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                final JSONObject jSONObject = new JSONObject(strString);
                final int i = 0;
                if (!jSONObject.optBoolean("success", false)) {
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda5
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m240lambda$doSpin$8$comzenoappCarRacingSpinActivity(jSONObject);
                        }
                    });
                    if (responseExecute != null) {
                        responseExecute.close();
                        return;
                    }
                    return;
                }
                final JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("data");
                int iOptInt = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optInt("id", -1) : -1;
                int i2 = 0;
                while (true) {
                    if (i2 >= this.spinItems.size()) {
                        break;
                    }
                    if (this.spinItems.get(i2).optInt("id", -1) == iOptInt) {
                        i = i2;
                        break;
                    }
                    i2++;
                }
                int i3 = this.turnFree;
                if (i3 > 0) {
                    final int i4 = i3 - 1;
                    this.turnFree = i4;
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda6
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m241lambda$doSpin$9$comzenoappCarRacingSpinActivity(i4);
                        }
                    });
                } else {
                    this.coins -= (long) this.spinPrice;
                    this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda7
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m233lambda$doSpin$10$comzenoappCarRacingSpinActivity();
                        }
                    });
                }
                final int i5 = this.isAutoSpinning ? 2800 : 4500;
                this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m236lambda$doSpin$13$comzenoappCarRacingSpinActivity(i, i5, jSONObjectOptJSONObject);
                    }
                });
                if (responseExecute != null) {
                    responseExecute.close();
                }
            } finally {
            }
        } catch (Exception e) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m237lambda$doSpin$14$comzenoappCarRacingSpinActivity(e);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$7$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m239lambda$doSpin$7$comzenoappCarRacingSpinActivity(Response response) {
        if (this.isAutoSpinning) {
            finishAutoSpin();
        } else {
            refreshSpinButton();
        }
        toast("Spin failed (" + response.code() + ")");
    }

    /* JADX INFO: renamed from: lambda$doSpin$8$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m240lambda$doSpin$8$comzenoappCarRacingSpinActivity(JSONObject jSONObject) {
        if (this.isAutoSpinning) {
            finishAutoSpin();
        } else {
            refreshSpinButton();
        }
        toast(jSONObject.optString("message", "Spin failed"));
    }

    /* JADX INFO: renamed from: lambda$doSpin$9$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m241lambda$doSpin$9$comzenoappCarRacingSpinActivity(int i) {
        TextView textView = this.tvFreeSpins;
        if (textView != null) {
            textView.setText(String.valueOf(i));
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$10$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m233lambda$doSpin$10$comzenoappCarRacingSpinActivity() {
        TextView textView = this.tvBananaBalance;
        if (textView != null) {
            textView.setText(String.format(Locale.getDefault(), "%,d", Long.valueOf(this.coins)));
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$13$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m236lambda$doSpin$13$comzenoappCarRacingSpinActivity(int i, int i2, final JSONObject jSONObject) {
        this.spinWheelView.spinToIndex(i, i2, new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda25
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m235lambda$doSpin$12$comzenoappCarRacingSpinActivity(jSONObject);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$doSpin$12$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m235lambda$doSpin$12$comzenoappCarRacingSpinActivity(JSONObject jSONObject) {
        if (this.isAutoSpinning) {
            if (jSONObject != null) {
                this.autoResults.add(jSONObject);
            }
            this.autoRemaining--;
            TextView textView = this.btnAutoSpin;
            if (textView != null) {
                textView.setText("STOP  (" + Math.max(this.autoRemaining, 0) + " left)");
            }
            final boolean z = this.autoRemaining > 0 && (this.turnFree > 0 || this.coins >= ((long) this.spinPrice)) && this.isAutoSpinning;
            showResultDialog(jSONObject, new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda26
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m234lambda$doSpin$11$comzenoappCarRacingSpinActivity(z);
                }
            });
            return;
        }
        showResultDialog(jSONObject, null);
        refreshSpinButton();
    }

    /* JADX INFO: renamed from: lambda$doSpin$11$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m234lambda$doSpin$11$comzenoappCarRacingSpinActivity(boolean z) {
        if (z && this.isAutoSpinning) {
            this.ui.postDelayed(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.doSpin();
                }
            }, 400L);
        } else {
            finishAutoSpin();
        }
    }

    /* JADX INFO: renamed from: lambda$doSpin$14$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m237lambda$doSpin$14$comzenoappCarRacingSpinActivity(Exception exc) {
        if (this.isAutoSpinning) {
            finishAutoSpin();
        } else {
            refreshSpinButton();
        }
        toast("Error: " + exc.getMessage());
    }

    private void showResultDialog(JSONObject jSONObject) {
        showResultDialog(jSONObject, null);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showResultDialog(JSONObject jSONObject, final Runnable runnable) {
        if (jSONObject == null || isFinishing()) {
            if (runnable != null) {
                runnable.run();
                return;
            }
            return;
        }
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_spin_result);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85f), -2);
        }
        String strOptString = jSONObject.optString("name", "Prize");
        int iOptInt = jSONObject.optInt("value", 0);
        final String strOptString2 = jSONObject.optString("icon", "");
        final ImageView imageView = (ImageView) dialog.findViewById(R.id.resultIcon);
        final TextView textView = (TextView) dialog.findViewById(R.id.resultEmoji);
        TextView textView2 = (TextView) dialog.findViewById(R.id.resultTitle);
        TextView textView3 = (TextView) dialog.findViewById(R.id.resultDetail);
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.llResultList);
        Button button = (Button) dialog.findViewById(R.id.btnResultClose);
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        Bitmap bitmap = this.iconCache.get(strOptString2);
        if (bitmap == null && strOptString2 != null && !strOptString2.isEmpty()) {
            this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda27
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m253lambda$showResultDialog$17$comzenoappCarRacingSpinActivity(strOptString2, imageView, textView);
                }
            });
        }
        if (imageView != null) {
            if (bitmap != null) {
                imageView.setImageBitmap(bitmap);
                imageView.setVisibility(0);
                if (textView != null) {
                    textView.setVisibility(8);
                }
            } else {
                imageView.setVisibility(8);
                if (textView != null) {
                    textView.setText("🎁");
                    textView.setVisibility(0);
                }
            }
        }
        if (textView2 != null) {
            textView2.setText(strOptString);
        }
        if (textView3 != null) {
            if (iOptInt > 0) {
                textView3.setText("+" + String.format(Locale.getDefault(), "%,d", Integer.valueOf(iOptInt)));
                textView3.setVisibility(0);
            } else {
                textView3.setVisibility(8);
            }
        }
        final boolean[] zArr = {false};
        final Runnable[] runnableArr = {null};
        final Runnable runnable2 = new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda28
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m254lambda$showResultDialog$18$comzenoappCarRacingSpinActivity(zArr, runnableArr, dialog, runnable);
            }
        };
        if (button != null) {
            button.setText("ရယူမည်");
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    runnable2.run();
                }
            });
        }
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda2
            @Override // android.content.DialogInterface.OnDismissListener
            public final void onDismiss(DialogInterface dialogInterface) {
                this.f$0.m255lambda$showResultDialog$20$comzenoappCarRacingSpinActivity(zArr, runnableArr, runnable, dialogInterface);
            }
        });
        dialog.show();
        if (runnable != null) {
            runnableArr[0] = runnable2;
            this.ui.postDelayed(runnable2, 2000L);
        }
    }

    /* JADX INFO: renamed from: lambda$showResultDialog$17$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m253lambda$showResultDialog$17$comzenoappCarRacingSpinActivity(String str, final ImageView imageView, final TextView textView) {
        final Bitmap bitmapLoadIconUrl = loadIconUrl(str);
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                CarRacingSpinActivity.lambda$showResultDialog$16(bitmapLoadIconUrl, imageView, textView);
            }
        });
    }

    static /* synthetic */ void lambda$showResultDialog$16(Bitmap bitmap, ImageView imageView, TextView textView) {
        if (bitmap == null || imageView == null) {
            return;
        }
        imageView.setImageBitmap(bitmap);
        imageView.setVisibility(0);
        if (textView != null) {
            textView.setVisibility(8);
        }
    }

    /* JADX INFO: renamed from: lambda$showResultDialog$18$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m254lambda$showResultDialog$18$comzenoappCarRacingSpinActivity(boolean[] zArr, Runnable[] runnableArr, Dialog dialog, Runnable runnable) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        Runnable runnable2 = runnableArr[0];
        if (runnable2 != null) {
            this.ui.removeCallbacks(runnable2);
        }
        try {
            dialog.dismiss();
        } catch (Exception unused) {
        }
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX INFO: renamed from: lambda$showResultDialog$20$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m255lambda$showResultDialog$20$comzenoappCarRacingSpinActivity(boolean[] zArr, Runnable[] runnableArr, Runnable runnable, DialogInterface dialogInterface) {
        if (zArr[0]) {
            return;
        }
        zArr[0] = true;
        Runnable runnable2 = runnableArr[0];
        if (runnable2 != null) {
            this.ui.removeCallbacks(runnable2);
        }
        if (runnable != null) {
            runnable.run();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void setupAutoSpinUi() {
        Button button = this.btnSpin;
        ViewGroup viewGroup = (button == null || !(button.getParent() instanceof ViewGroup)) ? null : (ViewGroup) this.btnSpin.getParent();
        if (viewGroup == null) {
            return;
        }
        float f = getResources().getDisplayMetrics().density;
        int iIndexOfChild = viewGroup.indexOfChild(this.btnSpin);
        LinearLayout linearLayout = new LinearLayout(this);
        this.chipRow = linearLayout;
        linearLayout.setOrientation(0);
        linearLayout.setGravity(17);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        int i = (int) (f * 14.0f);
        layoutParams.topMargin = i;
        int i2 = (int) (24.0f * f);
        layoutParams.leftMargin = i2;
        layoutParams.rightMargin = i2;
        linearLayout.setLayoutParams(layoutParams);
        final int[] iArr = {1, 5, 10, 20, 50};
        this.countChips = new TextView[5];
        int i3 = 0;
        for (int i4 = 5; i3 < i4; i4 = 5) {
            final int i5 = iArr[i3];
            TextView textView = new TextView(this);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(0, (int) (f * 34.0f), 1.0f);
            if (i3 > 0) {
                layoutParams2.leftMargin = (int) (6.0f * f);
            }
            textView.setLayoutParams(layoutParams2);
            textView.setGravity(17);
            textView.setText(String.valueOf(i5));
            textView.setTextSize(13.0f);
            textView.setTypeface(null, 1);
            textView.setClickable(true);
            textView.setFocusable(true);
            boolean z = i5 == this.autoSpinCount;
            textView.setBackgroundResource(z ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
            textView.setTextColor(z ? -3632086 : -6381922);
            textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda10
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m249lambda$setupAutoSpinUi$21$comzenoappCarRacingSpinActivity(i5, iArr, view);
                }
            });
            this.countChips[i3] = textView;
            linearLayout.addView(textView);
            i3++;
        }
        viewGroup.addView(linearLayout, iIndexOfChild + 1);
        this.btnAutoSpin = new TextView(this);
        int i6 = (int) (48.0f * f);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-1, i6);
        int i7 = (int) (10.0f * f);
        layoutParams3.topMargin = i7;
        layoutParams3.leftMargin = i2;
        layoutParams3.rightMargin = i2;
        this.btnAutoSpin.setLayoutParams(layoutParams3);
        this.btnAutoSpin.setGravity(17);
        this.btnAutoSpin.setTextSize(14.0f);
        this.btnAutoSpin.setTypeface(null, 1);
        this.btnAutoSpin.setTextColor(-16777216);
        this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
        this.btnAutoSpin.setClickable(true);
        this.btnAutoSpin.setFocusable(true);
        this.btnAutoSpin.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m250lambda$setupAutoSpinUi$22$comzenoappCarRacingSpinActivity(view);
            }
        });
        viewGroup.addView(this.btnAutoSpin, iIndexOfChild + 2);
        updateAutoSpinLabel();
        LinearLayout linearLayout2 = new LinearLayout(this);
        this.controlsLoading = linearLayout2;
        linearLayout2.setOrientation(1);
        ((LinearLayout) this.controlsLoading).setGravity(17);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.topMargin = i;
        layoutParams4.leftMargin = i2;
        layoutParams4.rightMargin = i2;
        this.controlsLoading.setLayoutParams(layoutParams4);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(17);
        for (int i8 = 0; i8 < 5; i8++) {
            View view = new View(this);
            LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(0, (int) (f * 34.0f), 1.0f);
            if (i8 > 0) {
                layoutParams5.leftMargin = (int) (f * 6.0f);
            }
            view.setLayoutParams(layoutParams5);
            view.setTag(SkeletonPulse.TAG);
            view.setBackgroundResource(R.drawable.bg_skeleton_bar);
            linearLayout3.addView(view);
        }
        ((LinearLayout) this.controlsLoading).addView(linearLayout3);
        View view2 = new View(this);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-1, i6);
        layoutParams6.topMargin = i7;
        view2.setLayoutParams(layoutParams6);
        view2.setTag(SkeletonPulse.TAG);
        view2.setBackgroundResource(R.drawable.bg_skeleton_bar);
        ((LinearLayout) this.controlsLoading).addView(view2);
        for (TextView textView2 : this.countChips) {
            textView2.setVisibility(0);
        }
        View view3 = this.chipRow;
        if (view3 != null) {
            view3.setVisibility(8);
        }
        this.btnAutoSpin.setVisibility(8);
        viewGroup.addView(this.controlsLoading, iIndexOfChild + 3);
    }

    /* JADX INFO: renamed from: lambda$setupAutoSpinUi$21$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m249lambda$setupAutoSpinUi$21$comzenoappCarRacingSpinActivity(int i, int[] iArr, View view) {
        if (this.isAutoSpinning) {
            return;
        }
        this.autoSpinCount = i;
        int i2 = 0;
        while (true) {
            TextView[] textViewArr = this.countChips;
            if (i2 < textViewArr.length) {
                boolean z = iArr[i2] == this.autoSpinCount;
                textViewArr[i2].setBackgroundResource(z ? R.drawable.bg_game_count_selected : R.drawable.bg_game_count_normal);
                this.countChips[i2].setTextColor(z ? -3632086 : -6381922);
                i2++;
            } else {
                updateAutoSpinLabel();
                return;
            }
        }
    }

    /* JADX INFO: renamed from: lambda$setupAutoSpinUi$22$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m250lambda$setupAutoSpinUi$22$comzenoappCarRacingSpinActivity(View view) {
        if (this.isAutoSpinning) {
            stopAutoSpin();
        } else {
            startAutoSpin();
        }
    }

    private void updateAutoSpinLabel() {
        if (this.btnAutoSpin == null || this.isAutoSpinning) {
            return;
        }
        int iMax = Math.max(1, this.autoSpinCount);
        int iMin = Math.min(this.turnFree, iMax);
        int i = iMax - iMin;
        long j = ((long) i) * ((long) this.spinPrice);
        try {
            Drawable drawableMutate = getResources().getDrawable(R.drawable.ic_coin, getTheme()).mutate();
            int i2 = (int) (getResources().getDisplayMetrics().density * 16.0f);
            drawableMutate.setBounds(0, 0, i2, i2);
            StringBuilder sb = new StringBuilder("AUTO SPIN");
            if (iMin > 0 && i > 0) {
                sb.append("  ");
                sb.append(iMin);
                sb.append(" Free + ");
                sb.append(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
                sb.append("  ");
            } else if (iMin > 0 && i == 0) {
                sb.append("  ");
                sb.append(iMin);
                sb.append(" Free");
            } else {
                sb.append("  ");
                sb.append(String.format(Locale.getDefault(), "%,d", Long.valueOf(j)));
                sb.append("  ");
            }
            if (i <= 0 && iMin != 0) {
                this.btnAutoSpin.setText(sb.toString());
                return;
            }
            SpannableString spannableString = new SpannableString(sb.toString() + "￼");
            spannableString.setSpan(new ImageSpan(drawableMutate, 2), sb.length(), sb.length() + 1, 33);
            this.btnAutoSpin.setText(spannableString);
        } catch (Exception unused) {
            if (iMin > 0 && i > 0) {
                this.btnAutoSpin.setText(String.format(Locale.getDefault(), "AUTO SPIN  %d Free + %,d", Integer.valueOf(iMin), Long.valueOf(j)));
                return;
            }
            if (iMin > 0) {
                this.btnAutoSpin.setText("AUTO SPIN  " + iMin + " Free");
                return;
            }
            this.btnAutoSpin.setText(String.format(Locale.getDefault(), "AUTO SPIN  %,d", Long.valueOf(j)));
        }
    }

    private void startAutoSpin() {
        if (this.spinItems.isEmpty()) {
            toast("Spin data မရှိသေးပါ");
            return;
        }
        if (this.turnFree <= 0 && this.coins < this.spinPrice) {
            toast("Coin မလောက်ပါ");
            return;
        }
        this.isAutoSpinning = true;
        this.autoRemaining = this.autoSpinCount;
        this.autoResults.clear();
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("STOP  (" + this.autoRemaining + " left)");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_stop);
            this.btnAutoSpin.setTextColor(-1);
        }
        Button button = this.btnSpin;
        if (button != null) {
            button.setEnabled(false);
        }
        doSpin();
    }

    private void stopAutoSpin() {
        this.isAutoSpinning = false;
        this.autoRemaining = 0;
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("AUTO SPIN");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
            this.btnAutoSpin.setTextColor(-16777216);
        }
        refreshSpinButton();
        this.autoResults.clear();
    }

    private void finishAutoSpin() {
        this.isAutoSpinning = false;
        this.autoRemaining = 0;
        TextView textView = this.btnAutoSpin;
        if (textView != null) {
            textView.setText("AUTO SPIN");
            this.btnAutoSpin.setBackgroundResource(R.drawable.bg_btn_gold);
            this.btnAutoSpin.setTextColor(-16777216);
        }
        refreshSpinButton();
        this.autoResults.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void showAutoSummary() {
        if (this.autoResults.isEmpty() || isFinishing()) {
            return;
        }
        int i = 0;
        if (this.autoResults.size() == 1) {
            showResultDialog(this.autoResults.get(0));
            this.autoResults.clear();
            return;
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        HashMap map = new HashMap();
        List<JSONObject> list = this.autoResults;
        JSONObject jSONObject = list.get(list.size() - 1);
        Iterator<JSONObject> it = this.autoResults.iterator();
        while (true) {
            if (it.hasNext()) {
                JSONObject next = it.next();
                String strOptString = next.optString("name", "Prize");
                int iOptInt = next.optInt("value", 0);
                String str = strOptString + "|" + iOptInt;
                int[] iArr = (int[]) linkedHashMap.get(str);
                if (iArr == null) {
                    linkedHashMap.put(str, new int[]{1, iOptInt});
                } else {
                    iArr[0] = iArr[0] + 1;
                }
                map.put(str, next.optString("icon", ""));
            } else {
                try {
                    break;
                } catch (Exception e) {
                    Log.e("CarRacingSpin", "showAutoSummary", e);
                    toast("Auto done: " + this.autoResults.size() + " spins");
                }
            }
        }
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(1);
        dialog.setContentView(R.layout.dialog_spin_result);
        int i2 = -2;
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85f), -2);
        }
        final ImageView imageView = (ImageView) dialog.findViewById(R.id.resultIcon);
        final TextView textView = (TextView) dialog.findViewById(R.id.resultEmoji);
        TextView textView2 = (TextView) dialog.findViewById(R.id.resultTitle);
        TextView textView3 = (TextView) dialog.findViewById(R.id.resultDetail);
        LinearLayout linearLayout = (LinearLayout) dialog.findViewById(R.id.llResultList);
        Button button = (Button) dialog.findViewById(R.id.btnResultClose);
        final String strOptString2 = jSONObject != null ? jSONObject.optString("icon", "") : "";
        Bitmap bitmap = this.iconCache.get(strOptString2);
        if (bitmap != null && imageView != null) {
            imageView.setImageBitmap(bitmap);
            imageView.setVisibility(0);
            if (textView != null) {
                textView.setVisibility(8);
            }
        } else if (imageView != null) {
            imageView.setVisibility(8);
            if (textView != null) {
                textView.setText("🎁");
                textView.setVisibility(0);
            }
            if (strOptString2 != null && !strOptString2.isEmpty()) {
                this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda21
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m251lambda$showAutoSummary$24$comzenoappCarRacingSpinActivity(strOptString2, imageView, textView);
                    }
                });
            }
        }
        if (textView2 != null) {
            textView2.setText("Auto Spin Complete");
        }
        if (textView3 != null) {
            textView3.setText(this.autoResults.size() + " ကြိမ်");
            textView3.setVisibility(0);
        }
        if (linearLayout != null) {
            linearLayout.setVisibility(0);
            linearLayout.removeAllViews();
            float f = getResources().getDisplayMetrics().density;
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                String str2 = ((String) entry.getKey()).split("\\|", 2)[i];
                int i3 = ((int[]) entry.getValue())[i];
                int i4 = ((int[]) entry.getValue())[1];
                final String str3 = (String) map.get(entry.getKey());
                LinearLayout linearLayout2 = new LinearLayout(this);
                linearLayout2.setOrientation(i);
                linearLayout2.setGravity(16);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, i2);
                int i5 = (int) (f * 6.0f);
                layoutParams.topMargin = i5;
                linearLayout2.setLayoutParams(layoutParams);
                int i6 = (int) (8.0f * f);
                linearLayout2.setPadding(i6, i5, i6, i5);
                final ImageView imageView2 = new ImageView(this);
                int i7 = (int) (28.0f * f);
                LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(i7, i7);
                layoutParams2.rightMargin = (int) (10.0f * f);
                imageView2.setLayoutParams(layoutParams2);
                imageView2.setScaleType(ImageView.ScaleType.FIT_CENTER);
                Bitmap bitmap2 = this.iconCache.get(str3);
                if (bitmap2 != null) {
                    imageView2.setImageBitmap(bitmap2);
                } else {
                    imageView2.setImageResource(R.drawable.ic_gift);
                    if (str3 != null && !str3.isEmpty()) {
                        this.exec.execute(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda22
                            @Override // java.lang.Runnable
                            public final void run() {
                                this.f$0.m252lambda$showAutoSummary$26$comzenoappCarRacingSpinActivity(str3, imageView2);
                            }
                        });
                    }
                }
                linearLayout2.addView(imageView2);
                TextView textView4 = new TextView(this);
                if (i4 > 0) {
                    str2 = str2 + "  +" + String.format(Locale.getDefault(), "%,d", Integer.valueOf(i4));
                }
                if (i3 > 1) {
                    str2 = str2 + "  ×" + i3;
                }
                textView4.setText(str2);
                textView4.setTextColor(-1);
                textView4.setTextSize(14.0f);
                textView4.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
                linearLayout2.addView(textView4);
                linearLayout.addView(linearLayout2);
                i = 0;
                i2 = -2;
            }
        }
        if (button != null) {
            button.setText("ရယူမည်");
            button.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda23
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    dialog.dismiss();
                }
            });
        }
        dialog.show();
        this.autoResults.clear();
    }

    /* JADX INFO: renamed from: lambda$showAutoSummary$24$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m251lambda$showAutoSummary$24$comzenoappCarRacingSpinActivity(String str, final ImageView imageView, final TextView textView) {
        final Bitmap bitmapLoadIconUrl = loadIconUrl(str);
        this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                CarRacingSpinActivity.lambda$showAutoSummary$23(bitmapLoadIconUrl, imageView, textView);
            }
        });
    }

    static /* synthetic */ void lambda$showAutoSummary$23(Bitmap bitmap, ImageView imageView, TextView textView) {
        if (bitmap == null || imageView == null) {
            return;
        }
        imageView.setImageBitmap(bitmap);
        imageView.setVisibility(0);
        if (textView != null) {
            textView.setVisibility(8);
        }
    }

    /* JADX INFO: renamed from: lambda$showAutoSummary$26$com-zeno-app-CarRacingSpinActivity, reason: not valid java name */
    /* synthetic */ void m252lambda$showAutoSummary$26$comzenoappCarRacingSpinActivity(String str, final ImageView imageView) {
        final Bitmap bitmapLoadIconUrl = loadIconUrl(str);
        if (bitmapLoadIconUrl != null) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.CarRacingSpinActivity$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    imageView.setImageBitmap(bitmapLoadIconUrl);
                }
            });
        }
    }

    private void refreshSpinButton() {
        Button button = this.btnSpin;
        boolean z = false;
        if (button != null) {
            button.setEnabled(false);
            this.btnSpin.setVisibility(8);
        }
        if (this.btnAutoSpin == null || this.isAutoSpinning) {
            return;
        }
        int iMax = Math.max(1, this.autoSpinCount);
        int iMin = Math.min(this.turnFree, iMax);
        long j = ((long) (iMax - iMin)) * ((long) this.spinPrice);
        if (!this.spinItems.isEmpty() && (iMin > 0 || this.coins >= j)) {
            z = true;
        }
        this.btnAutoSpin.setEnabled(z);
        this.btnAutoSpin.setAlpha(z ? 1.0f : 0.5f);
        updateAutoSpinLabel();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void toast(String str) {
        Toast.makeText((Context) this, (CharSequence) str, 0).show();
    }

    protected void onDestroy() {
        this.isAutoSpinning = false;
        this.ui.removeCallbacksAndMessages(null);
        this.exec.shutdownNow();
        super.onDestroy();
    }
}
