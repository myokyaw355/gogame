package com.zeno.app;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Html;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class KittyFallService extends Service {
    public static final String BASE = "https://kittyfall.com.mm";
    private volatile BotCallback callback;
    private ExecutorService executor;
    private volatile boolean running;
    private SessionManager session;
    private static final MediaType JSON = MediaType.parse("application/json");
    private static final Pattern HISTORY_ROW = Pattern.compile("<div class=\"history-row\">\\s*<span><b>([^<]*)</b><small>([^<]*)</small></span>\\s*<span><b>([^<]*)</b><small[^>]*>([^<]*)</small></span>\\s*<span>([^<]*)</span>\\s*<div class=\"history-reward-summary\"[^>]*>\\s*<span class=\"history-reward-value is-data\">\\s*<img[^>]*>\\s*<b>([^<]*)</b>\\s*<small>([^<]*)</small>\\s*</span>\\s*<span class=\"history-reward-value is-score\">\\s*<img[^>]*>\\s*<b>([^<]*)</b>\\s*<small>([^<]*)</small>\\s*</span>\\s*<span class=\"history-reward-value is-loyalty\">\\s*<img[^>]*>\\s*<b>([^<]*)</b>\\s*<small>([^<]*)</small>\\s*</span>", 32);
    private final IBinder binder = new ServiceBinder();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final OkHttpClient http = new OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).retryOnConnectionFailure(true).build();
    private volatile String mode = "Hard";
    private volatile int currentLevel = 0;
    private volatile int maxLevel = 50;
    private volatile long startedAt = 0;
    private volatile long levelStartedAt = 0;
    private volatile long lastSuccessAt = 0;
    private volatile long levelDelayMs = 0;
    private volatile int score = 0;
    private volatile int points = 0;
    private volatile String loyaltyPoint = "0";
    private volatile String mobileData = "";
    private long pointTotal = 0;
    private double dataTotal = 0.0d;
    private String dataUnit = "";
    private volatile int playTurns = 0;
    private volatile String sessionCookie = "";

    public interface BotCallback {
        void onGameInfoChanged(int i, String str, String str2);

        void onMessage(String str);

        void onResourcesChanged(int i, int i2);

        void onStateChanged(boolean z, String str, int i, int i2, long j, long j2, long j3);
    }

    public interface BuyTurnCallback {
        void onBuyError(String str);

        void onBuySuccess(String str, int i, int i2);
    }

    public interface HistoryCallback {
        void onHistory(List<HistoryEntry> list);

        void onHistoryError(String str);
    }

    public interface LeaderboardCallback {
        void onLeaderboard(LeaderboardResult leaderboardResult);

        void onLeaderboardError(String str);
    }

    public interface SubscriptionCallback {
        void onSubscriptionError(String str);

        void onSubscriptionSuccess(String str, int i, int i2);
    }

    public interface UserInfoCallback {
        void onUserInfo(UserInfo userInfo);

        void onUserInfoError(String str);
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        return 2;
    }

    private static long minDelayMs() {
        return ((long) RemoteConfig.kittyMinDelaySec) * 1000;
    }

    private static long maxDelayMs() {
        return ((long) RemoteConfig.kittyMaxDelaySec) * 1000;
    }

    public class ServiceBinder extends Binder {
        public ServiceBinder() {
        }

        public KittyFallService getService() {
            return KittyFallService.this;
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.session = new SessionManager(this);
        this.executor = Executors.newSingleThreadExecutor();
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.binder;
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.running = false;
        ExecutorService executorService = this.executor;
        if (executorService != null) {
            executorService.shutdownNow();
        }
        this.callback = null;
        super.onDestroy();
    }

    public void setCallback(BotCallback botCallback) {
        this.callback = botCallback;
    }

    public void clearCallback() {
        this.callback = null;
    }

    public boolean isRunning() {
        return this.running;
    }

    public String getMode() {
        return this.mode;
    }

    public int getCurrentLevel() {
        return this.currentLevel;
    }

    public int getMaxLevel() {
        return this.maxLevel;
    }

    public long getStartedAt() {
        return this.startedAt;
    }

    public long getLastSuccessAt() {
        return this.lastSuccessAt;
    }

    public long getLevelDelayMs() {
        return this.levelDelayMs;
    }

    public long getLevelStartedAt() {
        return this.levelStartedAt;
    }

    public int getScore() {
        return this.score;
    }

    public String getLoyaltyPoint() {
        return this.loyaltyPoint;
    }

    public String getMobileData() {
        return this.mobileData;
    }

    public int getPoints() {
        return this.points;
    }

    public int getPlayTurns() {
        return this.playTurns;
    }

    public synchronized void startBot(String str) {
        if (this.running) {
            return;
        }
        ExecutorService executorService = this.executor;
        if (executorService == null || executorService.isShutdown()) {
            this.executor = Executors.newSingleThreadExecutor();
        }
        this.mode = normalizeMode(str);
        this.running = true;
        this.currentLevel = 0;
        this.maxLevel = 50;
        this.startedAt = System.currentTimeMillis();
        this.levelStartedAt = 0L;
        this.lastSuccessAt = 0L;
        this.levelDelayMs = 0L;
        this.score = 0;
        this.loyaltyPoint = "0";
        this.mobileData = "";
        this.pointTotal = 0L;
        this.dataTotal = 0.0d;
        this.dataUnit = "";
        this.playTurns = 0;
        this.sessionCookie = "";
        notifyResources(this.points, 0);
        notifyGameInfo(0, "0", "");
        notifyState();
        this.executor.execute(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.runBot();
            }
        });
    }

    public synchronized void stopBot() {
        boolean z = this.running;
        this.running = false;
        ExecutorService executorService = this.executor;
        if (executorService != null) {
            executorService.shutdownNow();
        }
        if (z) {
            notifyMessage("Kitty Fall bot stopped.");
        }
        notifyState();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void runBot() {
        String accessToken;
        try {
            try {
                accessToken = this.session.getAccessToken();
            } catch (InterruptedException unused) {
            } catch (Exception e) {
                if (this.running) {
                    notifyMessage("Bot ရပ်သွားပါပြီ: " + e.getMessage());
                }
            }
            if (!ok(accessToken)) {
                throw new Exception("Login session မတွေ့ပါ။ ပြန်ဝင်ရောက်ပါ။");
            }
            notifyMessage("စတင်နေသည်…");
            loadWebSession(accessToken);
            JSONObject jSONObjectStartSession = startSession(accessToken, this.mode);
            if (!jSONObjectStartSession.optBoolean("success", false)) {
                throw new Exception(apiMessage(jSONObjectStartSession, "StartSession မအောင်မြင်ပါ။"));
            }
            String strOptString = jSONObjectStartSession.optString("transId", "");
            if (!ok(strOptString)) {
                throw new Exception("StartSession transId မရပါ။");
            }
            this.maxLevel = jSONObjectStartSession.optInt("max_level", 1);
            if (this.maxLevel < 1) {
                this.maxLevel = 1;
            }
            this.playTurns = optIntAny(jSONObjectStartSession, "totalTurn", "playTurns", "play_turns", "turns");
            notifyResources(this.points, this.playTurns);
            this.score = optIntAny(jSONObjectStartSession, "score");
            this.pointTotal = 0L;
            this.dataTotal = 0.0d;
            this.dataUnit = "";
            addPoint(optStringAny(jSONObjectStartSession, "point", "loyaltyPoint"));
            addData(optStringAny(jSONObjectStartSession, "data", "mobileData"));
            notifyGameInfo(this.score, this.loyaltyPoint, this.mobileData);
            this.currentLevel = this.maxLevel;
            this.levelStartedAt = System.currentTimeMillis();
            notifyState();
            while (this.running) {
                String str = accessToken;
                long jNextLong = ThreadLocalRandom.current().nextLong(minDelayMs(), maxDelayMs() + 1);
                this.levelDelayMs = jNextLong;
                this.levelStartedAt = System.currentTimeMillis();
                notifyState();
                notifyMessage("Level " + this.currentLevel + " - " + (jNextLong / 1000) + " စက္ကန့် စောင့်နေသည်…");
                sleepInterruptibly(jNextLong);
                if (!this.running) {
                    break;
                }
                int i = this.currentLevel;
                accessToken = str;
                JSONObject jSONObjectSaveLevelResult = saveLevelResult(accessToken, strOptString, i, this.mode);
                if (!jSONObjectSaveLevelResult.optBoolean("success", false)) {
                    throw new Exception(apiMessage(jSONObjectSaveLevelResult, "SaveLevelResult မအောင်မြင်ပါ။"));
                }
                this.score += optIntAny(jSONObjectSaveLevelResult, "score");
                addPoint(optStringAny(jSONObjectSaveLevelResult, "point", "loyaltyPoint"));
                addData(optStringAny(jSONObjectSaveLevelResult, "data", "mobileData"));
                notifyGameInfo(this.score, this.loyaltyPoint, this.mobileData);
                this.lastSuccessAt = System.currentTimeMillis();
                this.currentLevel = i + 1;
                notifyMessage("Level " + i + " အောင်မြင်ပါပြီ။");
                notifyState();
            }
            this.running = false;
            notifyState();
        } catch (Throwable th) {
            this.running = false;
            notifyState();
            throw th;
        }
    }

    public static final class BuyTurnPackage {
        public final String priceLabel;
        public final String productCode;
        public final String title;
        public final int turnCount;

        BuyTurnPackage(String str, int i, String str2, String str3) {
            this.productCode = str;
            this.turnCount = i;
            this.title = str2;
            this.priceLabel = str3;
        }
    }

    public static final class DailySubscriptionPackage {
        public final String benefitText;
        public final String priceLabel;
        public final String productCode;
        public final String renewalNote;
        public final String title;
        public final int turnCount;

        DailySubscriptionPackage(String str, String str2, String str3, int i, String str4, String str5) {
            this.productCode = str;
            this.title = str2;
            this.benefitText = str3;
            this.turnCount = i;
            this.priceLabel = str4;
            this.renewalNote = str5;
        }
    }

    public static final class UserInfo {
        public final String avatarUrl;
        public final List<BuyTurnPackage> buyTurnPackages;
        public final DailySubscriptionPackage dailySubscriptionPackage;
        public final String fullName;
        public final boolean hasSubscription;
        public final String phone;
        public final String playTurns;
        public final String points;

        UserInfo(String str, String str2, String str3, String str4, String str5, boolean z, List<BuyTurnPackage> list, DailySubscriptionPackage dailySubscriptionPackage) {
            this.phone = str;
            this.fullName = str2;
            this.points = str3;
            this.playTurns = str4;
            this.avatarUrl = str5;
            this.hasSubscription = z;
            this.buyTurnPackages = list;
            this.dailySubscriptionPackage = dailySubscriptionPackage;
        }
    }

    public void fetchUserInfo(final UserInfoCallback userInfoCallback) {
        String accessToken = this.session.getAccessToken();
        String phone = this.session.getPhone();
        if (!ok(accessToken)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda5
                @Override // java.lang.Runnable
                public final void run() {
                    userInfoCallback.onUserInfoError("Login session မတွေ့ပါ။");
                }
            });
            return;
        }
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").get().addHeader("accept", "text/html,application/xhtml+xml").addHeader("lang", "mu");
        if (!ok(phone)) {
            phone = "";
        }
        Request.Builder builderAddHeader2 = builderAddHeader.addHeader("phone-number", phone).addHeader("access-token", accessToken).addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        String str = this.sessionCookie;
        if (ok(str)) {
            builderAddHeader2.addHeader("cookie", str);
        }
        this.http.newCall(builderAddHeader2.build()).enqueue(new AnonymousClass1(userInfoCallback));
    }

    /* JADX INFO: renamed from: com.zeno.app.KittyFallService$1, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
    class AnonymousClass1 implements Callback {
        final /* synthetic */ UserInfoCallback val$callback;

        AnonymousClass1(UserInfoCallback userInfoCallback) {
            this.val$callback = userInfoCallback;
        }

        public void onFailure(Call call, final IOException iOException) {
            Handler handler = KittyFallService.this.ui;
            final UserInfoCallback userInfoCallback = this.val$callback;
            handler.post(new Runnable() { // from class: com.zeno.app.KittyFallService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    userInfoCallback.onUserInfoError(iOException.getMessage());
                }
            });
        }

        public void onResponse(Call call, final Response response) {
            try {
                try {
                    KittyFallService.this.captureCookies(response);
                    if (response.isSuccessful() && response.body() != null) {
                        final UserInfo userInfoExtractUserInfo = KittyFallService.extractUserInfo(response.body().string());
                        if (userInfoExtractUserInfo == null) {
                            Handler handler = KittyFallService.this.ui;
                            final UserInfoCallback userInfoCallback = this.val$callback;
                            handler.post(new Runnable() { // from class: com.zeno.app.KittyFallService$1$$ExternalSyntheticLambda2
                                @Override // java.lang.Runnable
                                public final void run() {
                                    userInfoCallback.onUserInfoError("Login session မတွေ့ပါ (token expired/invalid)");
                                }
                            });
                            if (response != null) {
                                response.close();
                                return;
                            }
                            return;
                        }
                        Handler handler2 = KittyFallService.this.ui;
                        final UserInfoCallback userInfoCallback2 = this.val$callback;
                        handler2.post(new Runnable() { // from class: com.zeno.app.KittyFallService$1$$ExternalSyntheticLambda3
                            @Override // java.lang.Runnable
                            public final void run() {
                                userInfoCallback2.onUserInfo(userInfoExtractUserInfo);
                            }
                        });
                        if (response != null) {
                            response.close();
                            return;
                        }
                        return;
                    }
                    Handler handler3 = KittyFallService.this.ui;
                    final UserInfoCallback userInfoCallback3 = this.val$callback;
                    handler3.post(new Runnable() { // from class: com.zeno.app.KittyFallService$1$$ExternalSyntheticLambda1
                        @Override // java.lang.Runnable
                        public final void run() {
                            userInfoCallback3.onUserInfoError("HTTP " + response.code());
                        }
                    });
                    if (response != null) {
                        response.close();
                    }
                } finally {
                }
            } catch (Exception e) {
                Handler handler4 = KittyFallService.this.ui;
                final UserInfoCallback userInfoCallback4 = this.val$callback;
                handler4.post(new Runnable() { // from class: com.zeno.app.KittyFallService$1$$ExternalSyntheticLambda4
                    @Override // java.lang.Runnable
                    public final void run() {
                        userInfoCallback4.onUserInfoError(e.getMessage());
                    }
                });
            }
        }
    }

    public static final class RankEntry {
        public final int order;
        public final String phone;
        public final String score;

        RankEntry(int i, String str, String str2) {
            this.order = i;
            this.phone = str;
            this.score = str2;
        }
    }

    public static final class LeaderboardResult {
        public final List<RankEntry> entries;
        public final RankEntry me;

        LeaderboardResult(List<RankEntry> list, RankEntry rankEntry) {
            this.entries = list;
            this.me = rankEntry;
        }
    }

    public void fetchLeaderboard(final LeaderboardCallback leaderboardCallback) {
        final String accessToken = this.session.getAccessToken();
        final String phone = this.session.getPhone();
        if (!ok(accessToken)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    leaderboardCallback.onLeaderboardError("Login session မတွေ့ပါ။");
                }
            });
        } else {
            new Thread(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda7
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m494lambda$fetchLeaderboard$4$comzenoappKittyFallService(accessToken, phone, leaderboardCallback);
                }
            }, "kitty-leaderboard").start();
        }
    }

    /* JADX INFO: renamed from: lambda$fetchLeaderboard$4$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m494lambda$fetchLeaderboard$4$comzenoappKittyFallService(String str, String str2, final LeaderboardCallback leaderboardCallback) {
        try {
            if (!ok(this.sessionCookie)) {
                try {
                    loadWebSession(str);
                } catch (Exception unused) {
                }
            }
            ArrayList arrayList = new ArrayList();
            RankEntry myRank = null;
            int iMax = 1;
            for (int i = 1; i <= iMax && i <= 10; i++) {
                String leaderboardPage = getLeaderboardPage(str, str2, i);
                if (i == 1) {
                    iMax = Math.max(1, maxLeaderboardPage(leaderboardPage));
                    myRank = parseMyRank(leaderboardPage);
                }
                parseRankRows(leaderboardPage, arrayList);
            }
            if (arrayList.isEmpty()) {
                throw new Exception("Leaderboard မတွေ့ပါ (session expired)");
            }
            final LeaderboardResult leaderboardResult = new LeaderboardResult(arrayList, myRank);
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda11
                @Override // java.lang.Runnable
                public final void run() {
                    leaderboardCallback.onLeaderboard(leaderboardResult);
                }
            });
        } catch (Exception e) {
            final String message = e.getMessage() != null ? e.getMessage() : "Leaderboard error";
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda17
                @Override // java.lang.Runnable
                public final void run() {
                    leaderboardCallback.onLeaderboardError(message);
                }
            });
        }
    }

    private String getLeaderboardPage(String str, String str2, int i) throws Exception {
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/Leaderboard?pageNumber=" + i).get().addHeader("accept", "text/html,application/xhtml+xml").addHeader("lang", "mu");
        if (!ok(str2)) {
            str2 = "";
        }
        Request.Builder builderAddHeader2 = builderAddHeader.addHeader("phone-number", str2).addHeader("access-token", str).addHeader("referer", "https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        String str3 = this.sessionCookie;
        if (ok(str3)) {
            builderAddHeader2.addHeader("cookie", str3);
        }
        Response responseExecute = this.http.newCall(builderAddHeader2.build()).execute();
        try {
            if (!responseExecute.isSuccessful() || responseExecute.body() == null) {
                throw new Exception("Leaderboard HTTP " + responseExecute.code());
            }
            String strString = responseExecute.body().string();
            if (responseExecute != null) {
                responseExecute.close();
            }
            return strString;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private static int maxLeaderboardPage(String str) {
        Matcher matcher = Pattern.compile("href=[\"']/Leaderboard\\?pageNumber=(\\d+)[\"']").matcher(str);
        int iMax = 1;
        while (matcher.find()) {
            try {
                iMax = Math.max(iMax, Integer.parseInt(matcher.group(1)));
            } catch (Exception unused) {
            }
        }
        return iMax;
    }

    private static void parseRankRows(String str, List<RankEntry> list) {
        Matcher matcher = Pattern.compile("data-rank-row=[\"'](\\d+)[\"'][\\s\\S]*?class=[\"']leaderboard-phone[\"']>\\s*([^<]+?)\\s*</span>[\\s\\S]*?<b>\\s*([^<]+?)\\s*</b>").matcher(str);
        while (matcher.find()) {
            try {
                list.add(new RankEntry(Integer.parseInt(matcher.group(1)), decodeHtml(matcher.group(2)), decodeHtml(matcher.group(3))));
            } catch (Exception unused) {
            }
        }
    }

    private static RankEntry parseMyRank(String str) {
        Matcher matcher = Pattern.compile("leaderboard-my-badge[\\s\\S]*?<b>\\s*([^<]+?)\\s*</b>\\s*</div>\\s*<span>\\s*([^<]+?)\\s*</span>\\s*<strong>[\\s\\S]*?<b>\\s*([^<]+?)\\s*</b>").matcher(str);
        if (!matcher.find()) {
            return null;
        }
        try {
            return new RankEntry(Integer.parseInt(matcher.group(1).trim()), decodeHtml(matcher.group(2)), decodeHtml(matcher.group(3)));
        } catch (Exception unused) {
            return null;
        }
    }

    public void registerDailySubscription(final String str, final SubscriptionCallback subscriptionCallback) {
        final String accessToken = this.session.getAccessToken();
        if (!ok(accessToken)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    subscriptionCallback.onSubscriptionError("Login session မတွေ့ပါ။");
                }
            });
        } else if (!ok(str)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    subscriptionCallback.onSubscriptionError("စာရင်းသွင်းမှု အထုပ်အချက်အလက် မရရှိပါ။");
                }
            });
        } else {
            new Thread(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda3
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m499lambda$registerDailySubscription$10$comzenoappKittyFallService(accessToken, str, subscriptionCallback);
                }
            }, "kitty-subscription").start();
        }
    }

    /* JADX INFO: renamed from: lambda$registerDailySubscription$10$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m499lambda$registerDailySubscription$10$comzenoappKittyFallService(String str, String str2, final SubscriptionCallback subscriptionCallback) {
        try {
            if (!ok(this.sessionCookie)) {
                try {
                    loadWebSession(str);
                } catch (Exception unused) {
                }
            }
            JSONObject jSONObjectPostDailySubscription = postDailySubscription(str2);
            final int iOptInt = jSONObjectPostDailySubscription.optInt("errorCode", -1);
            final String strOptString = jSONObjectPostDailySubscription.optString("message", "");
            final int iOptInt2 = jSONObjectPostDailySubscription.optInt("totalTurn", -1);
            final int iOptInt3 = jSONObjectPostDailySubscription.optInt("totalPoint", -1);
            if (iOptInt == 0) {
                if (iOptInt2 >= 0) {
                    this.playTurns = iOptInt2;
                }
                if (iOptInt3 >= 0) {
                    this.points = iOptInt3;
                }
                notifyResources(this.points, this.playTurns);
                this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda12
                    @Override // java.lang.Runnable
                    public final void run() {
                        subscriptionCallback.onSubscriptionSuccess(strOptString, iOptInt2, iOptInt3);
                    }
                });
                return;
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda13
                @Override // java.lang.Runnable
                public final void run() {
                    KittyFallService.lambda$registerDailySubscription$8(subscriptionCallback, strOptString, iOptInt);
                }
            });
        } catch (Exception e) {
            final String message = e.getMessage() != null ? e.getMessage() : "Network error";
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda14
                @Override // java.lang.Runnable
                public final void run() {
                    subscriptionCallback.onSubscriptionError(message);
                }
            });
        }
    }

    static /* synthetic */ void lambda$registerDailySubscription$8(SubscriptionCallback subscriptionCallback, String str, int i) {
        if (!ok(str)) {
            str = "စာရင်းသွင်းမှု မအောင်မြင်ပါ (Error " + i + ")";
        }
        subscriptionCallback.onSubscriptionError(str);
    }

    public void buyTurn(final String str, final BuyTurnCallback buyTurnCallback) {
        final String accessToken = this.session.getAccessToken();
        if (!ok(accessToken)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda18
                @Override // java.lang.Runnable
                public final void run() {
                    buyTurnCallback.onBuyError("Login session မတွေ့ပါ။");
                }
            });
        } else {
            new Thread(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda19
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m492lambda$buyTurn$15$comzenoappKittyFallService(accessToken, str, buyTurnCallback);
                }
            }, "kitty-buyturn").start();
        }
    }

    /* JADX INFO: renamed from: lambda$buyTurn$15$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m492lambda$buyTurn$15$comzenoappKittyFallService(String str, String str2, final BuyTurnCallback buyTurnCallback) {
        try {
            if (!ok(this.sessionCookie)) {
                try {
                    loadWebSession(str);
                } catch (Exception unused) {
                }
            }
            JSONObject jSONObjectPostBuyTurn = postBuyTurn(str2);
            final int iOptInt = jSONObjectPostBuyTurn.optInt("errorCode", -1);
            final String strOptString = jSONObjectPostBuyTurn.optString("message", "");
            final int iOptInt2 = jSONObjectPostBuyTurn.optInt("totalTurn", -1);
            final int iOptInt3 = jSONObjectPostBuyTurn.optInt("totalPoint", -1);
            if (iOptInt == 0) {
                if (iOptInt2 >= 0) {
                    this.playTurns = iOptInt2;
                }
                if (iOptInt3 >= 0) {
                    this.points = iOptInt3;
                }
                notifyResources(this.points, this.playTurns);
                this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda8
                    @Override // java.lang.Runnable
                    public final void run() {
                        buyTurnCallback.onBuySuccess(strOptString, iOptInt2, iOptInt3);
                    }
                });
                return;
            }
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda9
                @Override // java.lang.Runnable
                public final void run() {
                    KittyFallService.lambda$buyTurn$13(buyTurnCallback, strOptString, iOptInt);
                }
            });
        } catch (Exception e) {
            final String message = e.getMessage() != null ? e.getMessage() : "Network error";
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda10
                @Override // java.lang.Runnable
                public final void run() {
                    buyTurnCallback.onBuyError(message);
                }
            });
        }
    }

    static /* synthetic */ void lambda$buyTurn$13(BuyTurnCallback buyTurnCallback, String str, int i) {
        if (!ok(str)) {
            str = "ဝယ်ယူမှု မအောင်မြင်ပါ (Error " + i + ")";
        }
        buyTurnCallback.onBuyError(str);
    }

    private JSONObject postBuyTurn(String str) throws Exception {
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/Home/BuyTurnQAction").post(RequestBody.create("productName=" + str, MediaType.parse("application/x-www-form-urlencoded; charset=UTF-8"))).addHeader("accept", "*/*").addHeader("origin", BASE).addHeader("referer", "https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").addHeader("x-requested-with", "XMLHttpRequest").addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        if (ok(this.sessionCookie)) {
            builderAddHeader.addHeader("cookie", this.sessionCookie);
        }
        Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
        try {
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            if (!responseExecute.isSuccessful()) {
                throw new Exception("HTTP " + responseExecute.code());
            }
            try {
                JSONObject jSONObject = new JSONObject(strString);
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return jSONObject;
            } catch (Exception unused) {
                throw new Exception("Server response မဖတ်နိုင်ပါ။");
            }
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONObject postDailySubscription(String str) throws Exception {
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/Home/RegisterQAction").post(RequestBody.create("productName=" + str, MediaType.parse("application/x-www-form-urlencoded; charset=UTF-8"))).addHeader("accept", "*/*").addHeader("origin", BASE).addHeader("referer", "https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").addHeader("x-requested-with", "XMLHttpRequest").addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        if (ok(this.sessionCookie)) {
            builderAddHeader.addHeader("cookie", this.sessionCookie);
        }
        Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
        try {
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            if (!responseExecute.isSuccessful()) {
                throw new Exception("HTTP " + responseExecute.code());
            }
            try {
                JSONObject jSONObject = new JSONObject(strString);
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return jSONObject;
            } catch (Exception unused) {
                throw new Exception("Server response မဖတ်နိုင်ပါ။");
            }
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public static final class HistoryEntry {
        public final String date;
        public final String description;
        public final String difficulty;
        public final String loyaltyUnit;
        public final String loyaltyValue;
        public final String mbUnit;
        public final String mbValue;
        public final String scoreUnit;
        public final String scoreValue;
        public final String time;
        public final String title;

        HistoryEntry(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
            this.date = str;
            this.time = str2;
            this.title = str3;
            this.difficulty = str4;
            this.description = str5;
            this.mbValue = str6;
            this.mbUnit = str7;
            this.scoreValue = str8;
            this.scoreUnit = str9;
            this.loyaltyValue = str10;
            this.loyaltyUnit = str11;
        }
    }

    public void fetchHistory(final HistoryCallback historyCallback) {
        final String accessToken = this.session.getAccessToken();
        if (!ok(accessToken)) {
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda22
                @Override // java.lang.Runnable
                public final void run() {
                    historyCallback.onHistoryError("Login session မတွေ့ပါ။");
                }
            });
        } else {
            new Thread(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda23
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m493lambda$fetchHistory$19$comzenoappKittyFallService(accessToken, historyCallback);
                }
            }, "kitty-history").start();
        }
    }

    /* JADX INFO: renamed from: lambda$fetchHistory$19$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m493lambda$fetchHistory$19$comzenoappKittyFallService(String str, final HistoryCallback historyCallback) {
        try {
            if (!ok(this.sessionCookie)) {
                try {
                    loadWebSession(str);
                } catch (Exception unused) {
                }
            }
            final List<HistoryEntry> historyRows = parseHistoryRows(getHistoryPage(str));
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda20
                @Override // java.lang.Runnable
                public final void run() {
                    historyCallback.onHistory(historyRows);
                }
            });
        } catch (Exception e) {
            final String message = e.getMessage() != null ? e.getMessage() : "History error";
            this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    historyCallback.onHistoryError(message);
                }
            });
        }
    }

    private String getHistoryPage(String str) throws Exception {
        String phone = this.session.getPhone();
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/History").get().addHeader("accept", "text/html,application/xhtml+xml").addHeader("lang", "mu");
        if (!ok(phone)) {
            phone = "";
        }
        Request.Builder builderAddHeader2 = builderAddHeader.addHeader("phone-number", phone).addHeader("access-token", str).addHeader("referer", "https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        String str2 = this.sessionCookie;
        if (ok(str2)) {
            builderAddHeader2.addHeader("cookie", str2);
        }
        Response responseExecute = this.http.newCall(builderAddHeader2.build()).execute();
        try {
            if (!responseExecute.isSuccessful() || responseExecute.body() == null) {
                throw new Exception("History HTTP " + responseExecute.code());
            }
            String strString = responseExecute.body().string();
            if (responseExecute != null) {
                responseExecute.close();
            }
            return strString;
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private static List<HistoryEntry> parseHistoryRows(String str) {
        ArrayList arrayList = new ArrayList();
        if (str == null) {
            return arrayList;
        }
        Matcher matcher = HISTORY_ROW.matcher(str);
        while (matcher.find()) {
            arrayList.add(new HistoryEntry(decodeHtml(matcher.group(1).trim()), decodeHtml(matcher.group(2).trim()), decodeHtml(matcher.group(3).trim()), decodeHtml(matcher.group(4).trim()), decodeHtml(matcher.group(5).trim()), decodeHtml(matcher.group(6).trim()), decodeHtml(matcher.group(7).trim()), decodeHtml(matcher.group(8).trim()), decodeHtml(matcher.group(9).trim()), decodeHtml(matcher.group(10).trim()), decodeHtml(matcher.group(11).trim())));
        }
        return arrayList;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static UserInfo extractUserInfo(String str) {
        String strFirstMatch = firstMatch(str, "class=[\"'][^\"']*profile-copy[^\"']*[\"'][\\s\\S]*?<span>\\s*<span>([^<]+)</span>", "<span>\\s*(9\\d{8,14})\\s*</span>");
        String strFirstMatch2 = firstMatch(str, "class=[\"'][^\"']*profile-full-name[^\"']*[\"']>([^<]*)<");
        String strFirstMatch3 = firstMatch(str, "class=[\"'][^\"']*points[^\"']*[\"']>\\s*([^<]+)<");
        String strFirstMatch4 = firstMatch(str, "class=[\"'][^\"']*turns[^\"']*[\"']>\\s*([^<]+)<", "data-play-total-turn[^>]*>\\s*([^<]+)<", "data-total-turn=[\"']([^\"']+)[\"']");
        String strResolveAvatarUrl = resolveAvatarUrl(firstMatch(str, "class=[\"'][^\"']*profile-avatar[^\"']*[\"'][^>]*src=[\"']([^\"']+)[\"']", "src=[\"']([^\"']+)[\"'][^>]*class=[\"'][^\"']*profile-avatar[^\"']*[\"']", "data-profile-avatar[^>]*src=[\"']([^\"']+)[\"']"));
        boolean zFind = Pattern.compile("<button[^>]*\\bdata-open-buy-turn\\b[^>]*>", 2).matcher(str).find();
        List<BuyTurnPackage> buyTurnPackages = parseBuyTurnPackages(str);
        DailySubscriptionPackage dailySubscriptionPackage = parseDailySubscriptionPackage(str);
        if (strFirstMatch == null && strFirstMatch2 == null && strFirstMatch3 == null && strFirstMatch4 == null) {
            return null;
        }
        return new UserInfo(strFirstMatch, strFirstMatch2, strFirstMatch3, strFirstMatch4, strResolveAvatarUrl, zFind, buyTurnPackages, dailySubscriptionPackage);
    }

    private static DailySubscriptionPackage parseDailySubscriptionPackage(String str) {
        if (str == null) {
            return null;
        }
        String strFirstMatch = firstMatch(str, "<button\\b(?=[^>]*\\bdata-open-subscription\\b)[^>]*\\bdata-product-name\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>");
        String strFirstMatch2 = firstMatch(str, "<div\\b[^>]*class=[\"'][^\"']*\\bpackage-title\\b[^\"']*[\"'][^>]*>[\\s\\S]*?<h2[^>]*>([\\s\\S]*?)</h2>");
        String strFirstMatch3 = firstMatch(str, "<div\\b[^>]*class=[\"'][^\"']*\\bpackage-copy\\b[^\"']*[\"'][^>]*>[\\s\\S]*?<p[^>]*>([\\s\\S]*?)</p>");
        String strFirstMatch4 = firstMatch(str, "<div\\b[^>]*class=[\"'][^\"']*\\bpackage-copy\\b[^\"']*[\"'][^>]*>[\\s\\S]*?<p[^>]*>[\\s\\S]*?</p>\\s*<p[^>]*>([\\s\\S]*?)</p>");
        String strFirstMatch5 = firstMatch(str, "<div\\b[^>]*class=[\"'][^\"']*\\bpackage-action\\b[^\"']*[\"'][^>]*>\\s*<p[^>]*>([\\s\\S]*?)</p>");
        String strFirstMatch6 = firstMatch(str, "<div\\b[^>]*class=[\"'][^\"']*\\bconfirm-price\\b[^\"']*[\"'][^>]*>\\s*<strong[^>]*>[^<]*</strong>\\s*<span[^>]*>[^<]*?/(\\d+)\\s*Turns?[^<]*</span>");
        if (ok(strFirstMatch) && ok(strFirstMatch2) && ok(strFirstMatch3) && ok(strFirstMatch5) && ok(strFirstMatch6)) {
            try {
                int i = Integer.parseInt(strFirstMatch6);
                if (i < 1) {
                    return null;
                }
                return new DailySubscriptionPackage(strFirstMatch, strFirstMatch2, strFirstMatch3, i, strFirstMatch5, strFirstMatch4);
            } catch (NumberFormatException unused) {
            }
        }
        return null;
    }

    private static List<BuyTurnPackage> parseBuyTurnPackages(String str) {
        String str2;
        ArrayList arrayList = new ArrayList();
        if (str == null) {
            return arrayList;
        }
        Matcher matcher = Pattern.compile("<button\\b(?=[^>]*\\bdata-select-buy-turn-package\\b)([^>]*)>([\\s\\S]*?)</button>", 2).matcher(str);
        while (matcher.find()) {
            String strGroup = matcher.group(1);
            String strGroup2 = matcher.group(2);
            String strFirstMatch = firstMatch(strGroup, "\\bdata-product-name\\s*=\\s*[\"']([^\"']+)[\"']");
            String strFirstMatch2 = firstMatch(strGroup, "\\bdata-turn-count\\s*=\\s*[\"'](\\d+)[\"']");
            String strFirstMatch3 = firstMatch(strGroup, "\\bdata-turn-fee\\s*=\\s*[\"']([\\d.,]+)[\"']");
            String strFirstMatch4 = firstMatch(strGroup2, "<strong[^>]*>([\\s\\S]*?)</strong>");
            String strFirstMatch5 = firstMatch(strGroup2, "<b[^>]*>([\\s\\S]*?)</b>");
            if (ok(strFirstMatch) && ok(strFirstMatch2) && ok(strFirstMatch3) && ok(strFirstMatch4) && ok(strFirstMatch5)) {
                try {
                    int i = Integer.parseInt(strFirstMatch2);
                    if (i >= 1) {
                        String strTrim = strFirstMatch5.replaceFirst("^[\\s\\d.,]+", "").trim();
                        StringBuilder sb = new StringBuilder();
                        sb.append(strFirstMatch3);
                        if (strTrim.isEmpty()) {
                            str2 = "";
                        } else {
                            str2 = " " + strTrim;
                        }
                        sb.append(str2);
                        arrayList.add(new BuyTurnPackage(strFirstMatch, i, strFirstMatch4, sb.toString()));
                    }
                } catch (NumberFormatException unused) {
                }
            }
        }
        return arrayList;
    }

    private static String resolveAvatarUrl(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        try {
            return new URL(new URL(BASE), str).toString();
        } catch (Exception unused) {
            return str;
        }
    }

    private static String firstMatch(String str, String... strArr) {
        if (str == null) {
            return null;
        }
        for (String str2 : strArr) {
            Matcher matcher = Pattern.compile(str2, 2).matcher(str);
            if (matcher.find() && matcher.groupCount() >= 1) {
                return decodeHtml(matcher.group(1).trim());
            }
        }
        return null;
    }

    private static String decodeHtml(String str) {
        if (str == null || str.isEmpty()) {
            return "";
        }
        int i = 0;
        String str2 = str;
        while (i < 3) {
            String string = Html.fromHtml(str2).toString();
            if (string.equals(str2)) {
                break;
            }
            i++;
            str2 = string;
        }
        return str2.replace((char) 160, ' ').trim();
    }

    private void loadWebSession(String str) throws Exception {
        String phone = this.session.getPhone();
        Request.Builder builderAddHeader = new Request.Builder().url("https://kittyfall.com.mm/?mcuid=android-app&mcapp=myid").get().addHeader("accept", "text/html,application/xhtml+xml").addHeader("lang", "mu");
        if (!ok(phone)) {
            phone = "";
        }
        Response responseExecute = this.http.newCall(builderAddHeader.addHeader("phone-number", phone).addHeader("access-token", str).addHeader("user-agent", "ZenoMyID-KittyFall/1.0").build()).execute();
        try {
            captureCookies(responseExecute);
            if (!responseExecute.isSuccessful()) {
                throw new Exception("Profile request HTTP " + responseExecute.code());
            }
            if (responseExecute != null) {
                responseExecute.close();
            }
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    private JSONObject startSession(String str, String str2) throws Exception {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("msisdn", toMsisdn(this.session.getPhone()));
        jSONObject.put("token", str);
        jSONObject.put("transId", UUID.randomUUID().toString().replace("-", ""));
        jSONObject.put("gameType", str2);
        jSONObject.put("level", 1);
        jSONObject.put("score", 0);
        jSONObject.put("gameOver", 0);
        return postJson("https://kittyfall.com.mm/Game/StartSession", jSONObject.toString(), true, "https://kittyfall.com.mm/Play");
    }

    private JSONObject saveLevelResult(String str, String str2, int i, String str3) throws Exception {
        JSONObject jSONObject = new JSONObject();
        jSONObject.put("token", str);
        jSONObject.put("msisdn", toMsisdn(this.session.getPhone()));
        jSONObject.put("transId", str2);
        jSONObject.put("level", i);
        jSONObject.put("score", 0);
        jSONObject.put("gameType", str3);
        jSONObject.put("gameOver", 0);
        return postJson("https://kittyfall.com.mm/Game/SaveLevelResult", jSONObject.toString(), true, "https://kittyfall.com.mm/catpuzzle/index.html");
    }

    private JSONObject postJson(String str, String str2, boolean z, String str3) throws Exception {
        Request.Builder builderAddHeader = new Request.Builder().url(str).post(RequestBody.create(str2, JSON)).addHeader("accept", "*/*").addHeader("content-type", "application/json").addHeader("origin", BASE).addHeader("referer", str3).addHeader("user-agent", "ZenoMyID-KittyFall/1.0");
        if (z && ok(this.sessionCookie)) {
            builderAddHeader.addHeader("cookie", this.sessionCookie);
        }
        Response responseExecute = this.http.newCall(builderAddHeader.build()).execute();
        try {
            String strString = responseExecute.body() != null ? responseExecute.body().string() : "{}";
            if (!responseExecute.isSuccessful()) {
                throw new Exception("HTTP " + responseExecute.code());
            }
            try {
                JSONObject jSONObject = new JSONObject(strString);
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return jSONObject;
            } catch (Exception unused) {
                throw new Exception("Server response မဖတ်နိုင်ပါ။");
            }
        } catch (Throwable th) {
            if (responseExecute != null) {
                try {
                    responseExecute.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void captureCookies(Response response) {
        StringBuilder sb = new StringBuilder();
        for (String strSubstring : response.headers("Set-Cookie")) {
            int iIndexOf = strSubstring.indexOf(59);
            if (iIndexOf >= 0) {
                strSubstring = strSubstring.substring(0, iIndexOf);
            }
            if (sb.length() > 0) {
                sb.append("; ");
            }
            sb.append(strSubstring);
        }
        this.sessionCookie = sb.toString();
    }

    private void sleepInterruptibly(long j) throws InterruptedException {
        while (this.running && j > 0) {
            long jMin = Math.min(j, 1000L);
            Thread.sleep(jMin);
            j -= jMin;
        }
    }

    private void notifyState() {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m498lambda$notifyState$20$comzenoappKittyFallService();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyState$20$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m498lambda$notifyState$20$comzenoappKittyFallService() {
        BotCallback botCallback = this.callback;
        if (botCallback != null) {
            botCallback.onStateChanged(this.running, this.mode, this.currentLevel, this.maxLevel, this.startedAt, this.levelStartedAt, this.lastSuccessAt);
        }
    }

    private void notifyResources(final int i, final int i2) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m497lambda$notifyResources$21$comzenoappKittyFallService(i, i2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyResources$21$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m497lambda$notifyResources$21$comzenoappKittyFallService(int i, int i2) {
        BotCallback botCallback = this.callback;
        if (botCallback != null) {
            botCallback.onResourcesChanged(Math.max(0, i), Math.max(0, i2));
        }
    }

    private void notifyGameInfo(final int i, final String str, final String str2) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m495lambda$notifyGameInfo$22$comzenoappKittyFallService(i, str, str2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyGameInfo$22$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m495lambda$notifyGameInfo$22$comzenoappKittyFallService(int i, String str, String str2) {
        BotCallback botCallback = this.callback;
        if (botCallback != null) {
            botCallback.onGameInfoChanged(Math.max(0, i), str, str2);
        }
    }

    private void notifyMessage(final String str) {
        this.ui.post(new Runnable() { // from class: com.zeno.app.KittyFallService$$ExternalSyntheticLambda24
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m496lambda$notifyMessage$23$comzenoappKittyFallService(str);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyMessage$23$com-zeno-app-KittyFallService, reason: not valid java name */
    /* synthetic */ void m496lambda$notifyMessage$23$comzenoappKittyFallService(String str) {
        BotCallback botCallback = this.callback;
        if (botCallback != null) {
            botCallback.onMessage(str);
        }
    }

    private void addPoint(String str) {
        if (ok(str)) {
            try {
                this.pointTotal += (long) Double.parseDouble(str.trim());
            } catch (NumberFormatException unused) {
            }
        }
        this.loyaltyPoint = String.valueOf(this.pointTotal);
    }

    private void addData(String str) {
        String strValueOf;
        if (ok(str)) {
            Matcher matcher = Pattern.compile("^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(.*)$").matcher(str);
            if (matcher.matches()) {
                this.dataTotal += Double.parseDouble(matcher.group(1));
                String strTrim = matcher.group(2).trim();
                if (!strTrim.isEmpty()) {
                    this.dataUnit = strTrim;
                }
            }
        }
        double d = this.dataTotal;
        if (d <= 0.0d) {
            this.mobileData = "";
            return;
        }
        if (d == Math.rint(d)) {
            strValueOf = String.valueOf((long) this.dataTotal);
        } else {
            strValueOf = String.valueOf(this.dataTotal);
        }
        if (!this.dataUnit.isEmpty()) {
            strValueOf = strValueOf + " " + this.dataUnit;
        }
        this.mobileData = strValueOf;
    }

    private static String apiMessage(JSONObject jSONObject, String str) {
        String strOptString = jSONObject.optString("message", "");
        return ok(strOptString) ? strOptString : str;
    }

    private static int optIntAny(JSONObject jSONObject, String... strArr) {
        JSONObject[] jSONObjectArr = {jSONObject, jSONObject.optJSONObject("data"), jSONObject.optJSONObject("result")};
        int i = 0;
        while (i < 3) {
            JSONObject jSONObject2 = jSONObjectArr[i];
            if (jSONObject2 != null) {
                for (String str : strArr) {
                    if (jSONObject2.has(str) && !jSONObject2.isNull(str)) {
                        Object objOpt = jSONObject2.opt(str);
                        if (objOpt instanceof Number) {
                            return ((Number) objOpt).intValue();
                        }
                        try {
                            return Integer.parseInt(String.valueOf(objOpt));
                        } catch (Exception unused) {
                            continue;
                        }
                    }
                }
            }
            i++;
        }
        return 0;
    }

    private static String optStringAny(JSONObject jSONObject, String... strArr) {
        JSONObject[] jSONObjectArr = {jSONObject, jSONObject.optJSONObject("data"), jSONObject.optJSONObject("result")};
        for (int i = 0; i < 3; i++) {
            JSONObject jSONObject2 = jSONObjectArr[i];
            if (jSONObject2 != null) {
                for (String str : strArr) {
                    if (jSONObject2.has(str) && !jSONObject2.isNull(str)) {
                        String strOptString = jSONObject2.optString(str, "");
                        if (ok(strOptString)) {
                            return strOptString;
                        }
                    }
                }
            }
        }
        return "";
    }

    private static String normalizeMode(String str) {
        if ("Easy".equalsIgnoreCase(str)) {
            return "Easy";
        }
        if ("Medium".equalsIgnoreCase(str)) {
            return "Medium";
        }
        return "Hard";
    }

    private static String toMsisdn(String str) {
        if (str == null) {
            return "";
        }
        String strReplaceAll = str.replaceAll("\\D", "");
        if (strReplaceAll.startsWith("95") || !strReplaceAll.startsWith("0")) {
            return strReplaceAll;
        }
        return "95" + strReplaceAll.substring(1);
    }

    private static boolean ok(String str) {
        return (str == null || str.trim().isEmpty()) ? false : true;
    }
}
