package com.zeno.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.core.view.WindowCompat;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;
import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class LoginActivity extends BaseActivity {
    public static final String EXTRA_ADD_ACCOUNT = "add_account";
    private boolean addAccountMode;
    private MaterialButton btnSendOtp;
    private EditText etPhone;
    private SessionManager sessionManager;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(android.R.color.transparent, getTheme()));
        boolean z = false;
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_login);
        this.sessionManager = new SessionManager(this);
        if (getIntent() != null && getIntent().getBooleanExtra(EXTRA_ADD_ACCOUNT, false)) {
            z = true;
        }
        this.addAccountMode = z;
        if (!z && this.sessionManager.isLoggedIn()) {
            startDashboard();
            return;
        }
        this.etPhone = (EditText) findViewById(R.id.etPhone);
        MaterialButton materialButtonFindViewById = findViewById(R.id.btnSendOtp);
        this.btnSendOtp = materialButtonFindViewById;
        materialButtonFindViewById.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.LoginActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m592lambda$onCreate$0$comzenoappLoginActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-LoginActivity, reason: not valid java name */
    /* synthetic */ void m592lambda$onCreate$0$comzenoappLoginActivity(View view) {
        handleSendOtp();
    }

    private void handleSendOtp() {
        String strTrim = this.etPhone.getText().toString().trim();
        if (strTrim.isEmpty()) {
            snack("Please enter phone number");
            return;
        }
        if (!strTrim.startsWith("09") || strTrim.length() < 10) {
            snack("Enter a valid Mytel number (09xxxxxxxxx)");
            return;
        }
        this.btnSendOtp.setEnabled(false);
        this.btnSendOtp.setText("Checking...");
        ApiClient.checkAccount(strTrim, new AnonymousClass1(strTrim));
    }

    /* JADX INFO: renamed from: com.zeno.app.LoginActivity$1, reason: invalid class name */
    class AnonymousClass1 implements Callback {
        final /* synthetic */ String val$phone;

        AnonymousClass1(String str) {
            this.val$phone = str;
        }

        public void onFailure(Call call, final IOException iOException) {
            LoginActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$1$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m593lambda$onFailure$0$comzenoappLoginActivity$1(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-LoginActivity$1, reason: not valid java name */
        /* synthetic */ void m593lambda$onFailure$0$comzenoappLoginActivity$1(IOException iOException) {
            LoginActivity.this.resetBtn();
            LoginActivity.this.snack("Network error: " + iOException.getMessage());
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = LoginActivity.this.uiHandler;
            final String str = this.val$phone;
            handler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m594lambda$onResponse$1$comzenoappLoginActivity$1(strString, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-LoginActivity$1, reason: not valid java name */
        /* synthetic */ void m594lambda$onResponse$1$comzenoappLoginActivity$1(String str, String str2) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optInt("errorCode", -1) != 200) {
                    LoginActivity.this.resetBtn();
                    LoginActivity.this.snack(jSONObject.optString("message", "Account check failed"));
                } else {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("result");
                    if (jSONObjectOptJSONObject == null || !jSONObjectOptJSONObject.optBoolean("verify", false)) {
                        LoginActivity.this.doRegisterRequest(str2);
                    } else {
                        LoginActivity.this.resetBtn();
                        LoginActivity.this.goToOtp(str2, false, null);
                    }
                }
            } catch (Exception e) {
                LoginActivity.this.resetBtn();
                LoginActivity.this.snack("Error: " + e.getMessage());
            }
        }
    }

    /* JADX INFO: renamed from: com.zeno.app.LoginActivity$2, reason: invalid class name */
    class AnonymousClass2 implements Callback {
        final /* synthetic */ String val$phone;

        AnonymousClass2(String str) {
            this.val$phone = str;
        }

        public void onFailure(Call call, final IOException iOException) {
            LoginActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m595lambda$onFailure$0$comzenoappLoginActivity$2(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-LoginActivity$2, reason: not valid java name */
        /* synthetic */ void m595lambda$onFailure$0$comzenoappLoginActivity$2(IOException iOException) {
            LoginActivity.this.resetBtn();
            LoginActivity.this.snack("Failed to send OTP: " + iOException.getMessage());
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = LoginActivity.this.uiHandler;
            final String str = this.val$phone;
            handler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m596lambda$onResponse$1$comzenoappLoginActivity$2(strString, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-LoginActivity$2, reason: not valid java name */
        /* synthetic */ void m596lambda$onResponse$1$comzenoappLoginActivity$2(String str, String str2) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optInt("errorCode", -1) == 200) {
                    LoginActivity.this.resetBtn();
                    LoginActivity.this.goToOtp(str2, false, null);
                } else {
                    LoginActivity.this.resetBtn();
                    LoginActivity.this.snack(jSONObject.optString("message", "Failed to send OTP"));
                }
            } catch (Exception unused) {
                LoginActivity.this.resetBtn();
            }
        }
    }

    private void doGetOtp(String str) {
        this.btnSendOtp.setText("Sending OTP...");
        ApiClient.getOtp(str, new AnonymousClass2(str));
    }

    /* JADX INFO: renamed from: com.zeno.app.LoginActivity$3, reason: invalid class name */
    class AnonymousClass3 implements Callback {
        final /* synthetic */ String val$phone;

        AnonymousClass3(String str) {
            this.val$phone = str;
        }

        public void onFailure(Call call, final IOException iOException) {
            LoginActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m597lambda$onFailure$0$comzenoappLoginActivity$3(iOException);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-LoginActivity$3, reason: not valid java name */
        /* synthetic */ void m597lambda$onFailure$0$comzenoappLoginActivity$3(IOException iOException) {
            LoginActivity.this.resetBtn();
            LoginActivity.this.snack("Register failed: " + iOException.getMessage());
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            Handler handler = LoginActivity.this.uiHandler;
            final String str = this.val$phone;
            handler.post(new Runnable() { // from class: com.zeno.app.LoginActivity$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m598lambda$onResponse$1$comzenoappLoginActivity$3(strString, str);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-LoginActivity$3, reason: not valid java name */
        /* synthetic */ void m598lambda$onResponse$1$comzenoappLoginActivity$3(String str, String str2) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                if (jSONObject.optInt("errorCode", -1) != 200) {
                    LoginActivity.this.resetBtn();
                    LoginActivity.this.snack(jSONObject.optString("message", "Register failed"));
                } else {
                    JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("result");
                    String strOptString = jSONObjectOptJSONObject != null ? jSONObjectOptJSONObject.optString("reqId", "") : "";
                    LoginActivity.this.resetBtn();
                    LoginActivity.this.goToOtp(str2, true, strOptString);
                }
            } catch (Exception unused) {
                LoginActivity.this.resetBtn();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doRegisterRequest(String str) {
        this.btnSendOtp.setText("Registering...");
        ApiClient.registerRequest(str, new AnonymousClass3(str));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void goToOtp(String str, boolean z, String str2) {
        Intent intent = new Intent((Context) this, (Class<?>) OtpActivity.class);
        intent.putExtra("phone", str);
        intent.putExtra("isRegister", z);
        if (str2 != null) {
            intent.putExtra("reqId", str2);
        }
        intent.putExtra(EXTRA_ADD_ACCOUNT, this.addAccountMode);
        startActivity(intent);
        if (this.addAccountMode) {
            finish();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void resetBtn() {
        this.btnSendOtp.setEnabled(true);
        this.btnSendOtp.setText(getString(R.string.send_otp));
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void startDashboard() {
        startActivity(new Intent((Context) this, (Class<?>) DashboardActivity.class));
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void snack(String str) {
        Snackbar snackbarMake = Snackbar.make(findViewById(android.R.id.content), str, 0);
        View view = snackbarMake.getView();
        ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
        view.setLayoutParams(view.getLayoutParams());
        snackbarMake.show();
    }
}
