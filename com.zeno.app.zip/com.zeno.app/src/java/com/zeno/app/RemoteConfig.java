package com.zeno.app;

import org.json.JSONObject;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public class RemoteConfig {
    public static volatile int kittyMaxDelaySec = 35;
    public static volatile int kittyMinDelaySec = 30;
    public int adsDuration;
    public String adsLink;
    public int adsSkipAfter;
    public String adsUrl;
    public String changeApkMessage;
    public String changeApkTitle;
    public String closeTitle;
    public String message;
    public String notificationBtnText;
    public String notificationImage;
    public String notificationLink;
    public String notificationText;
    public String notificationTitle;
    private JSONObject raw;
    public boolean server;
    public boolean showBeatZoo;
    public boolean showCarRacing;
    public boolean showFightingFish;
    public boolean showKittyFall;
    public boolean showKongIsland;
    public boolean showMyIDGo;
    public boolean showSoftClimber;
    public String status;
    public String updateLink;
    public String updateMessage;
    public String updateTitle;
    public String version;

    public String lockedText(String str, String str2, String str3) {
        JSONObject jSONObject = this.raw;
        if (jSONObject == null) {
            return str3;
        }
        String strTrim = jSONObject.optString(str + "_locked_" + str2, "").trim();
        if (strTrim.isEmpty()) {
            strTrim = this.raw.optString("locked_" + str2, "").trim();
        }
        return strTrim.isEmpty() ? str3 : strTrim;
    }

    private static int parseIntSafe(String str) {
        try {
            return Integer.parseInt(str.trim());
        } catch (Exception unused) {
            return 0;
        }
    }

    public boolean hasNotification() {
        String str = this.notificationTitle;
        return (str == null || str.isEmpty()) ? false : true;
    }

    private static boolean flagFromServer(JSONObject jSONObject, String str) {
        if (!jSONObject.has(str) || jSONObject.isNull(str)) {
            return false;
        }
        Object objOpt = jSONObject.opt(str);
        if (objOpt instanceof Boolean) {
            return ((Boolean) objOpt).booleanValue();
        }
        if (objOpt instanceof Number) {
            return ((Number) objOpt).intValue() != 0;
        }
        if (!(objOpt instanceof String)) {
            return false;
        }
        String strTrim = ((String) objOpt).trim();
        return "true".equalsIgnoreCase(strTrim) || "1".equals(strTrim) || "yes".equalsIgnoreCase(strTrim);
    }

    public static RemoteConfig parse(String str) throws Exception {
        JSONObject jSONObject = new JSONObject(str);
        RemoteConfig remoteConfig = new RemoteConfig();
        remoteConfig.raw = jSONObject;
        remoteConfig.server = jSONObject.optBoolean("server", false);
        remoteConfig.status = jSONObject.optString("status", "close");
        remoteConfig.message = jSONObject.optString("message", "");
        remoteConfig.closeTitle = jSONObject.optString("close_title", "App Closed");
        remoteConfig.version = jSONObject.optString("version", "");
        remoteConfig.updateLink = jSONObject.optString("update_link", "");
        remoteConfig.updateTitle = jSONObject.optString("update_title", "Update အသစ်ထွက်ပြီ");
        remoteConfig.updateMessage = jSONObject.optString("update_message", "Version အသစ်တစ်ခု အသင့်ဖြစ်နေပါပြီ။ နောက်ဆုံးထွက် features များနှင့် တိုးတက်မှုများ ရရှိရန် ယခုပဲ Update လုပ်ပါ။");
        remoteConfig.changeApkTitle = jSONObject.optString("change_apk_title", "Admin Block");
        remoteConfig.changeApkMessage = jSONObject.optString("change_apk", "");
        remoteConfig.adsUrl = jSONObject.optString("ads_url", "");
        remoteConfig.adsLink = jSONObject.optString("ads_link", "");
        remoteConfig.adsDuration = parseIntSafe(jSONObject.optString("ads_duration", "0"));
        remoteConfig.adsSkipAfter = parseIntSafe(jSONObject.optString("ads_skip_after", "0"));
        remoteConfig.showKongIsland = flagFromServer(jSONObject, "kongisland");
        remoteConfig.showKittyFall = flagFromServer(jSONObject, "kittyfall");
        remoteConfig.showSoftClimber = flagFromServer(jSONObject, "softclimber");
        remoteConfig.showMyIDGo = flagFromServer(jSONObject, "myidgo");
        remoteConfig.showBeatZoo = flagFromServer(jSONObject, "beatzoo");
        remoteConfig.showCarRacing = flagFromServer(jSONObject, "carracing");
        remoteConfig.showFightingFish = flagFromServer(jSONObject, "fightingfish");
        int intSafe = parseIntSafe(jSONObject.optString("kitty_min_delay", "30"));
        int intSafe2 = parseIntSafe(jSONObject.optString("kitty_max_delay", "35"));
        if (intSafe < 1) {
            intSafe = 30;
        }
        if (intSafe2 < intSafe) {
            intSafe2 = intSafe;
        }
        kittyMinDelaySec = intSafe;
        kittyMaxDelaySec = intSafe2;
        JSONObject jSONObjectOptJSONObject = jSONObject.optJSONObject("notification");
        if (jSONObjectOptJSONObject != null) {
            remoteConfig.notificationTitle = jSONObjectOptJSONObject.optString("notification_title", "");
            remoteConfig.notificationText = jSONObjectOptJSONObject.optString("notification_text", "");
            remoteConfig.notificationLink = jSONObjectOptJSONObject.optString("notification_link", "");
            remoteConfig.notificationBtnText = jSONObjectOptJSONObject.optString("notification_btn_text", "Open");
            remoteConfig.notificationImage = jSONObjectOptJSONObject.optString("notification_image", "");
        }
        return remoteConfig;
    }
}
