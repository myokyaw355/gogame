package com.zeno.app;

import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.snackbar.Snackbar;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
public final class ZSnack {
    private ZSnack() {
    }

    public static Snackbar make(View view, CharSequence charSequence, int i) {
        Snackbar snackbarMake = Snackbar.make(view, charSequence, i);
        View view2 = snackbarMake.getView();
        ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            ((ViewGroup.MarginLayoutParams) layoutParams).setMargins(0, 0, 0, 0);
            view2.setLayoutParams(layoutParams);
        }
        return snackbarMake;
    }
}
