package com.zeno.app;

import android.animation.ObjectAnimator;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.core.graphics.Insets;
import androidx.core.view.OnApplyWindowInsetsListener;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/2.dex */
public class SplashActivity extends BaseActivity {
    private static final int ADS_DEFAULT_IMAGE_SECONDS = 5;
    private static final String ADS_PREFS = "ads_cache";
    private static final String CONFIG_URL = "https://zenoofficial.x10.mx/myid/message.json";
    public static final String FCM_TOPIC = "zenomyid_all_users";
    private static final long SHOW_DELAY_MS = 800;
    private ImageView adImage;
    private View adLayer;
    private VideoView adVideo;
    private ConnectivityManager connectivityManager;
    private AdData currentAd;
    private ConnectivityManager.NetworkCallback networkCallback;
    private Snackbar noInternetSnackbar;
    private RemoteConfig pendingCfg;
    private ObjectAnimator progressSlideAnim;
    private View splashContent;
    private ProgressBar splashProgress;
    private View splashProgressIndeterminate;
    private View splashProgressTrack;
    private TextView tvAdSkip;
    private TextView tvSplashTagline;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean navigated = false;
    private final ExecutorService adExec = Executors.newSingleThreadExecutor();
    private boolean progressKnown = false;
    private boolean instantAdShown = false;
    private boolean cfgResolved = false;
    private boolean fetching = false;
    private boolean adShowing = false;
    private boolean adFinished = false;
    private long adElapsedMs = 0;
    private int adTotalMs = 0;
    private final Runnable adTicker = new Runnable() { // from class: com.zeno.app.SplashActivity.1
        @Override // java.lang.Runnable
        public void run() {
            SplashActivity.this.onAdTick();
        }
    };

    public void onBackPressed() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    static class AdData {
        int durationSec;
        File file;
        String link;
        int skipAfterSec;
        boolean video;

        private AdData() {
        }
    }

    @Override // com.zeno.app.BaseActivity
    protected void onCreate(Bundle bundle) {
        setTheme(R.style.Theme_ZenoMyID);
        super.onCreate(bundle);
        getWindow().setStatusBarColor(getResources().getColor(R.color.bg_dark, getTheme()));
        getWindow().setNavigationBarColor(getResources().getColor(R.color.bg_dark, getTheme()));
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView()).setAppearanceLightStatusBars(false);
        setContentView(R.layout.activity_splash);
        this.splashContent = findViewById(R.id.splashContent);
        this.tvSplashTagline = (TextView) findViewById(R.id.tvSplashTagline);
        this.splashProgressTrack = findViewById(R.id.splashProgressTrack);
        this.splashProgressIndeterminate = findViewById(R.id.splashProgressIndeterminate);
        this.splashProgress = (ProgressBar) findViewById(R.id.splashProgress);
        startProgressSlideAnimation();
        this.adLayer = findViewById(R.id.adLayer);
        this.adImage = (ImageView) findViewById(R.id.adImage);
        this.adVideo = (VideoView) findViewById(R.id.adVideo);
        TextView textView = (TextView) findViewById(R.id.tvAdSkip);
        this.tvAdSkip = textView;
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda11
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m749lambda$onCreate$0$comzenoappSplashActivity(view);
            }
        });
        this.adLayer.setOnClickListener(new View.OnClickListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda12
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m750lambda$onCreate$1$comzenoappSplashActivity(view);
            }
        });
        setupPushNotifications();
        openNotificationLinkIfAny(getIntent());
        this.connectivityManager = (ConnectivityManager) getSystemService("connectivity");
        registerNetworkCallback();
        AdData instantCachedAd = getInstantCachedAd();
        if (instantCachedAd != null) {
            this.instantAdShown = true;
            this.splashContent.setVisibility(8);
            showAd(instantCachedAd);
        }
        this.uiHandler.postDelayed(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda13
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m751lambda$onCreate$2$comzenoappSplashActivity();
            }
        }, this.instantAdShown ? 0L : SHOW_DELAY_MS);
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m749lambda$onCreate$0$comzenoappSplashActivity(View view) {
        finishAd();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m750lambda$onCreate$1$comzenoappSplashActivity(View view) {
        openAdLink();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m751lambda$onCreate$2$comzenoappSplashActivity() {
        if (isConnected()) {
            startFetch();
        } else {
            if (this.instantAdShown) {
                return;
            }
            showNoInternetSnackbar();
        }
    }

    private void setupPushNotifications() {
        NotificationManager notificationManager;
        if (Build.VERSION.SDK_INT >= 26 && (notificationManager = (NotificationManager) getSystemService(NotificationManager.class)) != null && notificationManager.getNotificationChannel(ZenoMyIDFirebaseMessagingService.CHANNEL_ID) == null) {
            NotificationChannel notificationChannelM = SplashActivity$$ExternalSyntheticApiModelOutline0.m(ZenoMyIDFirebaseMessagingService.CHANNEL_ID, "ZenoMyID Notifications", 4);
            notificationChannelM.setDescription("ZenoMyID app ကနေ ပို့တဲ့ notification များ");
            notificationManager.createNotificationChannel(notificationChannelM);
        }
        try {
            FirebaseMessaging.getInstance().subscribeToTopic(FCM_TOPIC);
        } catch (Exception unused) {
        }
    }

    private void openNotificationLinkIfAny(Intent intent) {
        String stringExtra;
        if (intent == null || (stringExtra = intent.getStringExtra("notif_link")) == null || stringExtra.trim().isEmpty()) {
            return;
        }
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(stringExtra.trim())));
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isConnected() {
        Network activeNetwork;
        NetworkCapabilities networkCapabilities;
        ConnectivityManager connectivityManager = this.connectivityManager;
        if (connectivityManager == null || (activeNetwork = connectivityManager.getActiveNetwork()) == null || (networkCapabilities = this.connectivityManager.getNetworkCapabilities(activeNetwork)) == null) {
            return false;
        }
        return networkCapabilities.hasTransport(1) || networkCapabilities.hasTransport(0) || networkCapabilities.hasTransport(3);
    }

    private void registerNetworkCallback() {
        NetworkRequest networkRequestBuild = new NetworkRequest.Builder().addCapability(12).build();
        AnonymousClass2 anonymousClass2 = new AnonymousClass2();
        this.networkCallback = anonymousClass2;
        this.connectivityManager.registerNetworkCallback(networkRequestBuild, anonymousClass2);
    }

    /* JADX INFO: renamed from: com.zeno.app.SplashActivity$2, reason: invalid class name */
    /* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/1.dex */
    class AnonymousClass2 extends ConnectivityManager.NetworkCallback {
        AnonymousClass2() {
        }

        @Override // android.net.ConnectivityManager.NetworkCallback
        public void onAvailable(Network network) {
            SplashActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$2$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m760lambda$onAvailable$0$comzenoappSplashActivity$2();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onAvailable$0$com-zeno-app-SplashActivity$2, reason: not valid java name */
        /* synthetic */ void m760lambda$onAvailable$0$comzenoappSplashActivity$2() {
            SplashActivity.this.dismissNoInternetSnackbar();
            if (SplashActivity.this.navigated) {
                return;
            }
            SplashActivity.this.startFetch();
        }

        @Override // android.net.ConnectivityManager.NetworkCallback
        public void onLost(Network network) {
            SplashActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$2$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m761lambda$onLost$1$comzenoappSplashActivity$2();
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onLost$1$com-zeno-app-SplashActivity$2, reason: not valid java name */
        /* synthetic */ void m761lambda$onLost$1$comzenoappSplashActivity$2() {
            if (SplashActivity.this.isConnected() || SplashActivity.this.navigated || SplashActivity.this.instantAdShown) {
                return;
            }
            SplashActivity.this.showNoInternetSnackbar();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startFetch() {
        if (this.fetching) {
            return;
        }
        this.fetching = true;
        new OkHttpClient.Builder().connectTimeout(6L, TimeUnit.SECONDS).readTimeout(6L, TimeUnit.SECONDS).build().newCall(new Request.Builder().url(CONFIG_URL).build()).enqueue(new AnonymousClass3());
    }

    /* JADX INFO: renamed from: com.zeno.app.SplashActivity$3, reason: invalid class name */
    class AnonymousClass3 implements Callback {
        AnonymousClass3() {
        }

        /* JADX INFO: renamed from: lambda$onFailure$0$com-zeno-app-SplashActivity$3, reason: not valid java name */
        /* synthetic */ void m762lambda$onFailure$0$comzenoappSplashActivity$3() {
            SplashActivity.this.fetching = false;
            SplashActivity.this.onConfigUnavailable();
        }

        public void onFailure(Call call, IOException iOException) {
            SplashActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$3$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m762lambda$onFailure$0$comzenoappSplashActivity$3();
                }
            });
        }

        public void onResponse(Call call, Response response) throws IOException {
            final String strString = response.body() != null ? response.body().string() : "{}";
            SplashActivity.this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$3$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m763lambda$onResponse$1$comzenoappSplashActivity$3(strString);
                }
            });
        }

        /* JADX INFO: renamed from: lambda$onResponse$1$com-zeno-app-SplashActivity$3, reason: not valid java name */
        /* synthetic */ void m763lambda$onResponse$1$comzenoappSplashActivity$3(String str) {
            SplashActivity.this.handleRemoteConfig(str);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void handleRemoteConfig(String str) {
        String str2;
        if (isFinishing() || isDestroyed()) {
            return;
        }
        try {
            final RemoteConfig remoteConfig = RemoteConfig.parse(str);
            LiveConfig.seed(str, remoteConfig);
            if ("close".equalsIgnoreCase(remoteConfig.status)) {
                if (remoteConfig.message != null && !remoteConfig.message.isEmpty()) {
                    str2 = remoteConfig.message;
                } else {
                    str2 = "This app is currently closed. Please check back later.";
                }
                dismissInstantAd();
                ZDialog.showCloseApp(this, remoteConfig.closeTitle, str2);
                return;
            }
            if (isTampered()) {
                dismissInstantAd();
                checkAppIntegrity(remoteConfig.changeApkTitle, remoteConfig.changeApkMessage);
                return;
            }
            this.pendingCfg = remoteConfig;
            this.cfgResolved = true;
            if (this.instantAdShown) {
                if (remoteConfig.adsUrl != null && !remoteConfig.adsUrl.trim().isEmpty()) {
                    this.adExec.execute(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda18
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f$0.m746lambda$handleRemoteConfig$3$comzenoappSplashActivity(remoteConfig);
                        }
                    });
                } else {
                    clearAdCache();
                }
                if (this.adFinished) {
                    navigate(remoteConfig);
                    return;
                }
                return;
            }
            if (remoteConfig.adsUrl == null || remoteConfig.adsUrl.trim().isEmpty()) {
                clearAdCache();
            }
            if (remoteConfig.adsUrl != null && !remoteConfig.adsUrl.trim().isEmpty()) {
                this.adExec.execute(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda19
                    @Override // java.lang.Runnable
                    public final void run() {
                        this.f$0.m748lambda$handleRemoteConfig$5$comzenoappSplashActivity(remoteConfig);
                    }
                });
            } else {
                navigate(remoteConfig);
            }
        } catch (Exception unused) {
            onConfigUnavailable();
        }
    }

    /* JADX INFO: renamed from: lambda$handleRemoteConfig$3$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m746lambda$handleRemoteConfig$3$comzenoappSplashActivity(RemoteConfig remoteConfig) {
        try {
            if (prepareAd(remoteConfig.adsUrl.trim(), remoteConfig.adsDuration, remoteConfig.adsSkipAfter, remoteConfig.adsLink) != null) {
                saveAdMeta(remoteConfig.adsDuration, remoteConfig.adsSkipAfter, remoteConfig.adsLink);
            }
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: renamed from: lambda$handleRemoteConfig$5$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m748lambda$handleRemoteConfig$5$comzenoappSplashActivity(RemoteConfig remoteConfig) {
        final AdData adDataPrepareAd = null;
        try {
            adDataPrepareAd = prepareAd(remoteConfig.adsUrl.trim(), remoteConfig.adsDuration, remoteConfig.adsSkipAfter, remoteConfig.adsLink);
            if (adDataPrepareAd != null) {
                saveAdMeta(remoteConfig.adsDuration, remoteConfig.adsSkipAfter, remoteConfig.adsLink);
            }
        } catch (Exception unused) {
        }
        this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda6
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m747lambda$handleRemoteConfig$4$comzenoappSplashActivity(adDataPrepareAd);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$handleRemoteConfig$4$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m747lambda$handleRemoteConfig$4$comzenoappSplashActivity(AdData adData) {
        if (this.navigated) {
            return;
        }
        if (adData != null) {
            showAd(adData);
        } else {
            navigate(this.pendingCfg);
        }
    }

    private void startProgressSlideAnimation() {
        View view;
        if (this.splashProgressTrack == null || (view = this.splashProgressIndeterminate) == null) {
            return;
        }
        view.setVisibility(0);
        ProgressBar progressBar = this.splashProgress;
        if (progressBar != null) {
            progressBar.setVisibility(8);
        }
        this.splashProgressTrack.post(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda10
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m759lambda$startProgressSlideAnimation$6$comzenoappSplashActivity();
            }
        });
    }

    /* JADX INFO: renamed from: lambda$startProgressSlideAnimation$6$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m759lambda$startProgressSlideAnimation$6$comzenoappSplashActivity() {
        if (this.progressKnown) {
            return;
        }
        float fMax = Math.max(0, this.splashProgressTrack.getWidth() - this.splashProgressIndeterminate.getWidth());
        if (fMax <= 0.0f) {
            return;
        }
        ObjectAnimator objectAnimator = this.progressSlideAnim;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this.splashProgressIndeterminate, "translationX", 0.0f, fMax);
        this.progressSlideAnim = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(750L);
        this.progressSlideAnim.setInterpolator(new LinearInterpolator());
        this.progressSlideAnim.setRepeatMode(2);
        this.progressSlideAnim.setRepeatCount(-1);
        this.progressSlideAnim.start();
    }

    private void showKnownProgress(int i) {
        if (this.progressKnown) {
            ProgressBar progressBar = this.splashProgress;
            if (progressBar != null) {
                progressBar.setProgress(i);
                return;
            }
            return;
        }
        this.progressKnown = true;
        ObjectAnimator objectAnimator = this.progressSlideAnim;
        if (objectAnimator != null) {
            objectAnimator.cancel();
            this.progressSlideAnim = null;
        }
        View view = this.splashProgressIndeterminate;
        if (view != null) {
            view.setVisibility(8);
        }
        ProgressBar progressBar2 = this.splashProgress;
        if (progressBar2 != null) {
            progressBar2.setVisibility(0);
            this.splashProgress.setProgress(i);
        }
    }

    private void stopProgressUI() {
        ObjectAnimator objectAnimator = this.progressSlideAnim;
        if (objectAnimator != null) {
            objectAnimator.cancel();
            this.progressSlideAnim = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onConfigUnavailable() {
        this.cfgResolved = true;
        if (!this.instantAdShown || this.adFinished) {
            navigate(null);
        }
    }

    private void dismissInstantAd() {
        if (this.instantAdShown && this.adShowing) {
            this.adFinished = true;
            this.adShowing = false;
            this.uiHandler.removeCallbacks(this.adTicker);
            try {
                this.adVideo.stopPlayback();
            } catch (Exception unused) {
            }
            this.adLayer.setVisibility(8);
            this.splashContent.setVisibility(0);
            WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
            getWindow().setStatusBarColor(getResources().getColor(R.color.bg_dark, getTheme()));
            getWindow().setNavigationBarColor(getResources().getColor(R.color.bg_dark, getTheme()));
        }
    }

    private void saveAdMeta(int i, int i2, String str) {
        SharedPreferences.Editor editorPutInt = getSharedPreferences(ADS_PREFS, 0).edit().putInt("durationSec", i).putInt("skipAfterSec", i2);
        if (str == null) {
            str = "";
        }
        editorPutInt.putString("link", str).apply();
    }

    private void clearAdCache() {
        SharedPreferences sharedPreferences = getSharedPreferences(ADS_PREFS, 0);
        if (sharedPreferences.getAll().isEmpty()) {
            return;
        }
        File[] fileArrListFiles = adsDir().listFiles();
        if (fileArrListFiles != null) {
            for (File file : fileArrListFiles) {
                file.delete();
            }
        }
        sharedPreferences.edit().clear().apply();
    }

    private AdData getInstantCachedAd() {
        SharedPreferences sharedPreferences = getSharedPreferences(ADS_PREFS, 0);
        String string = sharedPreferences.getString("file", "");
        if (string.isEmpty()) {
            return null;
        }
        File file = new File(adsDir(), string);
        if (!file.exists() || file.length() <= 0) {
            return null;
        }
        AdData adData = new AdData();
        adData.file = file;
        adData.video = sharedPreferences.getBoolean("video", false);
        adData.durationSec = sharedPreferences.getInt("durationSec", 0);
        adData.skipAfterSec = sharedPreferences.getInt("skipAfterSec", 0);
        adData.link = sharedPreferences.getString("link", "");
        return adData;
    }

    private File adsDir() {
        File file = new File(getFilesDir(), ADS_PREFS);
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    private static boolean looksLikeVideo(String str) {
        String lowerCase = str.toLowerCase(Locale.US);
        int iIndexOf = lowerCase.indexOf(63);
        if (iIndexOf >= 0) {
            lowerCase = lowerCase.substring(0, iIndexOf);
        }
        return lowerCase.endsWith(".mp4") || lowerCase.endsWith(".webm") || lowerCase.endsWith(".3gp") || lowerCase.endsWith(".mkv") || lowerCase.endsWith(".mov") || lowerCase.endsWith(".m4v");
    }

    private String fetchRemoteChangeTag(OkHttpClient okHttpClient, String str) {
        try {
            Response responseExecute = okHttpClient.newCall(new Request.Builder().url(str).head().build()).execute();
            try {
                if (!responseExecute.isSuccessful()) {
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return null;
                }
                String strHeader = responseExecute.header("ETag");
                if (strHeader != null && !strHeader.trim().isEmpty()) {
                    String str2 = "etag:" + strHeader.trim();
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return str2;
                }
                String strHeader2 = responseExecute.header("Last-Modified");
                if (strHeader2 != null && !strHeader2.trim().isEmpty()) {
                    String str3 = "lm:" + strHeader2.trim();
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return str3;
                }
                String strHeader3 = responseExecute.header("Content-Length");
                if (strHeader3 == null || strHeader3.trim().isEmpty()) {
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return null;
                }
                String str4 = "len:" + strHeader3.trim();
                if (responseExecute != null) {
                    responseExecute.close();
                }
                return str4;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }

    private AdData prepareAd(String str, int i, int i2, String str2) {
        String strHeader;
        String strFetchRemoteChangeTag;
        SharedPreferences sharedPreferences = getSharedPreferences(ADS_PREFS, 0);
        OkHttpClient okHttpClientBuild = new OkHttpClient.Builder().connectTimeout(8L, TimeUnit.SECONDS).readTimeout(20L, TimeUnit.SECONDS).build();
        String string = sharedPreferences.getString("key", "");
        String string2 = sharedPreferences.getString("file", "");
        String string3 = sharedPreferences.getString("tag", "");
        if (str.equals(string) && !string2.isEmpty()) {
            File file = new File(adsDir(), string2);
            if (file.exists() && file.length() > 0 && ((strFetchRemoteChangeTag = fetchRemoteChangeTag(okHttpClientBuild, str)) == null || strFetchRemoteChangeTag.equals(string3))) {
                AdData adData = new AdData();
                adData.file = file;
                adData.video = sharedPreferences.getBoolean("video", false);
                adData.durationSec = i;
                adData.skipAfterSec = i2;
                adData.link = str2;
                return adData;
            }
        }
        File file2 = new File(adsDir(), "download.tmp");
        try {
            Response responseExecute = okHttpClientBuild.newCall(new Request.Builder().url(str).build()).execute();
            try {
                if (!responseExecute.isSuccessful()) {
                    if (responseExecute == null) {
                        return null;
                    }
                    responseExecute.close();
                    return null;
                }
                ResponseBody responseBodyBody = responseExecute.body();
                if (responseBodyBody == null) {
                    if (responseExecute != null) {
                        responseExecute.close();
                    }
                    return null;
                }
                String strHeader2 = responseExecute.header("Content-Type");
                boolean zLooksLikeVideo = (strHeader2 == null || !strHeader2.toLowerCase(Locale.US).startsWith("video/")) ? (strHeader2 == null || !strHeader2.toLowerCase(Locale.US).startsWith("image/")) ? looksLikeVideo(str) : false : true;
                String strHeader3 = responseExecute.header("ETag");
                String str3 = (strHeader3 == null || strHeader3.trim().isEmpty()) ? null : "etag:" + strHeader3.trim();
                if (str3 == null && (strHeader = responseExecute.header("Last-Modified")) != null && !strHeader.trim().isEmpty()) {
                    str3 = "lm:" + strHeader.trim();
                }
                long jContentLength = responseBodyBody.contentLength();
                InputStream inputStreamByteStream = responseBodyBody.byteStream();
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    try {
                        byte[] bArr = new byte[16384];
                        int i3 = -1;
                        long j = 0;
                        int i4 = -1;
                        while (true) {
                            int i5 = inputStreamByteStream.read(bArr);
                            if (i5 == i3) {
                                break;
                            }
                            fileOutputStream.write(bArr, 0, i5);
                            byte[] bArr2 = bArr;
                            j += (long) i5;
                            if (jContentLength > 0) {
                                final int i6 = (int) ((100 * j) / jContentLength);
                                int i7 = i4;
                                if (i6 != i7) {
                                    this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda14
                                        @Override // java.lang.Runnable
                                        public final void run() {
                                            this.f$0.m752lambda$prepareAd$7$comzenoappSplashActivity(i6);
                                        }
                                    });
                                    i4 = i6;
                                } else {
                                    i4 = i7;
                                }
                            }
                            bArr = bArr2;
                            i3 = -1;
                        }
                        fileOutputStream.close();
                        if (inputStreamByteStream != null) {
                            inputStreamByteStream.close();
                        }
                        if (file2.length() == 0) {
                            file2.delete();
                            if (responseExecute == null) {
                                return null;
                            }
                            responseExecute.close();
                            return null;
                        }
                        if (str3 == null) {
                            str3 = "len:" + file2.length();
                        }
                        File[] fileArrListFiles = adsDir().listFiles();
                        if (fileArrListFiles != null) {
                            for (File file3 : fileArrListFiles) {
                                if (!file3.equals(file2)) {
                                    file3.delete();
                                }
                            }
                        }
                        StringBuilder sb = new StringBuilder();
                        sb.append("ad_");
                        sb.append(System.currentTimeMillis());
                        sb.append(zLooksLikeVideo ? ".mp4" : ".img");
                        String string4 = sb.toString();
                        File file4 = new File(adsDir(), string4);
                        if (!file2.renameTo(file4)) {
                            file2.delete();
                            if (responseExecute == null) {
                                return null;
                            }
                            responseExecute.close();
                            return null;
                        }
                        sharedPreferences.edit().putString("key", str).putString("file", string4).putString("tag", str3).putBoolean("video", zLooksLikeVideo).apply();
                        AdData adData2 = new AdData();
                        adData2.file = file4;
                        adData2.video = zLooksLikeVideo;
                        adData2.durationSec = i;
                        adData2.skipAfterSec = i2;
                        adData2.link = str2;
                        if (responseExecute != null) {
                            responseExecute.close();
                        }
                        return adData2;
                    } finally {
                    }
                } finally {
                    file2.delete();
                    return null;
                }
            } finally {
            }
        } catch (Exception unused) {
            file2.delete();
            return null;
        }
        file2.delete();
        return null;
    }

    /* JADX INFO: renamed from: lambda$prepareAd$7$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m752lambda$prepareAd$7$comzenoappSplashActivity(int i) {
        if (this.instantAdShown || this.adShowing) {
            return;
        }
        TextView textView = this.tvSplashTagline;
        if (textView != null) {
            textView.setText("Downloading... " + i + "%");
        }
        showKnownProgress(i);
    }

    private void showAd(AdData adData) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.currentAd = adData;
        this.adShowing = true;
        this.adFinished = false;
        this.adElapsedMs = 0L;
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(0);
        getWindow().setNavigationBarColor(0);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = 1;
        }
        final int i = (int) (getResources().getDisplayMetrics().density * 16.0f);
        ViewCompat.setOnApplyWindowInsetsListener(this.adLayer, new OnApplyWindowInsetsListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda8
            public final WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                return this.f$0.m753lambda$showAd$8$comzenoappSplashActivity(i, view, windowInsetsCompat);
            }
        });
        ViewCompat.requestApplyInsets(this.adLayer);
        if (adData.video) {
            showVideoAd(adData);
        } else {
            showImageAd(adData);
        }
    }

    /* JADX INFO: renamed from: lambda$showAd$8$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ WindowInsetsCompat m753lambda$showAd$8$comzenoappSplashActivity(int i, View view, WindowInsetsCompat windowInsetsCompat) {
        Insets insets = windowInsetsCompat.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.tvAdSkip.getLayoutParams();
        layoutParams.topMargin = i + insets.top;
        this.tvAdSkip.setLayoutParams(layoutParams);
        return windowInsetsCompat;
    }

    private void showImageAd(AdData adData) {
        this.adImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        this.adImage.setVisibility(0);
        this.adVideo.setVisibility(8);
        this.adTotalMs = (adData.skipAfterSec > 0 ? adData.skipAfterSec * 1000 : 0) + ((adData.durationSec > 0 ? adData.durationSec : ADS_DEFAULT_IMAGE_SECONDS) * 1000);
        final File file = adData.file;
        this.adExec.execute(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda9
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m754lambda$showImageAd$10$comzenoappSplashActivity(file);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showImageAd$10$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m754lambda$showImageAd$10$comzenoappSplashActivity(File file) {
        final Bitmap bitmapDecodeFile;
        try {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            int i = displayMetrics.widthPixels;
            int i2 = displayMetrics.heightPixels;
            BitmapFactory.Options options = new BitmapFactory.Options();
            int i3 = 1;
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            int i4 = options.outWidth;
            int i5 = options.outHeight;
            if (i4 > 0 && i5 > 0) {
                while (true) {
                    int i6 = i3 * 2;
                    if (i4 / i6 < i || i5 / i6 < i2) {
                        break;
                    } else {
                        i3 = i6;
                    }
                }
            }
            BitmapFactory.Options options2 = new BitmapFactory.Options();
            options2.inSampleSize = i3;
            bitmapDecodeFile = BitmapFactory.decodeFile(file.getAbsolutePath(), options2);
        } catch (Exception | OutOfMemoryError unused) {
            bitmapDecodeFile = null;
        }
        this.uiHandler.post(new Runnable() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m755lambda$showImageAd$9$comzenoappSplashActivity(bitmapDecodeFile);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showImageAd$9$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m755lambda$showImageAd$9$comzenoappSplashActivity(Bitmap bitmap) {
        if (bitmap == null) {
            finishAd();
        } else {
            this.adImage.setImageBitmap(bitmap);
            revealAdAndStartTimer();
        }
    }

    private void showVideoAd(AdData adData) {
        this.adImage.setVisibility(8);
        this.adVideo.setVisibility(0);
        this.adLayer.setVisibility(0);
        this.adVideo.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda15
            @Override // android.media.MediaPlayer.OnPreparedListener
            public final void onPrepared(MediaPlayer mediaPlayer) {
                this.f$0.m756lambda$showVideoAd$11$comzenoappSplashActivity(mediaPlayer);
            }
        });
        this.adVideo.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda16
            @Override // android.media.MediaPlayer.OnCompletionListener
            public final void onCompletion(MediaPlayer mediaPlayer) {
                this.f$0.m757lambda$showVideoAd$12$comzenoappSplashActivity(mediaPlayer);
            }
        });
        this.adVideo.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.zeno.app.SplashActivity$$ExternalSyntheticLambda17
            @Override // android.media.MediaPlayer.OnErrorListener
            public final boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
                return this.f$0.m758lambda$showVideoAd$13$comzenoappSplashActivity(mediaPlayer, i, i2);
            }
        });
        this.adVideo.setVideoURI(Uri.fromFile(adData.file));
    }

    /* JADX INFO: renamed from: lambda$showVideoAd$11$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m756lambda$showVideoAd$11$comzenoappSplashActivity(MediaPlayer mediaPlayer) {
        mediaPlayer.setLooping(false);
        int duration = mediaPlayer.getDuration();
        if (this.currentAd.durationSec > 0) {
            this.adTotalMs = (int) Math.min((this.currentAd.skipAfterSec > 0 ? ((long) this.currentAd.skipAfterSec) * 1000 : 0L) + (((long) this.currentAd.durationSec) * 1000), duration);
        } else {
            this.adTotalMs = duration;
        }
        this.adVideo.start();
        revealAdAndStartTimer();
    }

    /* JADX INFO: renamed from: lambda$showVideoAd$12$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ void m757lambda$showVideoAd$12$comzenoappSplashActivity(MediaPlayer mediaPlayer) {
        finishAd();
    }

    /* JADX INFO: renamed from: lambda$showVideoAd$13$com-zeno-app-SplashActivity, reason: not valid java name */
    /* synthetic */ boolean m758lambda$showVideoAd$13$comzenoappSplashActivity(MediaPlayer mediaPlayer, int i, int i2) {
        finishAd();
        return true;
    }

    private void revealAdAndStartTimer() {
        if (this.adFinished) {
            return;
        }
        stopProgressUI();
        this.adLayer.setVisibility(0);
        updateSkipText();
        this.uiHandler.removeCallbacks(this.adTicker);
        this.uiHandler.postDelayed(this.adTicker, 250L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onAdTick() {
        if (this.adFinished || !this.adShowing) {
            return;
        }
        AdData adData = this.currentAd;
        if (adData != null && adData.video) {
            try {
                this.adElapsedMs = this.adVideo.getCurrentPosition();
            } catch (Exception unused) {
            }
        } else {
            this.adElapsedMs += 250;
        }
        int i = this.adTotalMs;
        if (i > 0 && this.adElapsedMs >= i) {
            finishAd();
        } else {
            updateSkipText();
            this.uiHandler.postDelayed(this.adTicker, 250L);
        }
    }

    private void updateSkipText() {
        int iMax = (int) Math.max(1L, (Math.max(0L, ((long) this.adTotalMs) - this.adElapsedMs) + 999) / 1000);
        this.tvAdSkip.setText("ကျော်မည် " + iMax);
        AdData adData = this.currentAd;
        this.tvAdSkip.setVisibility(adData == null || adData.skipAfterSec <= 0 || (this.adElapsedMs > (((long) this.currentAd.skipAfterSec) * 1000) ? 1 : (this.adElapsedMs == (((long) this.currentAd.skipAfterSec) * 1000) ? 0 : -1)) >= 0 ? 0 : 4);
    }

    private void openAdLink() {
        AdData adData = this.currentAd;
        if (adData == null || adData.link == null || this.currentAd.link.isEmpty()) {
            return;
        }
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.currentAd.link)));
        } catch (Exception unused) {
        }
    }

    private void finishAd() {
        if (this.adFinished) {
            return;
        }
        this.adFinished = true;
        this.uiHandler.removeCallbacks(this.adTicker);
        try {
            VideoView videoView = this.adVideo;
            if (videoView != null) {
                videoView.stopPlayback();
            }
        } catch (Exception unused) {
        }
        if (this.instantAdShown && !this.cfgResolved && isConnected()) {
            return;
        }
        navigate(this.pendingCfg);
    }

    private boolean isTampered() {
        try {
            String packageName = getPackageName();
            String string = getApplicationInfo().loadLabel(getPackageManager()).toString();
            if (BuildConfig.APPLICATION_ID.equals(packageName)) {
                if ("ZenoMyID".equals(string)) {
                    return false;
                }
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean checkAppIntegrity(String str, String str2) {
        if (!isTampered()) {
            return false;
        }
        this.navigated = true;
        ZDialog.showChangeApk(this, str, str2);
        return true;
    }

    private String getAppVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception unused) {
            return "";
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showNoInternetSnackbar() {
        View viewFindViewById;
        if (isFinishing() || isDestroyed()) {
            return;
        }
        Snackbar snackbar = this.noInternetSnackbar;
        if ((snackbar == null || !snackbar.isShown()) && (viewFindViewById = findViewById(android.R.id.content)) != null) {
            Snackbar snackbarMake = Snackbar.make(viewFindViewById, "အင်တာနက်ချိပ်ဆက်ထားခြင်းမရှိပါ", -2);
            this.noInternetSnackbar = snackbarMake;
            View view = snackbarMake.getView();
            ((ViewGroup.MarginLayoutParams) view.getLayoutParams()).setMargins(0, 0, 0, 0);
            view.setLayoutParams(view.getLayoutParams());
            this.noInternetSnackbar.show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissNoInternetSnackbar() {
        Snackbar snackbar = this.noInternetSnackbar;
        if (snackbar == null || !snackbar.isShown()) {
            return;
        }
        this.noInternetSnackbar.dismiss();
        this.noInternetSnackbar = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void navigate(RemoteConfig remoteConfig) {
        Intent intent;
        if (this.navigated || isFinishing() || isDestroyed()) {
            return;
        }
        this.navigated = true;
        SessionManager sessionManager = new SessionManager(this);
        if (sessionManager.isLoggedIn()) {
            intent = new Intent((Context) this, (Class<?>) DashboardActivity.class);
        } else {
            intent = new Intent((Context) this, (Class<?>) LoginActivity.class);
        }
        if (remoteConfig != null && sessionManager.isLoggedIn()) {
            intent.putExtra("cfg_app_version", getAppVersion());
            intent.putExtra("cfg_version", remoteConfig.version != null ? remoteConfig.version : "");
            intent.putExtra("cfg_update_link", remoteConfig.updateLink != null ? remoteConfig.updateLink : "");
            intent.putExtra("cfg_update_title", remoteConfig.updateTitle != null ? remoteConfig.updateTitle : "");
            intent.putExtra("cfg_update_message", remoteConfig.updateMessage != null ? remoteConfig.updateMessage : "");
            intent.putExtra("cfg_notif_title", remoteConfig.notificationTitle != null ? remoteConfig.notificationTitle : "");
            intent.putExtra("cfg_notif_text", remoteConfig.notificationText != null ? remoteConfig.notificationText : "");
            intent.putExtra("cfg_notif_link", remoteConfig.notificationLink != null ? remoteConfig.notificationLink : "");
            intent.putExtra("cfg_notif_btn", remoteConfig.notificationBtnText != null ? remoteConfig.notificationBtnText : "Open");
            intent.putExtra("cfg_notif_image", remoteConfig.notificationImage != null ? remoteConfig.notificationImage : "");
            intent.putExtra("cfg_show_kongisland", remoteConfig.showKongIsland);
            intent.putExtra("cfg_show_kittyfall", remoteConfig.showKittyFall);
            intent.putExtra("cfg_show_softclimber", remoteConfig.showSoftClimber);
            intent.putExtra("cfg_show_myidgo", remoteConfig.showMyIDGo);
            intent.putExtra("cfg_show_beatzoo", remoteConfig.showBeatZoo);
            intent.putExtra("cfg_show_carracing", remoteConfig.showCarRacing);
            intent.putExtra("cfg_show_fightingfish", remoteConfig.showFightingFish);
        }
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    protected void onDestroy() {
        ConnectivityManager.NetworkCallback networkCallback;
        super.onDestroy();
        ConnectivityManager connectivityManager = this.connectivityManager;
        if (connectivityManager != null && (networkCallback = this.networkCallback) != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
        stopProgressUI();
        this.uiHandler.removeCallbacksAndMessages(null);
        try {
            VideoView videoView = this.adVideo;
            if (videoView != null) {
                videoView.stopPlayback();
            }
        } catch (Exception unused) {
        }
        this.adExec.shutdown();
    }
}
