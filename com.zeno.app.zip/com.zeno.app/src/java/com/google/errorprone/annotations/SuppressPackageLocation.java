package com.google.errorprone.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/* JADX INFO: loaded from: /storage/emulated/0/Documents/jadec/sources/com.zeno.app/dex-files/0.dex */
@Target({ElementType.PACKAGE})
@Retention(RetentionPolicy.CLASS)
public @interface SuppressPackageLocation {
}
